"""Feature view module for Snowflake ML Feature Store."""
from __future__ import annotations

import json
import re
import warnings
from collections import OrderedDict
from dataclasses import asdict, dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional, Union

from snowflake.ml._internal.exceptions import (
    error_codes,
    exceptions as snowml_exceptions,
)
from snowflake.ml._internal.utils import identifier
from snowflake.ml._internal.utils.identifier import concat_names
from snowflake.ml._internal.utils.sql_identifier import (
    SqlIdentifier,
    to_sql_identifiers,
)
from snowflake.ml.feature_store.aggregation import AggregationSpec, AggregationType
from snowflake.ml.feature_store.entity import Entity
from snowflake.ml.feature_store.feature import Feature
from snowflake.ml.feature_store.spec.enums import FeatureAggregationMethod
from snowflake.ml.feature_store.tile_sql_generator import _TILE_START_COL
from snowflake.ml.lineage import lineage_node
from snowflake.snowpark import DataFrame, Session
from snowflake.snowpark._internal import utils as snowpark_utils
from snowflake.snowpark.exceptions import SnowparkSQLException
from snowflake.snowpark.types import (
    DateType,
    StructType,
    TimestampType,
    TimeType,
    _NumericType,
)

if TYPE_CHECKING:
    from snowflake.ml.feature_store.stream_config import StreamConfig

_BATCH_OFT_TARGET_LAG = "10 seconds"  # default lag for batch FV OFTs when OnlineConfig.target_lag is unset.
_NON_BATCH_OFT_TARGET_LAG = "0 seconds"  # default lag for non-batch OFTs (SFV, FG, and RTFV).
_DEFAULT_CONTINUOUS_FEATURE_GRANULARITY = "1m"
_MIN_FEATURE_GRANULARITY_SECONDS = 60
_FEATURE_VIEW_NAME_DELIMITER = "$"
_LEGACY_TIMESTAMP_COL_PLACEHOLDER_VALS = ["FS_TIMESTAMP_COL_PLACEHOLDER_VAL", "NULL"]
_TIMESTAMP_COL_PLACEHOLDER = "NULL"
_FEATURE_OBJ_TYPE = "FEATURE_OBJ_TYPE"
_ONLINE_TABLE_SUFFIX = "$ONLINE"
_UDF_TRANSFORMED_TABLE_SUFFIX = "$UDF_TRANSFORMED"
# Feature view version rule is aligned with dataset version rule in SQL.
_FEATURE_VIEW_VERSION_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.\-]*$")
_FEATURE_VIEW_VERSION_MAX_LENGTH = 128

_RESULT_SCAN_QUERY_PATTERN = re.compile(
    r".*FROM\s*TABLE\s*\(\s*RESULT_SCAN\s*\(.*",
    flags=re.DOTALL | re.IGNORECASE | re.X,
)


class OnlineStoreType(Enum):
    """Types of online storage backends.

    This is the **user-facing** enum controlling which backend stores
    the online feature table.  It is distinct from
    ``spec.enums.StoreType`` which is a spec-internal enum used inside
    the JSON payload sent to the Go backend.

    Attributes:
        HYBRID_TABLE: Snowflake Hybrid Table online store backend.
        POSTGRES: Postgres online store backend.
    """

    HYBRID_TABLE = "hybrid_table"
    POSTGRES = "postgres"


class _FeatureViewSchemaNotReadyWarning(UserWarning):
    """Issued when feature view schema is unavailable because the backing
    dynamic table has not completed its initial refresh yet."""

    pass


@dataclass(frozen=True)
class OnlineConfig:
    """Configuration for online feature storage.

    Example::

        >>> config = OnlineConfig(
        ...     enable=True,
        ...     target_lag="30s",
        ...     store_type=OnlineStoreType.POSTGRES,
        ... )
    """

    enable: Optional[bool] = None
    target_lag: Optional[str] = None
    store_type: OnlineStoreType = OnlineStoreType.HYBRID_TABLE

    def __post_init__(self) -> None:
        if self.target_lag is None:
            return
        if not isinstance(self.target_lag, str) or not self.target_lag.strip():
            raise ValueError("target_lag must be a non-empty string")

        object.__setattr__(self, "target_lag", self.target_lag.strip())

    def to_json(self) -> str:
        data: dict[str, Any] = asdict(self)
        # asdict() does not unwrap Enum members; convert to plain value.
        if isinstance(data.get("store_type"), OnlineStoreType):
            data["store_type"] = data["store_type"].value
        return json.dumps(data)

    @classmethod
    def from_json(cls, json_str: str) -> OnlineConfig:
        data = json.loads(json_str)
        # Backward compatibility: old configs don't have store_type
        if "store_type" not in data:
            data["store_type"] = OnlineStoreType.HYBRID_TABLE
        elif isinstance(data["store_type"], str):
            data["store_type"] = OnlineStoreType(data["store_type"])
        return cls(**data)


@dataclass
class RollupConfig:
    """Configuration for rolling up a tiled FeatureView to a coarser entity level.

    This enables creating subscriber-level features from visitor-level tiles,
    or any similar hierarchical entity rollup. The rollup uses the same aggregation
    logic as tile merging - mathematically identical operations applied across
    entities instead of time.

    Example::

        >>> visitor_fv = fs.get_feature_view("visitor_events", "v1")
        >>> subscriber_fv = FeatureView(
        ...     name="subscriber_events",
        ...     entities=[subscriber_entity],
        ...     rollup_config=RollupConfig(
        ...         source=visitor_fv,
        ...         mapping_df=session.table("VISITOR_SUBSCRIBER_MAPPING"),
        ...     ),
        ... )

    For point-in-time correct entity mappings with SCD Type 2 validity windows
    (e.g., when visitors get reassigned between subscribers over time), provide
    ``mapping_valid_from_col`` and ``mapping_valid_to_col`` (both are required together)::

        >>> subscriber_fv = FeatureView(
        ...     name="subscriber_events_temporal",
        ...     entities=[subscriber_entity],
        ...     rollup_config=RollupConfig(
        ...         source=visitor_fv,
        ...         mapping_df=session.table("VISITOR_SUBSCRIBER_MAPPING"),
        ...         mapping_valid_from_col="VALID_FROM",
        ...         mapping_valid_to_col="VALID_TO",
        ...     ),
        ... )

    Args:
        source: The parent tiled FeatureView to roll up from. Must be registered and tiled.
        mapping_df: DataFrame containing the entity mapping (e.g., visitor_id → subscriber_id).
            Must contain all join keys from source entity and target entity.
            Expected to be a many-to-one mapping (many source keys → one target key).
        mapping_valid_from_col: Optional timestamp column in mapping_df that indicates when
            each mapping became effective (SCD Type 2 lower bound). When provided, training via
            ``generate_training_set`` uses a range JOIN for point-in-time correct entity resolution.
            Inference via ``retrieve_feature_values`` always uses the latest mapping from the
            materialized Dynamic Table. If None, the latest mapping state is used everywhere
            (current behavior).

            **Important:** The column should use the same timestamp type (TIMESTAMP_NTZ or
            TIMESTAMP_LTZ) as the source FeatureView's ``timestamp_col`` to avoid implicit
            timezone conversion in the range JOIN comparison.

            **Tiles before the earliest effective date:** Any tiles with ``TILE_START`` earlier
            than the first ``mapping_valid_from_col`` value for an entity will have no valid
            mapping match and will be excluded from training results. To avoid this, ensure the
            mapping table has entries covering the full history of your event data.

            Must be provided together with ``mapping_valid_to_col``.
        mapping_valid_to_col: Optional timestamp column in mapping_df that indicates when
            each mapping expired (SCD Type 2 upper bound). Uses half-open interval semantics:
            a mapping is active for ``[valid_from, valid_to)``. Rows where this column is NULL
            are treated as still-active mappings.

            Must be provided together with ``mapping_valid_from_col``.

            When both temporal columns are provided, a range JOIN is used instead of a
            plain JOIN, which supports 1:N mappings (one child entity mapped to multiple
            parent entities simultaneously with overlapping validity windows). The inference
            DT filters to currently-active mappings only.
    """

    source: FeatureView
    mapping_df: DataFrame
    mapping_valid_from_col: Optional[str] = None
    mapping_valid_to_col: Optional[str] = None

    def validate(self, target_entity_keys: list[str]) -> None:
        """Validate the rollup configuration.

        Args:
            target_entity_keys: Join keys of the target (new) entity.

        Raises:
            ValueError: If validation fails.
        """
        # Source must be tiled
        if not self.source.is_tiled:
            raise ValueError("RollupConfig source must be a tiled FeatureView")

        # Source must be registered
        if self.source.status == FeatureViewStatus.DRAFT:
            raise ValueError("RollupConfig source must be registered")

        # Get column names from mapping as resolved SqlIdentifier strings for case-correct comparison
        mapping_col_ids = {SqlIdentifier(f.name).resolved() for f in self.mapping_df.schema.fields}

        # Source entity keys must exist in mapping (Entity.join_keys are already SqlIdentifiers)
        for source_key in (k for e in self.source.entities for k in e.join_keys):
            if source_key.resolved() not in mapping_col_ids:
                raise ValueError(f"Mapping must contain source join key '{source_key}'")

        # Target entity keys must exist in mapping
        for target_key in target_entity_keys:
            if SqlIdentifier(target_key).resolved() not in mapping_col_ids:
                raise ValueError(f"Mapping must contain target join key '{target_key}'")

        # Temporal columns must be provided together or both omitted
        if self.mapping_valid_from_col is None and self.mapping_valid_to_col is None:
            pass  # both omitted — no temporal validation needed
        elif self.mapping_valid_from_col is not None and self.mapping_valid_to_col is not None:
            if SqlIdentifier(self.mapping_valid_from_col).resolved() not in mapping_col_ids:
                raise ValueError(f"Mapping must contain mapping_valid_from_col '{self.mapping_valid_from_col}'")
            if SqlIdentifier(self.mapping_valid_to_col).resolved() not in mapping_col_ids:
                raise ValueError(f"Mapping must contain mapping_valid_to_col '{self.mapping_valid_to_col}'")
        else:
            raise ValueError(
                "mapping_valid_from_col and mapping_valid_to_col must both be provided "
                "or both be omitted. Providing only one is not supported."
            )


@dataclass
class RollupMetadata:
    """Serializable metadata for a rollup feature view.

    Persisted to the metadata table during registration and loaded back during
    ``get_feature_view`` reconstruction. Contains everything needed to generate
    PIT-correct range JOIN SQL at training time without requiring the original
    ``RollupConfig`` (which holds live FeatureView and DataFrame objects).
    """

    parent_tile_table: str
    parent_join_keys: list[str]
    mapping_query: str
    mapping_valid_from_col: Optional[str] = None
    mapping_valid_to_col: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "parent_tile_table": self.parent_tile_table,
            "parent_join_keys": self.parent_join_keys,
            "mapping_query": self.mapping_query,
            "mapping_valid_from_col": self.mapping_valid_from_col,
            "mapping_valid_to_col": self.mapping_valid_to_col,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RollupMetadata:
        return cls(
            parent_tile_table=data["parent_tile_table"],
            parent_join_keys=data["parent_join_keys"],
            mapping_query=data["mapping_query"],
            mapping_valid_from_col=data.get("mapping_valid_from_col"),
            mapping_valid_to_col=data.get("mapping_valid_to_col"),
        )


class StoreType(Enum):
    """
    Enumeration for specifying the storage type when reading from or refreshing feature views.

    The Feature View supports two storage modes:
    - OFFLINE: Traditional batch storage for historical feature data and training
    - ONLINE: Low-latency storage optimized for real-time feature serving
    """

    ONLINE = "online"
    OFFLINE = "offline"


class StorageFormat(Enum):
    """Storage format for managed Feature Views."""

    SNOWFLAKE = "snowflake"  # Native Snowflake storage (Dynamic Table)
    ICEBERG = "iceberg"  # Apache Iceberg format (Dynamic Iceberg Table)


@dataclass(frozen=True)
class StorageConfig:
    """
    Configuration for Feature View storage format.

    Args:
        format: Storage format. Defaults to SNOWFLAKE.
        external_volume: External volume for Iceberg storage. Required when
            format=ICEBERG unless a default is set on the FeatureStore.
        base_location: Path within external volume. Auto-generated if not provided.
    """

    format: StorageFormat = StorageFormat.SNOWFLAKE
    external_volume: Optional[str] = None
    base_location: Optional[str] = None

    def to_json(self) -> str:
        """Serialize StorageConfig to JSON string."""

        def dict_factory(items: list[tuple[str, Any]]) -> dict[str, Any]:
            return {k: (v.value if isinstance(v, Enum) else v) for k, v in items if v is not None}

        return json.dumps(asdict(self, dict_factory=dict_factory))

    @classmethod
    def from_json(cls, json_str: str) -> StorageConfig:
        """Deserialize StorageConfig from JSON string."""
        data = json.loads(json_str)
        format_value = data.get("format", "snowflake")
        return cls(
            format=StorageFormat(format_value),
            external_volume=data.get("external_volume"),
            base_location=data.get("base_location"),
        )


@dataclass(frozen=True)
class _FeatureViewMetadata:
    """Represent metadata tracked on top of FV backend object"""

    entities: list[str]
    timestamp_col: str
    is_tiled: bool = False  # Whether FV uses tile-based aggregations
    is_iceberg: bool = False  # Whether FV uses Iceberg storage format
    is_rollup: bool = False  # Whether FV is a rollup (entity aggregation) feature view
    is_streaming: bool = False  # Whether FV is a streaming feature view

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, json_str: str) -> _FeatureViewMetadata:
        state_dict = json.loads(json_str)
        # Backward compatibility: old FVs don't have is_tiled
        if "is_tiled" not in state_dict:
            state_dict["is_tiled"] = False
        # Backward compatibility: old FVs don't have is_iceberg
        if "is_iceberg" not in state_dict:
            state_dict["is_iceberg"] = False
        # Backward compatibility: old FVs don't have is_rollup
        if "is_rollup" not in state_dict:
            state_dict["is_rollup"] = False
        # Backward compatibility: old FVs don't have is_streaming
        if "is_streaming" not in state_dict:
            state_dict["is_streaming"] = False
        return cls(**state_dict)


@dataclass(frozen=True)
class _CompactRepresentation:
    """
    A compact representation for FeatureView and FeatureViewSlice, which contains fully qualified name
    and optionally a list of feature indices (None means all features will be included).
    This is to make the metadata much smaller when generating dataset.
    """

    db: str
    sch: str
    name: str
    version: str
    feature_indices: Optional[list[int]] = None

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, json_str: str) -> _CompactRepresentation:
        state_dict = json.loads(json_str)
        return cls(**state_dict)


class FeatureViewVersion(str):
    def __new__(cls, version: str) -> FeatureViewVersion:
        if not _FEATURE_VIEW_VERSION_RE.match(version) or len(version) > _FEATURE_VIEW_VERSION_MAX_LENGTH:
            raise ValueError(
                f"`{version}` is not a valid feature view version. "
                "It must start with letter or digit, and followed by letter, digit, '_', '-' or '.'. "
                f"The length limit is {_FEATURE_VIEW_VERSION_MAX_LENGTH}."
            )
        return super().__new__(cls, version)

    def __init__(self, version: str) -> None:
        super().__init__()


class FeatureViewStatus(Enum):
    # for shared feature views where scheduling state is not available
    MASKED = "MASKED"
    # A FeatureView that exists only locally and hasn't been registered/materialized to Snowflake yet.
    # This is the initial state when you create a new FeatureView object.
    DRAFT = "DRAFT"
    # The FeatureView is registered but has no scheduled refreshes.
    STATIC = "STATIC"
    # This can be deprecated after BCR 2024_02 gets fully deployed
    RUNNING = "RUNNING"
    # The FeatureView is registered but its scheduled refreshes are paused/suspended.
    SUSPENDED = "SUSPENDED"
    # The FeatureView is registered in Snowflake and actively running (e.g., scheduled refreshes are enabled).
    ACTIVE = "ACTIVE"


@dataclass(frozen=True)
class FeatureViewSlice:
    feature_view_ref: FeatureView
    names: list[SqlIdentifier]

    def __repr__(self) -> str:
        states = (f"{k}={v}" for k, v in vars(self).items())
        return f"{type(self).__name__}({', '.join(states)})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, FeatureViewSlice):
            return False

        return self.names == other.names and self.feature_view_ref == other.feature_view_ref

    def to_json(self) -> str:
        fvs_dict = {
            "feature_view_ref": self.feature_view_ref.to_json(),
            "names": self.names,
            _FEATURE_OBJ_TYPE: self.__class__.__name__,
        }
        return json.dumps(fvs_dict)

    @classmethod
    def from_json(cls, json_str: str, session: Session) -> FeatureViewSlice:
        json_dict = json.loads(json_str)
        if _FEATURE_OBJ_TYPE not in json_dict or json_dict[_FEATURE_OBJ_TYPE] != cls.__name__:
            raise ValueError(f"Invalid json str for {cls.__name__}: {json_str}")
        del json_dict[_FEATURE_OBJ_TYPE]
        json_dict["feature_view_ref"] = FeatureView.from_json(json_dict["feature_view_ref"], session)
        return cls(**json_dict)

    def with_name(self, name: str) -> FeatureViewSlice:
        """
        Use this Feature View Slice with a namespace for dataset generation.

        Returns a copy of this Feature View Slice with a custom namespace that will
        be used to prefix all feature columns during dataset generation. This
        is useful for avoiding column name collisions or using the same Feature
        View multiple times with different contexts.

        The name is NOT persisted to the Feature Store and only affects column
        naming in retrieve_feature_values(), generate_dataset(), and
        generate_training_set().

        Args:
            name: Namespace for feature columns. Will be formatted as '{name}_'
                before each column name.

        Returns:
            A new FeatureViewSlice instance with the namespace attached to the
            underlying FeatureView.

        Note:
            Similar to Tecton's with_name() method. This setting takes
            precedence over the auto_prefix parameter.
        """
        return FeatureViewSlice(
            feature_view_ref=self.feature_view_ref.with_name(name),
            names=self.names,
        )

    @property
    def column_alias(self) -> Optional[str]:
        """Returns the column namespace if set via with_name(), else None."""
        return self.feature_view_ref.column_alias

    def _get_compact_repr(self) -> _CompactRepresentation:
        return _CompactRepresentation(
            db=self.feature_view_ref.database.identifier(),  # type: ignore[union-attr]
            sch=self.feature_view_ref.schema.identifier(),  # type: ignore[union-attr]
            name=self.feature_view_ref.name.identifier(),
            version=self.feature_view_ref.version,  # type: ignore[arg-type]
            feature_indices=self._feature_names_to_indices(),
        )

    def _feature_names_to_indices(self) -> list[int]:
        name_to_indices_map = {name: idx for idx, name in enumerate(self.feature_view_ref.feature_names)}
        return [name_to_indices_map[n] for n in self.names]


def _prepend_keys_specs(
    value_specs: list[AggregationSpec], secondary_keys: Optional[list[str]]
) -> list[AggregationSpec]:
    """Synthesize one ``_SECONDARY_KEY_ARRAY`` spec per unique
    ``(secondary_key, window, offset)`` and prepend the synthesized specs as a
    single leading block before all value specs, so every output column still
    flows through the same ``Feature -> to_spec()`` pipeline (and naming
    convention) without being interleaved among the user's value features.

    Group ordering follows the first appearance of each ``(window, offset)``
    in ``value_specs``; within a group, keys columns are emitted in
    ``secondary_keys`` list order.

    Args:
        value_specs: User-defined value-aggregation specs in surface order.
        secondary_keys: FV-level secondary keys; when ``None`` or empty the input
            is returned unchanged.

    Returns:
        A new list containing all synthesized keys-specs (one per
        ``(secondary_key, window, offset)``) followed by ``value_specs`` in their
        original relative order.
    """
    if not secondary_keys:
        return value_specs
    seen_groups: set[tuple[str, str]] = set()
    keys_specs: list[AggregationSpec] = []
    for spec in value_specs:
        if spec.is_lifetime():
            continue
        group_key = (spec.window, spec.offset)
        if group_key in seen_groups:
            continue
        seen_groups.add(group_key)
        for sk in secondary_keys:
            keys_specs.append(
                Feature(
                    AggregationType._SECONDARY_KEY_ARRAY,
                    sk,
                    spec.window,
                    offset=spec.offset,
                ).to_spec()
            )
    return keys_specs + value_specs


def _resolve_tiled_config(
    *,
    features: Optional[list[Feature]],
    feature_granularity: Optional[str],
    feature_aggregation_method: Optional[FeatureAggregationMethod],
    aggregation_secondary_keys: Optional[list[str]],
) -> tuple[Optional[str], Optional[list[AggregationSpec]], Optional[FeatureAggregationMethod]]:
    """Resolve tiled-aggregation inputs into ``(granularity, specs, method)``.

    Rules:
        - ``features`` set + ``TILES`` (or no method) → ``feature_granularity`` required.
        - ``features`` set + ``CONTINUOUS`` → ``feature_granularity`` defaults to ``"1m"``.
        - ``feature_granularity`` or ``feature_aggregation_method`` set without
          ``features`` → invalid.
        - none of the three set → returns ``(None, None, None)`` (non-tiled FV).

    Args:
        features: User-supplied aggregation features.
        feature_granularity: Tile interval (e.g. ``"1h"``).
        feature_aggregation_method: ``TILES`` or ``CONTINUOUS``; ``None`` is treated as ``TILES``.
        aggregation_secondary_keys: FV-level secondary keys threaded into the synthesized specs.

    Returns:
        Tuple of ``(resolved_granularity, aggregation_specs, resolved_method)``.

    Raises:
        ValueError: If the inputs do not satisfy the rules above.
    """
    if not features:
        if feature_granularity is not None or feature_aggregation_method is not None:
            raise ValueError("feature_granularity and feature_aggregation_method require features to be set.")
        return None, None, None
    if feature_granularity is None:
        if feature_aggregation_method == FeatureAggregationMethod.CONTINUOUS:
            feature_granularity = _DEFAULT_CONTINUOUS_FEATURE_GRANULARITY
        else:
            raise ValueError("features requires feature_granularity to be specified.")
    specs = _prepend_keys_specs([f.to_spec() for f in features], aggregation_secondary_keys)
    return feature_granularity, specs, feature_aggregation_method or FeatureAggregationMethod.TILES


class FeatureView(lineage_node.LineageNode):
    """
    A FeatureView instance encapsulates a logical group of features.
    """

    def __init__(
        self,
        name: str,
        entities: list[Entity],
        feature_df: Optional[DataFrame] = None,
        *,
        timestamp_col: Optional[str] = None,
        refresh_freq: Optional[str] = None,
        desc: str = "",
        warehouse: Optional[str] = None,
        initialize: str = "ON_CREATE",
        refresh_mode: str = "AUTO",
        cluster_by: Optional[list[str]] = None,
        online_config: Optional[OnlineConfig] = None,
        feature_granularity: Optional[str] = None,
        features: Optional[list[Feature]] = None,
        aggregation_secondary_keys: Optional[list[str]] = None,
        feature_aggregation_method: Optional[FeatureAggregationMethod] = None,
        rollup_config: Optional[RollupConfig] = None,
        storage_config: Optional[StorageConfig] = None,
        stream_config: Optional[StreamConfig] = None,
        **_kwargs: Any,
    ) -> None:
        """
        Create a FeatureView instance.

        # noqa: DAR101

        Args:
            name: The name of the FeatureView. This must follow Snowflake identifier rules.
            entities: The entities that the FeatureView is associated with.
            feature_df: The Snowpark DataFrame containing data source and all feature feature_df logic.
                The final projection of the DataFrame should contain feature names, join keys and timestamp if
                applicable.
            timestamp_col: name of the timestamp column for point-in-time lookup when consuming the
                feature values.
            refresh_freq: Time unit defining how often the new feature data should be generated, in the format
                ``{ <num> { seconds | minutes | hours | days } | DOWNSTREAM | <cron expr> <time zone>}``.

                The minimum refresh frequency is 1 minute.

                When using a ``cron`` format, you must provide a time zone.

                When you don't provide a refresh value, the ``FeatureView`` is registered as a ``View`` on the Snowflake
                backend. There are no extra storage costs incurred for this view.
            desc: Description of the FeatureView.
            warehouse: The warehouse used to refresh this feature view. Not needed when ``refresh_freq`` is ``None``.
                This warehouse will overwrite the default warehouse of Feature Store if specified, otherwise the default
                warehouse will be used.
            initialize: Specifies the behavior of the initial refresh of feature view. This property cannot be altered
                after you register the feature view. It supports ON_CREATE (default) or ON_SCHEDULE. ON_CREATE refreshes
                the feature view synchronously at creation. ON_SCHEDULE refreshes the feature view at the next scheduled
                refresh. It is only effective when refresh_freq is not None.
            refresh_mode: The refresh mode of managed feature view. The value can be 'AUTO', 'FULL' or 'INCREMENTAL'.
                For managed feature view, the default value is 'AUTO'. For static feature view it has no effect. For
                more information, see
                `CREATE DYNAMIC TABLE <https://docs.snowflake.com/en/sql-reference/sql/create-dynamic-table>`__.
            cluster_by: Columns to cluster the feature view by. If ``timestamp_col`` is provided, it is added to the
                default clustering keys. Default is to use the join keys from entities in the view.
            online_config: Configuration for online storage. If provided with ``enable=True``,
                online storage will be enabled. Defaults to ``None`` (no online storage).

                .. note::
                    This feature is currently in preview.
            feature_granularity: The tile interval for time-series aggregations (e.g., "1h", "1d").
                When specified along with ``features``, enables tile-based aggregation where a
                Dynamic Table stores pre-computed partial aggregations (tiles), and dataset
                generation merges these tiles for point-in-time correct results.
            features: List of aggregation feature definitions using the ``Feature`` class.
                Required when ``feature_granularity`` is specified. Defines the aggregations
                to compute (e.g., SUM, COUNT, LAST_N) with their windows.
            aggregation_secondary_keys: Optional FV-level secondary aggregation keys
                (column names from ``feature_df``). Currently restricted to a list of
                exactly one element. When set, every supported aggregation in ``features``
                is additionally grouped by these keys, and at query time the output includes
                a shared per-window keys array alongside array-valued feature columns.
                Supported functions: SUM, COUNT, AVG, MIN, MAX, STD, VAR, APPROX_COUNT_DISTINCT,
                APPROX_PERCENTILE. Each secondary key may not be an entity join key, must exist in
                ``feature_df``, and is not supported with lifetime windows or list aggregations.

                .. note::
                    This feature is currently in private preview.
            feature_aggregation_method: The aggregation method for tiled streaming feature views.
                Supports ``FeatureAggregationMethod.TILES`` (default) or
                ``FeatureAggregationMethod.CONTINUOUS``.  Only applicable to streaming feature
                views with ``features`` set.  When ``FeatureAggregationMethod.CONTINUOUS`` is
                used and ``feature_granularity`` is omitted, it defaults to ``"1m"``; an
                explicit ``feature_granularity`` always takes precedence.  Raises ``ValueError``
                if specified on batch or rollup feature views.
            rollup_config: Configuration for rolling up a tiled FeatureView to a coarser entity
                level. When specified, this FeatureView will aggregate features from the source
                FeatureView using the provided entity mapping. Cannot be used together with
                ``feature_df``. See ``RollupConfig`` for details.
            storage_config: Configuration for storage format using ``StorageConfig``.
                Supports Snowflake native format (default) or Iceberg format.
                When using Iceberg, specify ``external_volume`` and optionally ``base_location``.
            stream_config: Configuration for streaming feature views using ``StreamConfig``.
                When provided, ``feature_df`` serves as backfill data, and an online feature table
                with a streaming spec is automatically created.  Requires ``timestamp_col`` and
                ``feature_df``.  Online storage is always enabled with the ``POSTGRES`` store type.

                .. note::
                    This feature is currently in private preview.
            _kwargs: Reserved kwargs for system generated args.

                .. caution::
                    Use of additional keywords is prohibited.

        Example::

            >>> fs = FeatureStore(...)
            >>> # draft_fv is a local object that hasn't materialized to Snowflake backend yet.
            >>> feature_df = session.sql("select f_1, f_2 from source_table")
            >>> draft_fv = FeatureView(
            ...     name="my_fv",
            ...     entities=[e1, e2],
            ...     feature_df=feature_df,
            ...     timestamp_col='TS', # optional
            ...     refresh_freq='1d',  # optional
            ...     desc='A line about this feature view',  # optional
            ...     warehouse='WH'      # optional, the warehouse used to refresh (managed) feature view
            ... )
            >>> print(draft_fv.status)
            FeatureViewStatus.DRAFT
            <BLANKLINE>
            >>> # registered_fv is a local object that maps to a Snowflake backend object.
            >>> registered_fv = fs.register_feature_view(draft_fv, "v1")
            >>> print(registered_fv.status)
            FeatureViewStatus.ACTIVE
            <BLANKLINE>
            >>> # Example with online configuration for online feature storage
            >>> config = OnlineConfig(enable=True, target_lag='15s')
            >>> online_fv = FeatureView(
            ...     name="my_online_fv",
            ...     entities=[e1, e2],
            ...     feature_df=feature_df,
            ...     timestamp_col='TS',
            ...     refresh_freq='1d',
            ...     desc='Feature view with online storage',
            ...     online_config=config  # optional, enables online feature storage
            ... )
            >>> registered_online_fv = fs.register_feature_view(online_fv, "v1")
            >>> print(registered_online_fv.online)
            True
            <BLANKLINE>
            >>> # Example with Iceberg storage configuration
            >>> storage = StorageConfig(
            ...     format=StorageFormat.ICEBERG,
            ...     external_volume='MY_EXTERNAL_VOLUME',
            ...     base_location='feature_store/my_fv'  # optional
            ... )
            >>> iceberg_fv = FeatureView(
            ...     name="my_iceberg_fv",
            ...     entities=[e1, e2],
            ...     feature_df=feature_df,
            ...     refresh_freq='1d',
            ...     storage_config=storage  # optional, configures Iceberg storage
            ... )

        # noqa: DAR401
        """
        # Validate mutual exclusion rules
        if rollup_config is not None and feature_df is not None:
            raise ValueError("Cannot specify both feature_df and rollup_config")
        if stream_config is not None and feature_df is not None:
            raise ValueError(
                "Cannot specify both feature_df and stream_config. " "Use stream_config.backfill_df for backfill data."
            )
        if rollup_config is None and feature_df is None and stream_config is None:
            raise ValueError("Must specify either feature_df, rollup_config, or stream_config")
        if rollup_config is not None:
            if feature_granularity is not None:
                raise ValueError(
                    "Cannot specify feature_granularity with rollup_config. "
                    "Rollup feature views inherit feature_granularity from the source feature view."
                )
            if features is not None:
                raise ValueError(
                    "Cannot specify features with rollup_config. "
                    "Rollup feature views inherit features from the source feature view."
                )

        self._name: SqlIdentifier = SqlIdentifier(name)
        self._entities: list[Entity] = entities
        self._rollup_config: Optional[RollupConfig] = rollup_config

        # Declare types before branching so mypy can track them
        self._feature_df: Optional[DataFrame] = None
        self._timestamp_col: Optional[SqlIdentifier] = None
        self._feature_granularity: Optional[str] = None
        self._aggregation_specs: Optional[list[AggregationSpec]] = None
        # Currently restricted to a single element; multi-key support is
        # reserved for a future change. The shape is plural-list now so the
        # API is forward-compatible.
        if aggregation_secondary_keys is not None:
            snowpark_utils.warning(
                "FeatureView.aggregation_secondary_keys",
                "Parameter aggregation_secondary_keys is in private preview since 1.38.0. "
                "Do not use it in production.",
            )
            if len(aggregation_secondary_keys) > 1:
                raise ValueError(
                    f"aggregation_secondary_keys currently supports a single element; "
                    f"got {len(aggregation_secondary_keys)}: {aggregation_secondary_keys}"
                )
        self._aggregation_secondary_keys: Optional[list[str]] = (
            [SqlIdentifier(k).identifier() for k in aggregation_secondary_keys] if aggregation_secondary_keys else None
        )
        self._feature_aggregation_method: Optional[FeatureAggregationMethod] = None
        self._infer_schema_df: Optional[DataFrame] = None
        self._query: str = ""
        self._feature_desc: Optional[OrderedDict[SqlIdentifier, str]] = None
        self._cluster_by: list[SqlIdentifier] = []
        self._refresh_freq: Optional[str] = None

        # --- Branch: Rollup FV ---
        if rollup_config is not None:
            if feature_aggregation_method is not None:
                raise ValueError("feature_aggregation_method is only supported for streaming feature views.")
            target_keys = [str(k) for e in entities for k in e.join_keys]
            rollup_config.validate(target_keys)

            parent = rollup_config.source
            self._timestamp_col = SqlIdentifier(_TILE_START_COL)
            self._feature_granularity = parent.feature_granularity
            self._aggregation_specs = parent.aggregation_specs
            if self._aggregation_secondary_keys is None:
                self._aggregation_secondary_keys = parent.aggregation_secondary_keys
            self._refresh_freq = refresh_freq or parent.refresh_freq
            self._infer_schema_df = self._build_rollup_schema_df(rollup_config, entities)
            self._feature_desc = rollup_config.source._feature_desc
            if cluster_by is not None:
                self._cluster_by = [SqlIdentifier(col) for col in cluster_by]
            else:
                self._cluster_by = [k for e in entities for k in e.join_keys] + [SqlIdentifier(_TILE_START_COL)]

        # --- Branch: Streaming FV ---
        elif stream_config is not None:
            # Defer feature_df initialization — completed during registration
            # via _initialize_from_feature_df() after the udf_transformed table is created.
            if timestamp_col is None:
                raise ValueError("Streaming feature views require timestamp_col to be specified.")
            self._timestamp_col = SqlIdentifier(timestamp_col)
            self._refresh_freq = refresh_freq
            (
                self._feature_granularity,
                self._aggregation_specs,
                self._feature_aggregation_method,
            ) = _resolve_tiled_config(
                features=features,
                feature_granularity=feature_granularity,
                feature_aggregation_method=feature_aggregation_method,
                aggregation_secondary_keys=self._aggregation_secondary_keys,
            )

            # Warn if non-time-aggregated streaming FV has refresh_freq (a VIEW is more efficient)
            if self._aggregation_specs is None and refresh_freq is not None:
                warnings.warn(
                    "Streaming feature views without time-aggregated features don't require refresh_freq. "
                    "A VIEW provides zero-lag access at no extra cost.",
                    stacklevel=2,
                    category=UserWarning,
                )

        # --- Branch: Batch FV (standard) ---
        else:
            if feature_aggregation_method is not None:
                raise ValueError("feature_aggregation_method is only supported for streaming feature views.")
            self._timestamp_col = SqlIdentifier(timestamp_col) if timestamp_col is not None else None
            self._feature_granularity = feature_granularity
            self._aggregation_specs = _kwargs.pop("_aggregation_specs", None)
            if features is not None:
                self._feature_granularity, self._aggregation_specs, _ = _resolve_tiled_config(
                    features=features,
                    feature_granularity=feature_granularity,
                    feature_aggregation_method=None,
                    aggregation_secondary_keys=self._aggregation_secondary_keys,
                )
            elif self._aggregation_specs is not None:
                has_secondary_key_specs = any(
                    spec.function.is_secondary_key_array() for spec in self._aggregation_specs
                )
                if has_secondary_key_specs and self._aggregation_secondary_keys is None:
                    # Load path: incoming specs already include synthesized
                    # _SECONDARY_KEY_ARRAY specs. Derive the FV-level SKs
                    # from them so callers don't have to thread it separately.
                    sk_columns: list[str] = []
                    seen_sk: set[str] = set()
                    for spec in self._aggregation_specs:
                        if spec.function.is_secondary_key_array() and spec.source_column not in seen_sk:
                            seen_sk.add(spec.source_column)
                            sk_columns.append(spec.source_column)
                    self._aggregation_secondary_keys = sk_columns or None
                elif self._aggregation_secondary_keys is not None and not has_secondary_key_specs:
                    self._aggregation_specs = _prepend_keys_specs(
                        self._aggregation_specs, self._aggregation_secondary_keys
                    )
            self._refresh_freq = refresh_freq
            self._initialize_from_feature_df(
                feature_df,
                cluster_by=cluster_by,
                infer_schema_df=_kwargs.pop("_infer_schema_df", None),
            )

        self._desc: str = desc
        self._version: Optional[FeatureViewVersion] = None
        self._status: FeatureViewStatus = FeatureViewStatus.DRAFT

        self._database: Optional[SqlIdentifier] = None
        self._schema: Optional[SqlIdentifier] = None
        self._initialize: str = initialize
        self._warehouse: Optional[SqlIdentifier] = SqlIdentifier(warehouse) if warehouse is not None else None
        self._refresh_mode: Optional[str] = refresh_mode
        self._refresh_mode_reason: Optional[str] = None
        self._owner: Optional[str] = None

        self._online_config: Optional[OnlineConfig] = online_config

        # Streaming feature view configuration
        self._stream_config = stream_config
        self._is_streaming_marker: bool = _kwargs.pop("_is_streaming_marker", False)
        self._transformation_fn_source: Optional[str] = None  # Populated from metadata for reconstructed FVs
        if self._stream_config is not None:
            if online_config is not None and online_config.enable is False:
                raise ValueError("Streaming feature views require online to be enabled.")
            if online_config is None:
                self._online_config = OnlineConfig(enable=True, store_type=OnlineStoreType.POSTGRES)

        # For tiled FVs, re-initialize feature_descs with output column names
        if self.is_tiled and self._aggregation_specs:
            self._feature_desc = OrderedDict(
                (SqlIdentifier(spec.get_sql_column_name()), "") for spec in self._aggregation_specs
            )
        self._storage_config: Optional[StorageConfig] = storage_config

        # Rollup metadata for PIT-correct training (set during registration, loaded during reconstruction)
        self._rollup_metadata: Optional[RollupMetadata] = None
        self._postgres_online_query_url: Optional[str] = None

        # Column aliasing for dataset generation (ephemeral, in-memory only)
        self._column_alias: Optional[str] = None

        # Validate kwargs
        if _kwargs:
            raise TypeError(f"FeatureView.__init__ got an unexpected keyword argument: '{next(iter(_kwargs.keys()))}'")

        # Validate for batch FVs only (rollup and streaming have different requirements)
        if rollup_config is None and stream_config is None:
            self._validate()

    def slice(self, names: list[str]) -> FeatureViewSlice:
        """
        Select a subset of features within the FeatureView.

        Args:
            names: feature names to select.

        Returns:
            FeatureViewSlice instance containing selected features.

        Raises:
            ValueError: if selected feature names is not found in the FeatureView.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = fs.get_entity('TRIP_ID')
            >>> # feature_df contains 3 features and 1 entity
            >>> feature_df = session.table(source_table).select(
            ...     'TRIPDURATION',
            ...     'START_STATION_LATITUDE',
            ...     'END_STATION_LONGITUDE',
            ...     'TRIP_ID'
            ... )
            >>> darft_fv = FeatureView(name='F_TRIP', entities=[e], feature_df=feature_df)
            >>> fv = fs.register_feature_view(darft_fv, version='1.0')
            >>> # shows all 3 features
            >>> fv.feature_names
            ['TRIPDURATION', 'START_STATION_LATITUDE', 'END_STATION_LONGITUDE']
            <BLANKLINE>
            >>> # slice a subset of features
            >>> fv_slice = fv.slice(['TRIPDURATION', 'START_STATION_LATITUDE'])
            >>> fv_slice.names
            ['TRIPDURATION', 'START_STATION_LATITUDE']
            <BLANKLINE>
            >>> # query the full set of features in original feature view
            >>> fv_slice.feature_view_ref.feature_names
            ['TRIPDURATION', 'START_STATION_LATITUDE', 'END_STATION_LONGITUDE']

        """
        res = []
        for name in names:
            name = SqlIdentifier(name)
            if name not in self.feature_names:
                raise ValueError(f"Feature name {name} not found in FeatureView {self.name}.")
            res.append(name)

        # Auto-include the keys column for any value column the user requested
        # whose keys-counterpart they did NOT also request. Missing keys are
        # prepended in the order their corresponding value first appears.
        unnamed_secondary_keys: list[SqlIdentifier] = []
        if self.is_tiled and self._aggregation_specs is not None:
            user_specified_columns = set(res)
            spec_by_output = {SqlIdentifier(s.output_column): s for s in self._aggregation_specs}
            # ``aggregation_secondary_keys`` is currently capped at length 1
            keys_specs_by_window_offset: dict[tuple[str, str], list[AggregationSpec]] = {}
            for s in self._aggregation_specs:
                if s.function.is_secondary_key_array():
                    keys_specs_by_window_offset.setdefault((s.window, s.offset), []).append(s)
            seen_groups: set[tuple[str, str]] = set()
            for name in res:
                spec = spec_by_output.get(name)
                if spec is None or spec.function.is_secondary_key_array():
                    continue
                group = (spec.window, spec.offset)
                if group in seen_groups:
                    continue
                seen_groups.add(group)
                for keys_spec in keys_specs_by_window_offset.get(group, []):
                    keys_col = SqlIdentifier(keys_spec.output_column)
                    if keys_col in user_specified_columns:
                        continue
                    unnamed_secondary_keys.append(keys_col)
            res = unnamed_secondary_keys + res

        return FeatureViewSlice(self, res)

    def with_name(self, name: str) -> FeatureView:
        """
        Use this Feature View with a namespace for dataset generation.

        Returns a copy of this Feature View with a custom namespace that will
        be used to prefix all feature columns during dataset generation. This
        is useful for avoiding column name collisions or using the same Feature
        View multiple times with different contexts.

        The name is NOT persisted to the Feature Store and only affects column
        naming in retrieve_feature_values(), generate_dataset(), and
        generate_training_set().

        Args:
            name: Namespace for feature columns. Will be formatted as '{name}_'
                before each column name.
                - "sender" -> sender_count, sender_total
                - "c" -> c_count, c_total
                - "" (empty) -> no prefix (useful to override auto_prefix)

        Returns:
            A new FeatureView instance with the namespace attached.

        Examples::

            >>> # Avoid collisions
            >>> fs.generate_training_set(
            ...     features=[
            ...         cart_fv.with_name("cart"),
            ...         page_fv.with_name("page"),
            ...     ]
            ... )
            >>> # Same FV twice (sender/recipient pattern)
            >>> user_fv = fs.get_feature_view("user_features", "v1")
            >>> fs.generate_training_set(
            ...     features=[
            ...         user_fv.with_name("sender"),
            ...         user_fv.with_name("recipient"),
            ...     ]
            ... )
            >>> # Override auto_prefix
            >>> fs.generate_training_set(
            ...     features=[
            ...         important_fv.with_name(""),  # No prefix
            ...         other_fv,  # Gets auto prefix
            ...     ],
            ...     auto_prefix=True
            ... )

        Note:
            Similar to Tecton's with_name() method. This setting takes
            precedence over the auto_prefix parameter.
        """
        import copy

        new_fv = copy.copy(self)
        new_fv._column_alias = name
        return new_fv

    @property
    def column_alias(self) -> Optional[str]:
        """Returns the column namespace if set via with_name(), else None."""
        return getattr(self, "_column_alias", None)

    def fully_qualified_name(self) -> str:
        """
        Returns the fully qualified name (<database_name>.<schema_name>.<feature_view_name>) for the
        FeatureView in Snowflake.

        Returns:
            fully qualified name string.

        Raises:
            RuntimeError: if the FeatureView is not registered.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = fs.get_entity('TRIP_ID')
            >>> feature_df = session.table(source_table).select(
            ...     'TRIPDURATION',
            ...     'START_STATION_LATITUDE',
            ...     'TRIP_ID'
            ... )
            >>> darft_fv = FeatureView(name='F_TRIP', entities=[e], feature_df=feature_df)
            >>> registered_fv = fs.register_feature_view(darft_fv, version='1.0')
            >>> registered_fv.fully_qualified_name()
            'MY_DB.MY_SCHEMA."F_TRIP$1.0"'

        """
        if self.status == FeatureViewStatus.DRAFT or self.version is None:
            raise RuntimeError(f"FeatureView {self.name} has not been registered.")
        return f"{self._database}.{self._schema}.{FeatureView._get_physical_name(self.name, self.version)}"

    def attach_feature_desc(self, descs: dict[str, str]) -> FeatureView:
        """
        Associate feature level descriptions to the FeatureView.

        Args:
            descs: Dictionary contains feature name and corresponding descriptions.

        Returns:
            FeatureView with feature level desc attached.

        Raises:
            ValueError: if feature name is not found in the FeatureView.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = fs.get_entity('TRIP_ID')
            >>> feature_df = session.table(source_table).select('TRIPDURATION', 'START_STATION_LATITUDE', 'TRIP_ID')
            >>> draft_fv = FeatureView(name='F_TRIP', entities=[e], feature_df=feature_df)
            >>> draft_fv = draft_fv.attach_feature_desc({
            ...     "TRIPDURATION": "Duration of a trip.",
            ...     "START_STATION_LATITUDE": "Latitude of the start station."
            ... })
            >>> registered_fv = fs.register_feature_view(draft_fv, version='1.0')
            >>> registered_fv.feature_descs
            OrderedDict([('TRIPDURATION', 'Duration of a trip.'),
                ('START_STATION_LATITUDE', 'Latitude of the start station.')])

        """
        if self._feature_desc is None:
            warnings.warn(
                "Failed to read feature view schema. Probably feature view is not refreshed yet. "
                "Schema will be available after initial refresh.",
                stacklevel=2,
                category=_FeatureViewSchemaNotReadyWarning,
            )
            return self

        for f, d in descs.items():
            f = SqlIdentifier(f)
            if f not in self._feature_desc:
                raise ValueError(
                    f"Feature name {f} is not found in FeatureView {self.name}, "
                    f"valid feature names are: {self.feature_names}"
                )
            self._feature_desc[f] = d
        return self

    @property
    def name(self) -> SqlIdentifier:
        return self._name

    @property
    def entities(self) -> list[Entity]:
        return self._entities

    @property
    def feature_df(self) -> Optional[DataFrame]:
        return self._feature_df

    @property
    def timestamp_col(self) -> Optional[SqlIdentifier]:
        return self._timestamp_col

    @property
    def cluster_by(self) -> Optional[list[SqlIdentifier]]:
        return self._cluster_by

    @property
    def desc(self) -> str:
        return self._desc

    @desc.setter
    def desc(self, new_value: str) -> None:
        """Set the description of feature view.

        Args:
            new_value: new value of description.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = fs.get_entity('TRIP_ID')
            >>> darft_fv = FeatureView(
            ...     name='F_TRIP',
            ...     entities=[e],
            ...     feature_df=feature_df,
            ...     desc='old desc'
            ... )
            >>> fv_1 = fs.register_feature_view(darft_fv, version='1.0')
            >>> print(fv_1.desc)
            old desc
            <BLANKLINE>
            >>> darft_fv.desc = 'NEW DESC'
            >>> fv_2 = fs.register_feature_view(darft_fv, version='2.0')
            >>> print(fv_2.desc)
            NEW DESC

        """
        warnings.warn(
            "You must call register_feature_view() to make it effective. "
            "Or use update_feature_view(desc=<new_value>).",
            stacklevel=2,
            category=UserWarning,
        )
        self._desc = new_value

    @property
    def query(self) -> str:
        return self._query

    @property
    def version(self) -> Optional[FeatureViewVersion]:
        return self._version

    @property
    def status(self) -> FeatureViewStatus:
        return self._status

    @property
    def feature_names(self) -> list[SqlIdentifier]:
        # For tiled FVs, return output column names from aggregation specs
        if self.is_tiled and self._aggregation_specs:
            return [SqlIdentifier(spec.get_sql_column_name()) for spec in self._aggregation_specs]
        if self._feature_desc:
            return list(self._feature_desc.keys())
        if self._status != FeatureViewStatus.DRAFT:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.SNOWML_READ_FAILED,
                original_exception=RuntimeError(
                    "Feature names are not available because the dynamic table had not completed its "
                    "initial refresh when this object was created. "
                    "Call fs.get_feature_view() again to get updated metadata."
                ),
            )
        return []

    @property
    def feature_descs(self) -> Optional[dict[SqlIdentifier, str]]:
        if self._feature_desc is None and self._status != FeatureViewStatus.DRAFT:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.SNOWML_READ_FAILED,
                original_exception=RuntimeError(
                    "Feature descriptions are not available because the dynamic table had not completed its "
                    "initial refresh when this object was created. "
                    "Call fs.get_feature_view() again to get updated metadata."
                ),
            )
        return self._feature_desc

    @property
    def online(self) -> bool:  # noqa: DAR101
        """Check if online storage is enabled for this feature view.

        Returns:
            True if online storage is enabled, False otherwise.
        """
        if self._online_config and self._online_config.enable is True:
            return True
        return False

    @property
    def online_config(self) -> Optional[OnlineConfig]:
        return self._online_config

    @property
    def is_tiled(self) -> bool:
        """Check if this feature view uses tile-based aggregation.

        Returns:
            True if feature_granularity and features are configured,
            or if this is a rollup feature view.
        """
        return self._feature_granularity is not None and self._aggregation_specs is not None

    @property
    def is_streaming(self) -> bool:
        """Check if this feature view is a streaming feature view.

        Returns:
            True if ``stream_config`` was provided or the FV was reconstructed
            from a streaming backend object.
        """
        return self._stream_config is not None or self._is_streaming_marker

    @property
    def stream_config(self) -> Optional[StreamConfig]:
        """Get the stream configuration if this is a streaming feature view.

        Returns:
            The StreamConfig used to create this feature view, or None.
            For reconstructed FVs (via ``get_feature_view``), this is None
            since the transformation function is only needed at registration time.
        """
        return self._stream_config

    @property
    def transformation_fn_source(self) -> Optional[str]:
        """Get the transformation function source code for streaming feature views.

        For draft FVs (with ``stream_config``), returns the source from the config.
        For reconstructed FVs (via ``get_feature_view``), returns the source from
        stored metadata.  Returns ``None`` for non-streaming FVs.

        Returns:
            The plain-text source code string, or ``None`` for non-streaming FVs.

        Example::

            >>> fv = fs.get_feature_view("realtime_txn_features", "v1")
            >>> print(fv.transformation_fn_source)
            def normalize_txn(df):
                df["amount_cents"] = (df["amount"] * 100).astype(int)
                df["is_large"] = df["amount"] > 1000
                return df
        """
        if self._stream_config is not None:
            return self._stream_config.get_function_source()
        return self._transformation_fn_source

    @property
    def is_rollup(self) -> bool:
        """Check if this feature view is a rollup of another tiled feature view.

        Returns True for both draft FVs created with ``rollup_config`` and
        registered FVs reconstructed from persisted ``rollup_metadata``.

        Returns:
            True if this is a rollup feature view, False otherwise.
        """
        return self._rollup_config is not None or self._rollup_metadata is not None

    @property
    def rollup_config(self) -> Optional[RollupConfig]:
        """Get the rollup configuration if this is a rollup feature view.

        Returns:
            The RollupConfig used to create this feature view, or None.
        """
        return self._rollup_config

    @property
    def rollup_metadata(self) -> Optional[RollupMetadata]:
        """Get the rollup metadata for PIT-correct training queries.

        Set during registration and loaded during ``get_feature_view`` reconstruction.
        Contains parent tile table info and mapping query needed to generate range JOIN
        SQL at training time.

        Returns:
            The RollupMetadata, or None if this is not a rollup FV or has no temporal mapping.
        """
        return self._rollup_metadata

    @property
    def feature_granularity(self) -> Optional[str]:
        """Get the tile interval for aggregations."""
        return self._feature_granularity

    @property
    def aggregation_specs(self) -> Optional[list[AggregationSpec]]:
        """Get the aggregation specifications (internal use)."""
        return self._aggregation_specs

    @property
    def aggregation_secondary_keys(self) -> Optional[list[str]]:
        """Get the FV-level secondary aggregation keys, if any."""
        return self._aggregation_secondary_keys

    @property
    def feature_aggregation_method(self) -> Optional[FeatureAggregationMethod]:
        """Get the aggregation method (TILES or CONTINUOUS). Only applicable to tiled streaming FVs."""
        return self._feature_aggregation_method

    @property
    def storage_config(self) -> Optional[StorageConfig]:
        """Get the storage configuration for this feature view.

        Returns:
            StorageConfig object if set, None otherwise.
            When None, the feature view uses the default Snowflake-native storage (Dynamic Table).
        """
        return self._storage_config

    def fully_qualified_online_table_name(self) -> str:
        """Get the fully qualified name for the online feature table.

        Returns:
            The fully qualified name (<database_name>.<schema_name>.<online_table_name>) for the
            online feature table in Snowflake.

        Raises:
            RuntimeError: if the FeatureView is not registered or not configured for online storage.
        """
        if self.status == FeatureViewStatus.DRAFT or self.version is None:
            raise RuntimeError(f"FeatureView {self.name} has not been registered.")
        if not self.online:
            raise RuntimeError(f"FeatureView {self.name} is not configured for online storage.")
        online_table_name = self._get_online_table_name(self.name, self.version)
        return f"{self._database}.{self._schema}.{online_table_name}"

    def list_columns(self) -> DataFrame:
        """List all columns and their information.

        Returns:
            A Snowpark DataFrame contains feature information.

        Raises:
            ValueError: if the FeatureView has no feature DataFrame (e.g. unregistered rollup).

        Example::

            >>> fs = FeatureStore(...)
            >>> e = Entity("foo", ["id"], desc='my entity')
            >>> fs.register_entity(e)
            <BLANKLINE>
            >>> draft_fv = FeatureView(
            ...     name="fv",
            ...     entities=[e],
            ...     feature_df=self._session.table(<source_table>).select(["NAME", "ID", "TITLE", "AGE", "TS"]),
            ...     timestamp_col="ts",
            >>> ).attach_feature_desc({"AGE": "my age", "TITLE": '"my title"'})
            >>> fv = fs.register_feature_view(draft_fv, '1.0')
            <BLANKLINE>
            >>> fv.list_columns().show()
            --------------------------------------------------
            |"NAME"  |"CATEGORY"  |"DTYPE"      |"DESC"      |
            --------------------------------------------------
            |NAME    |FEATURE     |string(64)   |            |
            |ID      |ENTITY      |bigint       |my entity   |
            |TITLE   |FEATURE     |string(128)  |"my title"  |
            |AGE     |FEATURE     |bigint       |my age      |
            |TS      |TIMESTAMP   |bigint       |NULL        |
            --------------------------------------------------

        """
        if self._feature_df is None:
            raise ValueError("list_columns is not supported for rollup feature views without a feature DataFrame.")
        session = self._feature_df.session
        rows = []  # type: ignore[var-annotated]

        if self.feature_descs is None:
            warnings.warn(
                "Failed to read feature view schema. Probably feature view is not refreshed yet. "
                "Schema will be available after initial refresh.",
                stacklevel=2,
                category=_FeatureViewSchemaNotReadyWarning,
            )
            return session.create_dataframe(rows, schema=["name", "category", "dtype", "desc"])

        for name, type in self._feature_df.dtypes:
            if SqlIdentifier(name) in self.feature_descs:
                desc = self.feature_descs[SqlIdentifier(name)]
                rows.append((name, "FEATURE", type, desc))
            elif SqlIdentifier(name) == self._timestamp_col:
                rows.append((name, "TIMESTAMP", type, None))  # type: ignore[arg-type]
            else:
                for e in self._entities:
                    if SqlIdentifier(name) in e.join_keys:
                        rows.append((name, "ENTITY", type, e.desc))
                        break

        return session.create_dataframe(rows, schema=["name", "category", "dtype", "desc"])

    @property
    def refresh_freq(self) -> Optional[str]:
        return self._refresh_freq

    @refresh_freq.setter
    def refresh_freq(self, new_value: str) -> None:
        """Set refresh frequency of feature view.

        Args:
            new_value: The new value of refresh frequency.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = fs.get_entity('TRIP_ID')
            >>> darft_fv = FeatureView(
            ...     name='F_TRIP',
            ...     entities=[e],
            ...     feature_df=feature_df,
            ...     refresh_freq='1d'
            ... )
            >>> fv_1 = fs.register_feature_view(darft_fv, version='1.0')
            >>> print(fv_1.refresh_freq)
            1 day
            <BLANKLINE>
            >>> darft_fv.refresh_freq = '12h'
            >>> fv_2 = fs.register_feature_view(darft_fv, version='2.0')
            >>> print(fv_2.refresh_freq)
            12 hours

        """
        warnings.warn(
            "You must call register_feature_view() to make it effective. "
            "Or use update_feature_view(refresh_freq=<new_value>).",
            stacklevel=2,
            category=UserWarning,
        )
        self._refresh_freq = new_value

    @property
    def database(self) -> Optional[SqlIdentifier]:
        return self._database

    @property
    def schema(self) -> Optional[SqlIdentifier]:
        return self._schema

    @property
    def warehouse(self) -> Optional[SqlIdentifier]:
        return self._warehouse

    @warehouse.setter
    def warehouse(self, new_value: str) -> None:
        """Set warehouse of feature view.

        Args:
            new_value: The new value of warehouse.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = fs.get_entity('TRIP_ID')
            >>> darft_fv = FeatureView(
            ...     name='F_TRIP',
            ...     entities=[e],
            ...     feature_df=feature_df,
            ...     refresh_freq='1d',
            ...     warehouse='WH1',
            ... )
            >>> fv_1 = fs.register_feature_view(darft_fv, version='1.0')
            >>> print(fv_1.warehouse)
            WH1
            <BLANKLINE>
            >>> darft_fv.warehouse = 'WH2'
            >>> fv_2 = fs.register_feature_view(darft_fv, version='2.0')
            >>> print(fv_2.warehouse)
            WH2

        """
        warnings.warn(
            "You must call register_feature_view() to make it effective. "
            "Or use update_feature_view(warehouse=<new_value>).",
            stacklevel=2,
            category=UserWarning,
        )
        self._warehouse = SqlIdentifier(new_value)

    @property
    def initialize(self) -> str:
        return self._initialize

    @property
    def output_schema(self) -> StructType:
        assert self._infer_schema_df is not None
        try:
            return self._infer_schema_df.schema
        except SnowparkSQLException as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.SNOWML_READ_FAILED,
                original_exception=RuntimeError(
                    "Feature view schema is not available because the dynamic table "
                    "has not completed its initial refresh yet."
                ),
            ) from e

    @property
    def refresh_mode(self) -> Optional[str]:
        return self._refresh_mode

    @property
    def refresh_mode_reason(self) -> Optional[str]:
        return self._refresh_mode_reason

    @property
    def owner(self) -> Optional[str]:
        return self._owner

    def _metadata(self) -> _FeatureViewMetadata:
        entity_names = [e.name.identifier() for e in self.entities]
        ts_col = self.timestamp_col.identifier() if self.timestamp_col is not None else _TIMESTAMP_COL_PLACEHOLDER
        is_iceberg = self._storage_config is not None and self._storage_config.format == StorageFormat.ICEBERG
        return _FeatureViewMetadata(
            entity_names,
            ts_col,
            is_tiled=self.is_tiled,
            is_iceberg=is_iceberg,
            is_rollup=self.is_rollup,
            is_streaming=self.is_streaming,
        )

    def _get_query(self) -> str:
        assert self._feature_df is not None, "_get_query called without feature_df"
        if len(self._feature_df.queries["queries"]) != 1:
            raise ValueError(
                f"""feature_df dataframe must contain only 1 query.
Got {len(self._feature_df.queries['queries'])}: {self._feature_df.queries['queries']}
"""
            )
        return str(self._feature_df.queries["queries"][0])

    def _build_rollup_schema_df(
        self,
        rollup_config: RollupConfig,
        entities: list[Entity],
    ) -> DataFrame:
        """Build a DataFrame for schema inference of rollup feature views.

        Constructs a query that represents the rollup output schema by selecting
        from the parent's tile table joined with the mapping table.

        Args:
            rollup_config: The rollup configuration.
            entities: The target entities for the rollup FV.

        Returns:
            A DataFrame with the correct schema for the rollup output.
        """
        from snowflake.ml.feature_store.tile_sql_generator import RollupSqlGenerator

        parent = rollup_config.source
        mapping_df = rollup_config.mapping_df

        assert parent.version is not None, "RollupConfig source must be registered (version required)"
        assert parent.aggregation_specs is not None, "RollupConfig source must be tiled (aggregation_specs required)"

        # Get session from mapping_df
        session = mapping_df._session
        assert session is not None, "mapping_df must have an active session"

        # Build parent tile table path
        parent_tile_table = (
            f"{parent.database}.{parent.schema}." f"{FeatureView._get_physical_name(parent.name, parent.version)}"
        )

        # Get join keys
        parent_join_keys = [str(k) for e in parent.entities for k in e.join_keys]
        new_join_keys = [str(k) for e in entities for k in e.join_keys]

        # Get mapping query
        mapping_query = mapping_df.queries["queries"][0]

        # Generate rollup SQL using the generator
        generator = RollupSqlGenerator(
            parent_tile_table=parent_tile_table,
            parent_join_keys=parent_join_keys,
            new_join_keys=new_join_keys,
            mapping_query=mapping_query,
            aggregation_specs=parent.aggregation_specs,
        )
        rollup_query = generator.generate()

        # Wrap in a schema-only query (LIMIT 0 for no data, just schema)
        schema_query = f"SELECT * FROM ({rollup_query}) WHERE 1=0"

        return session.sql(schema_query)

    def _initialize_from_feature_df(
        self,
        feature_df: Optional[DataFrame],
        *,
        cluster_by: Optional[list[str]] = None,
        infer_schema_df: Optional[DataFrame] = None,
    ) -> None:
        """Initialize all state derived from the feature DataFrame.

        Consolidates the fields that depend on ``feature_df`` into one method.
        Called from ``__init__`` for batch FVs, and from ``register_feature_view``
        for streaming FVs (after the udf_transformed table is created).

        Args:
            feature_df: The Snowpark DataFrame to derive state from.
            cluster_by: Explicit clustering columns, or ``None`` to auto-derive.
            infer_schema_df: Override for schema inference (used by ``_construct_feature_view``).
        """
        self._feature_df = feature_df
        self._infer_schema_df = infer_schema_df if infer_schema_df is not None else feature_df
        self._query = self._get_query()

        feature_names = self._get_feature_names()
        self._feature_desc = OrderedDict((f, "") for f in feature_names) if feature_names is not None else None

        # For tiled FVs, re-initialize with aggregation output names (not source column names)
        if self.is_tiled and self._aggregation_specs:
            self._feature_desc = OrderedDict(
                (SqlIdentifier(spec.get_sql_column_name()), "") for spec in self._aggregation_specs
            )

        if cluster_by is not None:
            self._cluster_by = [SqlIdentifier(col) for col in cluster_by]
        else:
            self._cluster_by = self._get_default_cluster_by()

    @property
    def ordered_entity_columns(self) -> list[str]:
        """Deduplicated entity join key column names, preserving order.

        Returns:
            List of resolved (uppercased) join key names from all entities,
            with duplicates removed while preserving the order of first occurrence.
        """
        cols: list[str] = []
        seen: set[str] = set()
        for e in self._entities:
            for jk in e.join_keys:
                resolved = jk.resolved()
                if resolved not in seen:
                    seen.add(resolved)
                    cols.append(resolved)
        return cols

    def _validate(self) -> None:
        if _FEATURE_VIEW_NAME_DELIMITER in self._name:
            raise ValueError(
                f"FeatureView name `{self._name}` contains invalid character `{_FEATURE_VIEW_NAME_DELIMITER}`."
            )

        df_cols = self._get_column_names()
        if df_cols is not None:
            for e in self._entities:
                for k in e.join_keys:
                    if k not in df_cols:
                        raise ValueError(f"join_key {k} in Entity {e.name} is not found in input dataframe: {df_cols}")

            # For tiled FVs, timestamp_col is used for tiling (not an output column)
            # and cluster_by is adjusted to use TILE_START instead of timestamp_col
            # So skip these validations for tiled FVs
            if self._timestamp_col is not None and not self.is_tiled:
                ts_col = self._timestamp_col
                if ts_col == SqlIdentifier(_TIMESTAMP_COL_PLACEHOLDER):
                    raise ValueError(f"Invalid timestamp_col name, cannot be {_TIMESTAMP_COL_PLACEHOLDER}.")
                if ts_col not in df_cols:
                    raise ValueError(f"timestamp_col {ts_col} is not found in input dataframe.")

                assert self._infer_schema_df is not None
                col_type = self._infer_schema_df.schema[ts_col].datatype
                if not isinstance(col_type, (DateType, TimeType, TimestampType, _NumericType)):
                    raise ValueError(f"Invalid data type for timestamp_col {ts_col}: {col_type}.")

            if self.cluster_by is not None and not self.is_tiled:
                for column in self.cluster_by:
                    if column not in df_cols:
                        raise ValueError(
                            f"Column '{column}' in `cluster_by` is not in the feature DataFrame schema. "
                            f"{df_cols}, {self.cluster_by}"
                        )

        if re.match(_RESULT_SCAN_QUERY_PATTERN, self._query) is not None:
            raise ValueError(f"feature_df should not be reading from RESULT_SCAN. Invalid query: {self._query}")

        if self._initialize not in ["ON_CREATE", "ON_SCHEDULE"]:
            raise ValueError("'initialize' only supports ON_CREATE or ON_SCHEDULE.")

        # Validate tiled aggregation configuration
        if self._feature_granularity is not None and self._aggregation_specs is None:
            raise ValueError(
                "feature_granularity requires features to be specified. "
                "Use the Feature class to define aggregations."
            )
        if self._aggregation_specs is not None and self._feature_granularity is None:
            raise ValueError(
                "features requires feature_granularity to be specified. "
                "Specify the tile interval (e.g., '1h', '1d')."
            )
        if self.is_tiled:
            if self._timestamp_col is None:
                raise ValueError(
                    "timestamp_col is required for tile-based aggregations. "
                    "Specify the timestamp column used for time-series lookups."
                )
            if self._refresh_freq is None:
                raise ValueError(
                    "refresh_freq is required for tile-based aggregations. "
                    "Tiled feature views must be managed (Dynamic Tables)."
                )
            from snowflake.ml.feature_store.interval_utils import interval_to_seconds

            granularity_seconds = interval_to_seconds(self._feature_granularity)  # type: ignore[arg-type]
            if granularity_seconds < _MIN_FEATURE_GRANULARITY_SECONDS:
                raise ValueError(f"feature_granularity '{self._feature_granularity}' is below the minimum of '1m'.")
            # Validate window and offset are multiples of granularity
            self._validate_window_offset_alignment()
            # Validate feature aliases are unique
            self._validate_unique_feature_aliases()
            self._validate_secondary_key_features()

        # Validate Iceberg storage configuration
        if self._storage_config is not None and self._storage_config.format == StorageFormat.ICEBERG:
            if self.online:
                raise ValueError("Online storage is not supported with Iceberg.")
            if self._refresh_freq is None:
                raise ValueError("Iceberg storage requires refresh_freq.")

    def _validate_window_offset_alignment(self) -> None:
        """Validate that window and offset are multiples of feature_granularity.

        This ensures clean tile boundaries for aggregations.
        Lifetime windows are exempt from this validation as they aggregate all tiles.

        Raises:
            ValueError: If window or offset is not a multiple of feature_granularity.
        """
        from snowflake.ml.feature_store.interval_utils import interval_to_seconds

        granularity_seconds = interval_to_seconds(self._feature_granularity)  # type: ignore[arg-type]

        for spec in self._aggregation_specs:  # type: ignore[union-attr]
            # Skip validation for lifetime windows (they aggregate all tiles)
            if spec.is_lifetime():
                continue

            # Validate window alignment
            window_seconds = spec.get_window_seconds()
            if window_seconds % granularity_seconds != 0:
                raise ValueError(
                    f"Window '{spec.window}' for feature '{spec.output_column}' must be a multiple of "
                    f"feature_granularity '{self._feature_granularity}'. "
                    f"Window ({window_seconds}s) is not divisible by granularity ({granularity_seconds}s)."
                )

            # Validate offset alignment (if offset is specified)
            offset_seconds = spec.get_offset_seconds()
            if offset_seconds > 0 and offset_seconds % granularity_seconds != 0:
                raise ValueError(
                    f"Offset '{spec.offset}' for feature '{spec.output_column}' must be a multiple of "
                    f"feature_granularity '{self._feature_granularity}'. "
                    f"Offset ({offset_seconds}s) is not divisible by granularity ({granularity_seconds}s)."
                )

    def _validate_unique_feature_aliases(self) -> None:
        """Validate that all feature aliases are unique.

        Duplicate aliases would cause SQL errors or ambiguous columns
        in the generated tile table and dataset queries.

        Raises:
            ValueError: If duplicate feature aliases are found.
        """
        if self._aggregation_specs is None:
            return

        seen_aliases: dict[str, int] = {}
        for spec in self._aggregation_specs:
            # Normalize to uppercase for comparison (Snowflake default)
            alias = spec.output_column.strip('"').upper()
            if alias in seen_aliases:
                raise ValueError(
                    f"Duplicate feature alias '{spec.output_column}' found. "
                    f"Each feature must have a unique alias. "
                    f"Use .alias() to provide distinct names for features."
                )
            seen_aliases[alias] = 1

    def _validate_secondary_key_features(self) -> None:
        """Validate the FV-level ``aggregation_secondary_keys`` configuration.

        Rules:
            1. Each secondary key column must exist in ``feature_df``.
            2. No secondary key may be an entity join key.
            3. At least one aggregation feature must be defined.
            4. Each aggregation must use a supported function. Simple scalars
               (SUM/COUNT/AVG/MIN/MAX/STD/VAR) and sketches
               (APPROX_COUNT_DISTINCT/APPROX_PERCENTILE) are mergeable per
               ``(entity, sk)``; list aggregations are not yet supported.
            5. Lifetime windows are not supported with secondary keys — the
               read-side merge pattern requires a bounded window.

        Raises:
            ValueError: If secondary key validation fails.
        """
        if self._aggregation_secondary_keys is None:
            return

        if not self._aggregation_specs:
            raise ValueError("aggregation_secondary_keys requires at least one aggregation feature to be defined.")

        join_keys = {k.resolved() for e in self._entities for k in e.join_keys}
        df_cols = self._get_column_names()
        available_cols = {c.resolved() for c in df_cols} if df_cols is not None else None

        for secondary_key in self._aggregation_secondary_keys:
            key_resolved = SqlIdentifier(secondary_key).resolved()
            if key_resolved in join_keys:
                raise ValueError(
                    f"aggregation_secondary_keys '{secondary_key}' cannot be an entity join key. "
                    f"Use a distinct column (e.g. a non-entity attribute) as a secondary key."
                )
            if available_cols is not None and key_resolved not in available_cols:
                raise ValueError(
                    f"aggregation_secondary_keys '{secondary_key}' is not found in the feature "
                    f"DataFrame columns. Available columns: {sorted(available_cols)}"
                )

        for spec in self._aggregation_specs:
            if spec.function.is_secondary_key_array():
                continue
            if spec.function.is_list():
                raise ValueError(
                    f"aggregation_secondary_keys is not supported with list aggregations "
                    f"(feature '{spec.output_column}' uses {spec.function.value.upper()}). "
                    f"Supported: SUM, COUNT, AVG, MIN, MAX, STD, VAR, APPROX_COUNT_DISTINCT, APPROX_PERCENTILE."
                )
            if spec.is_lifetime():
                raise ValueError(
                    f"aggregation_secondary_keys is not supported with lifetime windows "
                    f"(feature '{spec.output_column}')."
                )

    def _get_column_names(self) -> Optional[list[SqlIdentifier]]:
        assert self._infer_schema_df is not None
        try:
            return to_sql_identifiers(self._infer_schema_df.columns)
        except SnowparkSQLException as e:
            warnings.warn(
                "Failed to read feature view schema. Probably feature view is not refreshed yet. "
                f"Schema will be available after initial refresh. Original exception: {e}",
                stacklevel=2,
                category=_FeatureViewSchemaNotReadyWarning,
            )
            return None

    def _get_feature_names(self) -> Optional[list[SqlIdentifier]]:
        join_keys = [k for e in self._entities for k in e.join_keys]
        ts_col = [self._timestamp_col] if self._timestamp_col is not None else []
        feature_names = self._get_column_names()
        if feature_names is not None:
            return [c for c in feature_names if c not in join_keys + ts_col]
        return None

    def __repr__(self) -> str:
        states = (f"{k}={v}" for k, v in vars(self).items())
        return f"{type(self).__name__}({', '.join(states)})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, FeatureView):
            return False

        return (
            self.name == other.name
            and self.version == other.version
            and self.timestamp_col == other.timestamp_col
            and self.entities == other.entities
            and self.desc == other.desc
            and self.feature_descs == other.feature_descs
            and self.feature_names == other.feature_names
            and self.query == other.query
            and self.refresh_freq == other.refresh_freq
            and str(self.status) == str(other.status)
            and self.database == other.database
            and self.warehouse == other.warehouse
            and self.refresh_mode == other.refresh_mode
            and self.refresh_mode_reason == other.refresh_mode_reason
            and self._owner == other._owner
        )

    def _to_dict(self) -> dict[str, str]:
        fv_dict = self.__dict__.copy()
        if "_feature_df" in fv_dict:
            fv_dict.pop("_feature_df")
        if "_infer_schema_df" in fv_dict:
            infer_schema_df = fv_dict.pop("_infer_schema_df")
            if infer_schema_df is not None:
                fv_dict["_infer_schema_query"] = infer_schema_df.queries["queries"][0]
        fv_dict["_entities"] = [e._to_dict() for e in self._entities]
        fv_dict["_status"] = str(self._status)
        fv_dict["_name"] = str(self._name) if self._name is not None else None
        fv_dict["_version"] = str(self._version) if self._version is not None else None
        fv_dict["_database"] = str(self._database) if self._database is not None else None
        fv_dict["_schema"] = str(self._schema) if self._schema is not None else None
        fv_dict["_warehouse"] = str(self._warehouse) if self._warehouse is not None else None
        fv_dict["_timestamp_col"] = str(self._timestamp_col) if self._timestamp_col is not None else None
        fv_dict["_initialize"] = str(self._initialize)

        feature_desc_dict = {}
        if self._feature_desc is not None:
            for k, v in self._feature_desc.items():
                feature_desc_dict[k.identifier()] = v
            fv_dict["_feature_desc"] = feature_desc_dict

        fv_dict["_online_config"] = self._online_config.to_json() if self._online_config is not None else None
        fv_dict["_storage_config"] = self._storage_config.to_json() if self._storage_config is not None else None

        # Aggregation fields
        fv_dict["_feature_granularity"] = self._feature_granularity
        fv_dict["_aggregation_specs"] = (
            [spec.to_dict() for spec in self._aggregation_specs] if self._aggregation_specs is not None else None
        )

        # Remove non-serializable live objects
        fv_dict.pop("_rollup_config", None)
        # Serialize rollup metadata if present
        fv_dict["_rollup_metadata"] = self._rollup_metadata.to_dict() if self._rollup_metadata is not None else None

        lineage_node_keys = [key for key in fv_dict if key.startswith("_node") or key == "_session"]

        for key in lineage_node_keys:
            fv_dict.pop(key)

        return fv_dict

    def to_df(self, session: Optional[Session] = None) -> DataFrame:
        """Convert feature view to a Snowpark DataFrame object.

        Args:
            session: [deprecated] This argument has no effect. No need to pass a session object.

        Returns:
            A Snowpark Dataframe object contains the information about feature view.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = Entity("foo", ["id"], desc='my entity')
            >>> fs.register_entity(e)
            <BLANKLINE>
            >>> draft_fv = FeatureView(
            ...     name="fv",
            ...     entities=[e],
            ...     feature_df=self._session.table(<source_table>).select(["NAME", "ID", "TITLE", "AGE", "TS"]),
            ...     timestamp_col="ts",
            >>> ).attach_feature_desc({"AGE": "my age", "TITLE": '"my title"'})
            >>> fv = fs.register_feature_view(draft_fv, '1.0')
            <BLANKLINE>
            >>> fv.to_df().show()
            ----------------------------------------------------------------...
            |"NAME"  |"ENTITIES"                |"TIMESTAMP_COL"  |"DESC"  |
            ----------------------------------------------------------------...
            |FV      |[                         |TS               |foobar  |
            |        |  {                       |                 |        |
            |        |    "desc": "my entity",  |                 |        |
            |        |    "join_keys": [        |                 |        |
            |        |      "ID"                |                 |        |
            |        |    ],                    |                 |        |
            |        |    "name": "FOO",        |                 |        |
            |        |    "owner": null         |                 |        |
            |        |  }                       |                 |        |
            |        |]                         |                 |        |
            ----------------------------------------------------------------...
        """
        assert self._feature_df is not None, "to_df requires feature_df"
        values = list(self._to_dict().values())
        schema = [x.lstrip("_") for x in list(self._to_dict().keys())]
        values.append(str(FeatureView._get_physical_name(self._name, self._version)))  # type: ignore[arg-type]
        schema.append("physical_name")
        return self._feature_df.session.create_dataframe([values], schema=schema)

    def to_json(self) -> str:
        state_dict = self._to_dict()
        state_dict[_FEATURE_OBJ_TYPE] = self.__class__.__name__
        return json.dumps(state_dict)

    @classmethod
    def from_json(cls, json_str: str, session: Session) -> FeatureView:
        json_dict = json.loads(json_str)
        if _FEATURE_OBJ_TYPE not in json_dict or json_dict[_FEATURE_OBJ_TYPE] != cls.__name__:
            raise ValueError(f"Invalid json str for {cls.__name__}: {json_str}")

        entities = []
        for e_json in json_dict["_entities"]:
            e = Entity(e_json["name"], e_json["join_keys"], desc=e_json["desc"])
            e.owner = e_json["owner"]
            entities.append(e)

        # Deserialize aggregation specs if present
        aggregation_specs = None
        if json_dict.get("_aggregation_specs"):
            aggregation_specs = [AggregationSpec.from_dict(s) for s in json_dict["_aggregation_specs"]]

        fv = FeatureView._construct_feature_view(
            name=json_dict["_name"],
            entities=entities,
            feature_df=session.sql(json_dict["_query"]),
            timestamp_col=json_dict["_timestamp_col"],
            desc=json_dict["_desc"],
            version=json_dict["_version"],
            status=json_dict["_status"],
            feature_descs=json_dict["_feature_desc"],
            refresh_freq=json_dict["_refresh_freq"],
            database=json_dict["_database"],
            schema=json_dict["_schema"],
            warehouse=json_dict["_warehouse"],
            refresh_mode=json_dict["_refresh_mode"],
            refresh_mode_reason=json_dict["_refresh_mode_reason"],
            initialize=json_dict["_initialize"],
            owner=json_dict["_owner"],
            infer_schema_df=session.sql(json_dict.get("_infer_schema_query", None)),
            session=session,
            online_config=OnlineConfig.from_json(json_dict["_online_config"])
            if json_dict.get("_online_config")
            else None,
            feature_granularity=json_dict.get("_feature_granularity"),
            aggregation_specs=aggregation_specs,
            storage_config=StorageConfig.from_json(json_dict["_storage_config"])
            if json_dict.get("_storage_config")
            else None,
        )

        # Restore rollup metadata if present
        rollup_meta_dict = json_dict.get("_rollup_metadata")
        if rollup_meta_dict is not None:
            fv._rollup_metadata = RollupMetadata.from_dict(rollup_meta_dict)

        return fv

    def _get_compact_repr(self) -> _CompactRepresentation:
        return _CompactRepresentation(
            db=self.database.identifier(),  # type: ignore[union-attr]
            sch=self.schema.identifier(),  # type: ignore[union-attr]
            name=self.name.identifier(),
            version=self.version,  # type: ignore[arg-type]
        )

    @staticmethod
    def _get_physical_name(fv_name: SqlIdentifier, fv_version: FeatureViewVersion) -> SqlIdentifier:
        return SqlIdentifier(
            concat_names(
                [
                    str(fv_name),
                    _FEATURE_VIEW_NAME_DELIMITER,
                    str(fv_version),
                ]
            )
        )

    @staticmethod
    def _load_from_compact_repr(session: Session, serialized_repr: str) -> Union[FeatureView, FeatureViewSlice]:
        from snowflake.ml.feature_store import (
            feature_store,  # lazy import — avoids circular eager load
        )

        compact_repr = _CompactRepresentation.from_json(serialized_repr)

        fs = feature_store.FeatureStore(
            session, compact_repr.db, compact_repr.sch, default_warehouse=session.get_current_warehouse()
        )
        fv = fs.get_feature_view(compact_repr.name, compact_repr.version)

        if compact_repr.feature_indices is not None:
            feature_names = [fv.feature_names[i] for i in compact_repr.feature_indices]
            return fv.slice(feature_names)  # type: ignore[no-any-return]
        return fv  # type: ignore[no-any-return]

    @staticmethod
    def _load_from_lineage_node(session: Session, name: str, version: str) -> FeatureView:
        from snowflake.ml.feature_store import (
            feature_store,  # lazy import — avoids circular eager load
        )

        db_name, feature_store_name, feature_view_name = identifier.parse_schema_level_object_identifier(name)

        session_warehouse = session.get_current_warehouse()

        if not session_warehouse:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError("No active warehouse selected in the current session"),
            )

        fs = feature_store.FeatureStore(session, db_name, feature_store_name, default_warehouse=session_warehouse)
        return fs.get_feature_view(feature_view_name, version)  # type: ignore[no-any-return]

    @staticmethod
    def _construct_feature_view(
        name: str,
        entities: list[Entity],
        feature_df: DataFrame,
        timestamp_col: Optional[str],
        desc: str,
        version: str,
        status: FeatureViewStatus,
        feature_descs: dict[str, str],
        refresh_freq: Optional[str],
        database: str,
        schema: str,
        warehouse: Optional[str],
        refresh_mode: Optional[str],
        refresh_mode_reason: Optional[str],
        initialize: str,
        owner: Optional[str],
        infer_schema_df: Optional[DataFrame],
        session: Session,
        cluster_by: Optional[list[str]] = None,
        online_config: Optional[OnlineConfig] = None,
        feature_granularity: Optional[str] = None,
        aggregation_specs: Optional[list[AggregationSpec]] = None,
        storage_config: Optional[StorageConfig] = None,
        is_streaming: bool = False,
    ) -> FeatureView:
        # For reconstructed FVs, always go through the batch path in __init__
        # (even for streaming FVs — they use _is_streaming_marker, not stream_config)
        fv = FeatureView(
            name=name,
            entities=entities,
            feature_df=feature_df,
            timestamp_col=timestamp_col,
            desc=desc,
            refresh_freq=refresh_freq,
            _infer_schema_df=infer_schema_df,
            cluster_by=cluster_by,
            online_config=online_config,
            feature_granularity=feature_granularity,
            _aggregation_specs=aggregation_specs,
            storage_config=storage_config,
            _is_streaming_marker=is_streaming,
        )
        fv._version = FeatureViewVersion(version) if version is not None else None
        fv._status = status
        fv._database = SqlIdentifier(database) if database is not None else None
        fv._schema = SqlIdentifier(schema) if schema is not None else None
        fv._warehouse = SqlIdentifier(warehouse) if warehouse is not None else None
        fv._refresh_mode = refresh_mode
        fv._refresh_mode_reason = refresh_mode_reason
        fv._initialize = initialize
        fv._owner = owner
        fv.attach_feature_desc(feature_descs)

        lineage_node.LineageNode.__init__(
            fv, session=session, name=f"{fv.database}.{fv._schema}.{name}", domain="feature_view", version=version
        )
        return fv

    #
    def _get_default_cluster_by(self) -> list[SqlIdentifier]:
        """
        Get default columns to cluster the feature view by.
        Default cluster_by columns are join keys from entities and timestamp_col if it exists

        Returns:
            List of SqlIdentifiers representing the default columns to cluster the feature view by.
        """
        # We don't focus on the order of entities here, as users can define a custom 'cluster_by'
        # if a specific order is required.
        default_cluster_by_cols = [key for entity in self.entities if entity.join_keys for key in entity.join_keys]

        if self.timestamp_col:
            default_cluster_by_cols.append(self.timestamp_col)

        return default_cluster_by_cols

    def _get_tile_query(self) -> str:
        """Generate the tiling query for tile-based aggregations.

        This query is used as the source for the Dynamic Table that stores
        pre-computed partial aggregations (tiles).

        Returns:
            SQL query string for creating tile table.

        Raises:
            ValueError: If the feature view is not configured for tiling.
        """
        if not self.is_tiled:
            raise ValueError("_get_tile_query called on non-tiled feature view")

        from snowflake.ml.feature_store.tile_sql_generator import TilingSqlGenerator

        join_keys = [k for e in self._entities for k in e.join_keys]
        assert self._timestamp_col is not None

        generator = TilingSqlGenerator(
            source_query=self._query,
            join_keys=join_keys,
            timestamp_col=self._timestamp_col,
            feature_granularity=self._feature_granularity,  # type: ignore[arg-type]
            features=self._aggregation_specs,  # type: ignore[arg-type]
        )
        return generator.generate()

    @staticmethod
    def _get_online_table_name(
        feature_view_name: Union[SqlIdentifier, str], version: Optional[Union[FeatureViewVersion, str]] = None
    ) -> SqlIdentifier:
        """Get the online feature table name without qualification.

        Args:
            feature_view_name: Offline feature view name.
            version: Feature view version. If not provided, feature_view_name must be a SqlIdentifier.

        Returns:
            The online table name SqlIdentifier
        """
        if version is None:
            assert isinstance(feature_view_name, SqlIdentifier), "Single argument must be SqlIdentifier"
            online_name = f"{feature_view_name.resolved()}{_ONLINE_TABLE_SUFFIX}"
            return SqlIdentifier(online_name, case_sensitive=True)
        else:
            fv_name = (
                feature_view_name
                if isinstance(feature_view_name, SqlIdentifier)
                else SqlIdentifier(feature_view_name, case_sensitive=True)
            )
            fv_version = version if isinstance(version, FeatureViewVersion) else FeatureViewVersion(version)
            physical_name = FeatureView._get_physical_name(fv_name, fv_version).resolved()
            online_name = f"{physical_name}{_ONLINE_TABLE_SUFFIX}"
            return SqlIdentifier(online_name, case_sensitive=True)

    @staticmethod
    def _get_udf_transformed_table_name(
        feature_view_name: Union[SqlIdentifier, str], version: Optional[Union[FeatureViewVersion, str]] = None
    ) -> SqlIdentifier:
        """Get the udf_transformed table name without qualification.

        Follows the same pattern as ``_get_online_table_name``: appends
        ``$UDF_TRANSFORMED`` to the physical name.

        Args:
            feature_view_name: Offline feature view name.  When *version*
                is ``None``, this must already be the physical
                ``SqlIdentifier`` (e.g., ``"MY_FV$V1"``).
            version: Feature view version.  If not provided,
                *feature_view_name* must be a ``SqlIdentifier``.

        Returns:
            The udf_transformed table name as a ``SqlIdentifier``.
        """
        if version is None:
            assert isinstance(feature_view_name, SqlIdentifier), "Single argument must be SqlIdentifier"
            udf_name = f"{feature_view_name.resolved()}{_UDF_TRANSFORMED_TABLE_SUFFIX}"
            return SqlIdentifier(udf_name, case_sensitive=True)
        else:
            fv_name = (
                feature_view_name
                if isinstance(feature_view_name, SqlIdentifier)
                else SqlIdentifier(feature_view_name, case_sensitive=True)
            )
            fv_version = version if isinstance(version, FeatureViewVersion) else FeatureViewVersion(version)
            physical_name = FeatureView._get_physical_name(fv_name, fv_version).resolved()
            udf_name = f"{physical_name}{_UDF_TRANSFORMED_TABLE_SUFFIX}"
            return SqlIdentifier(udf_name, case_sensitive=True)


def get_feature_prefix(
    feature_view: Union[FeatureView, FeatureViewSlice],
    auto_prefix: bool,
) -> Optional[str]:
    """Resolve the column prefix for a feature view reference.

    Resolution order:

    1. Explicit name from :meth:`FeatureView.with_name` /
       :meth:`FeatureViewSlice.with_name` (empty string disables prefixing).
    2. ``auto_prefix`` derived from ``"<fv_name>_<fv_version>_"``.
    3. No prefix.

    Args:
        feature_view: The :class:`FeatureView` or :class:`FeatureViewSlice`
            whose columns will be emitted under the resolved prefix.
        auto_prefix: When ``True`` and no explicit alias was set via
            :meth:`with_name`, derive the prefix from
            ``"<feature_view.name>_<feature_view.version>_"``.

    Returns:
        The prefix string with a trailing underscore, or ``None`` if no
        prefix should be applied.
    """
    if feature_view.column_alias is not None:
        if feature_view.column_alias == "":
            return None
        return f"{feature_view.column_alias}_"

    if auto_prefix:
        if isinstance(feature_view, FeatureViewSlice):
            return f"{feature_view.feature_view_ref.name}_{feature_view.feature_view_ref.version}_"
        return f"{feature_view.name}_{feature_view.version}_"

    return None


# OFT DDL builders shared by the per-FV path
# (FeatureStore._create_online_feature_table) and the per-FG path
# (FeatureStore.register_feature_group); kept here as the single source of
# truth for clause ordering, quoting, and WAREHOUSE precedence.


def build_oft_primary_key_clause(ordered_resolved_keys: list[str]) -> str:
    """Build a ``PRIMARY KEY (...)`` clause from already-resolved key names.

    Args:
        ordered_resolved_keys: Resolved (canonical) key names in the order
            they should appear in the primary key tuple. Must be unique;
            callers are responsible for de-duplicating beforehand.

    Returns:
        The ``PRIMARY KEY ("k1", "k2", ...)`` SQL fragment.
    """
    quoted = [f'"{k}"' for k in ordered_resolved_keys]
    return f"PRIMARY KEY ({', '.join(quoted)})"


def build_oft_warehouse_clause(
    feature_view_warehouse: Optional[SqlIdentifier],
    default_warehouse: Optional[SqlIdentifier],
) -> str:
    """Build the ``WAREHOUSE=...`` clause for ``CREATE ONLINE FEATURE TABLE``.

    Precedence: FV-level warehouse > FeatureStore default; empty when
    neither is set (HYBRID_TABLE OFTs do not require it).

    Args:
        feature_view_warehouse: Warehouse declared on the source FV, if any.
        default_warehouse: FeatureStore-level default warehouse, if any.

    Returns:
        ``WAREHOUSE=<wh>`` or an empty string.
    """
    if feature_view_warehouse:
        return f"WAREHOUSE={feature_view_warehouse}"
    if default_warehouse:
        return f"WAREHOUSE={default_warehouse}"
    return ""


def build_oft_create_sql(
    *,
    fully_qualified_oft_name: str,
    primary_key_clause: str,
    target_lag: str,
    source_clause: str,
    warehouse_clause: str = "",
    refresh_mode_clause: str = "",
    timestamp_clause: str = "",
    overwrite: bool = False,
) -> str:
    """Single source of truth for ``CREATE ONLINE FEATURE TABLE`` SQL.

    Clause order matters for the parser: ``PRIMARY KEY`` and the optional
    metadata clauses must precede ``TARGET_LAG``, which must precede
    ``FROM``.

    Args:
        fully_qualified_oft_name: ``DB.SCHEMA.OFT_NAME``.
        primary_key_clause: Pre-built ``PRIMARY KEY (...)`` fragment from
            :func:`build_oft_primary_key_clause`.
        target_lag: Target lag value (e.g. ``"0 seconds"``).
        source_clause: Either ``FROM <table>`` (HYBRID_TABLE) or
            ``FROM SPECIFICATION $$...$$`` (POSTGRES).
        warehouse_clause: Pre-built ``WAREHOUSE=...`` fragment, or empty.
        refresh_mode_clause: Pre-built ``REFRESH_MODE='...'`` fragment, or empty.
        timestamp_clause: Pre-built ``TIMESTAMP_COLUMN='...'`` fragment, or empty.
        overwrite: When ``True``, emits ``CREATE OR REPLACE``.

    Returns:
        The fully-formed ``CREATE [OR REPLACE] ONLINE FEATURE TABLE ...`` SQL.
    """
    overwrite_clause = "OR REPLACE " if overwrite else ""
    query_parts = [
        f"CREATE {overwrite_clause}ONLINE FEATURE TABLE {fully_qualified_oft_name}",
        primary_key_clause,
        refresh_mode_clause,
        timestamp_clause,
        warehouse_clause,
        f"TARGET_LAG='{target_lag}'",
        source_clause,
    ]
    return " ".join(p for p in query_parts if p)


def build_oft_set_tag_sql(
    fully_qualified_oft_name: str,
    fully_qualified_tag_name: str,
    tag_value_json: str,
) -> str:
    """Build the post-create ``ALTER ... SET TAG`` SQL.

    Args:
        fully_qualified_oft_name: ``DB.SCHEMA.OFT_NAME``.
        fully_qualified_tag_name: ``DB.SCHEMA.TAG_NAME``.
        tag_value_json: Pre-serialized tag value JSON string.

    Returns:
        The fully-formed ``ALTER ONLINE FEATURE TABLE ... SET TAG ...`` SQL.
    """
    return (
        f"ALTER ONLINE FEATURE TABLE {fully_qualified_oft_name} "
        f"SET TAG {fully_qualified_tag_name} = '{tag_value_json}'"
    )


def execute_oft_set_tag(
    session: Session,
    *,
    fully_qualified_oft_name: str,
    fully_qualified_tag_name: str,
    tag_value_json: str,
    statement_params: Optional[dict[str, Any]] = None,
) -> None:
    """Build + execute the ``ALTER ... SET TAG`` SQL.

    Split from :func:`build_oft_set_tag_sql` so tests can inspect the SQL
    string without exercising the session.

    Args:
        session: Snowpark session to ``.sql(...).collect(...)`` against.
        fully_qualified_oft_name: ``DB.SCHEMA.OFT_NAME``.
        fully_qualified_tag_name: ``DB.SCHEMA.TAG_NAME``.
        tag_value_json: Pre-serialized tag value JSON string.
        statement_params: Telemetry statement params forwarded to ``collect``.
    """
    sql = build_oft_set_tag_sql(
        fully_qualified_oft_name=fully_qualified_oft_name,
        fully_qualified_tag_name=fully_qualified_tag_name,
        tag_value_json=tag_value_json,
    )
    session.sql(sql).collect(statement_params=statement_params)


lineage_node.DOMAIN_LINEAGE_REGISTRY["feature_view"] = FeatureView
