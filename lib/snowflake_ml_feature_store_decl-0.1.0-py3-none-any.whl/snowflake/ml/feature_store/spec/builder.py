"""FeatureViewSpecBuilder — constructs validated JSON payloads for OFT creation specification.

This is the single entry point for internal SDK code to build feature view
specs.  Supports all :class:`FeatureViewKind` values; each kind has its own
required inputs (see ``_validate_*`` methods).

Example — StreamingFeatureView::

    spec_obj = (
        FeatureViewSpecBuilder(
            FeatureViewKind.StreamingFeatureView,
            database="DB", schema="SCH", name="my_fv", version="v1",
        )
        .set_sources([stream_source])
        .set_udf(name=..., engine=..., output_columns=[...], function_definition=...)
        .set_features([agg_spec_1, agg_spec_2])
        .set_properties(entity_columns=[...], timestamp_field=..., ...)
        .set_offline_configs([...])
        .build()
    )

Example — RealtimeFeatureView (no offline_configs, features come from UDF outputs)::

    # ``ordered_entity_column_names`` is derived from the upstream FVs in
    # ``set_sources``; passing ``entity_columns`` to ``set_properties`` is
    # rejected for RTFV / FeatureGroup.
    spec_obj = (
        FeatureViewSpecBuilder(FeatureViewKind.RealtimeFeatureView, ...)
        .set_sources([request_source, user_fv])
        .set_udf(name=..., engine=..., output_columns=[...], function_definition=...)
        .build()
    )

Example — FeatureGroup (FV sources only, features passthrough, optional prefixing)::

    spec_obj = (
        FeatureViewSpecBuilder(FeatureViewKind.FeatureGroup, ...)
        .set_sources([user_fv_v1, user_fv_v2, txn_fv])
        .set_source_prefixes({
            ("USER_FV", "v1"): "USER_FV_v1_",
            ("USER_FV", "v2"): "USER_FV_v2_",
            ("TXN_FV", "v1"): "TXN_FV_v1_",
        })
        .build()
    )
"""

from __future__ import annotations

import ast
from collections.abc import Iterable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional, Union

from snowflake.ml._internal.utils.sql_identifier import SqlIdentifier
from snowflake.ml.feature_store.aggregation import AggregationSpec, AggregationType
from snowflake.ml.feature_store.interval_utils import interval_to_seconds
from snowflake.ml.feature_store.request_source import RequestSource
from snowflake.ml.feature_store.spec.enums import (
    FeatureAggregationMethod,
    FeatureViewKind,
    SourceType,
    StoreType,
    TableType,
)
from snowflake.ml.feature_store.spec.models import (
    UDF,
    Feature,
    FeatureViewSpec,
    FSColumn,
    Metadata,
    OfflineTableConfig,
    Source,
    Spec,
    _columns_from_struct_type,
    _columns_from_tiled_struct_type,
    _make_fs_column,
    _make_tiled_fs_column,
)
from snowflake.ml.feature_store.stream_source import StreamSource
from snowflake.ml.version import VERSION
from snowflake.snowpark.types import DataType, StructType

if TYPE_CHECKING:
    from snowflake.ml.feature_store.feature_view import FeatureView, FeatureViewSlice
    from snowflake.snowpark import Session


@dataclass(frozen=True)
class SnowflakeTableInfo:
    """Describes a Snowflake table used for offline storage in a feature view.

    Passed to :meth:`FeatureViewSpecBuilder.set_offline_configs` to describe
    each offline table.  The builder converts the Snowpark ``StructType`` to
    internal column representations automatically.

    Attributes:
        table_type: Kind of offline table
            (``UDF_TRANSFORMED``, ``TILED``, or ``BATCH_SOURCE``).
        database: Database name.
        schema: Schema name.
        table: Physical table name.
        columns: Table schema as a Snowpark ``StructType``.
    """

    table_type: TableType
    database: str
    schema: str
    table: str
    columns: StructType


@dataclass(frozen=True)
class BatchSource:
    """Schema of the source table/query for a batch feature view.

    Wraps the StructType from the feature_df used to define the batch FV.
    Converted to an internal ``Source`` with ``source_type=BATCH`` during
    ``set_sources()``.  The builder uses the columns on the BATCH source
    to resolve feature column types during ``build()``.

    Attributes:
        schema: Snowpark StructType from the feature_df.
    """

    schema: StructType


# Aggregation functions supported by the Postgres (PG) online store backend.
# List aggregations are not implemented in the PG path, except the ordered-N
# family (last/first_distinct_n and last/first_n). The sketch aggregation
# APPROX_COUNT_DISTINCT is also supported, restricted to STRING source columns
# (enforced by _validate_pg_source_types).
_PG_SUPPORTED_AGGREGATIONS: frozenset[AggregationType] = frozenset(
    {
        AggregationType.SUM,
        AggregationType.MIN,
        AggregationType.MAX,
        AggregationType.COUNT,
        AggregationType.AVG,
        AggregationType.STD,
        AggregationType.VAR,
        AggregationType.APPROX_COUNT_DISTINCT,
        AggregationType.LAST_DISTINCT_N,
        AggregationType.FIRST_DISTINCT_N,
        AggregationType.LAST_N,
        AggregationType.FIRST_N,
    }
)

# Ordered-N aggregations gated for the Postgres online path: distinct (per-N
# columns) and non-distinct (shared columns). Both share the n-bound and
# source-type restrictions below.
_PG_ORDERED_N_AGGREGATIONS: frozenset[AggregationType] = frozenset(
    {
        AggregationType.LAST_DISTINCT_N,
        AggregationType.FIRST_DISTINCT_N,
        AggregationType.LAST_N,
        AggregationType.FIRST_N,
    }
)

# Upper bound on ``n`` for the ordered-N aggregations served by the Postgres
# online store.
_PG_ORDERED_N_MAX = 100

# Source column element types the Postgres online store can serve as ordered-N
# arrays (last/first_n and last/first_distinct_n). ``BinaryType`` is a valid
# scalar but is intentionally excluded: Quake does not support it as an array
# element type.
_PG_ORDERED_N_SOURCE_TYPES: frozenset[str] = frozenset(
    {
        "StringType",
        "LongType",
        "DoubleType",
        "DecimalType",
        "BooleanType",
        "TimestampType",
    }
)

# Aggregation functions whose output type is predetermined regardless of source type.
# Functions not listed here (SUM, MIN, MAX, LAST_N, etc.) preserve the source type.
_AGG_PREDETERMINED_OUTPUT: dict[AggregationType, FSColumn] = {
    # COUNT / APPROX_COUNT_DISTINCT produce NUMBER(38,0), which Snowpark
    # surfaces as LongType. DecimalType here would mismatch the upstream FV's
    # stored ArrayType<LongType> and be rejected by the exact-shape check.
    AggregationType.COUNT: FSColumn(name="", type="LongType"),
    AggregationType.APPROX_COUNT_DISTINCT: FSColumn(name="", type="LongType"),
    # AVG / STD / VAR / APPROX_PERCENTILE always produce a float.
    AggregationType.AVG: FSColumn(name="", type="DoubleType"),
    AggregationType.STD: FSColumn(name="", type="DoubleType"),
    AggregationType.VAR: FSColumn(name="", type="DoubleType"),
    AggregationType.APPROX_PERCENTILE: FSColumn(name="", type="DoubleType"),
}

# Source-preserving aggregations: output type is inherited from the corresponding
# ``_PARTIAL_<suffix>_<src>`` tile column.
_AGG_PARTIAL_TYPE_LOOKUP: dict[AggregationType, str] = {
    AggregationType.SUM: "SUM",
    AggregationType.MIN: "MIN",
    AggregationType.MAX: "MAX",
    AggregationType.LAST_N: "LAST",
    AggregationType.LAST_DISTINCT_N: "LAST",
    AggregationType.FIRST_N: "FIRST",
    AggregationType.FIRST_DISTINCT_N: "FIRST",
}


def _resolve_tiled_fv_output_column(
    spec: AggregationSpec,
    partials_by_name: dict[str, FSColumn],
) -> FSColumn:
    """Resolve the FSColumn an aggregation contributes when its tiled FV is an upstream source.

    Args:
        spec: The aggregation spec from the upstream FV.
        partials_by_name: ``_PARTIAL_*`` columns from the FV's ``output_schema``,
            keyed by name.

    Returns:
        FSColumn for the logical output of *spec*.

    Raises:
        ValueError: If the function has no resolution rule, or its expected
            ``_PARTIAL_*`` companion column is missing from *partials_by_name*.
    """
    predetermined = _AGG_PREDETERMINED_OUTPUT.get(spec.function)
    if predetermined is not None:
        return FSColumn(
            name=spec.output_column,
            type=predetermined.type,
            precision=predetermined.precision,
            scale=predetermined.scale,
            length=predetermined.length,
            timezone=predetermined.timezone,
        )
    partial_suffix = _AGG_PARTIAL_TYPE_LOOKUP.get(spec.function)
    if partial_suffix is None:
        raise ValueError(
            f"Cannot resolve output type for tiled feature view aggregation "
            f"'{spec.output_column}' (function={spec.function.value})."
        )
    partial_name = spec.get_tile_column_name(partial_suffix)
    partial = partials_by_name.get(partial_name)
    # LAST_DISTINCT_N / FIRST_DISTINCT_N use per-N tile column names in the new
    # tile format: _PARTIAL_{LAST|FIRST}_DISTINCT_{n}_{col}. Fall back to that
    # name when the old-format name (_PARTIAL_{LAST|FIRST}_{col}) is absent.
    if partial is None and spec.function in (AggregationType.LAST_DISTINCT_N, AggregationType.FIRST_DISTINCT_N):
        n = spec.params.get("n")
        new_partial_name = spec.get_tile_column_name(f"{partial_suffix}_DISTINCT_{n}")
        partial = partials_by_name.get(new_partial_name)
        if partial is not None:
            partial_name = new_partial_name
    if partial is None:
        raise ValueError(
            f"Cannot resolve output type for tiled feature view aggregation "
            f"'{spec.output_column}': expected tile column '{partial_name}' was "
            f"not found in the feature view's schema."
        )
    return FSColumn(
        name=spec.output_column,
        type=partial.type,
        precision=partial.precision,
        scale=partial.scale,
        length=partial.length,
        timezone=partial.timezone,
        element_type=partial.element_type,
    )


def _as_secondary_key_array_column(col: FSColumn) -> FSColumn:
    """Wrap a scalar aggregation output column as the ``ArrayType<scalar>`` a secondary-key FV materializes.

    Args:
        col: The scalar FSColumn resolved for the aggregation's logical output.

    Returns:
        An ``ArrayType`` FSColumn carrying ``col``'s scalar type as
        ``element_type`` and preserving precision/scale/length/timezone.
    """
    return FSColumn(
        name=col.name,
        type="ArrayType",
        element_type=col.type,
        precision=col.precision,
        scale=col.scale,
        length=col.length,
        timezone=col.timezone,
    )


# Type alias for the polymorphic source input
SourceInput = Union[StreamSource, RequestSource, "FeatureView", "FeatureViewSlice", BatchSource]

# Allowed upstream FV kinds when a FEATURES source is consumed by another FV.
_FG_ALLOWED_UPSTREAM_KINDS: frozenset[FeatureViewKind] = frozenset(
    {
        FeatureViewKind.StreamingFeatureView,
        FeatureViewKind.BatchFeatureView,
        FeatureViewKind.RealtimeFeatureView,
    }
)
_RTFV_ALLOWED_UPSTREAM_KINDS: frozenset[FeatureViewKind] = frozenset(
    {
        FeatureViewKind.StreamingFeatureView,
        FeatureViewKind.BatchFeatureView,
    }
)


class FeatureViewSpecBuilder:
    """Builds a validated FeatureView spec payload for the Go backend.

    Supports all :class:`FeatureViewKind` values: ``BatchFeatureView``,
    ``StreamingFeatureView``, ``RealtimeFeatureView``, and ``FeatureGroup``.
    All methods use the ``set_*`` convention. Accepts raw inputs — Snowpark types,
    StreamSource objects, user-facing Feature objects. Constructs spec-internal
    Pydantic models internally. Validates cross-model rules at ``build()`` time.
    """

    # Schema constants — bumped when the spec format changes
    _SPEC_FORMAT_VERSION = "1"
    _INTERNAL_DATA_VERSION = "1"

    def __init__(
        self,
        kind: FeatureViewKind,
        *,
        database: str,
        schema: str,
        name: str,
        version: str,
        session: Optional[Session] = None,
    ) -> None:
        """Initialize the builder with feature view identity and kind.

        Args:
            kind: The kind of feature view.
            database: Database name.
            schema: Schema name.
            name: Feature view name.
            version: Feature view version.
            session: Optional Snowpark session used to read upstream
                FeatureView column shapes from the materialized DT/View, so
                source column shapes match the upstream's stored
                ``OutputColumn`` for the Online Service exact-shape check.
                When ``None``, falls back to ``output_schema``.
        """
        self._kind = kind
        self._database = database
        self._schema = schema
        self._name = name
        self._version = version
        self._session = session

        # State — set by builder methods, consumed at build()
        self._offline_configs: list[OfflineTableConfig] = []
        self._sources: list[Source] = []
        self._agg_specs: list[AggregationSpec] = []
        self._udf: Optional[UDF] = None
        self._source_prefix_map: dict[tuple[str, Optional[str]], str] = {}
        # Upstream kind per FEATURES source, keyed by (name, source_version).
        # Populated and reset by set_sources; missing entries are skipped by
        # the upstream-kind validators.
        self._source_kinds: dict[tuple[str, Optional[str]], FeatureViewKind] = {}
        # First-seen union of upstream FVs' ``ordered_entity_columns`` across
        # FEATURES sources, in user-provided source order. Built inside
        # :meth:`set_sources` alongside ``self._sources``; used by RTFV / FG
        # as ``Spec.ordered_entity_column_names`` and as the entity-column
        # exclude set in :meth:`_resolve_passthrough_features`.
        self._derived_entity_columns: list[str] = []

        # Properties
        self._entity_columns: list[str] = []
        self._secondary_key_columns: Optional[list[str]] = None
        self._timestamp_field: Optional[str] = None
        self._granularity_sec: Optional[int] = None
        self._agg_method: Optional[FeatureAggregationMethod] = None
        self._target_lag_sec: Optional[int] = None

    # -----------------------------------------------------------------------
    # set_* methods
    # -----------------------------------------------------------------------

    def set_offline_configs(
        self,
        configs: list[SnowflakeTableInfo],
    ) -> FeatureViewSpecBuilder:
        """Set offline table configurations.

        Args:
            configs: List of :class:`SnowflakeTableInfo` describing each
                offline table.  The Snowpark ``StructType`` on each entry is
                converted to internal ``FSColumn`` representations automatically.

        Returns:
            self for method chaining.
        """
        self._offline_configs = []
        for cfg in configs:
            self._offline_configs.append(
                OfflineTableConfig(
                    store_type=StoreType.SNOWFLAKE,
                    table_type=cfg.table_type,
                    database=cfg.database,
                    schema=cfg.schema,
                    table=cfg.table,
                    columns=_columns_from_tiled_struct_type(cfg.columns),
                )
            )
        return self

    def set_properties(
        self,
        *,
        entity_columns: Optional[list[str]] = None,
        secondary_key_columns: Optional[list[str]] = None,
        timestamp_field: Optional[str] = None,
        granularity: Optional[str] = None,
        agg_method: Optional[FeatureAggregationMethod] = None,
        target_lag: Optional[str] = None,
    ) -> FeatureViewSpecBuilder:
        """Set core spec properties.

        Interval strings (e.g., ``'1h'``, ``'30s'``) are converted to integer
        seconds internally.

        ``entity_columns`` is required for Streaming and Batch feature views,
        where it defines the join keys. It must not be set for
        :class:`FeatureViewKind.RealtimeFeatureView` or
        :class:`FeatureViewKind.FeatureGroup`: those kinds derive their
        ordered entity columns from the upstream FEATURES sources at
        :meth:`build` time.

        Args:
            entity_columns: Ordered list of entity/join-key column names
                (Streaming/Batch only; must be ``None`` for RTFV/FG).
            secondary_key_columns: Optional ordered list of secondary aggregation
                key column names
            timestamp_field: Optional timestamp column name.
            granularity: Optional tile interval (e.g., ``"1h"``). Converted to seconds.
            agg_method: Optional aggregation method.
            target_lag: Optional target lag (e.g., ``"30s"``). Converted to seconds.

        Returns:
            self for method chaining.

        Raises:
            ValueError: If ``entity_columns`` or ``secondary_key_columns`` is
                provided for a :class:`FeatureViewKind.RealtimeFeatureView` or
                :class:`FeatureViewKind.FeatureGroup`.
        """
        if entity_columns is not None and self._kind in (
            FeatureViewKind.RealtimeFeatureView,
            FeatureViewKind.FeatureGroup,
        ):
            raise ValueError(
                f"{self._kind.value}.set_properties(entity_columns=...) is not allowed; "
                f"entity columns are derived from upstream FeatureView sources."
            )
        if secondary_key_columns is not None and self._kind in (
            FeatureViewKind.RealtimeFeatureView,
            FeatureViewKind.FeatureGroup,
        ):
            raise ValueError(
                f"{self._kind.value}.set_properties(secondary_key_columns=...) is not allowed; "
                f"secondary aggregation keys are only defined on Streaming/Batch feature views."
            )
        self._entity_columns = list(entity_columns) if entity_columns is not None else []
        self._secondary_key_columns = list(secondary_key_columns) if secondary_key_columns else None
        self._timestamp_field = timestamp_field
        self._granularity_sec = interval_to_seconds(granularity) if granularity else None
        self._agg_method = agg_method
        self._target_lag_sec = interval_to_seconds(target_lag) if target_lag else None
        return self

    def set_sources(
        self,
        sources: list[SourceInput],
    ) -> FeatureViewSpecBuilder:
        """Set data sources.

        Args:
            sources: List of source inputs (``StreamSource``, ``RequestSource``,
                ``FeatureView``, ``FeatureViewSlice``, or ``BatchSource``).

        Returns:
            self for method chaining.

        Raises:
            ValueError: If an unsupported source type is encountered.
        """
        # Lazy imports to avoid circular dependencies
        from snowflake.ml.feature_store.feature_view import (
            FeatureView,
            FeatureViewSlice,
        )

        self._sources = []
        self._source_kinds = {}
        self._derived_entity_columns = []

        for src in sources:
            if isinstance(src, BatchSource):
                self._sources.append(self._convert_batch_source(src))
            elif isinstance(src, StreamSource):
                self._sources.append(self._convert_stream_source(src))
            elif isinstance(src, RequestSource):
                self._sources.append(self._convert_request_source(src))
            elif isinstance(src, FeatureViewSlice):
                materialized_schema = self._resolve_materialized_schema(src.feature_view_ref)
                converted = self._convert_feature_view_slice(src, materialized_schema=materialized_schema)
                self._sources.append(converted)
                key = (converted.name, converted.source_version)
                self._source_kinds[key] = FeatureViewSpecBuilder._kind_of_fv(src.feature_view_ref)
                self._append_derived_entity_columns(src.feature_view_ref.ordered_entity_columns)
            elif isinstance(src, FeatureView):
                materialized_schema = self._resolve_materialized_schema(src)
                converted = self._convert_feature_view(src, materialized_schema=materialized_schema)
                self._sources.append(converted)
                key = (converted.name, converted.source_version)
                self._source_kinds[key] = FeatureViewSpecBuilder._kind_of_fv(src)
                self._append_derived_entity_columns(src.ordered_entity_columns)
            else:
                raise ValueError(f"Unsupported source type: {type(src).__name__}")
        return self

    def _resolve_materialized_schema(self, fv: FeatureView) -> Optional[StructType]:
        """Return the upstream FeatureView's materialized DT/View schema, or None to fall back to ``fv.output_schema``.

        Returns ``None`` when no session is available, or for source kinds whose
        stored shapes do not come from a DT describe:

          - RTFVs have no backing DT / View.
          - Tiled FVs expose columns derived from aggregation specs.
          - Streaming FVs' stored shapes come from ``feature_df`` (the
            authoring view); a downstream source must use the same
            ``output_schema`` to stay in lock-step.

        Args:
            fv: The upstream FeatureView source.

        Returns:
            The materialized Snowpark ``StructType``, or ``None`` to fall back.

        Raises:
            ValueError: If the upstream's materialized table cannot be read
                (e.g. its Dynamic Table has not finished its initial refresh).
        """
        if self._session is None:
            return None
        if fv.realtime_config is not None:
            return None
        if fv.is_tiled or fv.is_streaming:
            return None
        from snowflake.snowpark.exceptions import SnowparkSQLException

        try:
            schema = self._session.table(fv.fully_qualified_name()).schema
        except SnowparkSQLException as e:
            raise ValueError(
                f"feature retrieval: could not read the materialized schema of upstream feature view "
                f"'{fv.name}' (version '{fv.version}'). Its dynamic table may not have "
                f"completed its initial refresh yet; retry once it is ready."
            ) from e
        return schema if isinstance(schema, StructType) else None

    def _append_derived_entity_columns(self, cols: Iterable[str]) -> None:
        """Append upstream entity columns to ``self._derived_entity_columns``.

        Preserves first-seen order across calls (dedup against what's already
        been collected from earlier FEATURES sources in the same
        :meth:`set_sources` invocation).

        Args:
            cols: Entity column names from a single upstream FeatureView
                (typically ``fv.ordered_entity_columns``).
        """
        seen = set(self._derived_entity_columns)
        for col in cols:
            if col not in seen:
                seen.add(col)
                self._derived_entity_columns.append(col)

    @staticmethod
    def _kind_of_fv(fv: FeatureView) -> FeatureViewKind:
        """Map a user-facing FeatureView to its spec FeatureViewKind.

        Realtime takes precedence over streaming/batch because the realtime
        path is what distinguishes RTFVs from a hypothetical SFV that also
        sets ``realtime_config`` (which the constructor rejects, but the
        check here makes the dispatch self-evidently correct).

        FeatureGroup is dispatched by a separate type (not a FeatureView)
        and never flows through this helper.

        Args:
            fv: A user-facing FeatureView.

        Returns:
            The spec FeatureViewKind that this FV represents.
        """
        if fv.is_realtime_feature_view:
            return FeatureViewKind.RealtimeFeatureView
        if fv.is_streaming:
            return FeatureViewKind.StreamingFeatureView
        return FeatureViewKind.BatchFeatureView

    _SUPPORTED_UDF_ENGINES: frozenset[str] = frozenset({"pandas"})

    def set_udf(
        self,
        *,
        name: str,
        engine: str,
        output_columns: list[tuple[str, DataType]],
        function_definition: str,
    ) -> FeatureViewSpecBuilder:
        """Set the UDF transform.

        The ``function_definition`` is stored as plain text. SQL ``$$`` quoting
        is handled during serialization.

        Args:
            name: UDF name.
            engine: Execution engine. Currently only ``"pandas"`` is supported.
            output_columns: List of (name, Snowpark DataType) pairs.
            function_definition: The UDF source code (plain text).

        Returns:
            self for method chaining.

        Raises:
            ValueError: If *engine* is not a supported value.
        """
        if engine not in self._SUPPORTED_UDF_ENGINES:
            raise ValueError(
                f"Unsupported UDF engine '{engine}'. Supported engines: {sorted(self._SUPPORTED_UDF_ENGINES)}"
            )
        fs_columns = [_make_fs_column(n, dt) for n, dt in output_columns]
        self._udf = UDF(
            name=name,
            engine=engine,
            output_columns=fs_columns,
            function_definition=function_definition,
        )
        return self

    def set_features(
        self,
        features: list[AggregationSpec],
    ) -> FeatureViewSpecBuilder:
        """Set features from AggregationSpec objects.

        Column types are resolved from sources/UDF outputs at ``build()`` time.

        Args:
            features: List of :class:`AggregationSpec` instances describing
                each feature's aggregation function, source column, window, etc.

        Returns:
            self for method chaining.
        """
        self._agg_specs = features
        return self

    def set_source_prefixes(
        self,
        prefix_map: dict[tuple[str, Optional[str]], str],
    ) -> FeatureViewSpecBuilder:
        """Set per-source column prefixes for FeatureGroup output column naming.

        Only meaningful for ``FeatureViewKind.FeatureGroup``; ignored for
        other kinds.  When resolving passthrough features, columns from
        sources listed in *prefix_map* have their ``output_column.name``
        prefixed with the given string while ``source_column.name`` retains
        the original upstream column name.  Sources not present in the map
        (or mapped to an empty string) get no prefix.

        Keys are ``(source_name, source_version)`` tuples so that distinct
        versions of the same upstream feature view (e.g., ``USER_FV@v1`` and
        ``USER_FV@v2``) can be disambiguated with different prefixes.
        ``source_version`` mirrors :attr:`Source.source_version` and will be
        a non-None string for FEATURES sources in a FeatureGroup.

        Args:
            prefix_map: Mapping from ``(source_name, source_version)`` to
                prefix string including trailing underscore (e.g.,
                ``{("USER_FV", "v1"): "USER_FV_v1_"}``). Omit an entry or use
                an empty string for explicit no-prefix.

        Returns:
            self for method chaining.
        """
        self._source_prefix_map = dict(prefix_map)
        return self

    # -----------------------------------------------------------------------
    # build
    # -----------------------------------------------------------------------

    def build(self) -> FeatureViewSpec:
        """Validate all rules and construct the typed spec model.

        Returns:
            FeatureViewSpec instance.  Call ``.to_dict()`` or
            ``.to_json()`` to serialize.

        Raises:
            ValueError: If validation fails.  # noqa: DAR402
        """
        # 1. Cross-model validation
        self._validate()

        # 2. Resolve user features → spec features
        spec_features = self._resolve_features()

        # 2a. Validate PG source type constraints (needs resolved features).
        self._validate_pg_source_types(spec_features)

        # 2b. Reject duplicate output column names (e.g., unprefixed
        #     FeatureGroup sources that expose the same feature name).
        self._validate_unique_output_columns(spec_features)

        # 2c. Stamp exact element types onto the distinct-N partial columns in
        #     the offline configs. The physical tile arrays are untyped
        #     (ARRAY_AGG), so element_type must come from the spec, not storage.
        self._apply_distinct_partial_element_types(spec_features)

        # 3. Auto-populate metadata
        metadata = Metadata(
            database=self._database,
            schema=self._schema,
            name=self._name,
            version=self._version,
            spec_format_version=self._SPEC_FORMAT_VERSION,
            internal_data_version=self._INTERNAL_DATA_VERSION,
            client_version=VERSION,
        )

        # 4. Construct spec — filter out BATCH sources (builder-internal only).
        external_sources = [s for s in self._sources if s.source_type != SourceType.BATCH]
        if self._kind in (FeatureViewKind.RealtimeFeatureView, FeatureViewKind.FeatureGroup):
            ordered_entity_column_names = self._derived_entity_columns
        else:
            ordered_entity_column_names = self._entity_columns
        spec = Spec(
            ordered_entity_column_names=ordered_entity_column_names,
            ordered_secondary_key_column_names=self._secondary_key_columns,
            sources=external_sources,
            features=spec_features,
            timestamp_field=self._timestamp_field,
            feature_granularity_sec=self._granularity_sec,
            feature_aggregation_method=self._agg_method,
            udf=self._udf,
            target_lag_sec=self._target_lag_sec,
        )

        # 5. Construct and return root
        return FeatureViewSpec(
            kind=self._kind,
            metadata=metadata,
            offline_configs=self._offline_configs,
            spec=spec,
            online_store_type=StoreType.POSTGRES,
        )

    # -----------------------------------------------------------------------
    # Source conversion helpers
    # -----------------------------------------------------------------------

    @staticmethod
    def _convert_batch_source(src: BatchSource) -> Source:
        """Convert a BatchSource to a spec Source with source_type=BATCH."""
        return Source(
            name="batch",
            source_type=SourceType.BATCH,
            columns=_columns_from_struct_type(src.schema),
        )

    @staticmethod
    def _convert_stream_source(src: StreamSource) -> Source:
        """Convert a StreamSource to a spec Source."""
        return Source(
            name=src.name.resolved(),
            source_type=SourceType.STREAM,
            columns=_columns_from_struct_type(src.schema),
        )

    @staticmethod
    def _convert_request_source(src: RequestSource) -> Source:
        """Convert a RequestSource to a spec Source."""
        return Source(
            name="request",
            source_type=SourceType.REQUEST,
            columns=_columns_from_struct_type(src.schema),
        )

    @staticmethod
    def _columns_from_feature_view(fv: FeatureView, materialized_schema: Optional[StructType] = None) -> list[FSColumn]:
        """Extract feature columns from a FeatureView's output schema.

        RTFV sources rehydrate with an empty ``_feature_desc`` (so
        :attr:`FeatureView.feature_names` returns ``[]``); fall back to the
        canonical ``realtime_config.output_schema`` minus the RTFV's own
        entity columns. The FeatureGroup passthrough path additionally
        drops the FG's superset primary key from this list before emitting
        spec features.

        For tiled FVs the columns are derived from ``aggregation_specs`` because
        ``output_schema`` exposes ``_PARTIAL_*`` tile columns, not the FV's logical
        aggregation outputs. A secondary-key FV (``aggregation_secondary_keys``)
        additionally wraps each value aggregation as ``ArrayType<scalar>`` and emits
        the companion ``<SK>_KEYS_<window>`` keys array (also ``ArrayType<scalar>``)
        so the columns match the upstream FV's stored ``OutputColumn`` for the Online
        Service exact-shape check. Without the keys array the value arrays cannot be
        mapped back to their secondary-key values.

        For non-tiled, non-RTFV sources, when ``materialized_schema`` is
        provided, column shapes are read from it instead of the authoring-time
        ``output_schema`` so they match the upstream FV's stored
        ``OutputColumn`` for the Online Service exact-shape check.

        Args:
            fv: The FeatureView whose feature columns to extract.
            materialized_schema: Optional materialized DT/View schema. Only
                consulted for the non-tiled, non-RTFV branch.

        Returns:
            FSColumns for the source's feature columns, in declaration order.

        Raises:
            ValueError: If a tiled secondary-key FV's keys array references a
                secondary-key column absent from the tiled schema.
        """
        if fv.realtime_config is not None:
            entity_names = set(fv.ordered_entity_columns)
            return [
                _make_fs_column(f.name, f.datatype)
                for f in fv.realtime_config.output_schema.fields
                if f.name not in entity_names
            ]
        if fv.is_tiled and fv.aggregation_specs is not None:
            partials_by_name = {f.name: _make_tiled_fs_column(f.name, f.datatype) for f in fv.output_schema.fields}
            has_secondary_key = bool(fv.aggregation_secondary_keys)
            columns: list[FSColumn] = []
            for spec in fv.aggregation_specs:
                if spec.function.is_secondary_key_array():
                    # Keys array has no _PARTIAL_* companion; its element type is
                    # the secondary-key column, which the tiled DT exposes directly.
                    sk_column = partials_by_name.get(spec.source_column)
                    if sk_column is None:
                        raise ValueError(
                            f"feature retrieval: secondary aggregation key column "
                            f"'{spec.source_column}' was not found in feature view "
                            f"'{fv.name.resolved()}'; its keys array cannot be built."
                        )
                    columns.append(
                        _as_secondary_key_array_column(sk_column.model_copy(update={"name": spec.output_column}))
                    )
                    continue
                resolved = _resolve_tiled_fv_output_column(spec, partials_by_name)
                if has_secondary_key:
                    resolved = _as_secondary_key_array_column(resolved)
                columns.append(resolved)
            return columns
        feature_name_set = {fn.resolved() for fn in fv.feature_names}
        schema = materialized_schema if materialized_schema is not None else fv.output_schema
        return [_make_fs_column(f.name, f.datatype) for f in schema.fields if f.name in feature_name_set]

    @staticmethod
    def _convert_feature_view(fv: FeatureView, materialized_schema: Optional[StructType] = None) -> Source:
        """Convert a FeatureView to a spec Source with source_type=FEATURES."""
        return Source(
            name=fv.name.resolved(),
            source_type=SourceType.FEATURES,
            columns=FeatureViewSpecBuilder._columns_from_feature_view(fv, materialized_schema),
            source_version=str(fv.version) if fv.version else None,
        )

    @staticmethod
    def _convert_feature_view_slice(fvs: FeatureViewSlice, materialized_schema: Optional[StructType] = None) -> Source:
        """Convert a FeatureViewSlice to a spec Source containing only the selected columns.

        The slice's caller-requested feature order is preserved in ``columns``.
        Selected names that don't appear in the upstream FV's exposed schema
        are silently dropped (matching prior selected-features semantics).

        Args:
            fvs: The feature view slice to convert.
            materialized_schema: Optional materialized DT/View schema,
                forwarded to :meth:`_columns_from_feature_view`.

        Returns:
            A FEATURES Source whose ``columns`` are exactly the slice's selected
            columns, in the slice's requested order.
        """
        fv = fvs.feature_view_ref
        all_cols = FeatureViewSpecBuilder._columns_from_feature_view(fv, materialized_schema)
        col_by_name = {c.name: c for c in all_cols}
        selected_cols = [col_by_name[n.resolved()] for n in fvs.names if n.resolved() in col_by_name]
        return Source(
            name=fv.name.resolved(),
            source_type=SourceType.FEATURES,
            columns=selected_cols,
            source_version=str(fv.version) if fv.version else None,
        )

    # -----------------------------------------------------------------------
    # Feature resolution
    # -----------------------------------------------------------------------

    def _find_offline_config(self, table_type: TableType) -> Optional[OfflineTableConfig]:
        """Return the first offline config matching *table_type*, or ``None``."""
        for cfg in self._offline_configs:
            if cfg.table_type == table_type:
                return cfg
        return None

    def _find_batch_source(self) -> Optional[Source]:
        """Return the first BATCH source, or ``None``."""
        for src in self._sources:
            if src.source_type == SourceType.BATCH:
                return src
        return None

    def _get_feature_input_columns(self) -> list[FSColumn]:
        """Return the pipeline-stage columns that features aggregate over.

        Which columns serve as input depends on the FV kind:
          - **Streaming**: UDF_TRANSFORMED offline config columns.
          - **Batch tiled**: BATCH source columns (from ``BatchSource``
            passed via ``set_sources``).
          - **Batch non-tiled**: BATCH_SOURCE offline config columns.
          - **Realtime**: not supported (no aggregation features).

        Returns:
            List of FSColumn instances from the appropriate pipeline stage.

        Raises:
            ValueError: If the required column pool is not available.
        """
        if self._kind == FeatureViewKind.StreamingFeatureView:
            config = self._find_offline_config(TableType.UDF_TRANSFORMED)
            if config is None:
                raise ValueError("Streaming FV with features requires a " "UDF_TRANSFORMED offline config")
            return config.columns

        if self._kind == FeatureViewKind.BatchFeatureView:
            if self._agg_method is not None:
                # Tiled batch: features aggregate over the FV source table
                batch_src = self._find_batch_source()
                if batch_src is None or not batch_src.columns:
                    raise ValueError(
                        "Batch tiled FV requires the FV source schema " "(pass a BatchSource in set_sources)"
                    )
                return batch_src.columns
            # Non-tiled batch: input = output = BATCH_SOURCE
            config = self._find_offline_config(TableType.BATCH_SOURCE)
            if config is None:
                raise ValueError("Batch FV with features requires a " "BATCH_SOURCE offline config")
            return config.columns

        raise ValueError(f"{self._kind.value} does not support aggregation features")

    def _resolve_features(self) -> list[Feature]:
        """Convert AggregationSpecs to spec-internal Feature models.

        Column types are resolved from a pipeline-specific column pool
        determined by :meth:`_get_feature_input_columns`.

        Returns:
            List of spec-internal Feature models.

        Raises:
            ValueError: If a feature references a column not in the resolution pool.
        """
        if not self._agg_specs:
            return self._resolve_passthrough_features()

        resolve_columns = self._get_feature_input_columns()
        column_map: dict[str, FSColumn] = {col.name: col for col in resolve_columns}

        spec_features = []
        for agg_spec in self._agg_specs:
            source_col = column_map.get(agg_spec.source_column)
            if source_col is None:
                raise ValueError(
                    f"Column '{agg_spec.source_column}' not found in "
                    f"resolution pool. Available columns: "
                    f"{list(column_map.keys())}"
                )

            is_secondary_key_array = agg_spec.function.is_secondary_key_array()

            # On a secondary-key FV every per-feature value is served as one
            # element per SK bucket; the server reads output_column.type as the
            # COALESCE fallback for array_agg(...)
            type_template: FSColumn = _AGG_PREDETERMINED_OUTPUT.get(agg_spec.function) or source_col
            output_is_array = bool(self._secondary_key_columns) or agg_spec.function.is_list()
            output_col = FSColumn(
                name=agg_spec.output_column,
                type="ArrayType" if output_is_array else type_template.type,
                element_type=type_template.type if output_is_array else None,
                precision=type_template.precision,
                scale=type_template.scale,
                length=type_template.length,
                timezone=type_template.timezone,
            )

            # interval_to_seconds() returns -1 as a sentinel for lifetime
            # windows.  Convert non-positive values to None so they are
            # omitted (omitempty).
            raw_window = agg_spec.get_window_seconds()
            window_sec = raw_window if raw_window > 0 else None

            raw_offset = interval_to_seconds(agg_spec.offset) if agg_spec.offset != "0" else 0
            offset_sec = raw_offset if raw_offset > 0 else None

            function_value: Optional[str] = None if is_secondary_key_array else agg_spec.function.value

            spec_features.append(
                Feature(
                    source_column=source_col,
                    output_column=output_col,
                    function=function_value,
                    window_sec=window_sec,
                    offset_sec=offset_sec,
                    function_params=(agg_spec.params if agg_spec.params else None),
                )
            )
        return spec_features

    def _resolve_passthrough_features(self) -> list[Feature]:
        """Auto-generate identity features for FVs without time-aggregated features.

        Each non-entity column (and, where applicable, non-timestamp column)
        in the appropriate source becomes a passthrough feature with no
        aggregation function or window.  By default ``source_column`` and
        ``output_column`` are the same; the FeatureGroup path may rename
        ``output_column`` via :meth:`set_source_prefixes`.

        The source is determined explicitly by kind:
          - **Batch**: ``BATCH_SOURCE`` offline config.
          - **Streaming**: ``UDF_TRANSFORMED`` offline config.
          - **Realtime**: UDF's ``output_columns``.
          - **FeatureGroup**: union of columns from all ``FEATURES`` sources,
            with ``output_column.name`` optionally prefixed per source via
            :meth:`set_source_prefixes`.  Entity columns are not present in
            ``source.columns`` in production flows (they are filtered out by
            ``_convert_feature_view``); the exclude check is defensive.

        Returns:
            List of passthrough Feature models, or empty list if the
            appropriate source is not present.

        Raises:
            ValueError: If the feature view kind does not support
                passthrough feature resolution.  # noqa: DAR402
        """
        if self._kind == FeatureViewKind.BatchFeatureView:
            config = self._find_offline_config(TableType.BATCH_SOURCE)
            if config is None:
                return []
            exclude: set[str] = set(self._entity_columns)
            if self._timestamp_field:
                exclude.add(self._timestamp_field)
            return [Feature(source_column=col, output_column=col) for col in config.columns if col.name not in exclude]

        elif self._kind == FeatureViewKind.StreamingFeatureView:
            config = self._find_offline_config(TableType.UDF_TRANSFORMED)
            if config is None:
                return []
            exclude = set(self._entity_columns)
            if self._timestamp_field:
                exclude.add(self._timestamp_field)
            return [Feature(source_column=col, output_column=col) for col in config.columns if col.name not in exclude]

        elif self._kind == FeatureViewKind.RealtimeFeatureView:
            # RealtimeFV has no timestamp_field (validated in _validate_realtime).
            if self._udf is None:
                return []
            exclude = set(self._derived_entity_columns)
            return [
                Feature(source_column=col, output_column=col)
                for col in self._udf.output_columns
                if col.name not in exclude
            ]

        elif self._kind == FeatureViewKind.FeatureGroup:
            # FeatureGroup has no timestamp_field (validated in _validate_feature_group).
            # ``source.columns`` already represents the caller's selection in
            # their requested order (slice projection happens at conversion time).
            exclude = set(self._derived_entity_columns)
            spec_features: list[Feature] = []
            for source in self._sources:
                if source.source_type != SourceType.FEATURES:
                    continue
                prefix = self._source_prefix_map.get((source.name, source.source_version), "")
                for col in source.columns:
                    if col.name in exclude:
                        continue
                    if prefix:
                        output_col = col.model_copy(update={"name": f"{prefix}{col.name}"})
                    else:
                        output_col = col
                    spec_features.append(
                        Feature(
                            source_column=col,
                            output_column=output_col,
                            source_name=source.name,
                            source_version=source.source_version,
                        )
                    )
            return spec_features

        raise ValueError(f"Passthrough features are not supported for kind: {self._kind.value}")

    # -----------------------------------------------------------------------
    # Validation
    # -----------------------------------------------------------------------

    def _validate(self) -> None:
        """Cross-model validation. Raises ValueError on rule violations."""
        kind = self._kind
        table_types = [c.table_type for c in self._offline_configs]
        source_types = [s.source_type for s in self._sources]

        if kind == FeatureViewKind.StreamingFeatureView:
            self._validate_streaming(table_types, source_types)
        elif kind == FeatureViewKind.BatchFeatureView:
            self._validate_batch(table_types, source_types)
        elif kind == FeatureViewKind.RealtimeFeatureView:
            self._validate_realtime(source_types)
        elif kind == FeatureViewKind.FeatureGroup:
            self._validate_feature_group(source_types)
        else:
            raise ValueError(f"No validator wired up for FeatureViewKind: {kind.value}")

        # PG online store only supports a subset of aggregation functions.
        self._validate_pg_aggregations()

        # Source field validation (applies to all kinds)
        self._validate_source_fields()

    def _validate_streaming(self, table_types: list[TableType], source_types: list[SourceType]) -> None:
        """Validate rules specific to StreamingFeatureView."""
        # UDFTransformed always required
        if TableType.UDF_TRANSFORMED not in table_types:
            raise ValueError("StreamingFeatureView requires a UDFTransformed offline config")

        if self._agg_method is not None:
            # tiles or continuous → 2 configs: UDFTransformed + Tiled
            if len(self._offline_configs) != 2:
                raise ValueError(
                    f"StreamingFeatureView with agg_method={self._agg_method.value} "
                    f"requires 2 offline configs (UDFTransformed + Tiled), "
                    f"got {len(self._offline_configs)}"
                )
            if TableType.TILED not in table_types:
                raise ValueError(
                    f"StreamingFeatureView with agg_method={self._agg_method.value} " f"requires a Tiled offline config"
                )
            if self._granularity_sec is None:
                raise ValueError(f"granularity_sec is required when agg_method is " f"{self._agg_method.value}")
        else:
            # No aggregation → 1 config: UDFTransformed only
            if len(self._offline_configs) != 1:
                raise ValueError(
                    "StreamingFeatureView with no agg_method requires 1 offline "
                    f"config (UDFTransformed), got {len(self._offline_configs)}"
                )
            if self._granularity_sec is not None:
                raise ValueError("granularity_sec must be None when agg_method is None")

        # Exactly 1 Stream source
        if len(self._sources) != 1 or source_types != [SourceType.STREAM]:
            raise ValueError("StreamingFeatureView requires exactly 1 Stream source")

        # UDF required
        if self._udf is None:
            raise ValueError("StreamingFeatureView requires a UDF")
        self._validate_udf_signature()

        # Timestamp required
        if self._timestamp_field is None:
            raise ValueError("StreamingFeatureView requires a timestamp_field")

    def _validate_batch(self, table_types: list[TableType], source_types: list[SourceType]) -> None:
        """Validate rules specific to BatchFeatureView."""
        if len(self._offline_configs) != 1:
            raise ValueError("BatchFeatureView requires exactly 1 offline config")
        if table_types != [TableType.BATCH_SOURCE]:
            raise ValueError("BatchFeatureView requires exactly 1 BatchSource offline config")

        # No UDF
        if self._udf is not None:
            raise ValueError("BatchFeatureView must not have a UDF")

        # agg_method: tiles or None
        if self._agg_method is not None and self._agg_method != FeatureAggregationMethod.TILES:
            raise ValueError(f"BatchFeatureView agg_method must be 'tiles' or None, " f"got {self._agg_method.value}")

        # Tiled vs non-tiled: different granularity + source rules
        if self._agg_method == FeatureAggregationMethod.TILES:
            if self._granularity_sec is None:
                raise ValueError("granularity_sec is required when agg_method is tiles")
            # Tiled: requires exactly 1 Batch source (raw events schema)
            if len(self._sources) != 1 or source_types != [SourceType.BATCH]:
                raise ValueError("Tiled BatchFeatureView requires exactly 1 Batch source")
        else:
            if self._granularity_sec is not None:
                raise ValueError("granularity_sec must be None when agg_method is None")
            # Non-tiled: no sources needed (features == offline table columns)
            if self._sources:
                raise ValueError("Non-tiled BatchFeatureView must not have sources")

    def _validate_realtime(self, source_types: list[SourceType]) -> None:
        """Validate rules specific to RealtimeFeatureView.

        RealtimeFeatureView rules:
          - No offline configs (computed at request time)
          - At least 1 Features source; at most 1 Request source (when
            present, it must be at position 0); no Stream/Batch
          - UDF required; features are derived from its output_columns
          - No aggregation (no agg_method, no granularity_sec, no agg features)
          - No timestamp_field
          - Each FEATURES source's upstream FV kind (when known) must be
            ``StreamingFeatureView`` or ``BatchFeatureView`` — RTFV does not
            support chaining (RTFV-on-RTFV) or FeatureGroup upstreams.

        Args:
            source_types: Source types present on the builder.

        Raises:
            ValueError: If any RealtimeFeatureView rule is violated.  # noqa: DAR402
        """
        if len(self._offline_configs) != 0:
            raise ValueError("RealtimeFeatureView must not have offline configs")

        request_count = source_types.count(SourceType.REQUEST)
        if request_count > 1:
            raise ValueError(f"RealtimeFeatureView allows at most 1 Request source, got {request_count}")
        if SourceType.STREAM in source_types:
            raise ValueError("RealtimeFeatureView must not have Stream sources")
        if SourceType.BATCH in source_types:
            raise ValueError("RealtimeFeatureView must not have Batch sources")
        if request_count == 1 and self._sources[0].source_type != SourceType.REQUEST:
            raise ValueError(
                "RealtimeFeatureView requires the Request source to be first in "
                "sources[] (its data is bound to the UDF's first positional argument)."
            )
        if source_types.count(SourceType.FEATURES) < 1:
            raise ValueError("RealtimeFeatureView requires at least 1 Features source (an upstream FeatureView).")

        if self._udf is None:
            raise ValueError("RealtimeFeatureView requires a UDF")

        if self._agg_method is not None:
            raise ValueError("RealtimeFeatureView must not have an agg_method")
        if self._granularity_sec is not None:
            raise ValueError("RealtimeFeatureView must not have granularity_sec")
        if self._agg_specs:
            raise ValueError("RealtimeFeatureView must not have aggregation features (set_features)")
        if self._timestamp_field is not None:
            raise ValueError("RealtimeFeatureView must not have a timestamp_field")

        self._validate_features_upstream_kinds(
            allowed_kinds=_RTFV_ALLOWED_UPSTREAM_KINDS,
            consumer_label="RealtimeFeatureView",
            allowed_label="StreamingFeatureView, BatchFeatureView",
            extra_hint="RealtimeFeatureView does not support chaining or FeatureGroup upstreams.",
        )

        self._validate_udf_signature()

    def _validate_feature_group(self, source_types: list[SourceType]) -> None:
        """Validate rules specific to FeatureGroup.

        FeatureGroup rules:
          - No offline configs (reads from upstream FVs' storage)
          - At least 1 source, all must be FEATURES type
          - No UDF
          - No aggregation (no agg_method, no granularity_sec, no agg features)
          - No timestamp_field
          - No target_lag_sec (FG inherits freshness from its upstream FVs)
          - Each FEATURES source's upstream FV kind (when known) must be
            ``StreamingFeatureView``, ``BatchFeatureView``, or
            ``RealtimeFeatureView`` — FG-on-FG chaining is not supported.

        Args:
            source_types: Source types present on the builder.

        Raises:
            ValueError: If any FeatureGroup rule is violated.  # noqa: DAR402
        """
        if len(self._offline_configs) != 0:
            raise ValueError("FeatureGroup must not have offline configs")

        if not self._sources:
            raise ValueError("FeatureGroup requires at least 1 Features source")

        non_features = sorted({st.value for st in source_types if st != SourceType.FEATURES})
        if non_features:
            raise ValueError(f"FeatureGroup must only have Features sources, got disallowed types: {non_features}")

        if self._udf is not None:
            raise ValueError("FeatureGroup must not have a UDF")

        if self._agg_method is not None:
            raise ValueError("FeatureGroup must not have an agg_method")
        if self._granularity_sec is not None:
            raise ValueError("FeatureGroup must not have granularity_sec")
        if self._agg_specs:
            raise ValueError("FeatureGroup must not have aggregation features (set_features)")
        if self._timestamp_field is not None:
            raise ValueError("FeatureGroup must not have a timestamp_field")
        if self._target_lag_sec is not None:
            raise ValueError("FeatureGroup must not have target_lag_sec")

        self._validate_features_upstream_kinds(
            allowed_kinds=_FG_ALLOWED_UPSTREAM_KINDS,
            consumer_label="FeatureGroup",
            allowed_label="StreamingFeatureView, BatchFeatureView, RealtimeFeatureView",
            extra_hint="FeatureGroup chaining is not supported.",
        )

    def _validate_unique_output_columns(self, features: list[Feature]) -> None:
        """Reject specs whose resolved features contain duplicate output names.

        Duplicates can arise e.g. when two FeatureGroup sources expose a
        feature with the same name and no prefixing is applied, or when
        a prefix yields a name that collides with an existing one.

        Args:
            features: The resolved spec features to check.

        Raises:
            ValueError: If any output_column name appears more than once.
        """
        seen: set[str] = set()
        duplicates: list[str] = []
        for feat in features:
            name = feat.output_column.name
            if name in seen:
                duplicates.append(name)
            else:
                seen.add(name)
        if duplicates:
            hint = (
                " For FeatureGroup, use set_source_prefixes(...) to disambiguate features from different sources."
                if self._kind == FeatureViewKind.FeatureGroup
                else " Check your AggregationSpec output_column values for collisions."
            )
            raise ValueError(f"Duplicate output column name(s) in resolved features: {sorted(set(duplicates))}.{hint}")

    @staticmethod
    def _distinct_partial_column_names(agg_spec: AggregationSpec) -> Optional[tuple[str, str]]:
        """Return the (value, timestamp) partial column names for an ordered-N spec.

        Mirrors the tile-column naming emitted by the tile SQL generator so element
        types can be stamped onto the matching offline-config columns:
          - distinct-N (new format): ``_PARTIAL_(LAST|FIRST)_DISTINCT_<N>[_TS]_<COL>``
          - non-distinct last_n/first_n (shared, n-agnostic):
            ``_PARTIAL_(LAST|FIRST)[_TS]_<COL>``
        Returns ``None`` for non-ordered aggregations.

        Args:
            agg_spec: The aggregation spec to derive partial column names for.

        Returns:
            A ``(value_column, timestamp_column)`` tuple, or ``None`` if the spec
            is not a LAST/FIRST ordered-N aggregation.
        """
        resolved_src = SqlIdentifier(agg_spec.source_column).resolved()
        if agg_spec.function == AggregationType.LAST_DISTINCT_N:
            n = agg_spec.params["n"]
            return (
                f"_PARTIAL_LAST_DISTINCT_{n}_{resolved_src}",
                f"_PARTIAL_LAST_DISTINCT_{n}_TS_{resolved_src}",
            )
        if agg_spec.function == AggregationType.FIRST_DISTINCT_N:
            n = agg_spec.params["n"]
            return (
                f"_PARTIAL_FIRST_DISTINCT_{n}_{resolved_src}",
                f"_PARTIAL_FIRST_DISTINCT_{n}_TS_{resolved_src}",
            )
        # Non-distinct last_n/first_n reuse a shared, n-agnostic column pair.
        if agg_spec.function == AggregationType.LAST_N:
            return f"_PARTIAL_LAST_{resolved_src}", f"_PARTIAL_LAST_TS_{resolved_src}"
        if agg_spec.function == AggregationType.FIRST_N:
            return f"_PARTIAL_FIRST_{resolved_src}", f"_PARTIAL_FIRST_TS_{resolved_src}"
        return None

    def _apply_distinct_partial_element_types(self, spec_features: list[Feature]) -> None:
        """Set exact element types on distinct-N partial columns in offline configs.

        The physical tile columns are built with ``ARRAY_AGG`` and therefore have
        no usable element type when read back from storage. Quake's contract,
        however, requires the value array to carry the source column's scalar type
        and the companion timestamp array to be ``TimestampType``. We stamp those
        here from the resolved features (mirroring how secondary-key output columns
        derive ``element_type`` from the spec rather than from storage).

        Args:
            spec_features: Resolved spec-internal Feature models, aligned 1:1 with
                ``self._agg_specs``.
        """
        if not self._agg_specs:
            return

        element_types: dict[str, str] = {}
        for agg_spec, feat in zip(self._agg_specs, spec_features):
            names = self._distinct_partial_column_names(agg_spec)
            if names is None:
                continue
            value_col, ts_col = names
            element_types[value_col] = feat.source_column.type
            element_types[ts_col] = "TimestampType"

        if not element_types:
            return

        for config in self._offline_configs:
            for column in config.columns:
                element_type = element_types.get(column.name)
                if element_type is not None:
                    column.type = "ArrayType"
                    column.element_type = element_type

    def _validate_pg_aggregations(self) -> None:
        """Reject aggregation functions not supported by the PG online store."""
        if not self._agg_specs:
            return
        unsupported = [
            spec.function
            for spec in self._agg_specs
            if not spec.function.is_secondary_key_array() and spec.function not in _PG_SUPPORTED_AGGREGATIONS
        ]
        if unsupported:
            names = sorted({fn.value for fn in unsupported})
            allowed = sorted(fn.value for fn in _PG_SUPPORTED_AGGREGATIONS)
            raise ValueError(
                f"Unsupported aggregation(s) for Postgres online store: {names}. " f"Supported aggregations: {allowed}"
            )

        for spec in self._agg_specs:
            if spec.function in _PG_ORDERED_N_AGGREGATIONS:
                n = spec.params.get("n")
                if not isinstance(n, int) or not (1 <= n <= _PG_ORDERED_N_MAX):
                    raise ValueError(
                        f"{spec.function.value} on column '{spec.source_column}' has n={n}, "
                        f"which is not supported for Postgres online store. "
                        f"n must be between 1 and {_PG_ORDERED_N_MAX}."
                    )

    def _validate_pg_source_types(self, features: list[Feature]) -> None:
        """Reject source column types the PG online store cannot serve.

        This runs after feature resolution so that source column types are
        available.  Only fires for spec-builder invocations (Postgres OFT).

        - APPROX_COUNT_DISTINCT is limited to STRING source columns.
        - Distinct-N source columns must be one of the element types Quake can
          store/serve as a JSONB array (see ``_PG_ORDERED_N_SOURCE_TYPES``).

        Args:
            features: Resolved spec-internal Feature models.

        Raises:
            ValueError: If a feature uses a source column type unsupported for
                its aggregation on the Postgres online store.
        """
        for feat in features:
            if feat.function == AggregationType.APPROX_COUNT_DISTINCT.value:
                if feat.source_column.type != "StringType":
                    raise ValueError(
                        f"APPROX_COUNT_DISTINCT on column '{feat.source_column.name}' "
                        f"(type {feat.source_column.type}) is not supported for Postgres "
                        f"online store. Only STRING/TEXT source columns are allowed."
                    )
            elif feat.function in {fn.value for fn in _PG_ORDERED_N_AGGREGATIONS}:
                if feat.source_column.type not in _PG_ORDERED_N_SOURCE_TYPES:
                    allowed = sorted(_PG_ORDERED_N_SOURCE_TYPES)
                    raise ValueError(
                        f"{feat.function} on column '{feat.source_column.name}' "
                        f"(type {feat.source_column.type}) is not supported for Postgres "
                        f"online store. Supported source column types: {allowed}."
                    )

    def _validate_source_fields(self) -> None:
        """Validate that each source has the correct fields for its type."""
        for source in self._sources:
            if source.source_type == SourceType.STREAM:
                if not source.columns:
                    raise ValueError(f"Stream source '{source.name}' must have columns")
                if source.source_version is not None:
                    raise ValueError(f"Stream source '{source.name}' must not have " f"source_version")

            elif source.source_type == SourceType.REQUEST:
                if not source.columns:
                    raise ValueError(f"Request source '{source.name}' must have columns")
                if source.source_version is not None:
                    raise ValueError(f"Request source '{source.name}' must not have " f"source_version")

            elif source.source_type == SourceType.FEATURES:
                if not source.columns:
                    raise ValueError(f"Features source '{source.name}' must have columns")
                if source.source_version is None:
                    raise ValueError(f"Features source '{source.name}' requires " f"source_version")

            elif source.source_type == SourceType.BATCH:
                if not source.columns:
                    raise ValueError(f"Batch source '{source.name}' must have columns")
                if source.source_version is not None:
                    raise ValueError(f"Batch source '{source.name}' must not have " f"source_version")

    def _validate_features_upstream_kinds(
        self,
        *,
        allowed_kinds: frozenset[FeatureViewKind],
        consumer_label: str,
        allowed_label: str,
        extra_hint: str,
    ) -> None:
        """Reject FEATURES sources whose upstream FV kind is not allowed.

        Only sources registered through ``set_sources`` with a real
        ``FeatureView`` / ``FeatureViewSlice`` input have an entry in
        ``self._source_kinds``. Sources with no recorded kind are skipped
        so that test fixtures injecting raw ``Source`` objects continue
        to work without explicit kind annotations.

        Args:
            allowed_kinds: Permitted upstream FV kinds for this consumer.
            consumer_label: Human-readable label for the consumer kind
                (e.g., ``"FeatureGroup"``) used in the error message.
            allowed_label: Comma-separated list of permitted kind names
                used in the error message.
            extra_hint: Additional explanatory sentence appended to the
                error message.

        Raises:
            ValueError: If any FEATURES source has a recorded upstream
                kind that is not in *allowed_kinds*.
        """
        for source in self._sources:
            if source.source_type != SourceType.FEATURES:
                continue
            upstream_kind = self._source_kinds.get((source.name, source.source_version))
            if upstream_kind is None:
                continue
            if upstream_kind not in allowed_kinds:
                raise ValueError(
                    f"{consumer_label} upstream '{source.name}@{source.source_version}' "
                    f"has kind '{upstream_kind.value}'; allowed: {allowed_label}. "
                    f"{extra_hint}"
                )

    def _validate_udf_signature(self) -> None:
        """Validate that the UDF's signature matches the runtime positional contract.

        At inference / materialization time the runtime invokes the UDF with
        exactly one positional argument per ``self._sources`` entry, in
        ``sources[]`` order. This helper enforces that the provided
        ``function_definition`` exposes a top-level ``def`` matching
        ``udf.name`` whose signature is strictly positional, non-variadic,
        non-async, non-generator, and has the correct arity.

        Raises:
            ValueError: If the UDF source is unparsable, lacks a top-level
                ``def`` matching ``udf.name``, is async / a generator,
                uses ``*args`` / ``**kwargs`` / keyword-only args, or has an
                arity that doesn't match ``len(self._sources)``.
        """
        udf = self._udf
        assert udf is not None  # caller has already verified UDF presence
        try:
            tree = ast.parse(udf.function_definition)
        except SyntaxError as e:
            raise ValueError(f"UDF '{udf.name}' function_definition is not valid Python: {e.msg}") from e

        matches = [
            node
            for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == udf.name
        ]
        if not matches:
            raise ValueError(
                f"UDF '{udf.name}' function_definition must contain a top-level " f"'def {udf.name}(...)'."
            )
        if len(matches) > 1:
            raise ValueError(
                f"UDF '{udf.name}' function_definition contains multiple top-level "
                f"defs named '{udf.name}'; expected exactly one."
            )
        fn = matches[0]

        if isinstance(fn, ast.AsyncFunctionDef):
            raise ValueError(f"UDF '{udf.name}' must not be async.")

        for node in ast.walk(fn):
            if isinstance(node, (ast.Yield, ast.YieldFrom)):
                raise ValueError(f"UDF '{udf.name}' must not be a generator.")

        args = fn.args
        if args.vararg is not None:
            raise ValueError(f"UDF '{udf.name}' must not use *args.")
        if args.kwarg is not None:
            raise ValueError(f"UDF '{udf.name}' must not use **kwargs.")
        if args.kwonlyargs:
            raise ValueError(f"UDF '{udf.name}' must not use keyword-only args.")

        expected = len(self._sources)
        actual = len(args.args) + len(args.posonlyargs)
        if actual != expected:
            raise ValueError(
                f"UDF '{udf.name}' has {actual} positional argument(s) but the "
                f"feature view has {expected} source(s). The UDF receives one "
                f"positional argument per source, in sources[] order."
            )
