"""Minimal feature_store package for the decl wheel.

This stub replaces the original ``__init__.py`` in the standalone
``snowflake-ml-feature-store-decl`` wheel.  It avoids importing
``stream_config`` (which requires pandas) and the dynamic module
scanner (``init_utils.fetch_classes_from_modules_in_pkg_dir``).

Only the modules needed by the declarative executor are exported.
"""

from snowflake.ml.feature_store.entity import Entity
from snowflake.ml.feature_store.feature import Feature
from snowflake.ml.feature_store.feature_store import CreationMode, FeatureStore
from snowflake.ml.feature_store.feature_view import (
    FeatureView,
    FeatureViewSlice,
    FeatureViewStatus,
    FeatureViewVersion,
    OnlineConfig,
    OnlineStoreType,
)
from snowflake.ml.feature_store.spec.enums import FeatureAggregationMethod
from snowflake.ml.feature_store.stream_source import StreamSource

__all__ = [
    "CreationMode",
    "Entity",
    "Feature",
    "FeatureAggregationMethod",
    "FeatureStore",
    "FeatureView",
    "FeatureViewSlice",
    "FeatureViewStatus",
    "FeatureViewVersion",
    "OnlineConfig",
    "OnlineStoreType",
    "StreamSource",
]
