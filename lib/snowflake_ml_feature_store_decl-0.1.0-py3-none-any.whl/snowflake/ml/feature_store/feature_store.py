from __future__ import annotations

import datetime
import functools
import json
import logging
import re
import warnings
from dataclasses import dataclass
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Literal,
    NamedTuple,
    Optional,
    TypeVar,
    Union,
    cast,
    overload,
)

import packaging.version as pkg_version
from pytimeparse.timeparse import timeparse
from typing_extensions import Concatenate, ParamSpec

import snowflake.ml.feature_store.feature_view as fv_mod
import snowflake.ml.version as snowml_version
from snowflake.ml._internal import telemetry
from snowflake.ml._internal.exceptions import (
    dataset_errors,
    error_codes,
    exceptions as snowml_exceptions,
    sql_error_codes,
)
from snowflake.ml._internal.utils import identifier
from snowflake.ml._internal.utils.sql_identifier import (
    SqlIdentifier,
    get_fully_qualified_name,
    parse_fully_qualified_name,
    to_sql_identifiers,
)

if TYPE_CHECKING:
    from snowflake.ml import dataset
    from snowflake.ml.dataset.dataset_metadata import FeatureStoreMetadata

from snowflake.ml.feature_store import online_service, online_service_http_client
from snowflake.ml.feature_store.entity import _ENTITY_NAME_LENGTH_LIMIT, Entity
from snowflake.ml.feature_store.feature_view import (
    _FEATURE_OBJ_TYPE,
    _FEATURE_VIEW_NAME_DELIMITER,
    _LEGACY_TIMESTAMP_COL_PLACEHOLDER_VALS,
    FeatureView,
    FeatureViewSlice,
    FeatureViewStatus,
    FeatureViewVersion,
    OnlineStoreType,
    StorageConfig,
    StorageFormat,
    _FeatureViewMetadata,
    _FeatureViewSchemaNotReadyWarning,
)
from snowflake.ml.feature_store.metadata_manager import (
    AggregationMetadata,
    FeatureStoreMetadataManager,
    MetadataObjectType,
    MetadataType,
)
from snowflake.ml.feature_store.spec.builder import (
    BatchSource,
    FeatureViewSpecBuilder,
    SnowflakeTableInfo,
)
from snowflake.ml.feature_store.spec.enums import (
    FeatureAggregationMethod,
    FeatureViewKind,
    TableType,
)
from snowflake.ml.feature_store.spec.models import (
    FeatureViewSpec,
    validate_spec_oft_offline_table_schema,
)
from snowflake.ml.feature_store.stream_source import (
    _LIST_STREAM_SOURCE_SCHEMA,
    StreamSource,
)
from snowflake.ml.feature_store.tile_sql_generator import (
    _TILE_START_COL,
    MergingSqlGenerator,
    RollupSqlGenerator,
)
from snowflake.ml.utils import sql_client
from snowflake.snowpark import DataFrame, Row, Session, functions as F
from snowflake.snowpark._internal import utils as snowpark_utils
from snowflake.snowpark.exceptions import SnowparkSQLException
from snowflake.snowpark.types import (
    ArrayType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

if TYPE_CHECKING:
    import pandas as pd

_Args = ParamSpec("_Args")
_RT = TypeVar("_RT")

logger = logging.getLogger(__name__)


def _stream_source_schema_field_names(schema: StructType) -> list[str]:
    return [f.name for f in schema.fields]


def _normalize_stream_ingest_records(
    records: Union[list[dict[str, Any]], dict[str, Any]],
) -> list[dict[str, Any]]:
    if isinstance(records, dict):
        return [records]
    if isinstance(records, list):
        if not records:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError("records must be non-empty for stream_ingest."),
            )
        rows: list[dict[str, Any]] = []
        for i, row in enumerate(records):
            if not isinstance(row, dict):
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=TypeError(
                        f"records must be a list of dicts; element {i} has type {type(row)!r}."
                    ),
                )
            rows.append(row)
        return rows
    raise snowml_exceptions.SnowflakeMLException(
        error_code=error_codes.INVALID_ARGUMENT,
        original_exception=TypeError(f"records must be a dict or non-empty list[dict]; got {type(records)!r}."),
    )


def _validate_stream_ingest_record_keys(expected: list[str], row: dict[str, Any], row_index: int) -> None:
    exp_set = set(expected)
    keys = set(row.keys())
    if keys != exp_set:
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_ARGUMENT,
            original_exception=ValueError(
                f"Record {row_index} column keys must match StreamSource schema exactly: "
                f"expected={expected!r}, missing={sorted(exp_set - keys)!r}, extra={sorted(keys - exp_set)!r}."
            ),
        )


def _store_type_from_oft_show_row(row: Row) -> OnlineStoreType:
    """Map SHOW ONLINE FEATURE TABLES ``store_type`` to ``OnlineStoreType``.

    Args:
        row: A Snowpark ``Row`` from SHOW ONLINE FEATURE TABLES.

    Returns:
        OnlineStoreType: ``HYBRID_TABLE`` if missing or unrecognized.

    When the column is absent (older Snowflake builds), defaults to ``HYBRID_TABLE``
    to match ``OnlineConfig`` / ``from_json`` behavior without ``store_type``.
    """
    raw: Any = None
    if "store_type" in row:
        raw = row["store_type"]
    elif "STORE_TYPE" in row:
        raw = row["STORE_TYPE"]
    else:
        return OnlineStoreType.HYBRID_TABLE

    if raw is None:
        return OnlineStoreType.HYBRID_TABLE
    s = str(raw).strip()
    if not s:
        return OnlineStoreType.HYBRID_TABLE

    key = s.lower()
    if key == OnlineStoreType.POSTGRES.value:
        return OnlineStoreType.POSTGRES
    if key == OnlineStoreType.HYBRID_TABLE.value:
        return OnlineStoreType.HYBRID_TABLE

    logger.warning(
        "Unknown SHOW ONLINE FEATURE TABLES store_type %r; defaulting to hybrid_table",
        raw,
    )
    return OnlineStoreType.HYBRID_TABLE


_ENTITY_TAG_PREFIX = "SNOWML_FEATURE_STORE_ENTITY_"
_FEATURE_STORE_OBJECT_TAG = "SNOWML_FEATURE_STORE_OBJECT"
_FEATURE_VIEW_METADATA_TAG = "SNOWML_FEATURE_VIEW_METADATA"


@dataclass(frozen=True)
class _FeatureStoreObjInfo:
    type: _FeatureStoreObjTypes
    pkg_version: str

    def to_json(self) -> str:
        state_dict = self.__dict__.copy()
        state_dict["type"] = state_dict["type"].value
        return json.dumps(state_dict)

    @classmethod
    def from_json(cls, json_str: str) -> _FeatureStoreObjInfo:
        json_dict = json.loads(json_str)
        # since we may introduce new fields in the json blob in the future,
        # in order to guarantee compatibility, we need to select ones that can be
        # decoded in the current version
        state_dict = {}
        state_dict["type"] = _FeatureStoreObjTypes.parse(json_dict["type"])
        state_dict["pkg_version"] = json_dict["pkg_version"]
        return cls(**state_dict)  # type: ignore[arg-type]


class _FeatureStoreObjTypes(Enum):
    UNKNOWN = "UNKNOWN"  # for forward compatibility
    MANAGED_FEATURE_VIEW = "MANAGED_FEATURE_VIEW"  # Snowflake manages the refresh for the user
    EXTERNAL_FEATURE_VIEW = "EXTERNAL_FEATURE_VIEW"
    FEATURE_VIEW_REFRESH_TASK = "FEATURE_VIEW_REFRESH_TASK"
    TRAINING_DATA = "TRAINING_DATA"
    ONLINE_FEATURE_TABLE = "ONLINE_FEATURE_TABLE"
    UDF_TRANSFORMED_TABLE = "UDF_TRANSFORMED_TABLE"
    INTERNAL_METADATA_TABLE = "INTERNAL_METADATA_TABLE"

    @classmethod
    def parse(cls, val: str) -> _FeatureStoreObjTypes:
        try:
            return cls(val)
        except ValueError:
            return cls.UNKNOWN


_PROJECT = "FeatureStore"
_DT_OR_VIEW_QUERY_PATTERN = re.compile(
    r"""CREATE\ (OR\ REPLACE\ )?(?P<obj_type>(DYNAMIC\ ICEBERG\ TABLE|DYNAMIC\ TABLE|VIEW))\ .*
        COMMENT\ =\ '(?P<comment>.*)'\s*
        TAG.*?{fv_metadata_tag}\ =\ '(?P<fv_metadata>.*?)',?.*?
        AS\ (?P<query>.*)
    """.format(
        fv_metadata_tag=_FEATURE_VIEW_METADATA_TAG,
    ),
    flags=re.DOTALL | re.IGNORECASE | re.X,
)

_DT_INITIALIZE_PATTERN = re.compile(
    r"""CREATE\ DYNAMIC\ TABLE\ .*
        initialize\ =\ '(?P<initialize>.*)'\ .*?
        AS\ .*
    """,
    flags=re.DOTALL | re.IGNORECASE | re.X,
)

# _LIST_FEATURE_VIEW_SCHEMA acts as a metadata blueprint for columns in the DataFrame.
_LIST_FEATURE_VIEW_SCHEMA = StructType(
    [
        StructField("name", StringType()),
        StructField("version", StringType()),
        StructField("database_name", StringType()),
        StructField("schema_name", StringType()),
        StructField("created_on", TimestampType()),
        StructField("owner", StringType()),
        StructField("desc", StringType()),
        StructField("entities", ArrayType(StringType())),
        StructField("refresh_freq", StringType()),
        StructField("refresh_mode", StringType()),
        StructField("scheduling_state", StringType()),
        StructField("warehouse", StringType()),
        StructField("cluster_by", StringType()),
        StructField("online_config", StringType()),
        StructField("storage_config", StringType()),
        StructField("stream_config", StringType()),
    ]
)


# Default storage config JSON strings for list_feature_views output
_DEFAULT_STORAGE_CONFIG_JSON = StorageConfig().to_json()  # {"format": "snowflake"}
_DEFAULT_ICEBERG_STORAGE_CONFIG_JSON = StorageConfig(format=StorageFormat.ICEBERG).to_json()  # {"format": "iceberg"}

CreationMode = sql_client.CreationOption
CreationMode.__module__ = __name__


@dataclass(frozen=True)
class _FeatureStoreConfig:
    database: SqlIdentifier
    schema: SqlIdentifier

    @property
    def full_schema_path(self) -> str:
        return f"{self.database}.{self.schema}"


def switch_warehouse(
    f: Callable[Concatenate[FeatureStore, _Args], _RT],
) -> Callable[Concatenate[FeatureStore, _Args], _RT]:
    @functools.wraps(f)
    def wrapper(self: FeatureStore, /, *args: _Args.args, **kargs: _Args.kwargs) -> _RT:
        original_warehouse = self._session.get_current_warehouse()
        if original_warehouse is not None:
            original_warehouse = SqlIdentifier(original_warehouse)
        warehouse_updated = False
        try:
            if original_warehouse != self._default_warehouse:
                self._session.use_warehouse(self._default_warehouse)
                warehouse_updated = True
            return f(self, *args, **kargs)
        finally:
            if warehouse_updated and original_warehouse is not None:
                self._session.use_warehouse(original_warehouse)

    return wrapper


_CTE_MERGE_BATCH_SIZE = 10


class _FvJoinInfo(NamedTuple):
    cte_name: str
    key_sig: tuple[tuple[str, ...], bool]
    join_keys: list[SqlIdentifier]
    has_ts: bool
    select_cols: list[str]
    col_names: list[str]


def _make_fv_join_clause(
    lhs_alias: str,
    cte_name: str,
    join_keys: list[SqlIdentifier],
    has_ts: bool,
    spine_timestamp_col: Optional[SqlIdentifier],
) -> str:
    conditions = [f"{lhs_alias}.{k.identifier()} = {cte_name}.{k.identifier()}" for k in join_keys]
    if has_ts and spine_timestamp_col:
        ts_id = spine_timestamp_col.identifier()
        conditions.append(f"{lhs_alias}.{ts_id} = {cte_name}.{ts_id}")
    return f"\n    LEFT JOIN {cte_name}\n    ON {' AND '.join(conditions)}"


def dispatch_decorator(
    *,
    skip_wh_switch: Optional[Callable[..., bool]] = None,
    skip_telemetry: Optional[Callable[..., bool]] = None,
) -> Callable[[Callable[Concatenate[FeatureStore, _Args], _RT]], Callable[Concatenate[FeatureStore, _Args], _RT],]:
    def decorator(
        f: Callable[Concatenate[FeatureStore, _Args], _RT],
    ) -> Callable[Concatenate[FeatureStore, _Args], _RT]:
        wrapped_with_wh = switch_warehouse(f)
        if skip_wh_switch is not None:

            @functools.wraps(f)
            def maybe_switch_wh(self: FeatureStore, /, *args: _Args.args, **kargs: _Args.kwargs) -> _RT:
                if skip_wh_switch(self, *args, **kargs):
                    return f(self, *args, **kargs)
                return wrapped_with_wh(self, *args, **kargs)

            after_wh: Callable[Concatenate[FeatureStore, _Args], _RT] = maybe_switch_wh
        else:
            after_wh = wrapped_with_wh

        wrapped_with_telemetry = telemetry.send_api_usage_telemetry(project=_PROJECT)(after_wh)
        if skip_telemetry is not None:

            @functools.wraps(f)
            def maybe_telemetry(self: FeatureStore, /, *args: _Args.args, **kargs: _Args.kwargs) -> _RT:
                if skip_telemetry(self, *args, **kargs):
                    return after_wh(self, *args, **kargs)
                return wrapped_with_telemetry(self, *args, **kargs)

            return maybe_telemetry

        return wrapped_with_telemetry

    return decorator


def _predicate_read_feature_view_skip_wh_switch(*args: Any, **kwargs: Any) -> bool:
    """Skip warehouse switch when opted-in or targeting a Postgres online read (uses HTTP, not a warehouse)."""
    if bool(kwargs.get("use_session_warehouse", False)):
        return True
    if _get_store_type(kwargs.get("store_type", fv_mod.StoreType.OFFLINE)) != fv_mod.StoreType.ONLINE:
        return False
    # String (name, version) inputs would require a metadata round-trip to resolve online_config,
    # defeating the savings; fall through for them.
    feature_view = kwargs.get("feature_view") if "feature_view" in kwargs else (args[1] if len(args) > 1 else None)
    if not isinstance(feature_view, FeatureView):
        return False
    return feature_view.online_config is not None and feature_view.online_config.store_type == OnlineStoreType.POSTGRES


def _predicate_read_feature_view_skip_telemetry(*args: Any, **kwargs: Any) -> bool:
    return _get_store_type(kwargs.get("store_type", fv_mod.StoreType.OFFLINE)) == fv_mod.StoreType.ONLINE


class FeatureStore:
    """
    FeatureStore provides APIs to create, materialize, retrieve and manage feature pipelines.
    """

    # Prefixes for temporary objects used during shadow swap operations
    _TMP_VIEW_PREFIX = "_TMP_VIEW_"
    _TMP_DT_PREFIX = "_TMP_TABLE_"

    @telemetry.send_api_usage_telemetry(project=_PROJECT)
    def __init__(
        self,
        session: Session,
        database: str,
        name: str,
        default_warehouse: str,
        *,
        creation_mode: CreationMode = CreationMode.FAIL_IF_NOT_EXIST,
        default_iceberg_external_volume: Optional[str] = None,
    ) -> None:
        """
        Creates a FeatureStore instance.

        Args:
            session: Snowpark Session to interact with Snowflake backend.
            database: Database to create the FeatureStore instance.
            name: Target FeatureStore name, maps to a schema in the database.
            default_warehouse: Default warehouse for feature store compute.
            creation_mode: If FAIL_IF_NOT_EXIST, feature store throws when required resources not already exist; If
                CREATE_IF_NOT_EXIST, feature store will create required resources if they not already exist. Required
                resources include schema and tags. Note database must already exist in either mode.
            default_iceberg_external_volume: Default external volume for Iceberg-backed Feature Views. If set,
                Feature Views using StorageFormat.ICEBERG can omit external_volume in their StorageConfig.

        Raises:
            SnowflakeMLException: [ValueError] default_warehouse does not exist.
            SnowflakeMLException: [ValueError] Required resources not exist when mode is FAIL_IF_NOT_EXIST.
            SnowflakeMLException: [RuntimeError] Failed to find resources.
            SnowflakeMLException: [RuntimeError] Failed to create feature store.

        Example::

            >>> from snowflake.ml.feature_store import (
            ...     FeatureStore,
            ...     CreationMode,
            ... )
            <BLANKLINE>
            >>> # Create a new Feature Store:
            >>> fs = FeatureStore(
            ...     session=session,
            ...     database="MYDB",
            ...     name="MYSCHEMA",
            ...     default_warehouse="MYWH",
            ...     creation_mode=CreationMode.CREATE_IF_NOT_EXIST
            ... )
            <BLANKLINE>
            >>> # Connect to an existing Feature Store:
            >>> fs = FeatureStore(
            ...     session=session,
            ...     database="MYDB",
            ...     name="MYSCHEMA",
            ...     default_warehouse="MYWH",
            ...     creation_mode=CreationMode.FAIL_IF_NOT_EXIST
            ... )

        """

        database = SqlIdentifier(database)
        name = SqlIdentifier(name)

        self._telemetry_stmp = telemetry.get_function_usage_statement_params(_PROJECT)
        self._session: Session = session
        self._config = _FeatureStoreConfig(
            database=database,
            schema=name,
        )
        self._metadata_manager = FeatureStoreMetadataManager(
            session=session,
            schema_path=self._config.full_schema_path,
            fs_object_tag_path=self._get_fully_qualified_name(_FEATURE_STORE_OBJECT_TAG),
            telemetry_stmp=self._telemetry_stmp,
        )
        self._asof_join_enabled = None

        # A dict from object name to tuple of search space and object domain.
        # search space used in query "SHOW <object_TYPE> LIKE <object_name> IN <search_space>"
        # object domain used in query "TAG_REFERENCE(<object_name>, <object_domain>)"
        self._obj_search_spaces = {
            "DATASETS": (self._config.full_schema_path, "DATASET"),
            "DYNAMIC TABLES": (self._config.full_schema_path, "TABLE"),
            "VIEWS": (self._config.full_schema_path, "TABLE"),
            "ONLINE FEATURE TABLES": (self._config.full_schema_path, "TABLE"),
            "SCHEMAS": (f"DATABASE {self._config.database}", "SCHEMA"),
            "TAGS": (self._config.full_schema_path, None),
            "TASKS": (self._config.full_schema_path, "TASK"),
            "WAREHOUSES": (None, None),
        }

        self.update_default_warehouse(default_warehouse)
        self._default_iceberg_external_volume = default_iceberg_external_volume

        self._check_database_exists_or_throw()
        if creation_mode == CreationMode.FAIL_IF_NOT_EXIST:
            self._check_internal_objects_exist_or_throw()

        else:
            try:
                # Explicitly check if schema exists first since we may not have CREATE SCHEMA privilege
                if len(self._find_object("SCHEMAS", self._config.schema)) == 0:
                    self._session.sql(f"CREATE SCHEMA IF NOT EXISTS {self._config.full_schema_path}").collect(
                        statement_params=self._telemetry_stmp
                    )
                for tag in to_sql_identifiers([_FEATURE_VIEW_METADATA_TAG, _FEATURE_STORE_OBJECT_TAG]):
                    self._session.sql(f"CREATE TAG IF NOT EXISTS {self._get_fully_qualified_name(tag)}").collect(
                        statement_params=self._telemetry_stmp
                    )
                # Metadata table for aggregation configs is created lazily by metadata manager
            except Exception as e:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                    original_exception=RuntimeError(f"Failed to create feature store {name}: {e}."),
                ) from e
        self._check_feature_store_object_versions()
        self._online_http_client: Optional[online_service_http_client.OnlineServiceHttpClient] = None
        logger.info(f"Successfully connected to feature store: {self._config.full_schema_path}.")

    def _get_or_create_online_http_client(self) -> online_service_http_client.OnlineServiceHttpClient:
        """Return the FeatureStore-scoped HTTP client, creating it on first use."""
        if self._online_http_client is None:
            self._online_http_client = online_service_http_client.OnlineServiceHttpClient()
        return self._online_http_client

    def close(self) -> None:
        """Release per-FeatureStore resources (currently: the Online Service HTTP pool). Idempotent."""
        if self._online_http_client is not None:
            self._online_http_client.close()
            self._online_http_client = None

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:  # noqa: BLE001 - best-effort cleanup at GC
            pass

    @telemetry.send_api_usage_telemetry(project=_PROJECT)
    def update_default_warehouse(self, warehouse_name: str) -> None:
        """Update default warehouse for feature store.

        Args:
            warehouse_name: Name of warehouse.

        Raises:
            SnowflakeMLException: If warehouse does not exists.

        Example::

            >>> fs = FeatureStore(...)
            >>> fs.update_default_warehouse("MYWH_2")
            >>> draft_fv = FeatureView("my_fv", ...)
            >>> registered_fv = fs.register_feature_view(draft_fv, '2.0')
            >>> print(registered_fv.warehouse)
            MYWH_2

        """
        warehouse = SqlIdentifier(warehouse_name)
        warehouse_result = self._find_object("WAREHOUSES", warehouse)
        if len(warehouse_result) == 0:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"Cannot find warehouse {warehouse}"),
            )

        self._default_warehouse = warehouse

    @dispatch_decorator()
    def register_entity(self, entity: Entity) -> Entity:
        """
        Register Entity in the FeatureStore.

        Args:
            entity: Entity object to be registered.

        Returns:
            A registered entity object.

        Raises:
            SnowflakeMLException: [RuntimeError] Failed to find resources.

        Example::

            >>> fs = FeatureStore(...)
            >>> e = Entity('BAR', ['A'], desc='entity bar')
            >>> fs.register_entity(e)
            >>> fs.list_entities().show()
            --------------------------------------------------
            |"NAME"  |"JOIN_KEYS"  |"DESC"      |"OWNER"     |
            --------------------------------------------------
            |BAR     |["A"]        |entity bar  |REGTEST_RL  |
            --------------------------------------------------

        """
        tag_name = self._get_entity_name(entity.name)
        found_rows = self._find_object("TAGS", tag_name)
        if len(found_rows) > 0:
            warnings.warn(
                f"Entity {entity.name} already exists. Skip registration.",
                stacklevel=2,
                category=UserWarning,
            )
            return entity

        # allowed_values will add double-quotes around each value, thus use resolved str here.
        join_keys = [f"{key.resolved()}" for key in entity.join_keys]
        join_keys_str = ",".join(join_keys)
        full_tag_name = self._get_fully_qualified_name(tag_name)
        try:
            self._session.sql(
                f"""CREATE TAG IF NOT EXISTS {full_tag_name}
                    ALLOWED_VALUES '{join_keys_str}'
                    COMMENT = '{entity.desc}'
                """
            ).collect(statement_params=self._telemetry_stmp)
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to register entity `{entity.name}`: {e}."),
            ) from e

        logger.info(f"Registered Entity {entity}.")

        return self.get_entity(entity.name)

    def update_entity(self, name: str, *, desc: Optional[str] = None) -> Optional[Entity]:
        """Update a registered entity with provided information.

        Args:
            name: Name of entity to update.
            desc: Optional new description to apply. Default to None.

        Raises:
            SnowflakeMLException: Error happen when updating.

        Returns:
            A new entity with updated information or None if the entity doesn't exist.

        Example::

            >>> fs = FeatureStore(...)
            <BLANKLINE>
            >>> e = Entity(name='foo', join_keys=['COL_1'], desc='old desc')
            >>> fs.list_entities().show()
            ------------------------------------------------
            |"NAME"  |"JOIN_KEYS"  |"DESC"    |"OWNER"     |
            ------------------------------------------------
            |FOO     |["COL_1"]    |old desc  |REGTEST_RL  |
            ------------------------------------------------
            <BLANKLINE>
            >>> fs.update_entity('foo', desc='NEW DESC')
            >>> fs.list_entities().show()
            ------------------------------------------------
            |"NAME"  |"JOIN_KEYS"  |"DESC"    |"OWNER"     |
            ------------------------------------------------
            |FOO     |["COL_1"]    |NEW DESC  |REGTEST_RL  |
            ------------------------------------------------

        """
        name = SqlIdentifier(name)
        found_rows = (
            self.list_entities().filter(F.col("NAME") == name.resolved()).collect(statement_params=self._telemetry_stmp)
        )

        if len(found_rows) == 0:
            warnings.warn(
                f"Entity {name} does not exist.",
                stacklevel=2,
                category=UserWarning,
            )
            return None

        new_desc = desc if desc is not None else found_rows[0]["DESC"]

        try:
            full_name = f"{self._config.full_schema_path}.{self._get_entity_name(name)}"
            self._session.sql(f"ALTER TAG {full_name} SET COMMENT = '{new_desc}'").collect(
                statement_params=self._telemetry_stmp
            )
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to update entity `{name}`: {e}."),
            ) from e

        logger.info(f"Successfully updated Entity {name}.")
        return self.get_entity(name)

    # TODO: add support to update column desc once SNOW-894249 is fixed
    @dispatch_decorator()
    def register_feature_view(
        self,
        feature_view: FeatureView,
        version: str,
        *,
        block: bool = True,
        overwrite: bool = False,
    ) -> FeatureView:
        """
        Materialize a FeatureView to Snowflake backend.
        Incremental maintenance for updates on the source data will be automated if refresh_freq is set.
        NOTE: Each new materialization will trigger a full FeatureView history refresh for the data included in the
              FeatureView.

        Args:
            feature_view: FeatureView instance to materialize.
            version: version of the registered FeatureView.
                NOTE: Version only accepts letters, numbers and underscore. Also version will be capitalized.
            block: Deprecated. To make the initial refresh asynchronous, set the `initialize`
                argument on the `FeatureView` to `"ON_SCHEDULE"`. Default is true.
            overwrite: Overwrite the existing FeatureView with same version. This is the same as dropping the
                FeatureView first then recreate. NOTE: there will be backfill cost associated if the FeatureView is
                being continuously maintained.

        Returns:
            A materialized FeatureView object.

        Raises:
            SnowflakeMLException: [ValueError] FeatureView entity has not been registered.
            SnowflakeMLException: [ValueError] Warehouse or default warehouse is not specified.
            SnowflakeMLException: [RuntimeError] Failed to create dynamic table, task, or view.
            SnowflakeMLException: [RuntimeError] Failed to find resources.
            Exception: Unexpected error during registration.

        Example::

            >>> fs = FeatureStore(...)
            >>> # draft_fv is a local object that hasn't materialized to Snowflake backend yet.
            >>> feature_df = session.sql("select f_1, f_2 from source_table")
            >>> draft_fv = FeatureView("my_fv", [entities], feature_df)
            >>> print(draft_fv.status)
            FeatureViewStatus.DRAFT
            <BLANKLINE>
            >>> fs.list_feature_views().select("NAME", "VERSION", "SCHEDULING_STATE").show()
            -------------------------------------------
            |"NAME"  |"VERSION"  |"SCHEDULING_STATE"  |
            -------------------------------------------
            |        |           |                    |
            -------------------------------------------
            <BLANKLINE>
            >>> # registered_fv is a local object that maps to a Snowflake backend object.
            >>> registered_fv = fs.register_feature_view(draft_fv, "v1")
            >>> print(registered_fv.status)
            FeatureViewStatus.ACTIVE
            <BLANKLINE>
            >>> fs.list_feature_views().select("NAME", "VERSION", "SCHEDULING_STATE").show()
            -------------------------------------------
            |"NAME"  |"VERSION"  |"SCHEDULING_STATE"  |
            -------------------------------------------
            |MY_FV   |v1         |ACTIVE              |
            -------------------------------------------

        """
        version = FeatureViewVersion(version)

        if block is False:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    'block=False is deprecated. Use FeatureView(..., initialize="ON_SCHEDULE") '
                    "for async initial refresh."
                ),
            )

        if feature_view.status != FeatureViewStatus.DRAFT:
            try:
                return self._get_feature_view_if_exists(feature_view.name, str(version))
            except Exception:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.NOT_FOUND,
                    original_exception=ValueError(
                        f"FeatureView {feature_view.name}/{feature_view.version} status is {feature_view.status}, "
                        + "but it doesn't exist."
                    ),
                )

        for e in feature_view.entities:
            if not self._validate_entity_exists(e.name):
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.NOT_FOUND,
                    original_exception=ValueError(f"Entity {e.name} has not been registered."),
                )

        feature_view_name = FeatureView._get_physical_name(feature_view.name, version)
        if not overwrite:
            try:
                return self._get_feature_view_if_exists(feature_view.name, str(version))
            except Exception:
                pass

        created_resources = []
        streaming_preamble = None
        streaming_ref_count_incremented = False
        try:
            fully_qualified_name = self._get_fully_qualified_name(feature_view_name)
            refresh_freq = feature_view.refresh_freq

            if refresh_freq is None:
                obj_info = _FeatureStoreObjInfo(_FeatureStoreObjTypes.EXTERNAL_FEATURE_VIEW, snowml_version.VERSION)
            else:
                obj_info = _FeatureStoreObjInfo(_FeatureStoreObjTypes.MANAGED_FEATURE_VIEW, snowml_version.VERSION)

            self._resolve_storage_config(feature_view, fully_qualified_name)

            tagging_clause = [
                f"{self._get_fully_qualified_name(_FEATURE_STORE_OBJECT_TAG)} = '{obj_info.to_json()}'",
                f"{self._get_fully_qualified_name(_FEATURE_VIEW_METADATA_TAG)} = '"
                f"{feature_view._metadata().to_json()}'",
            ]
            for e in feature_view.entities:
                join_keys = [f"{key.resolved()}" for key in e.join_keys]
                tagging_clause.append(
                    f"{self._get_fully_qualified_name(self._get_entity_name(e.name))} = '{','.join(join_keys)}'"
                )
            tagging_clause_str = ",\n".join(tagging_clause)

            if feature_view.online and feature_view.online_config is not None:
                if feature_view.online_config.store_type == OnlineStoreType.POSTGRES:
                    logger.warning(
                        "POSTGRES online store type is in private preview since 1.33.0. " "Do not use in production."
                    )
                    online_service.assert_online_service_running_with_query_endpoint(
                        self._session,
                        self._config.database,
                        self._config.schema,
                        statement_params=self._telemetry_stmp,
                    )

            def create_col_desc(col: StructField) -> str:
                desc = feature_view.feature_descs.get(SqlIdentifier(col.name), None)  # type: ignore[union-attr]
                desc = "" if desc is None else f"COMMENT '{desc}'"
                return f"{col.name} {desc}"

            # Streaming preamble: create udf_transformed table, then complete FV initialization
            if feature_view.is_streaming:
                from snowflake.ml.feature_store.streaming_registration import (
                    run_streaming_preamble,
                )

                streaming_preamble = run_streaming_preamble(
                    session=self._session,
                    feature_view=feature_view,
                    version=version,
                    feature_view_name=feature_view_name,
                    overwrite=overwrite,
                    metadata_manager=self._metadata_manager,
                    telemetry_stmp=self._telemetry_stmp,
                    get_stream_source_fn=self.get_stream_source,
                    get_fully_qualified_name_fn=self._get_fully_qualified_name,
                )
                created_resources.append((_FeatureStoreObjTypes.UDF_TRANSFORMED_TABLE, streaming_preamble.fq_udf_table))
                created_resources.append(
                    (_FeatureStoreObjTypes.UDF_TRANSFORMED_TABLE, streaming_preamble.fq_backfill_table)
                )

                # Complete FeatureView initialization with the transformed schema.
                # After this, feature_view.query, output_schema, feature_names all
                # reflect the udf_transformed table — existing code paths work as-is.
                udf_df = self._session.table(streaming_preamble.fq_udf_table)
                feature_view._initialize_from_feature_df(udf_df)
                feature_view._validate()

            # For tiled feature views, skip column definitions since the tiling query
            # produces different columns (TILE_START, partial aggregates)
            if feature_view.is_tiled:
                column_descs = ""
            else:
                column_descs = (
                    ", ".join([f"{create_col_desc(col)}" for col in feature_view.output_schema.fields])
                    if feature_view.feature_descs is not None
                    else ""
                )

            # Step 1: Create offline feature view (Dynamic Table or View)
            if feature_view.is_rollup:
                created_resources.extend(
                    self._create_rollup_feature_view(
                        feature_view=feature_view,
                        feature_view_name=feature_view_name,
                        fully_qualified_name=fully_qualified_name,
                        tagging_clause_str=tagging_clause_str,
                        overwrite=overwrite,
                    )
                )
            else:
                created_resources.extend(
                    self._create_offline_feature_view(
                        feature_view=feature_view,
                        feature_view_name=feature_view_name,
                        fully_qualified_name=fully_qualified_name,
                        column_descs=column_descs,
                        tagging_clause_str=tagging_clause_str,
                        block=block,
                        overwrite=overwrite,
                    )
                )

            # Step 2: Create online feature table if requested
            # (for streaming FVs, the existing POSTGRES path builds the streaming spec internally)
            if feature_view.online:
                online_table_name = self._create_online_feature_table(
                    feature_view, feature_view_name, version=str(version), overwrite=overwrite
                )
                created_resources.append(
                    (_FeatureStoreObjTypes.ONLINE_FEATURE_TABLE, self._get_fully_qualified_name(online_table_name))
                )
            elif overwrite:
                # Delete dangling online feature table when overwriting online-enabled FV with online-disabled FV
                online_table_name = FeatureView._get_online_table_name(feature_view_name)
                fully_qualified_online_name = self._get_fully_qualified_name(online_table_name)
                self._session.sql(f"DROP ONLINE FEATURE TABLE IF EXISTS {fully_qualified_online_name}").collect(
                    statement_params=self._telemetry_stmp
                )

            # Step 3: Save aggregation metadata for tiled feature views (atomically)
            if feature_view.is_tiled:
                agg_metadata = AggregationMetadata(
                    feature_granularity=feature_view.feature_granularity,  # type: ignore[arg-type]
                    features=feature_view.aggregation_specs,  # type: ignore[arg-type]
                    feature_aggregation_method=(
                        feature_view.feature_aggregation_method.value
                        if feature_view.feature_aggregation_method is not None
                        else None
                    ),
                )
                # Convert SqlIdentifier keys to strings if descriptions exist
                descs = None
                if feature_view.feature_descs:
                    descs = {k.identifier(): v for k, v in feature_view.feature_descs.items()}
                # Save specs and descs atomically in a single statement
                self._metadata_manager.save_feature_view_metadata(feature_view.name, version, agg_metadata, descs)

            # Step 4: Save rollup metadata for PIT-correct training queries
            if feature_view._rollup_metadata is not None:
                self._metadata_manager.save_rollup_metadata(
                    feature_view.name, version, feature_view._rollup_metadata.to_dict()
                )

            # Step 5: Streaming postamble (metadata + ref_count + async backfill)
            if streaming_preamble is not None:
                from snowflake.ml.feature_store.streaming_registration import (
                    run_streaming_postamble,
                )

                run_streaming_postamble(
                    session=self._session,
                    feature_view=feature_view,
                    version=version,
                    preamble=streaming_preamble,
                    metadata_manager=self._metadata_manager,
                )
                streaming_ref_count_incremented = True

        except Exception as e:
            # We can't rollback in case of overwrite.
            if not overwrite:
                self._rollback_created_resources(created_resources)
                # Cleanup metadata (covers both tiled and streaming FVs)
                if feature_view.is_tiled or streaming_preamble is not None:
                    self._metadata_manager.delete_feature_view_metadata(str(feature_view.name), version)
                # Only decrement ref_count if postamble successfully incremented it
                if streaming_preamble is not None and streaming_ref_count_incremented:
                    try:
                        self._metadata_manager.decrement_stream_source_ref_count(
                            streaming_preamble.resolved_source_name
                        )
                    except Exception as rollback_err:
                        logger.warning(
                            f"Best-effort rollback: failed to decrement stream source ref_count "
                            f"for {streaming_preamble.resolved_source_name}: {rollback_err}"
                        )

            if isinstance(e, snowml_exceptions.SnowflakeMLException):
                raise
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to register feature view {feature_view.name}/{version}: {e}"),
            ) from e

        logger.info(f"Registered FeatureView {feature_view.name}/{version} successfully.")
        # Suppress the warning that fires when the just-created dynamic table hasn't had
        # its first refresh yet.
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=_FeatureViewSchemaNotReadyWarning)
            return self.get_feature_view(feature_view.name, str(version))

    @overload
    def update_feature_view(
        self,
        name: str,
        version: str,
        *,
        refresh_freq: Optional[str] = None,
        warehouse: Optional[str] = None,
        desc: Optional[str] = None,
        online_config: Optional[fv_mod.OnlineConfig] = None,
    ) -> FeatureView:
        ...

    @overload
    def update_feature_view(
        self,
        name: FeatureView,
        version: Optional[str] = None,
        *,
        refresh_freq: Optional[str] = None,
        warehouse: Optional[str] = None,
        desc: Optional[str] = None,
        online_config: Optional[fv_mod.OnlineConfig] = None,
    ) -> FeatureView:
        ...

    @dispatch_decorator()  # type: ignore[misc]
    def update_feature_view(
        self,
        name: Union[FeatureView, str],
        version: Optional[str] = None,
        *,
        refresh_freq: Optional[str] = None,
        warehouse: Optional[str] = None,
        desc: Optional[str] = None,
        online_config: Optional[fv_mod.OnlineConfig] = None,
    ) -> FeatureView:
        """Update a registered feature view.
            Check feature_view.py for which fields are allowed to be updated after registration.

        Args:
            name: FeatureView object or name to suspend.
            version: Optional version of feature view. Must set when argument feature_view is a str.
            refresh_freq: updated refresh frequency.
            warehouse: updated warehouse.
            desc: description of feature view.
            online_config: updated online configuration for the online feature table.
                If provided with enable=True, creates online feature table if absent.
                If provided with enable=False, drops online feature table if present.
                If None (default), no change to online status.
                During update, only explicitly set fields in the OnlineConfig will be updated.

        Returns:
            Updated FeatureView.

        Example::

            >>> fs = FeatureStore(...)
            >>> fv = FeatureView(
            ...     name='foo',
            ...     entities=[e1, e2],
            ...     feature_df=session.sql('...'),
            ...     desc='this is old description',
            ... )
            >>> fv = fs.register_feature_view(feature_view=fv, version='v1')
            >>> fs.list_feature_views().select("name", "version", "desc").show()
            ------------------------------------------------
            |"NAME"  |"VERSION"  |"DESC"                   |
            ------------------------------------------------
            |FOO     |v1         |this is old description  |
            ------------------------------------------------
            <BLANKLINE>
            >>> # update_feature_view will apply new arguments to the registered feature view.
            >>> new_fv = fs.update_feature_view(
            ...     name='foo',
            ...     version='v1',
            ...     desc='that is new descption',
            ... )
            >>> fs.list_feature_views().select("name", "version", "desc").show()
            ------------------------------------------------
            |"NAME"  |"VERSION"  |"DESC"                   |
            ------------------------------------------------
            |FOO     |v1         |THAT IS NEW DESCRIPTION  |
            ------------------------------------------------
            <BLANKLINE>
            >>> # Enable online storage with custom configuration
            >>> config = OnlineConfig(enable=True, target_lag='15s')
            >>> online_fv = fs.update_feature_view(
            ...     name='foo',
            ...     version='v1',
            ...     online_config=config,
            ... )
            >>> print(online_fv.online)
            True

        Raises:
            SnowflakeMLException: [RuntimeError] If FeatureView is not managed and refresh_freq is defined.
            SnowflakeMLException: [RuntimeError] Failed to update feature view.
        """
        if online_config is not None and online_config.store_type == OnlineStoreType.POSTGRES:
            logger.warning(
                "POSTGRES online store type is in private preview since 1.33.0. " "Do not use in production."
            )

        # Step 1: Validate inputs
        feature_view = self._validate_feature_view_name_and_version_input(name, version)
        new_desc = desc if desc is not None else feature_view.desc

        # Validate static feature view constraints
        if feature_view.status == FeatureViewStatus.STATIC and (refresh_freq or warehouse):
            full_name = f"{feature_view.name}/{feature_view.version}"
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=RuntimeError(
                    f"Static feature view '{full_name}' does not support refresh_freq and warehouse."
                ),
            )

        # Step 2: Plan all operations
        rollback_operations: list[Any] = []
        try:
            operations, rollback_operations = self._plan_feature_view_update_operations(
                feature_view, refresh_freq, warehouse, new_desc, online_config
            )

            # Step 3: Execute atomically
            self._execute_atomic_operations(operations)

        except Exception as e:
            # Step 4: Rollback on failure
            self._handle_update_failure(e, rollback_operations, feature_view)

        return self.get_feature_view(name=feature_view.name, version=str(feature_view.version))

    @overload
    def read_feature_view(
        self,
        feature_view: str,
        version: str,
        *,
        keys: Optional[list[list[str]]] = None,
        feature_names: Optional[list[str]] = None,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
        use_session_warehouse: bool = False,
        as_pandas: Literal[False],
    ) -> DataFrame:
        ...

    @overload
    def read_feature_view(
        self,
        feature_view: str,
        version: str,
        *,
        keys: Optional[list[list[str]]] = None,
        feature_names: Optional[list[str]] = None,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
        use_session_warehouse: bool = False,
        as_pandas: Literal[True],
    ) -> pd.DataFrame:
        ...

    @overload
    def read_feature_view(
        self,
        feature_view: str,
        version: str,
        *,
        keys: Optional[list[list[str]]] = None,
        feature_names: Optional[list[str]] = None,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
        use_session_warehouse: bool = False,
        as_pandas: None = None,
    ) -> Union[DataFrame, pd.DataFrame]:
        ...

    @overload
    def read_feature_view(
        self,
        feature_view: FeatureView,
        *,
        keys: Optional[list[list[str]]] = None,
        feature_names: Optional[list[str]] = None,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
        use_session_warehouse: bool = False,
        as_pandas: Literal[False],
    ) -> DataFrame:
        ...

    @overload
    def read_feature_view(
        self,
        feature_view: FeatureView,
        *,
        keys: Optional[list[list[str]]] = None,
        feature_names: Optional[list[str]] = None,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
        use_session_warehouse: bool = False,
        as_pandas: Literal[True],
    ) -> pd.DataFrame:
        ...

    @overload
    def read_feature_view(
        self,
        feature_view: FeatureView,
        *,
        keys: Optional[list[list[str]]] = None,
        feature_names: Optional[list[str]] = None,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
        use_session_warehouse: bool = False,
        as_pandas: None = None,
    ) -> Union[DataFrame, pd.DataFrame]:
        ...

    @dispatch_decorator(  # type: ignore[misc]
        skip_wh_switch=_predicate_read_feature_view_skip_wh_switch,
        skip_telemetry=_predicate_read_feature_view_skip_telemetry,
    )
    def read_feature_view(
        self,
        feature_view: Union[FeatureView, str],
        version: Optional[str] = None,
        *,
        keys: Optional[list[list[str]]] = None,
        feature_names: Optional[list[str]] = None,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
        use_session_warehouse: bool = False,
        as_pandas: Optional[bool] = None,
    ) -> Union[DataFrame, pd.DataFrame]:
        """
        Read values from a FeatureView from either offline or online store.

        Args:
            feature_view: A FeatureView object to read from, or the name of feature view.
                If name is provided then version also must be provided.
            version: Optional version of feature view. Must set when argument feature_view is a str.
            keys: Optional list of primary key value lists to filter by. Each inner list should contain
                values in the same order as the entity join_keys. Works for both offline and online stores.
                Example: [["user1"], ["user2"]] for single key,
                [["user1", "item1"], ["user2", "item2"]] for composite keys.
                If None, returns all data (hybrid online tables only). For **Postgres**-backed online
                feature views, ``keys`` must be **non-empty**; the Online Service Query API does not support
                unbounded scans from SnowML.
            feature_names: Optional list of feature names to return. If None, returns all features.
                For **Postgres** online reads, a non-empty list is sent to the Query API as JSON
                ``features`` so the service can return only those columns; the DataFrame still contains
                only that subset (and join keys). Offline and hybrid online SQL paths use the same list
                in the SELECT clause.
            store_type: Store to read from - StoreType.ONLINE or StoreType.OFFLINE (default).
            use_session_warehouse: If True, use the session's current warehouse instead of the feature
                store's configured warehouse. No-op for Postgres-backed online reads.
            as_pandas: Return type. ``None`` (default) returns ``pandas.DataFrame`` for Postgres-backed
                online reads and Snowpark ``DataFrame`` everywhere else. ``True`` forces
                ``pandas.DataFrame`` (rejected for ``store_type=StoreType.OFFLINE``). ``False`` forces
                Snowpark ``DataFrame``.

        Returns:
            Snowpark DataFrame (or ``pandas.DataFrame`` when ``as_pandas`` resolves to True)
            containing the FeatureView data.

        Raises:
            SnowflakeMLException: [ValueError] version argument is missing when argument feature_view is a str.
            SnowflakeMLException: [ValueError] FeatureView is not registered.
            SnowflakeMLException: [ValueError] Online store is not enabled for this feature view.
            SnowflakeMLException: [ValueError] Invalid store type.
            SnowflakeMLException: [ValueError] ``as_pandas=True`` with ``store_type=StoreType.OFFLINE``.

        Example::

            >>> fs = FeatureStore(...)
            >>> # Read all data from offline store
            >>> fs.read_feature_view('foo', 'v1', store_type=StoreType.OFFLINE).show()
            ------------------------------------------
            |"NAME"  |"ID"  |"TITLE"  |"AGE"  |"TS"  |
            ------------------------------------------
            |jonh    |1     |boss     |20     |100   |
            |porter  |2     |manager  |30     |200   |
            ------------------------------------------
            <BLANKLINE>
            >>> # Filter by keys in offline store
            >>> fs.read_feature_view('foo', 'v1', keys=[["1"], ["2"]], store_type=StoreType.OFFLINE).show()
            ------------------------------------------
            |"NAME"  |"ID"  |"TITLE"  |"AGE"  |"TS"  |
            ------------------------------------------
            |jonh    |1     |boss     |20     |100   |
            |porter  |2     |manager  |30     |200   |
            ------------------------------------------
            <BLANKLINE>
            >>> # Read from online store with specific keys (same API)
            >>> fs.read_feature_view('foo', 'v1', keys=[["1"], ["2"]], store_type=StoreType.ONLINE).show()
            --------------------------------
            |"ID"  |"TITLE"  |"AGE"       |
            --------------------------------
            |1     |boss     |20          |
            |2     |manager  |30          |
            --------------------------------
            <BLANKLINE>
            >>> # Select specific features (works for both stores)
            >>> fs.read_feature_view('foo', 'v1', keys=[["1"]], feature_names=["TITLE", "AGE"]).show()
            ----------------------
            |"TITLE"  |"AGE"    |
            ----------------------
            |boss     |20       |
            ----------------------
            >>> # Postgres online reads default to pandas (local-build fast path).
            >>> # Pass as_pandas=False to force a Snowpark DataFrame instead.
            >>> pdf = fs.read_feature_view('foo', 'v1', keys=[["1"]], store_type=StoreType.ONLINE)
            >>> type(pdf).__name__
            'DataFrame'

        """
        feature_view = self._validate_feature_view_name_and_version_input(feature_view, version)

        if feature_view.status == FeatureViewStatus.DRAFT or feature_view.version is None:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"FeatureView {feature_view.name} has not been registered."),
            )

        store_type = _get_store_type(store_type)

        # Resolve the as_pandas default. Postgres online reads default to pandas because
        # the Online Service Query API already returns row-oriented JSON; the historical
        # Snowpark default required a wasteful create_dataframe(VALUES ...) round-trip.
        # All other paths default to Snowpark DataFrame to preserve existing behavior.
        if as_pandas is None:
            as_pandas = (
                store_type == fv_mod.StoreType.ONLINE
                and feature_view.online_config is not None
                and feature_view.online_config.store_type == OnlineStoreType.POSTGRES
            )

        if store_type == fv_mod.StoreType.ONLINE:
            return self._read_from_online_store(feature_view, keys, feature_names, as_pandas=as_pandas)
        elif store_type == fv_mod.StoreType.OFFLINE:
            if as_pandas:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        "as_pandas=True is not supported for store_type=OFFLINE; offline reads can be arbitrarily "
                        "large and a local pandas materialization invites OOM. Call .to_pandas() on the returned "
                        "Snowpark DataFrame instead if you accept the full-scan cost."
                    ),
                )
            return self._read_from_offline_store(feature_view, keys, feature_names)
        else:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(f"Invalid store type: {store_type}"),
            )

    @dispatch_decorator()
    def list_feature_views(
        self,
        *,
        entity_name: Optional[str] = None,
        feature_view_name: Optional[str] = None,
    ) -> DataFrame:
        """
        List FeatureViews in the FeatureStore.
        If entity_name is specified, FeatureViews associated with that Entity will be listed.
        If feature_view_name is specified, further reducing the results to only match the specified name.

        Args:
            entity_name: Entity name.
            feature_view_name: FeatureView name.

        Returns:
            FeatureViews information as a Snowpark DataFrame.

        Example::

            >>> fs = FeatureStore(...)
            >>> draft_fv = FeatureView(
            ...     name='foo',
            ...     entities=[e1, e2],
            ...     feature_df=session.sql('...'),
            ...     desc='this is description',
            ... )
            >>> fs.register_feature_view(feature_view=draft_fv, version='v1')
            >>> fs.list_feature_views().select("name", "version", "desc").show()
            --------------------------------------------
            |"NAME"  |"VERSION"  |"DESC"               |
            --------------------------------------------
            |FOO     |v1         |this is description  |
            --------------------------------------------

        """
        if feature_view_name is not None:
            feature_view_name = SqlIdentifier(feature_view_name)

        if entity_name is not None:
            entity_name = SqlIdentifier(entity_name)
            return self._optimized_find_feature_views(entity_name, feature_view_name)
        else:
            fv_rows = self._get_fv_backend_representations(feature_view_name, prefix_match=True)

            output_values: list[list[Any]] = []
            iceberg_config_cache: dict[str, StorageConfig] = {}
            for row, _ in fv_rows:
                self._extract_feature_view_info(row, output_values, iceberg_config_cache)

            return self._session.create_dataframe(output_values, schema=_LIST_FEATURE_VIEW_SCHEMA)

    @dispatch_decorator()
    def get_feature_view(self, name: str, version: str) -> FeatureView:
        """
        Retrieve previously registered FeatureView.

        Args:
            name: FeatureView name.
            version: FeatureView version.

        Returns:
            FeatureView object.

        Raises:
            SnowflakeMLException: [ValueError] FeatureView with name and version is not found,
                or incurred exception when reconstructing the FeatureView object.

        Example::

            >>> fs = FeatureStore(...)
            >>> # draft_fv is a local object that hasn't materialized to Snowflake backend yet.
            >>> draft_fv = FeatureView(
            ...     name='foo',
            ...     entities=[e1],
            ...     feature_df=session.sql('...'),
            ...     desc='this is description',
            ... )
            >>> fs.register_feature_view(feature_view=draft_fv, version='v1')
            <BLANKLINE>
            >>> # fv is a local object that maps to a Snowflake backend object.
            >>> fv = fs.get_feature_view('foo', 'v1')
            >>> print(f"name: {fv.name}")
            >>> print(f"version:{fv.version}")
            >>> print(f"desc:{fv.desc}")
            name: FOO
            version:v1
            desc:this is description

        """
        name = SqlIdentifier(name)
        version = FeatureViewVersion(version)

        fv_name = FeatureView._get_physical_name(name, version)
        results = self._get_fv_backend_representations(fv_name)
        if len(results) != 1:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"Failed to find FeatureView {name}/{version}: {results}"),
            )

        return self._compose_feature_view(
            results[0][0], results[0][1], self.list_entities().collect(statement_params=self._telemetry_stmp)
        )

    @dispatch_decorator()
    def create_online_service(self, producer_role: str, consumer_role: str) -> online_service.OnlineServiceResult:
        """Create the Online Service for this store's schema.

        Requires schema OWNERSHIP and account feature enablement. After SUCCESS, poll
        :meth:`get_online_service_status` until ``RUNNING`` before using online feature
        reads or stream ingestion.

        Args:
            producer_role: Role name granted producer privileges on the Online Service.
            consumer_role: Role name granted consumer privileges on the Online Service.

        Returns:
            Parsed create result from the Online Service.
        """
        return online_service.create_online_service(
            self._session,
            self._config.database,
            self._config.schema,
            producer_role,
            consumer_role,
            statement_params=self._telemetry_stmp,
        )

    @dispatch_decorator()
    def get_online_service_status(self) -> online_service.OnlineServiceStatus:
        """Return Online Service status.

        Poll this method after :meth:`create_online_service` until ``status`` is
        ``RUNNING`` before using online feature reads or stream ingestion.

        Returns:
            OnlineServiceStatus with ``status``, ``message``, and ``endpoints``.
        """
        return online_service.get_online_service_status(
            self._session,
            self._config.database,
            self._config.schema,
            statement_params=self._telemetry_stmp,
        )

    @dispatch_decorator()
    def drop_online_service(self) -> online_service.OnlineServiceResult:
        """Drop the Online Service.

        Stops the Online Service and releases its resources. Online feature reads
        and stream ingestion will no longer be available after this call.

        Returns:
            OnlineServiceResult with ``status`` and ``message``.
        """
        return online_service.drop_online_service(
            self._session,
            self._config.database,
            self._config.schema,
            statement_params=self._telemetry_stmp,
        )

    @overload
    def refresh_feature_view(
        self, feature_view: str, version: str, *, store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE
    ) -> None:
        ...

    @overload
    def refresh_feature_view(
        self,
        feature_view: FeatureView,
        version: Optional[str] = None,
        *,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
    ) -> None:
        ...

    @dispatch_decorator()  # type: ignore[misc]
    def refresh_feature_view(
        self,
        feature_view: Union[FeatureView, str],
        version: Optional[str] = None,
        *,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
    ) -> None:
        """Manually refresh a feature view.

        Args:
            feature_view: A registered feature view object, or the name of feature view.
            version: Optional version of feature view. Must set when argument feature_view is a str.
            store_type: Specify which storage to refresh. Can be StoreType.OFFLINE or StoreType.ONLINE.
                - StoreType.OFFLINE (default): Refreshes the offline feature view.
                - StoreType.ONLINE: Refreshes the online feature table for real-time serving.
                  Only available for feature views with online=True.
                Defaults to StoreType.OFFLINE.

        Raises:
            SnowflakeMLException: [ValueError] Invalid store type.

        Example::

            >>> fs = FeatureStore(...)
            >>> fv = fs.get_feature_view(name='MY_FV', version='v1')
            <BLANKLINE>
            >>> # refresh with name and version
            >>> fs.refresh_feature_view('MY_FV', 'v1')
            >>> fs.get_refresh_history('MY_FV', 'v1').show()
            -----------------------------------------------------------------------------------------------------
            |"NAME"    |"STATE"    |"REFRESH_START_TIME"        |"REFRESH_END_TIME"          |"REFRESH_ACTION"  |
            -----------------------------------------------------------------------------------------------------
            |MY_FV$v1  |SUCCEEDED  |2024-07-10 14:53:58.504000  |2024-07-10 14:53:59.088000  |INCREMENTAL       |
            -----------------------------------------------------------------------------------------------------
            <BLANKLINE>
            >>> # refresh with feature view object
            >>> fs.refresh_feature_view(fv)
            >>> fs.get_refresh_history(fv).show()
            -----------------------------------------------------------------------------------------------------
            |"NAME"    |"STATE"    |"REFRESH_START_TIME"        |"REFRESH_END_TIME"          |"REFRESH_ACTION"  |
            -----------------------------------------------------------------------------------------------------
            |MY_FV$v1  |SUCCEEDED  |2024-07-10 14:54:06.680000  |2024-07-10 14:54:07.226000  |INCREMENTAL       |
            |MY_FV$v1  |SUCCEEDED  |2024-07-10 14:53:58.504000  |2024-07-10 14:53:59.088000  |INCREMENTAL       |
            -----------------------------------------------------------------------------------------------------

        """
        feature_view = self._validate_feature_view_name_and_version_input(feature_view, version)

        store_type = _get_store_type(store_type)

        if store_type == fv_mod.StoreType.ONLINE:
            # Refresh online feature table only
            if not feature_view.online:
                warnings.warn(
                    f"Feature view {feature_view.name}/{feature_view.version} does not have online storage enabled.",
                    stacklevel=2,
                    category=UserWarning,
                )
                return

            if (
                feature_view.online_config is not None
                and feature_view.online_config.store_type == fv_mod.OnlineStoreType.POSTGRES
            ):
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        "Manual refresh is not supported for Postgres online feature tables. "
                        "Postgres online stores are refreshed automatically by the Online Service."
                    ),
                )

            # Use the unified method but specify online-only refresh
            self._update_feature_view_status(feature_view, "REFRESH", store_type=fv_mod.StoreType.ONLINE)
        elif store_type == fv_mod.StoreType.OFFLINE:
            # Refresh offline feature view only
            if feature_view.status == FeatureViewStatus.STATIC:
                warnings.warn(
                    "Static feature view can't be refreshed. You must set refresh_freq when register_feature_view().",
                    stacklevel=2,
                    category=UserWarning,
                )
                return
            self._update_feature_view_status(feature_view, "REFRESH", store_type=fv_mod.StoreType.OFFLINE)
        else:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(f"Invalid store type: {store_type}"),
            )

    @overload
    def get_refresh_history(
        self,
        feature_view: FeatureView,
        version: Optional[str] = None,
        *,
        verbose: bool = False,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
    ) -> DataFrame:
        ...

    @overload
    def get_refresh_history(
        self,
        feature_view: str,
        version: str,
        *,
        verbose: bool = False,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
    ) -> DataFrame:
        ...

    def get_refresh_history(
        self,
        feature_view: Union[FeatureView, str],
        version: Optional[str] = None,
        *,
        verbose: bool = False,
        store_type: Union[fv_mod.StoreType, str] = fv_mod.StoreType.OFFLINE,
    ) -> DataFrame:
        """Get refresh history statistics about a feature view.

        Args:
            feature_view: A registered feature view object, or the name of feature view.
            version: Optional version of feature view. Must set when argument feature_view is a str.
            verbose: Return more detailed history when set true.
            store_type: Store to get refresh history from - StoreType.ONLINE or StoreType.OFFLINE (default).
                - StoreType.OFFLINE (default): Returns refresh history for the offline feature view (dynamic table).
                - StoreType.ONLINE: Returns refresh history for the online feature table.
                  Only available for feature views with online=True.

        Returns:
            A dataframe contains the refresh history information.

        Raises:
            SnowflakeMLException: [ValueError]
                If store_type is ONLINE but feature view doesn't have online storage enabled.

        Example::

            >>> fs = FeatureStore(...)
            >>> fv = fs.get_feature_view(name='MY_FV', version='v1')
            >>> # Get offline refresh history (default)
            >>> fs.refresh_feature_view('MY_FV', 'v1')
            >>> fs.get_refresh_history('MY_FV', 'v1').show()
            -----------------------------------------------------------------------------------------------------
            |"NAME"    |"STATE"    |"REFRESH_START_TIME"        |"REFRESH_END_TIME"          |"REFRESH_ACTION"  |
            -----------------------------------------------------------------------------------------------------
            |MY_FV$v1  |SUCCEEDED  |2024-07-10 14:53:58.504000  |2024-07-10 14:53:59.088000  |INCREMENTAL       |
            -----------------------------------------------------------------------------------------------------
            <BLANKLINE>
            >>> # Get online refresh history (for feature views with online storage)
            >>> fs.get_refresh_history('MY_FV', 'v1', store_type=StoreType.ONLINE).show()
            -----------------------------------------------------------------------------------------------------
            |"NAME"          |"STATE"    |"REFRESH_START_TIME"        |"REFRESH_END_TIME"          |"REFRESH_ACTION"  |
            -----------------------------------------------------------------------------------------------------
            |MY_FV$v1$ONLINE |SUCCEEDED  |2024-07-10 14:54:01.200000  |2024-07-10 14:54:02.100000  |INCREMENTAL       |
            -----------------------------------------------------------------------------------------------------
            <BLANKLINE>
            >>> # Verbose mode works for both storage types
            >>> fs.get_refresh_history(fv, verbose=True, store_type=StoreType.OFFLINE).show()
            >>> fs.get_refresh_history(fv, verbose=True, store_type=StoreType.ONLINE).show()

        """
        feature_view = self._validate_feature_view_name_and_version_input(feature_view, version)

        store_type = _get_store_type(store_type)

        if feature_view.status == FeatureViewStatus.STATIC:
            warnings.warn(
                "Static feature view never refreshes.",
                stacklevel=2,
                category=UserWarning,
            )
            return self._session.create_dataframe([Row()])

        if feature_view.status == FeatureViewStatus.DRAFT:
            warnings.warn(
                "This feature view has not been registered thus has no refresh history.",
                stacklevel=2,
                category=UserWarning,
            )
            return self._session.create_dataframe([Row()])

        # Validate online store request
        if store_type == fv_mod.StoreType.ONLINE:
            if not feature_view.online:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        f"Feature view '{feature_view.name}' version '{feature_view.version}' "
                        "does not have online storage enabled. Cannot retrieve online refresh history."
                    ),
                )
            return self._get_online_refresh_history(feature_view, verbose)
        elif store_type == fv_mod.StoreType.OFFLINE:
            return self._get_offline_refresh_history(feature_view, verbose)
        else:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(f"Invalid store type: {store_type}"),
            )

    def _get_offline_refresh_history(self, feature_view: FeatureView, verbose: bool) -> DataFrame:
        """Get refresh history for offline feature view (dynamic table)."""
        fv_resolved_name = FeatureView._get_physical_name(
            feature_view.name,
            feature_view.version,  # type: ignore[arg-type]
        ).resolved()
        select_cols = "*" if verbose else "name, state, refresh_start_time, refresh_end_time, refresh_action"
        return self._session.sql(
            f"""
            SELECT
                {select_cols}
            FROM TABLE (
                {self._config.database}.INFORMATION_SCHEMA.DYNAMIC_TABLE_REFRESH_HISTORY (RESULT_LIMIT => 10000)
            )
            WHERE NAME = '{fv_resolved_name}'
            AND SCHEMA_NAME = '{self._config.schema.resolved()}'
            """
        )

    def _get_online_refresh_history(self, feature_view: FeatureView, verbose: bool) -> DataFrame:
        """Get refresh history for online feature table."""
        online_table_name = FeatureView._get_online_table_name(feature_view.name, feature_view.version)
        select_cols = "*" if verbose else "name, state, refresh_start_time, refresh_end_time, refresh_action"
        name = (
            f"{self._config.database.identifier()}."
            f"{self._config.schema.identifier()}."
            f"{online_table_name.identifier()}"
        )
        return self._session.sql(
            f"""
            SELECT
                {select_cols}
            FROM TABLE (
                {self._config.database}.INFORMATION_SCHEMA.ONLINE_FEATURE_TABLE_REFRESH_HISTORY (
                    NAME => '{name}'
                )
            )
            """
        )

    @overload
    def resume_feature_view(self, feature_view: FeatureView) -> FeatureView:
        ...

    @overload
    def resume_feature_view(self, feature_view: str, version: str) -> FeatureView:
        ...

    @dispatch_decorator()  # type: ignore[misc]
    def resume_feature_view(self, feature_view: Union[FeatureView, str], version: Optional[str] = None) -> FeatureView:
        """
        Resume a previously suspended FeatureView.

        This operation resumes both the offline feature view (dynamic table and associated task)
        and the online feature table (if it exists) to ensure consistent state across all storage types.

        Args:
            feature_view: FeatureView object or name to resume.
            version: Optional version of feature view. Must set when argument feature_view is a str.

        Returns:
            A new feature view with updated status.

        Example::

            >>> fs = FeatureStore(...)
            >>> # you must already have feature views registered
            >>> fv = fs.get_feature_view(name='MY_FV', version='v1')
            >>> fs.suspend_feature_view('MY_FV', 'v1')
            >>> fs.list_feature_views().select("NAME", "VERSION", "SCHEDULING_STATE").show()
            -------------------------------------------
            |"NAME"  |"VERSION"  |"SCHEDULING_STATE"  |
            -------------------------------------------
            |MY_FV   |v1         |SUSPENDED           |
            -------------------------------------------
            <BLANKLINE>
            >>> fs.resume_feature_view('MY_FV', 'v1')
            >>> fs.list_feature_views().select("NAME", "VERSION", "SCHEDULING_STATE").show()
            -------------------------------------------
            |"NAME"  |"VERSION"  |"SCHEDULING_STATE"  |
            -------------------------------------------
            |MY_FV   |v1         |ACTIVE              |
            -------------------------------------------

        """
        feature_view = self._validate_feature_view_name_and_version_input(feature_view, version)

        # Plan atomic resume operations
        operations, rollback_operations = self._plan_feature_view_status_operations(feature_view, "RESUME")

        try:
            # Execute all operations atomically
            self._execute_atomic_operations(operations)
            logger.info(f"Successfully RESUME FeatureView {feature_view.name}/{feature_view.version}.")
        except Exception as e:
            # Handle failure with rollback
            self._handle_status_operation_failure(e, rollback_operations, feature_view, "RESUME")

        return self.get_feature_view(feature_view.name, str(feature_view.version))

    @overload
    def suspend_feature_view(self, feature_view: FeatureView) -> FeatureView:
        ...

    @overload
    def suspend_feature_view(self, feature_view: str, version: str) -> FeatureView:
        ...

    @dispatch_decorator()  # type: ignore[misc]
    def suspend_feature_view(self, feature_view: Union[FeatureView, str], version: Optional[str] = None) -> FeatureView:
        """
        Suspend an active FeatureView.

        This operation suspends both the offline feature view (dynamic table and associated task)
        and the online feature table (if it exists).

        Args:
            feature_view: FeatureView object or name to suspend.
            version: Optional version of feature view. Must set when argument feature_view is a str.

        Returns:
            A new feature view with updated status.

        Example::

            >>> fs = FeatureStore(...)
            >>> # assume you already have feature views registered
            >>> fv = fs.get_feature_view(name='MY_FV', version='v1')
            >>> fs.suspend_feature_view('MY_FV', 'v1')
            >>> fs.list_feature_views().select("NAME", "VERSION", "SCHEDULING_STATE").show()
            -------------------------------------------
            |"NAME"  |"VERSION"  |"SCHEDULING_STATE"  |
            -------------------------------------------
            |MY_FV   |v1         |SUSPENDED           |
            -------------------------------------------
            <BLANKLINE>
            >>> fs.resume_feature_view('MY_FV', 'v1')
            >>> fs.list_feature_views().select("NAME", "VERSION", "SCHEDULING_STATE").show()
            -------------------------------------------
            |"NAME"  |"VERSION"  |"SCHEDULING_STATE"  |
            -------------------------------------------
            |MY_FV   |v1         |ACTIVE              |
            -------------------------------------------

        """
        feature_view = self._validate_feature_view_name_and_version_input(feature_view, version)

        # Plan atomic suspend operations
        operations, rollback_operations = self._plan_feature_view_status_operations(feature_view, "SUSPEND")

        try:
            # Execute all operations atomically
            self._execute_atomic_operations(operations)
            logger.info(f"Successfully suspended FeatureView {feature_view.name}/{feature_view.version}.")
        except Exception as e:
            # Handle failure with rollback
            self._handle_status_operation_failure(e, rollback_operations, feature_view, "SUSPEND")

        return self.get_feature_view(feature_view.name, str(feature_view.version))

    @overload
    def delete_feature_view(self, feature_view: FeatureView) -> None:
        ...

    @overload
    def delete_feature_view(self, feature_view: str, version: str) -> None:
        ...

    @dispatch_decorator()  # type: ignore[misc]
    def delete_feature_view(self, feature_view: Union[FeatureView, str], version: Optional[str] = None) -> None:
        """
        Delete a FeatureView.

        Args:
            feature_view: FeatureView object or name to delete.
            version: Optional version of feature view. Must set when argument feature_view is a str.

        Raises:
            SnowflakeMLException: [ValueError] FeatureView is not registered.

        Example::

            >>> fs = FeatureStore(...)
            >>> fv = FeatureView('FV0', ...)
            >>> fv1 = fs.register_feature_view(fv, 'FIRST')
            >>> fv2 = fs.register_feature_view(fv, 'SECOND')
            >>> fs.list_feature_views().select('NAME', 'VERSION').show()
            ----------------------
            |"NAME"  |"VERSION"  |
            ----------------------
            |FV0     |SECOND     |
            |FV0     |FIRST      |
            ----------------------
            <BLANKLINE>
            >>> # delete with name and version
            >>> fs.delete_feature_view('FV0', 'FIRST')
            >>> fs.list_feature_views().select('NAME', 'VERSION').show()
            ----------------------
            |"NAME"  |"VERSION"  |
            ----------------------
            |FV0     |SECOND     |
            ----------------------
            <BLANKLINE>
            >>> # delete with feature view object
            >>> fs.delete_feature_view(fv2)
            >>> fs.list_feature_views().select('NAME', 'VERSION').show()
            ----------------------
            |"NAME"  |"VERSION"  |
            ----------------------
            |        |           |
            ----------------------

        """
        feature_view = self._validate_feature_view_name_and_version_input(feature_view, version)

        # TODO: we should leverage lineage graph to check downstream deps, and block the deletion
        # if there're other FVs depending on this
        if feature_view.status == FeatureViewStatus.DRAFT or feature_view.version is None:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"FeatureView {feature_view.name} has not been registered."),
            )

        fully_qualified_name = feature_view.fully_qualified_name()
        if feature_view.status == FeatureViewStatus.STATIC:
            self._session.sql(f"DROP VIEW IF EXISTS {fully_qualified_name}").collect(
                statement_params=self._telemetry_stmp
            )
        else:
            # Both regular Dynamic Tables and Dynamic Iceberg Tables use DROP DYNAMIC TABLE
            self._session.sql(f"DROP DYNAMIC TABLE IF EXISTS {fully_qualified_name}").collect(
                statement_params=self._telemetry_stmp
            )
            # CRON-based FVs have a companion Task with the same name. Drop it
            # unconditionally — IF EXISTS makes this a no-op for duration-based FVs.
            self._session.sql(f"DROP TASK IF EXISTS {fully_qualified_name}").collect(
                statement_params=self._telemetry_stmp
            )

        # Delete online feature table if it exists
        if feature_view.online:
            fully_qualified_online_name = feature_view.fully_qualified_online_table_name()
            try:
                self._session.sql(f"DROP ONLINE FEATURE TABLE IF EXISTS {fully_qualified_online_name}").collect(
                    statement_params=self._telemetry_stmp
                )
            except Exception as e:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                    original_exception=RuntimeError(
                        f"Failed to delete online feature table {fully_qualified_online_name}: {e}"
                    ),
                )

        # Clean up streaming FV resources (udf_transformed table + ref count)
        if feature_view.is_streaming:
            from snowflake.ml.feature_store.streaming_registration import (
                cleanup_streaming_feature_view,
            )

            feature_view_name = FeatureView._get_physical_name(feature_view.name, feature_view.version)
            cleanup_streaming_feature_view(
                session=self._session,
                feature_view_name=feature_view_name,
                version=str(feature_view.version),
                fv_name=str(feature_view.name),
                fv_metadata=feature_view._metadata(),
                metadata_manager=self._metadata_manager,
                get_fully_qualified_name_fn=self._get_fully_qualified_name,
                telemetry_stmp=self._telemetry_stmp,
            )

        # Delete aggregation metadata and feature descriptions if exist
        self._metadata_manager.delete_feature_view_metadata(str(feature_view.name), str(feature_view.version))

        logger.info(f"Deleted FeatureView {feature_view.name}/{feature_view.version}.")

    @dispatch_decorator()
    def list_entities(self) -> DataFrame:
        """
        List all Entities in the FeatureStore.

        Returns:
            Snowpark DataFrame containing the results.

        Example::

            >>> fs = FeatureStore(...)
            >>> e_1 = Entity("my_entity", ['col_1'], desc='My first entity.')
            >>> fs.register_entity(e_1)
            >>> fs.list_entities().show()
            -----------------------------------------------------------
            |"NAME"     |"JOIN_KEYS"  |"DESC"            |"OWNER"     |
            -----------------------------------------------------------
            |MY_ENTITY  |["COL_1"]    |My first entity.  |REGTEST_RL  |
            -----------------------------------------------------------

        """
        prefix_len = len(_ENTITY_TAG_PREFIX) + 1
        return cast(
            DataFrame,
            self._session.sql(
                f"SHOW TAGS LIKE '{_ENTITY_TAG_PREFIX}%' IN SCHEMA {self._config.full_schema_path}"
            ).select(
                F.col('"name"').substr(prefix_len, _ENTITY_NAME_LENGTH_LIMIT).alias("NAME"),
                F.call_builtin("REPLACE", F.col('"allowed_values"'), F.lit(","), F.lit('", "')).alias("JOIN_KEYS"),
                F.col('"comment"').alias("DESC"),
                F.col('"owner"').alias("OWNER"),
            ),
        )

    @dispatch_decorator()
    def get_entity(self, name: str) -> Entity:
        """
        Retrieve previously registered Entity object.

        Args:
            name: Entity name.

        Returns:
            Entity object.

        Raises:
            SnowflakeMLException: [ValueError] Entity is not found.
            SnowflakeMLException: [RuntimeError] Failed to retrieve tag reference information.
            SnowflakeMLException: [RuntimeError] Failed to find resources.

        Example::

            >>> fs = FeatureStore(...)
            >>> # e_1 is a local object that hasn't registered to Snowflake backend yet.
            >>> e_1 = Entity("my_entity", ['col_1'], desc='My first entity.')
            >>> fs.register_entity(e_1)
            <BLANKLINE>
            >>> # e_2 is a local object that points a backend object in Snowflake.
            >>> e_2 = fs.get_entity("my_entity")
            >>> print(e_2)
            Entity(name=MY_ENTITY, join_keys=['COL_1'], owner=REGTEST_RL, desc=My first entity.)

        """
        name = SqlIdentifier(name)
        try:
            result = (
                self.list_entities()
                .filter(F.col("NAME") == name.resolved())
                .collect(statement_params=self._telemetry_stmp)
            )
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to list entities: {e}"),
            ) from e
        if len(result) == 0:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"Cannot find Entity with name: {name}."),
            )

        join_keys = [f'"{k}"' for k in json.loads(result[0]["JOIN_KEYS"])]

        return Entity._construct_entity(
            name=SqlIdentifier(result[0]["NAME"], case_sensitive=True).identifier(),
            join_keys=join_keys,
            desc=result[0]["DESC"],
            owner=result[0]["OWNER"],
        )

    @dispatch_decorator()
    def delete_entity(self, name: str) -> None:
        """
        Delete a previously registered Entity.

        Args:
            name: Name of entity to be deleted.

        Raises:
            SnowflakeMLException: [ValueError] Entity with given name not exists.
            SnowflakeMLException: [RuntimeError] Failed to alter schema or drop tag.
            SnowflakeMLException: [RuntimeError] Failed to find resources.

        Example::

            >>> fs = FeatureStore(...)
            >>> e_1 = Entity("my_entity", ['col_1'], desc='My first entity.')
            >>> fs.register_entity(e_1)
            >>> fs.list_entities().show()
            -----------------------------------------------------------
            |"NAME"     |"JOIN_KEYS"  |"DESC"            |"OWNER"     |
            -----------------------------------------------------------
            |MY_ENTITY  |["COL_1"]    |My first entity.  |REGTEST_RL  |
            -----------------------------------------------------------
            <BLANKLINE>
            >>> fs.delete_entity("my_entity")
            >>> fs.list_entities().show()
            -------------------------------------------
            |"NAME"  |"JOIN_KEYS"  |"DESC"  |"OWNER"  |
            -------------------------------------------
            |        |             |        |         |
            -------------------------------------------

        """
        name = SqlIdentifier(name)

        if not self._validate_entity_exists(name):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"Entity {name} does not exist."),
            )

        active_feature_views = self.list_feature_views(entity_name=name).collect(statement_params=self._telemetry_stmp)

        if len(active_feature_views) > 0:
            active_fvs = [r["NAME"] for r in active_feature_views]
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.SNOWML_DELETE_FAILED,
                original_exception=ValueError(f"Cannot delete Entity {name} due to active FeatureViews: {active_fvs}."),
            )

        tag_name = self._get_fully_qualified_name(self._get_entity_name(name))
        try:
            self._session.sql(f"DROP TAG IF EXISTS {tag_name}").collect(statement_params=self._telemetry_stmp)
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to delete entity: {e}."),
            ) from e
        logger.info(f"Deleted Entity {name}.")

    # =========================================================================
    # Stream Source APIs
    # =========================================================================

    @dispatch_decorator()
    @snowpark_utils.private_preview(version="1.33.0")
    def register_stream_source(self, stream_source: StreamSource) -> StreamSource:
        """
        Register a StreamSource in the FeatureStore.

        Args:
            stream_source: StreamSource object to be registered.

        Returns:
            A registered StreamSource object with owner populated.

        Raises:
            SnowflakeMLException: [RuntimeError] Failed to save stream source metadata.

        Example::

            >>> fs = FeatureStore(...)
            >>> from snowflake.snowpark.types import (
            ...     StructType, StructField, StringType, FloatType, TimestampType,
            ... )
            >>> txn_source = StreamSource(
            ...     name="transaction_events",
            ...     schema=StructType([
            ...         StructField("user_id", StringType()),
            ...         StructField("amount", FloatType()),
            ...         StructField("event_time", TimestampType()),
            ...     ]),
            ...     desc="Real-time transaction events",
            ... )
            >>> fs.register_stream_source(txn_source)
            >>> fs.list_stream_sources().show()
            -------------------------------------------------------------------------------------...
            |"NAME"                |"SCHEMA"  |"DESC"                    |"OWNER"     |
            -------------------------------------------------------------------------------------...
            |TRANSACTION_EVENTS    |[...]     |Real-time transaction...  |REGTEST_RL  |
            -------------------------------------------------------------------------------------...

        """

        if self._metadata_manager.stream_source_exists(stream_source.name.resolved()):
            warnings.warn(
                f"StreamSource {stream_source.name} already exists. Skip registration.",
                stacklevel=2,
                category=UserWarning,
            )
            return self.get_stream_source(stream_source.name)

        owner = self._session.get_current_role()
        stream_source.owner = owner

        metadata = stream_source._to_dict()
        try:
            self._metadata_manager.save_stream_source(
                name=stream_source.name.resolved(),
                metadata=metadata,
            )
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to register stream source `{stream_source.name}`: {e}."),
            ) from e

        logger.info(f"Registered StreamSource {stream_source}.")

        return self.get_stream_source(stream_source.name)

    @dispatch_decorator()
    def get_stream_source(self, name: str) -> StreamSource:
        """
        Retrieve a previously registered StreamSource object.

        Args:
            name: StreamSource name.

        Returns:
            StreamSource object.

        Raises:
            SnowflakeMLException: [ValueError] StreamSource is not found.
            SnowflakeMLException: [RuntimeError] Failed to retrieve stream source metadata.

        Example::

            >>> fs = FeatureStore(...)
            >>> ss = fs.get_stream_source("transaction_events")
            >>> print(ss)
            StreamSource(name=TRANSACTION_EVENTS, ...)

        """
        name_id = SqlIdentifier(name)
        try:
            metadata = self._metadata_manager.get_stream_source_metadata(name_id.resolved())
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to retrieve stream source: {e}"),
            ) from e

        if metadata is None:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"Cannot find StreamSource with name: {name_id}."),
            )

        return StreamSource._from_dict(metadata)

    @dispatch_decorator()
    def stream_ingest(
        self,
        stream_source: Union[str, StreamSource],
        records: Union[list[dict[str, Any]], dict[str, Any]],
        *,
        timeout_sec: float = 120.0,
        statement_params: Optional[dict[str, Any]] = None,
    ) -> int:
        """Send rows to the Online Service for ingestion.

        Requires the ``SNOWFLAKE_PAT`` environment variable to be set with a valid
        Snowflake Programmatic Access Token.

        ``records`` may be one row as a dict or a non-empty ``list`` of row dicts.
        Each row's keys must match the registered ``StreamSource`` schema exactly
        (no missing or extra columns).

        Args:
            stream_source: Registered stream source name or a ``StreamSource`` instance.
            records: Rows to ingest.
            timeout_sec: Timeout in seconds for the ingest request.
            statement_params: Optional Snowpark statement parameters (for example telemetry).

        Returns:
            Count of records accepted by the Online Service. On partial success, the returned
            count may be less than the number of rows sent.

        Raises:
            SnowflakeMLException: If the Online Service or ingest endpoint is unavailable, ``SNOWFLAKE_PAT`` is
                unset, the request fails, or rows do not match the stream source schema.
        """
        if isinstance(stream_source, StreamSource):
            src = stream_source
            stream_name_wire = stream_source.name.resolved()
        else:
            src = self.get_stream_source(str(stream_source))
            stream_name_wire = src.name.resolved()

        stmp = self._telemetry_stmp if statement_params is None else statement_params
        st = online_service.assert_online_service_running_with_ingest_endpoint(
            self._session,
            self._config.database,
            self._config.schema,
            statement_params=stmp,
        )
        ingest_url = online_service.endpoint_url(st, "ingest")
        if not ingest_url:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError("Online Service returned no ingest endpoint."),
            )
        ingest_base = ingest_url

        expected_cols = _stream_source_schema_field_names(src.schema)
        rows = _normalize_stream_ingest_records(records)
        for i, row in enumerate(rows):
            _validate_stream_ingest_record_keys(expected_cols, row, i)

        return online_service.stream_ingest_records(
            self._session,
            ingest_base,
            stream_name_wire,
            rows,
            timeout_sec=timeout_sec,
            http_client=self._get_or_create_online_http_client(),
        )

    @dispatch_decorator()
    def list_stream_sources(self) -> DataFrame:
        """
        List all StreamSources in the FeatureStore.

        Returns:
            Snowpark DataFrame containing the results with columns:
            NAME, SCHEMA, DESC, OWNER.

        Raises:
            SnowflakeMLException: If the metadata query fails.

        Example::

            >>> fs = FeatureStore(...)
            >>> fs.list_stream_sources().show()
            -------------------------------------------------------------------------------------...
            |"NAME"                |"SCHEMA"  |"DESC"                    |"OWNER"     |
            -------------------------------------------------------------------------------------...
            |TRANSACTION_EVENTS    |[...]     |Real-time transaction...  |REGTEST_RL  |
            -------------------------------------------------------------------------------------...

        """
        if not self._metadata_manager.table_exists():
            return self._session.create_dataframe([], schema=_LIST_STREAM_SOURCE_SCHEMA)

        try:
            return self._session.sql(
                f"""
                    SELECT
                        METADATA:name::VARCHAR AS "NAME",
                        METADATA:schema::VARCHAR AS "SCHEMA",
                        METADATA:desc::VARCHAR AS "DESC",
                        METADATA:owner::VARCHAR AS "OWNER"
                    FROM {self._metadata_manager.table_path}
                    WHERE OBJECT_TYPE = '{MetadataObjectType.STREAM_SOURCE.value}'
                    AND METADATA_TYPE = '{MetadataType.STREAM_SOURCE_CONFIG.value}'
                    ORDER BY "NAME"
                    """
            )
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to list stream sources: {e}"),
            ) from e

    @dispatch_decorator()
    def delete_stream_source(self, name: str) -> None:
        """
        Delete a previously registered StreamSource.

        The StreamSource can only be deleted if no active FeatureViews reference it.

        Args:
            name: Name of the StreamSource to be deleted.

        Raises:
            SnowflakeMLException: [ValueError] StreamSource with given name not found.
            SnowflakeMLException: [ValueError] Cannot delete due to active references.
            SnowflakeMLException: [RuntimeError] Failed to delete stream source.

        Example::

            >>> fs = FeatureStore(...)
            >>> fs.delete_stream_source("transaction_events")

        """
        name_id = SqlIdentifier(name)

        if not self._metadata_manager.stream_source_exists(name_id.resolved()):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"StreamSource {name_id} does not exist."),
            )

        # Check for active feature view references
        ref_count = self._metadata_manager.get_stream_source_ref_count(name_id.resolved())
        if ref_count > 0:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.SNOWML_DELETE_FAILED,
                original_exception=ValueError(
                    f"Cannot delete StreamSource {name_id}: has {ref_count} active reference(s)."
                ),
            )

        try:
            self._metadata_manager.delete_stream_source_metadata(name_id.resolved())
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to delete stream source: {e}."),
            ) from e
        logger.info(f"Deleted StreamSource {name_id}.")

    @dispatch_decorator()
    def update_stream_source(self, name: str, *, desc: Optional[str] = None) -> Optional[StreamSource]:
        """Update a registered StreamSource description.

        Args:
            name: Name of the StreamSource to update.
            desc: New description to apply. Default to None (no change).

        Returns:
            Updated StreamSource object, or None if the StreamSource doesn't exist.

        Raises:
            SnowflakeMLException: [RuntimeError] Failed to update stream source.

        Example::

            >>> fs = FeatureStore(...)
            >>> fs.update_stream_source("transaction_events", desc="Updated description")
            >>> fs.get_stream_source("transaction_events").desc
            'Updated description'

        """
        name_id = SqlIdentifier(name)

        if not self._metadata_manager.stream_source_exists(name_id.resolved()):
            warnings.warn(
                f"StreamSource {name_id} does not exist.",
                stacklevel=2,
                category=UserWarning,
            )
            return None

        if desc is not None:
            try:
                self._metadata_manager.update_stream_source_desc(name_id.resolved(), desc)
            except Exception as e:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                    original_exception=RuntimeError(f"Failed to update stream source `{name_id}`: {e}."),
                ) from e

        logger.info(f"Successfully updated StreamSource {name_id}.")
        return self.get_stream_source(name_id)

    @dispatch_decorator()
    def retrieve_feature_values(
        self,
        spine_df: DataFrame,
        features: Union[list[Union[FeatureView, FeatureViewSlice]], list[str]],
        *,
        spine_timestamp_col: Optional[str] = None,
        exclude_columns: Optional[list[str]] = None,
        include_feature_view_timestamp_col: bool = False,
        auto_prefix: bool = False,
        join_method: Literal["sequential", "cte"] = "sequential",
    ) -> DataFrame:
        """
        Enrich spine dataframe with feature values for inference.

        Uses the latest entity mappings for rollup feature views. For point-in-time
        correct entity mappings (e.g., during training or backtesting with temporal
        rollup FVs), use ``generate_training_set`` instead.

        If spine_timestamp_col is specified, point-in-time feature values will be fetched.

        Args:
            spine_df: Snowpark DataFrame to join features into.
            features: List of features to join into the spine_df. Can be a list of FeatureView or FeatureViewSlice,
                or a list of serialized feature objects from Dataset.
            spine_timestamp_col: Timestamp column in spine_df for point-in-time feature value lookup.
            exclude_columns: Column names to exclude from the result dataframe.
            include_feature_view_timestamp_col: Generated dataset will include timestamp column of feature view
                (if feature view has timestamp column) if set true. Default to false.
            auto_prefix: If True, automatically prefix all feature columns with
                '{feature_view_name}_{version}_' to avoid name collisions.
                Default False. Use FeatureView.with_name() for custom prefixes.
            join_method: Method for feature joins. "sequential" for layer-by-layer joins (default),
                "cte" for CTE method. (Internal use only - subject to change)

        Returns:
            Snowpark DataFrame containing the joined results.

        Raises:
            ValueError: if features is empty.

        Example::

            >>> fs = FeatureStore(...)
            >>> # Assume you already have feature view registered.
            >>> fv = fs.get_feature_view('my_fv', 'v1')
            >>> # Spine dataframe has same join keys as the entity of fv.
            >>> spine_df = session.create_dataframe(["1", "2"], schema=["id"])
            >>> fs.retrieve_feature_values(spine_df, [fv]).show()
            --------------------
            |"END_STATION_ID"  |
            --------------------
            |505               |
            |347               |
            |466               |
            --------------------

        """
        if spine_timestamp_col is not None:
            spine_timestamp_col = SqlIdentifier(spine_timestamp_col)

        if len(features) == 0:
            raise ValueError("features cannot be empty")
        if isinstance(features[0], str):
            features = self._load_serialized_feature_views(cast(list[str], features))

        df, _ = self._join_features(
            spine_df,
            cast(list[Union[FeatureView, FeatureViewSlice]], features),
            spine_timestamp_col,
            include_feature_view_timestamp_col,
            auto_prefix,
            join_method,
        )

        if exclude_columns is not None:
            df = self._exclude_columns(df, exclude_columns)

        return df

    @dispatch_decorator()
    def generate_training_set(
        self,
        spine_df: DataFrame,
        features: list[Union[FeatureView, FeatureViewSlice]],
        *,
        save_as: Optional[str] = None,
        spine_timestamp_col: Optional[str] = None,
        spine_label_cols: Optional[list[str]] = None,
        exclude_columns: Optional[list[str]] = None,
        include_feature_view_timestamp_col: bool = False,
        auto_prefix: bool = False,
        join_method: Literal["sequential", "cte"] = "sequential",
    ) -> DataFrame:
        """
        Generate a training set from the specified Spine DataFrame and Feature Views.

        For rollup feature views with temporal entity mappings (``mapping_valid_from_col``
        and ``mapping_valid_to_col``), this method uses point-in-time correct entity
        resolution via a range JOIN with bounded validity windows ``[valid_from, valid_to)``,
        supporting 1:N mappings (one child entity to multiple parent entities simultaneously).
        For inference with latest mappings, use ``retrieve_feature_values`` instead.

        Result is materialized to a Snowflake Table if `save_as` is specified.

        Args:
            spine_df: Snowpark DataFrame to join features into.
            features: A list of FeatureView or FeatureViewSlice which contains features to be joined.
            save_as: If specified, a new table containing the produced result will be created. Name can be a fully
                qualified name or an unqualified name. If unqualified, defaults to the Feature Store database and schema
            spine_timestamp_col: Name of timestamp column in spine_df that will be used to join
                time-series features. If spine_timestamp_col is not none, the input features also must have
                timestamp_col.
            spine_label_cols: Name of column(s) in spine_df that contains labels.
            exclude_columns: Name of column(s) to exclude from the resulting training set.
            include_feature_view_timestamp_col: Generated dataset will include timestamp column of feature view
                (if feature view has timestamp column) if set true. Default to false.
            auto_prefix: If True, automatically prefix all feature columns with
                '{feature_view_name}_{version}_'. Default False.
                Use FeatureView.with_name() for custom prefixes.
            join_method: Method for feature joins. "sequential" for layer-by-layer joins (default),
                "cte" for CTE method. (Internal use only - subject to change)

        Returns:
            Returns a Snowpark DataFrame representing the training set.

        Raises:
            SnowflakeMLException: [RuntimeError] Materialized table name already exists
            SnowflakeMLException: [RuntimeError] Failed to create materialized table.

        Example::

            >>> fs = FeatureStore(session, ...)
            >>> # Assume you already have feature view registered.
            >>> fv = fs.get_feature_view("MY_FV", "1")
            >>> # Spine dataframe has same join keys as the entity of fv.
            >>> spine_df = session.create_dataframe(["1", "2"], schema=["id"])
            >>> training_set = fs.generate_training_set(
            ...     spine_df,
            ...     [fv],
            ...     save_as="my_training_set",
            ... )
            >>> print(type(training_set))
            <class 'snowflake.snowpark.table.Table'>
            <BLANKLINE>
            >>> print(training_set.queries)
            {'queries': ['SELECT  *  FROM (my_training_set)'], 'post_actions': []}

        """
        if spine_timestamp_col is not None:
            spine_timestamp_col = SqlIdentifier(spine_timestamp_col)
        if spine_label_cols is not None:
            spine_label_cols = to_sql_identifiers(spine_label_cols)  # type: ignore[assignment]

        result_df, join_keys = self._join_features(
            spine_df,
            features,
            spine_timestamp_col,
            include_feature_view_timestamp_col,
            auto_prefix,
            join_method,
            is_training=True,
        )

        if exclude_columns is not None:
            result_df = self._exclude_columns(result_df, exclude_columns)

        if save_as is not None:
            try:
                save_as = self._get_fully_qualified_name(save_as)
                result_df.write.mode("errorifexists").save_as_table(save_as, statement_params=self._telemetry_stmp)

                # Add tag
                task_obj_info = _FeatureStoreObjInfo(_FeatureStoreObjTypes.TRAINING_DATA, snowml_version.VERSION)
                self._session.sql(
                    f"""
                    ALTER TABLE {save_as}
                    SET TAG {self._get_fully_qualified_name(_FEATURE_STORE_OBJECT_TAG)}='{task_obj_info.to_json()}'
                    """
                ).collect(statement_params=self._telemetry_stmp)

                return self._session.table(save_as)

            except SnowparkSQLException as e:
                if e.sql_error_code == sql_error_codes.OBJECT_ALREADY_EXISTS:
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.OBJECT_ALREADY_EXISTS,
                        original_exception=RuntimeError(str(e)),
                    ) from e
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                    original_exception=RuntimeError(f"An error occurred during training set materialization: {e}."),
                ) from e
        return result_df

    @overload
    def generate_dataset(
        self,
        name: str,
        spine_df: DataFrame,
        features: list[Union[FeatureView, FeatureViewSlice]],
        *,
        version: Optional[str] = None,
        spine_timestamp_col: Optional[str] = None,
        spine_label_cols: Optional[list[str]] = None,
        exclude_columns: Optional[list[str]] = None,
        include_feature_view_timestamp_col: bool = False,
        auto_prefix: bool = False,
        desc: str = "",
        output_type: Literal["dataset"] = "dataset",
        join_method: Literal["sequential", "cte"] = "sequential",
    ) -> dataset.Dataset:
        ...

    @overload
    def generate_dataset(
        self,
        name: str,
        spine_df: DataFrame,
        features: list[Union[FeatureView, FeatureViewSlice]],
        *,
        output_type: Literal["table"],
        version: Optional[str] = None,
        spine_timestamp_col: Optional[str] = None,
        spine_label_cols: Optional[list[str]] = None,
        exclude_columns: Optional[list[str]] = None,
        include_feature_view_timestamp_col: bool = False,
        auto_prefix: bool = False,
        desc: str = "",
        join_method: Literal["sequential", "cte"] = "sequential",
    ) -> DataFrame:
        ...

    @dispatch_decorator()  # type: ignore[misc]
    def generate_dataset(
        self,
        name: str,
        spine_df: DataFrame,
        features: list[Union[FeatureView, FeatureViewSlice]],
        *,
        version: Optional[str] = None,
        spine_timestamp_col: Optional[str] = None,
        spine_label_cols: Optional[list[str]] = None,
        exclude_columns: Optional[list[str]] = None,
        include_feature_view_timestamp_col: bool = False,
        auto_prefix: bool = False,
        desc: str = "",
        output_type: Literal["dataset", "table"] = "dataset",
        join_method: Literal["sequential", "cte"] = "sequential",
    ) -> Union[dataset.Dataset, DataFrame]:
        """
        Generate dataset by given source table and feature views.

        Args:
            name: The name of the Dataset to be generated. Datasets are uniquely identified within a schema
                by their name and version.
            spine_df: Snowpark DataFrame to join features into.
            features: A list of FeatureView or FeatureViewSlice which contains features to be joined.
            version: The version of the Dataset to be generated. If none specified, the current timestamp
                will be used instead.
            spine_timestamp_col: Name of timestamp column in spine_df that will be used to join
                time-series features. If spine_timestamp_col is not none, the input features also must have
                timestamp_col.
            spine_label_cols: Name of column(s) in spine_df that contains labels.
            exclude_columns: Name of column(s) to exclude from the resulting training set.
            include_feature_view_timestamp_col: Generated dataset will include timestamp column of feature view
                (if feature view has timestamp column) if set true. Default to false.
            auto_prefix: If True, automatically prefix all feature columns with
                '{feature_view_name}_{version}_'. Default False.
                Use FeatureView.with_name() for custom prefixes.
            desc: A description about this dataset.
            output_type: (Deprecated) The type of Snowflake storage to use for the generated training data.
            join_method: Method for feature joins. "sequential" for layer-by-layer joins (default),
                "cte" for CTE method. (Internal use only - subject to change)

        Returns:
            If output_type is "dataset" (default), returns a Dataset object.
            If output_type is "table", returns a Snowpark DataFrame representing the table.

        Raises:
            SnowflakeMLException: [ValueError] Invalid output_type specified.
            SnowflakeMLException: [RuntimeError] Dataset name/version already exists.
            SnowflakeMLException: [RuntimeError] Failed to find resources.

        Example::

            >>> fs = FeatureStore(session, ...)
            >>> # Assume you already have feature view registered.
            >>> fv = fs.get_feature_view("MY_FV", "1")
            >>> # Spine dataframe has same join keys as the entity of fv.
            >>> spine_df = session.create_dataframe(["1", "2"], schema=["id"])
            >>> my_dataset = fs.generate_dataset(
            ...     "my_dataset"
            ...     spine_df,
            ...     [fv],
            ... )
            >>> # Current timestamp will be used as default version name.
            >>> # You can explicitly overwrite by setting a version.
            >>> my_dataset.list_versions()
            ['2024_07_12_11_26_22']
            <BLANKLINE>
            >>> my_dataset.read.to_snowpark_dataframe().show(n=3)
            -------------------------------------------------------
            |"QUALITY"  |"FIXED_ACIDITY"     |"VOLATILE_ACIDITY"  |
            -------------------------------------------------------
            |3          |11.600000381469727  |0.5799999833106995  |
            |3          |8.300000190734863   |1.0199999809265137  |
            |3          |7.400000095367432   |1.184999942779541   |
            -------------------------------------------------------

        """
        from snowflake.ml import (
            dataset,  # lazy import — heavy deps (numpy/pandas/pyarrow)
        )
        from snowflake.ml.dataset.dataset_metadata import FeatureStoreMetadata

        if output_type not in {"table", "dataset"}:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(f"Invalid output_type: {output_type}."),
            )

        # Convert name to fully qualified name if not already fully qualified
        name = self._get_fully_qualified_name(name)
        version = version or datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")

        fs_meta = FeatureStoreMetadata(
            spine_query=spine_df.queries["queries"][-1],
            compact_feature_views=[fv._get_compact_repr().to_json() for fv in features],
            spine_timestamp_col=spine_timestamp_col,
        )

        # Only set a save_as name if output_type is table
        table_name = f"{name}_{version}" if output_type == "table" else None
        result_df = self.generate_training_set(
            spine_df,
            features,
            spine_timestamp_col=spine_timestamp_col,
            spine_label_cols=spine_label_cols,
            exclude_columns=exclude_columns,
            include_feature_view_timestamp_col=include_feature_view_timestamp_col,
            auto_prefix=auto_prefix,
            save_as=table_name,
            join_method=join_method,
        )
        if output_type == "table":
            warnings.warn(
                "Generating a table from generate_dataset() is deprecated and will be removed in a future release,"
                " use generate_training_set() instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            return result_df

        try:
            assert output_type == "dataset"
            if not self._is_dataset_enabled():
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.SNOWML_CREATE_FAILED,
                    original_exception=RuntimeError(
                        "Dataset is not enabled in your account. Ask your account admin to set"
                        " FEATURE_DATASET=ENABLED or use generate_training_set() instead"
                        " to generate the data as a Snowflake Table."
                    ),
                )

            # Cache the result to a temporary table before creating the dataset
            # to ensure single query evaluation:
            has_tiled_fv = any(
                (fv.feature_view_ref if isinstance(fv, FeatureViewSlice) else fv).is_tiled for fv in features
            )
            if has_tiled_fv:
                result_df = result_df.cache_result()

            # TODO: Add feature store tag once Dataset (version) supports tags
            ds: dataset.Dataset = dataset.create_from_dataframe(
                self._session,
                name,
                version,
                input_dataframe=result_df,
                exclude_cols=[spine_timestamp_col] if spine_timestamp_col is not None else [],
                label_cols=spine_label_cols,
                properties=fs_meta,
                comment=desc,
            )
            return ds

        except dataset_errors.DatasetExistError as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.OBJECT_ALREADY_EXISTS,
                original_exception=RuntimeError(str(e)),
            ) from e
        except SnowparkSQLException as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"An error occurred during dataset generation: {e}."),
            ) from e

    @dispatch_decorator()
    def load_feature_views_from_dataset(self, ds: dataset.Dataset) -> list[Union[FeatureView, FeatureViewSlice]]:
        """
        Retrieve FeatureViews used during Dataset construction.

        Args:
            ds: Dataset object created from feature store.

        Returns:
            List of FeatureViews used during Dataset construction.

        Raises:
            ValueError: if dataset object is not generated from feature store.

        Example::

            >>> fs = FeatureStore(session, ...)
            >>> # Assume you already have feature view registered.
            >>> fv = fs.get_feature_view("MY_FV", "1.0")
            >>> # Spine dataframe has same join keys as the entity of fv.
            >>> spine_df = session.create_dataframe(["1", "2"], schema=["id"])
            >>> my_dataset = fs.generate_dataset(
            ...     "my_dataset"
            ...     spine_df,
            ...     [fv],
            ... )
            >>> fvs = fs.load_feature_views_from_dataset(my_dataset)
            >>> print(len(fvs))
            1
            <BLANKLINE>
            >>> print(type(fvs[0]))
            <class 'snowflake.ml.feature_store.feature_view.FeatureView'>
            <BLANKLINE>
            >>> print(fvs[0].name)
            MY_FV
            <BLANKLINE>
            >>> print(fvs[0].version)
            1.0

        """
        from snowflake.ml.dataset.dataset_metadata import (
            FeatureStoreMetadata,  # lazy import
        )

        assert ds.selected_version is not None
        source_meta = ds.selected_version._get_metadata()
        if (
            source_meta is None
            or not isinstance(source_meta.properties, FeatureStoreMetadata)
            or (
                source_meta.properties.serialized_feature_views is None
                and source_meta.properties.compact_feature_views is None
            )
        ):
            raise ValueError(f"Dataset {ds} does not contain valid feature view information.")

        properties = source_meta.properties
        if properties.serialized_feature_views:
            return self._load_serialized_feature_views(properties.serialized_feature_views)
        else:
            return self._load_compact_feature_views(properties.compact_feature_views)  # type: ignore[arg-type]

    def _rollback_created_resources(self, created_resources: list[tuple[_FeatureStoreObjTypes, str]]) -> None:
        """Rollback created resources in reverse order.

        Args:
            created_resources: List of (resource_type, resource_name) tuples to clean up
        """
        for resource_type, resource_name in reversed(created_resources):
            try:
                if resource_type == _FeatureStoreObjTypes.MANAGED_FEATURE_VIEW:
                    self._session.sql(f"DROP DYNAMIC TABLE IF EXISTS {resource_name}").collect(
                        statement_params=self._telemetry_stmp
                    )
                elif resource_type == _FeatureStoreObjTypes.EXTERNAL_FEATURE_VIEW:
                    self._session.sql(f"DROP VIEW IF EXISTS {resource_name}").collect(
                        statement_params=self._telemetry_stmp
                    )
                elif resource_type == _FeatureStoreObjTypes.FEATURE_VIEW_REFRESH_TASK:
                    self._session.sql(f"DROP TASK IF EXISTS {resource_name}").collect(
                        statement_params=self._telemetry_stmp
                    )
                elif resource_type == _FeatureStoreObjTypes.ONLINE_FEATURE_TABLE:
                    self._session.sql(f"DROP ONLINE FEATURE TABLE IF EXISTS {resource_name}").collect(
                        statement_params=self._telemetry_stmp
                    )
                elif resource_type == _FeatureStoreObjTypes.UDF_TRANSFORMED_TABLE:
                    self._session.sql(f"DROP TABLE IF EXISTS {resource_name}").collect(
                        statement_params=self._telemetry_stmp
                    )
                logger.info(f"Rollback: Successfully dropped {resource_type.value} {resource_name}")
            except Exception as rollback_error:
                # Log but don't fail the rollback process
                logger.warning(f"Rollback: Failed to drop {resource_type.value} {resource_name}: {rollback_error}")

    @telemetry.send_api_usage_telemetry(project=_PROJECT)
    def _create_updated_feature_view(
        self, base_fv: FeatureView, online_config: Optional[fv_mod.OnlineConfig] = None
    ) -> FeatureView:
        """Create an updated FeatureView with new online configuration."""
        assert base_fv.version is not None
        assert base_fv.database is not None
        assert base_fv.schema is not None
        assert base_fv.feature_df is not None

        feature_descs_str: Optional[dict[str, str]] = (
            {k.identifier(): v for k, v in base_fv.feature_descs.items()} if base_fv.feature_descs is not None else None
        )
        cluster_by_str: Optional[list[str]] = (
            [col.identifier() for col in base_fv.cluster_by] if base_fv.cluster_by is not None else None
        )

        return FeatureView._construct_feature_view(
            name=base_fv.name.identifier(),
            entities=base_fv.entities,
            feature_df=base_fv.feature_df,
            timestamp_col=base_fv.timestamp_col.identifier() if base_fv.timestamp_col is not None else None,
            desc=base_fv.desc,
            version=str(base_fv.version),
            status=base_fv.status,
            feature_descs=feature_descs_str or {},
            refresh_freq=base_fv.refresh_freq,
            database=base_fv.database.identifier(),
            schema=base_fv.schema.identifier(),
            warehouse=base_fv.warehouse.identifier() if base_fv.warehouse is not None else None,
            refresh_mode=base_fv.refresh_mode,
            refresh_mode_reason=base_fv.refresh_mode_reason,
            initialize=base_fv.initialize,
            owner=base_fv.owner,
            infer_schema_df=base_fv._infer_schema_df,
            session=self._session,
            cluster_by=cluster_by_str,
            online_config=online_config,
            storage_config=base_fv.storage_config,
        )

    def _build_offline_update_queries(
        self,
        feature_view: FeatureView,
        refresh_freq: Optional[str],
        warehouse: Optional[str],
        desc: str,
    ) -> tuple[list[tuple[str, str]], list[tuple[str, str]]]:
        """Build offline update operations and their rollback operations.

        For CRON-based refresh, the DT must keep ``TARGET_LAG = 'DOWNSTREAM'``
        and the actual cron schedule lives on a companion Task — Dynamic Tables
        do not accept cron expressions in ``TARGET_LAG``. Duration-based refresh
        sets ``TARGET_LAG`` directly on the DT and there is no Task.

        The presence/absence of the companion Task is what disambiguates a
        user-set ``refresh_freq='DOWNSTREAM'`` from a cron-driven FV (whose DT
        also carries ``TARGET_LAG='DOWNSTREAM'``) when reading state back via
        ``get_feature_view``. Maintain that invariant across all four
        ``(old_kind, new_kind)`` transitions:

            duration ↔ duration : DT-only ALTER; no Task involvement.
            duration → cron     : ALTER DT to DOWNSTREAM, then create the Task.
            cron     → duration : ALTER DT to the new lag, then drop the Task.
            cron     ↔ cron     : ALTER DT, then SUSPEND/SET SCHEDULE/RESUME the Task.

        ("duration" above includes a literal ``"DOWNSTREAM"`` value.)

        Args:
            feature_view: The currently registered ``FeatureView`` whose
                offline state is being mutated; supplies the existing
                refresh_freq/warehouse/desc used to construct the rollback.
            refresh_freq: New refresh frequency requested by the caller, or
                ``None`` to keep the existing value.
            warehouse: New warehouse identifier requested by the caller, or
                ``None`` to keep the existing value.
            desc: New description to set on the DT/view.

        Returns:
            A tuple of ``(operations, rollback_operations)`` where each is a
            list of ``(op_type, sql)`` tuples consumable by
            ``_execute_atomic_operations``.
        """
        fqn = feature_view.fully_qualified_name()

        if feature_view.status == FeatureViewStatus.STATIC:
            return [("OFFLINE_UPDATE", f"ALTER VIEW {fqn} SET COMMENT = '{desc}'")], []

        # Managed (Dynamic-Table-backed) FVs always have a refresh_freq — the
        # only refresh_freq=None case is an external (View-backed) FV, which
        # is STATIC and handled above.
        assert feature_view.refresh_freq is not None, "Managed FV must have a refresh_freq"
        new_warehouse = SqlIdentifier(warehouse) if warehouse else feature_view.warehouse
        old_warehouse = feature_view.warehouse
        effective_freq: str = refresh_freq if refresh_freq is not None else feature_view.refresh_freq
        new_is_cron = effective_freq != "DOWNSTREAM" and timeparse(effective_freq) is None
        old_freq: str = feature_view.refresh_freq
        old_is_cron = old_freq != "DOWNSTREAM" and timeparse(old_freq) is None

        new_target_lag = "DOWNSTREAM" if new_is_cron else effective_freq
        old_target_lag = "DOWNSTREAM" if old_is_cron else old_freq

        def alter_dt(op_type: str, *, target_lag: str, wh: Optional[SqlIdentifier], comment: str) -> tuple[str, str]:
            return (
                op_type,
                f"ALTER DYNAMIC TABLE {fqn} SET TARGET_LAG = '{target_lag}'" f" WAREHOUSE = {wh} COMMENT = '{comment}'",
            )

        def create_task_ops(op_type: str, *, cron_expr: str, wh: Optional[SqlIdentifier]) -> list[tuple[str, str]]:
            # CREATE OR REPLACE keeps the operation idempotent even if a stale
            # task with the same name happens to exist (e.g. partial prior failure).
            task_obj_info = _FeatureStoreObjInfo(
                _FeatureStoreObjTypes.FEATURE_VIEW_REFRESH_TASK, snowml_version.VERSION
            )
            tag_path = self._get_fully_qualified_name(_FEATURE_STORE_OBJECT_TAG)
            return [
                (
                    op_type,
                    f"CREATE OR REPLACE TASK {fqn} WAREHOUSE = {wh} "
                    f"SCHEDULE = 'USING CRON {cron_expr}' "
                    f"AS ALTER DYNAMIC TABLE {fqn} REFRESH",
                ),
                (op_type, f"ALTER TASK {fqn} SET TAG {tag_path}='{task_obj_info.to_json()}'"),
                (op_type, f"ALTER TASK {fqn} RESUME"),
            ]

        def drop_task_op(op_type: str) -> tuple[str, str]:
            return (op_type, f"DROP TASK IF EXISTS {fqn}")

        def alter_task_schedule_ops(op_type: str, *, cron_expr: str) -> list[tuple[str, str]]:
            # ALTER TASK SET SCHEDULE requires the task to be suspended.
            return [
                (op_type, f"ALTER TASK {fqn} SUSPEND"),
                (op_type, f"ALTER TASK {fqn} SET SCHEDULE = 'USING CRON {cron_expr}'"),
                (op_type, f"ALTER TASK {fqn} RESUME"),
            ]

        operations: list[tuple[str, str]] = [
            alter_dt("OFFLINE_UPDATE", target_lag=new_target_lag, wh=new_warehouse, comment=desc)
        ]
        if old_is_cron and new_is_cron:
            operations.extend(alter_task_schedule_ops("OFFLINE_UPDATE", cron_expr=effective_freq))
        elif old_is_cron and not new_is_cron:
            operations.append(drop_task_op("OFFLINE_UPDATE"))
        elif not old_is_cron and new_is_cron:
            operations.extend(create_task_ops("OFFLINE_UPDATE", cron_expr=effective_freq, wh=new_warehouse))

        rollback_ops: list[tuple[str, str]] = [
            alter_dt(
                "OFFLINE_ROLLBACK",
                target_lag=old_target_lag,
                wh=old_warehouse,
                comment=feature_view.desc,
            )
        ]
        if old_is_cron and new_is_cron:
            rollback_ops.extend(alter_task_schedule_ops("OFFLINE_ROLLBACK", cron_expr=old_freq))
        elif old_is_cron and not new_is_cron:
            rollback_ops.extend(create_task_ops("OFFLINE_ROLLBACK", cron_expr=old_freq, wh=old_warehouse))
        elif not old_is_cron and new_is_cron:
            rollback_ops.append(drop_task_op("OFFLINE_ROLLBACK"))

        return operations, rollback_ops

    @dataclass(frozen=True)
    class _OnlineUpdateStrategy:
        """Encapsulates online update operations and their rollbacks."""

        operations: list[tuple[str, Union[str, FeatureView]]]
        rollback_operations: list[tuple[str, Union[str, FeatureView]]]
        final_config: Optional[fv_mod.OnlineConfig]

    def _plan_online_update(
        self, feature_view: FeatureView, online_config: Optional[fv_mod.OnlineConfig]
    ) -> _OnlineUpdateStrategy:
        """Plan online update operations based on current state and target config.

        Handles three cases:
        - enable is None: Preserve current online state, only update if currently online
        - enable is True: Enable online storage (create if needed, update if exists)
        - enable is False: Disable online storage (drop if exists)

        Args:
            feature_view: The FeatureView object to check current online state.
            online_config: The OnlineConfig with target enable and lag settings.

        Returns:
            _OnlineUpdateStrategy containing operations and their rollbacks.
        """
        if online_config is None:
            return self._OnlineUpdateStrategy([], [], None)

        current_online = feature_view.online
        target_online = online_config.enable

        # Case 1: enable is None - preserve current online state, only update if currently online
        if target_online is None:
            if current_online and (online_config.target_lag is not None):
                # Online is currently enabled and user wants to update lag
                return self._plan_online_update_existing(feature_view, online_config)
            else:
                # No online changes needed (either not online, or lag not specified)
                return self._OnlineUpdateStrategy([], [], None)

        # Case 2: Enable online (create table)
        if target_online and not current_online:
            return self._plan_online_enable(feature_view, online_config)

        # Case 3: Disable online (drop table)
        elif not target_online and current_online:
            return self._plan_online_disable(feature_view)

        # Case 4: Update existing online table
        elif target_online and current_online:
            return self._plan_online_update_existing(feature_view, online_config)

        # Case 5: No change needed
        else:
            return self._OnlineUpdateStrategy([], [], online_config)

    def _plan_online_enable(
        self, feature_view: FeatureView, online_config: fv_mod.OnlineConfig
    ) -> _OnlineUpdateStrategy:
        """Plan operations to enable online storage."""
        # Get default target_lag from existing config or use default
        default_target_lag = (
            feature_view.online_config.target_lag
            if feature_view.online_config and feature_view.online_config.target_lag
            else fv_mod._DEFAULT_TARGET_LAG
        )
        final_config = fv_mod.OnlineConfig(
            enable=True,
            target_lag=online_config.target_lag if online_config.target_lag is not None else default_target_lag,
        )

        temp_fv = self._create_updated_feature_view(feature_view, final_config)

        operations: list[tuple[str, Union[str, FeatureView]]] = [("CREATE_ONLINE", temp_fv)]
        rollback_ops: list[tuple[str, Union[str, FeatureView]]] = [
            ("DELETE_ONLINE", temp_fv.fully_qualified_online_table_name())
        ]

        return self._OnlineUpdateStrategy(operations, rollback_ops, final_config)

    def _plan_online_disable(self, feature_view: FeatureView) -> _OnlineUpdateStrategy:
        """Plan operations to disable online storage."""
        table_name = feature_view.fully_qualified_online_table_name()

        operations: list[tuple[str, Union[str, FeatureView]]] = [("DELETE_ONLINE", table_name)]
        rollback_ops: list[tuple[str, Union[str, FeatureView]]] = [
            ("CREATE_ONLINE", self._create_updated_feature_view(feature_view, feature_view.online_config))
        ]

        # Create disabled config to properly represent the new state
        disabled_config = fv_mod.OnlineConfig(enable=False)

        return self._OnlineUpdateStrategy(operations, rollback_ops, disabled_config)

    def _plan_online_update_existing(
        self, feature_view: FeatureView, online_config: fv_mod.OnlineConfig
    ) -> _OnlineUpdateStrategy:
        """Plan operations to update existing online table configuration."""
        existing_config = feature_view.online_config or fv_mod.OnlineConfig(
            enable=True, target_lag=fv_mod._DEFAULT_TARGET_LAG
        )
        if online_config.target_lag is None or online_config.target_lag == existing_config.target_lag:
            return self._OnlineUpdateStrategy([], [], existing_config)

        table_name = feature_view.fully_qualified_online_table_name()
        update_query = f"ALTER ONLINE FEATURE TABLE {table_name} SET TARGET_LAG = '{online_config.target_lag}'"
        rollback_query = f"ALTER ONLINE FEATURE TABLE {table_name} SET TARGET_LAG = '{existing_config.target_lag}'"

        operations: list[tuple[str, Union[str, FeatureView]]] = [("UPDATE_ONLINE", update_query)]
        rollback_ops: list[tuple[str, Union[str, FeatureView]]] = [("UPDATE_ONLINE", rollback_query)]

        final_config = fv_mod.OnlineConfig(
            enable=True,
            target_lag=online_config.target_lag,
        )

        return self._OnlineUpdateStrategy(operations, rollback_ops, final_config)

    def _plan_feature_view_update_operations(
        self,
        feature_view: FeatureView,
        refresh_freq: Optional[str],
        warehouse: Optional[str],
        desc: str,
        online_config: Optional[fv_mod.OnlineConfig],
    ) -> tuple[list[tuple[str, Union[str, FeatureView]]], list[tuple[str, Union[str, FeatureView]]]]:
        """Plan all update operations and their rollbacks."""
        operations: list[tuple[str, Union[str, FeatureView]]] = []
        rollback_operations: list[tuple[str, Union[str, FeatureView]]] = []

        # Plan offline updates
        offline_ops, offline_rollback_ops = self._build_offline_update_queries(
            feature_view, refresh_freq, warehouse, desc
        )
        operations.extend(offline_ops)
        rollback_operations.extend(offline_rollback_ops)

        # Plan online updates
        online_strategy = self._plan_online_update(feature_view, online_config)
        operations.extend(online_strategy.operations)
        rollback_operations.extend(online_strategy.rollback_operations)

        return operations, rollback_operations

    def _plan_feature_view_status_operations(
        self, feature_view: FeatureView, operation: str
    ) -> tuple[list[tuple[str, Union[str, FeatureView]]], list[tuple[str, Union[str, FeatureView]]]]:
        """Plan atomic operations for suspend/resume operations.

        Args:
            feature_view: The feature view to operate on
            operation: "SUSPEND" or "RESUME"

        Returns:
            Tuple of (operations, rollback_operations)
        """
        assert operation in ["SUSPEND", "RESUME"], f"Operation {operation} not supported"

        operations: list[tuple[str, Union[str, FeatureView]]] = []
        rollback_operations: list[tuple[str, Union[str, FeatureView]]] = []

        fully_qualified_name = feature_view.fully_qualified_name()

        # Define the reverse operation for rollback
        reverse_operation = "RESUME" if operation == "SUSPEND" else "SUSPEND"

        # Plan offline operations (dynamic table + task)
        offline_sql = f"ALTER DYNAMIC TABLE {fully_qualified_name} {operation}"
        offline_rollback_sql = f"ALTER DYNAMIC TABLE {fully_qualified_name} {reverse_operation}"

        task_sql = f"ALTER TASK IF EXISTS {fully_qualified_name} {operation}"
        task_rollback_sql = f"ALTER TASK IF EXISTS {fully_qualified_name} {reverse_operation}"

        operations.append(("OFFLINE_STATUS", offline_sql))
        operations.append(("TASK_STATUS", task_sql))

        # Rollback operations (in reverse order)
        rollback_operations.insert(0, ("TASK_STATUS", task_rollback_sql))
        rollback_operations.insert(0, ("OFFLINE_STATUS", offline_rollback_sql))

        # Plan online operations if applicable
        if feature_view.online:
            fully_qualified_online_name = feature_view.fully_qualified_online_table_name()
            online_sql = f"ALTER ONLINE FEATURE TABLE {fully_qualified_online_name} {operation}"
            online_rollback_sql = f"ALTER ONLINE FEATURE TABLE {fully_qualified_online_name} {reverse_operation}"

            operations.append(("ONLINE_STATUS", online_sql))
            # Add to front of rollback operations to maintain reverse order
            rollback_operations.insert(0, ("ONLINE_STATUS", online_rollback_sql))

        return operations, rollback_operations

    def _handle_update_failure(
        self,
        error: Exception,
        rollback_operations: list[tuple[str, Union[str, FeatureView]]],
        feature_view: FeatureView,
    ) -> None:
        """Handle update failure with rollback."""
        logger.warning(f"Update failed, attempting rollback: {error}")
        try:
            self._execute_atomic_operations(rollback_operations)
            logger.info("Rollback completed successfully")
        except Exception as rollback_error:
            logger.error(f"Rollback failed: {rollback_error}")
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(
                    f"Update failed and rollback failed. Original error: {error}. Rollback error: {rollback_error}"
                ),
            ) from error

        # Re-raise original error
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
            original_exception=RuntimeError(
                f"Update feature view {feature_view.name}/{feature_view.version} failed: {error}"
            ),
        ) from error

    def _handle_status_operation_failure(
        self,
        error: Exception,
        rollback_operations: list[tuple[str, Union[str, FeatureView]]],
        feature_view: FeatureView,
        operation: str,
    ) -> None:
        """Handle status operation failure (suspend/resume) with rollback."""
        logger.warning(f"{operation} failed, attempting rollback: {error}")
        try:
            self._execute_atomic_operations(rollback_operations)
            logger.info("Rollback completed successfully")
        except Exception as rollback_error:
            logger.error(f"Rollback failed: {rollback_error}")
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(
                    f"{operation} failed and rollback failed. "
                    f"Operation error: {error}. "
                    f"Rollback error: {rollback_error}"
                ),
            ) from error

        # Re-raise original error
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
            original_exception=RuntimeError(
                f"{operation} feature view {feature_view.name}/{feature_view.version} failed: {error}"
            ),
        ) from error

    def _execute_atomic_operations(self, operations: list[tuple[str, Union[str, FeatureView]]]) -> None:
        """Execute a list of operations atomically.

        Args:
            operations: List of (operation_type, operation_data) tuples
        """
        for op_type, op_data in operations:
            if op_type in (
                "OFFLINE_UPDATE",
                "OFFLINE_ROLLBACK",
                "UPDATE_ONLINE",
                "OFFLINE_STATUS",
                "TASK_STATUS",
                "ONLINE_STATUS",
            ):
                assert isinstance(op_data, str)
                self._session.sql(op_data).collect(statement_params=self._telemetry_stmp)
            elif op_type == "CREATE_ONLINE":
                assert isinstance(op_data, FeatureView)
                assert op_data.version is not None
                feature_view_name = FeatureView._get_physical_name(op_data.name, op_data.version)
                self._create_online_feature_table(op_data, feature_view_name, version=str(op_data.version))
            elif op_type == "DELETE_ONLINE":
                assert isinstance(op_data, str)
                self._session.sql(f"DROP ONLINE FEATURE TABLE IF EXISTS {op_data}").collect(
                    statement_params=self._telemetry_stmp
                )

    def _read_from_offline_store(
        self, feature_view: FeatureView, keys: Optional[list[list[str]]], feature_names: Optional[list[str]]
    ) -> DataFrame:
        """Read feature values from the offline store (main feature view table).

        For tiled feature views, this computes aggregated features at current time
        by creating a synthetic spine with unique entity combinations.

        Args:
            feature_view: The feature view to read from.
            keys: Optional list of key values to filter by.
            feature_names: Optional list of feature names to return.

        Returns:
            Snowpark DataFrame containing the feature values.
        """
        table_name = feature_view.fully_qualified_name()

        # For tiled FVs, compute features at current time
        if feature_view.is_tiled:
            return self._read_tiled_fv_at_current_time(feature_view, keys, feature_names)

        # Build SELECT and WHERE clauses using helper methods
        select_clause = self._build_select_clause_and_validate(feature_view, feature_names, include_join_keys=True)
        where_clause, _ = self._build_where_clause_for_keys(feature_view, keys)

        query = f"SELECT {select_clause} FROM {table_name}{where_clause}"
        return self._session.sql(query)

    def _read_tiled_fv_at_current_time(
        self, feature_view: FeatureView, keys: Optional[list[list[str]]], feature_names: Optional[list[str]]
    ) -> DataFrame:
        """Read tiled feature view by computing aggregated features at current time.

        Creates a synthetic spine with unique entity combinations from the tile table,
        uses CURRENT_TIMESTAMP as the query time, and merges tiles to compute features.

        Args:
            feature_view: The tiled feature view to read from.
            keys: Optional list of key values to filter by.
            feature_names: Optional list of feature names to return.

        Returns:
            Snowpark DataFrame containing the computed feature values.
        """
        table_name = feature_view.fully_qualified_name()

        # Get join keys from entities
        join_keys: list[SqlIdentifier] = []
        for entity in feature_view.entities:
            join_keys.extend(entity.join_keys)

        join_keys_str = ", ".join(join_keys)

        # Build WHERE clause for key filtering (if any)
        where_clause, _ = self._build_where_clause_for_keys(feature_view, keys)

        # Step 1: Create spine CTE with unique entities + CURRENT_TIMESTAMP
        spine_cte = f"""
            SELECT DISTINCT {join_keys_str},
                   CURRENT_TIMESTAMP() AS "_QUERY_TS"
            FROM {table_name}{where_clause}
        """

        # Step 2: Generate merge CTEs using MergingSqlGenerator
        assert feature_view.aggregation_specs is not None
        assert feature_view.feature_granularity is not None
        assert feature_view.timestamp_col is not None

        generator = MergingSqlGenerator(
            tile_table=table_name,
            join_keys=join_keys,
            timestamp_col=feature_view.timestamp_col,
            feature_granularity=feature_view.feature_granularity,
            features=feature_view.aggregation_specs,
            spine_timestamp_col="_QUERY_TS",
            fv_index=0,
        )

        merge_ctes = generator.generate_all_ctes()

        # Step 3: Build full query
        cte_parts = [f"SPINE AS ({spine_cte})"]
        for cte_name, cte_body in merge_ctes:
            cte_parts.append(f"{cte_name} AS ({cte_body})")

        # Get feature columns for final SELECT
        all_feature_cols = [spec.get_sql_column_name() for spec in feature_view.aggregation_specs]
        if feature_names:
            # Filter to requested features
            feature_names_upper = [f.upper() for f in feature_names]
            all_feature_cols = [c for c in all_feature_cols if c.strip('"').upper() in feature_names_upper]

        feature_cols_str = ", ".join(all_feature_cols)
        # CTE name format matches generator: FV{index:03d}
        final_select = f"SELECT {join_keys_str}, {feature_cols_str} FROM FV000"

        full_query = f"WITH {', '.join(cte_parts)} {final_select}"
        return self._session.sql(full_query)

    def _postgres_online_read_struct_type(
        self, feature_view: FeatureView, feature_names: Optional[list[str]]
    ) -> StructType:
        join_names = [k.resolved() for e in feature_view.entities for k in e.join_keys]
        if feature_names:
            wanted = set(join_names) | set(feature_names)
            fields = [f for f in feature_view.output_schema.fields if f.name in wanted]
        else:
            fields = list(feature_view.output_schema.fields)
        return StructType(fields)

    def _empty_dataframe_for_postgres_online_read(
        self, feature_view: FeatureView, feature_names: Optional[list[str]]
    ) -> DataFrame:
        return self._session.create_dataframe(
            [], schema=self._postgres_online_read_struct_type(feature_view, feature_names)
        )

    def _read_postgres_online_via_query_api(
        self,
        feature_view: FeatureView,
        keys: Optional[list[list[str]]],
        feature_names: Optional[list[str]],
        *,
        as_pandas: bool = False,
    ) -> Union[DataFrame, pd.DataFrame]:
        query_url = getattr(feature_view, "_postgres_online_query_url", None)
        if not query_url:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    "Online read for this Postgres-backed feature view requires a hydrated query endpoint. "
                    "Call get_feature_view(name, version) again after the Online Service is RUNNING."
                ),
            )
        if not keys:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    "Online read from a Postgres-backed feature view requires at least one row in `keys`; "
                    "unbounded table scans are not supported via the Online Service Query API."
                ),
            )
        if feature_view.version is None:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    "Online read requires a registered feature view with a version for Postgres-backed online tables."
                ),
            )
        self._build_select_clause_and_validate(feature_view, feature_names, include_join_keys=True)

        join_names = [k.resolved() for e in feature_view.entities for k in e.join_keys]
        join_set = set(join_names)
        join_key_field_types = {f.name: f.datatype for f in feature_view.output_schema.fields if f.name in join_set}

        rows, schema = online_service.read_postgres_online_features(
            self._session,
            query_url,
            str(feature_view.name),
            str(feature_view.version),
            join_names,
            keys,
            feature_names,
            join_key_field_types=join_key_field_types,
            http_client=self._get_or_create_online_http_client(),
        )
        if as_pandas:
            return online_service._rows_to_pandas_for_postgres_online(rows, schema)
        if not rows:
            return self._empty_dataframe_for_postgres_online_read(feature_view, feature_names)
        coerced = [online_service._coerce_row_values_for_snowpark_local_schema(r, schema) for r in rows]
        return self._session.create_dataframe(coerced, schema=schema)

    def _read_from_online_store(
        self,
        feature_view: FeatureView,
        keys: Optional[list[list[str]]],
        feature_names: Optional[list[str]],
        *,
        as_pandas: bool = False,
    ) -> Union[DataFrame, pd.DataFrame]:
        """Read feature values from the online store with optional key filtering.

        Uses bind variables for single-key lookups and literal interpolation
        for batch lookups.

        Args:
            feature_view: The registered feature view to read from.
            keys: Optional list of key value lists to filter by.
            feature_names: Optional list of feature names to return.
            as_pandas: If True, return a ``pandas.DataFrame`` instead of a Snowpark ``DataFrame``.

        Returns:
            Snowpark DataFrame (or pandas DataFrame when ``as_pandas`` is True) containing the
            feature view data.

        Raises:
            SnowflakeMLException: If online store is not enabled.
        """
        if not feature_view.online:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    f"Online store is not enabled for feature view {feature_view.name}/{feature_view.version}"
                ),
            )

        if feature_view.online_config is not None and feature_view.online_config.store_type == OnlineStoreType.POSTGRES:
            return self._read_postgres_online_via_query_api(feature_view, keys, feature_names, as_pandas=as_pandas)

        fully_qualified_online_name = feature_view.fully_qualified_online_table_name()

        select_clause = self._build_select_clause_and_validate(feature_view, feature_names, include_join_keys=True)
        # NOTE: We use snowflake sql query binds for single-point lookups to ensure the best performance.
        # We don't use binds for multi-point lookups because we don't have any evidence that it improves
        # performance, but we may need to revisit this in the future.
        use_binds = keys is not None and len(keys) == 1
        where_clause, params = self._build_where_clause_for_keys(feature_view, keys, use_binds=use_binds)

        query = f"SELECT {select_clause} FROM {fully_qualified_online_name}{where_clause}"
        df = self._session.sql(query, params=params) if params else self._session.sql(query)
        if as_pandas:
            return df.to_pandas(statement_params=self._telemetry_stmp)
        return df

    @dispatch_decorator()
    def _clear(self, dryrun: bool = True) -> None:
        """
        Clear all feature views and entities. Note Feature Store schema and metadata will NOT be purged
        together. Use SQL to delete schema and metadata instead.

        Args:
            dryrun: Print a list of objects will be deleted but not actually perform the deletion when true.
        """
        warnings.warn(
            "It will clear ALL feature views and entities in this Feature Store. Make sure your role"
            " has sufficient access to all feature views and entities. Insufficient access to some feature"
            " views or entities will leave Feature Store in an incomplete state.",
            stacklevel=2,
            category=UserWarning,
        )

        all_fvs_df = self.list_feature_views()
        all_entities_df = self.list_entities()
        all_fvs_rows = all_fvs_df.collect(statement_params=self._telemetry_stmp)
        all_entities_rows = all_entities_df.collect(statement_params=self._telemetry_stmp)

        if dryrun:
            logger.info(
                "Following feature views and entities will be deleted."
                + " Set 'dryrun=False' to perform the actual deletion.",
            )
            logger.info(f"Total {len(all_fvs_rows)} Feature views to be deleted:")
            all_fvs_df.show(n=len(all_fvs_rows))
            logger.info(f"\nTotal {len(all_entities_rows)} Entities to be deleted:")
            all_entities_df.show(n=len(all_entities_rows))
            return

        for fv_row in all_fvs_rows:
            fv = self.get_feature_view(
                SqlIdentifier(fv_row["NAME"], case_sensitive=True).identifier(), fv_row["VERSION"]
            )
            self.delete_feature_view(fv)

        for entity_row in all_entities_rows:
            self.delete_entity(SqlIdentifier(entity_row["NAME"], case_sensitive=True).identifier())

        logger.info(f"Feature store {self._config.full_schema_path} has been cleared.")

    def _get_feature_view_if_exists(self, name: str, version: str) -> FeatureView:
        existing_fv = self.get_feature_view(name, version)
        warnings.warn(
            f"FeatureView {name}/{version} already exists. Skip registration."
            + " Set `overwrite` to True if you want to replace existing FeatureView.",
            stacklevel=2,
            category=UserWarning,
        )
        return existing_fv

    def _recompose_join_keys(self, join_key: str) -> list[str]:
        # ALLOWED_VALUES in TAG will follow format ["key_1,key2,..."]
        # since keys are already resolved following the SQL identifier rule on the write path,
        # we simply parse the keys back and wrap them with quotes to preserve cases
        # Example join_key repr from TAG value: "[key1,key2,key3]"
        join_keys = join_key[2:-2].split(",")
        res = []
        for k in join_keys:
            res.append(f'"{k}"')
        return res

    def _create_dynamic_table(
        self,
        feature_view_name: SqlIdentifier,
        feature_view: FeatureView,
        fully_qualified_name: str,
        column_descs: str,
        tagging_clause: str,
        schedule_task: bool,
        warehouse: SqlIdentifier,
        block: bool,
        override: bool,
    ) -> None:
        # TODO: cluster by join keys once DT supports that
        query = ""
        try:
            override_clause = " OR REPLACE" if override else ""
            query = self._create_dynamic_table_query(
                override_clause,
                fully_qualified_name,
                column_descs,
                schedule_task,
                feature_view,
                tagging_clause,
                warehouse,
            )
            self._session.sql(query).collect(block=block, statement_params=self._telemetry_stmp)

            # Create scheduled task after DT creation
            if schedule_task:
                task_override_clause = " OR REPLACE" if override else ""
                self._create_scheduled_refresh_task(
                    task_override_clause,
                    feature_view,
                    fully_qualified_name,
                    warehouse,
                )
            elif override:
                # Clean up any existing task when overwriting with a non-CRON feature view.
                # This handles the following scenarios:
                # Duration DT → DOWNSTREAM DT: old task is orphaned
                self._session.sql(f"DROP TASK IF EXISTS {fully_qualified_name}").collect(
                    statement_params=self._telemetry_stmp
                )
        except Exception as e:
            # Check for type conflict: VIEW exists but we want to create a DYNAMIC TABLE
            if (
                override
                and isinstance(e, SnowparkSQLException)
                and e.error_code == error_codes.SQL_COMPILATION_ERROR
                and self._get_existing_feature_view_object_type(feature_view_name) == "VIEW"
            ):
                # Use shadow swap to replace VIEW with DYNAMIC TABLE
                logger.info(
                    f"Existing VIEW detected, performing shadow swap to DYNAMIC TABLE for {fully_qualified_name}"
                )
                self._shadow_swap_to_dynamic_table(
                    feature_view,
                    fully_qualified_name,
                    column_descs,
                    tagging_clause,
                    schedule_task,
                    warehouse,
                    block,
                )
                # Create scheduled task after shadow swap (shadow swap only happens with override=True)
                if schedule_task:
                    self._create_scheduled_refresh_task(
                        " OR REPLACE",
                        feature_view,
                        fully_qualified_name,
                        warehouse,
                    )
            else:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                    original_exception=RuntimeError(
                        f"Create dynamic table [\n{query}\n] or task {fully_qualified_name} failed: {e}."
                    ),
                ) from e

        if block:
            self._check_dynamic_table_refresh_mode(feature_view_name)

    def _create_dynamic_table_query(
        self,
        override_clause: str,
        table_name: str,
        column_descs: str,
        schedule_task: bool,
        feature_view: FeatureView,
        tagging_clause: str,
        warehouse: str,
    ) -> str:
        # Use tiling query for tiled feature views
        if feature_view.is_tiled:
            source_query = feature_view._get_tile_query()
        else:
            source_query = feature_view.query

        # Include column definitions only if provided (skip for tiled feature views)
        column_clause = f" ({column_descs})" if column_descs else ""

        storage_config = feature_view.storage_config
        if storage_config is not None and storage_config.format == StorageFormat.ICEBERG:
            # These should be validated by FeatureView constructor and _resolve_storage_config
            assert storage_config.external_volume is not None, "external_volume is required for ICEBERG format"
            assert storage_config.base_location is not None, "base_location is required for ICEBERG format"
            query = f"""CREATE{override_clause} DYNAMIC ICEBERG TABLE {table_name}{column_clause}
                TARGET_LAG = '{'DOWNSTREAM' if schedule_task else feature_view.refresh_freq}'
                COMMENT = '{feature_view.desc}'
                TAG (
                    {tagging_clause}
                )
                WAREHOUSE = {warehouse}
                REFRESH_MODE = {feature_view.refresh_mode}
                INITIALIZE = {feature_view.initialize}
                CATALOG = 'SNOWFLAKE'
                EXTERNAL_VOLUME = {SqlIdentifier(storage_config.external_volume)}
                BASE_LOCATION = '{storage_config.base_location.replace("'", "''")}'
            """
        else:
            query = f"""CREATE{override_clause} DYNAMIC TABLE {table_name}{column_clause}
                TARGET_LAG = '{'DOWNSTREAM' if schedule_task else feature_view.refresh_freq}'
                COMMENT = '{feature_view.desc}'
                TAG (
                    {tagging_clause}
                )
                WAREHOUSE = {warehouse}
                REFRESH_MODE = {feature_view.refresh_mode}
                INITIALIZE = {feature_view.initialize}
            """
        if feature_view.cluster_by:
            # For tiled FVs, replace timestamp column with TILE_START in cluster_by
            if feature_view.is_tiled and feature_view.timestamp_col:
                ts_col_upper = feature_view.timestamp_col.upper()
                cluster_by_cols = [
                    _TILE_START_COL if col.upper() == ts_col_upper else col for col in feature_view.cluster_by
                ]
            else:
                cluster_by_cols = [str(col) for col in feature_view.cluster_by]
            cluster_by_clause = f"CLUSTER BY ({', '.join(cluster_by_cols)})"
            query += f"{cluster_by_clause}"

        query += f"""
            AS {source_query}
        """
        return query

    def _create_scheduled_refresh_task(
        self,
        override_clause: str,
        feature_view: FeatureView,
        fully_qualified_name: str,
        warehouse: SqlIdentifier,
    ) -> None:
        """Create a Snowflake Task to refresh a Dynamic Table on a CRON schedule.

        This function creates a scheduled task that executes ALTER DYNAMIC TABLE ... REFRESH
        to trigger periodic refreshes based on a CRON expression.

        Note:
            Dynamic Iceberg tables are managed with ALTER DYNAMIC TABLE (no ICEBERG keyword),
            so this approach works the same way for both regular Dynamic Tables and
            Dynamic Iceberg Tables.

        Args:
            override_clause: SQL clause for CREATE OR REPLACE behavior.
            feature_view: The FeatureView containing refresh configuration.
            fully_qualified_name: Fully qualified name for the task (same as the DT).
            warehouse: Warehouse to use for task execution.

        Raises:
            Exception: Re-raises any exception after cleanup (dropping DT and task).
        """
        task_obj_info = _FeatureStoreObjInfo(_FeatureStoreObjTypes.FEATURE_VIEW_REFRESH_TASK, snowml_version.VERSION)
        try:
            # ALTER DYNAMIC TABLE works for both regular Dynamic Tables and Dynamic Iceberg Tables.
            # The ICEBERG keyword is only used in CREATE, not in ALTER/SHOW/DROP.
            self._session.sql(
                f"""CREATE{override_clause} TASK {fully_qualified_name}
                    WAREHOUSE = {warehouse}
                    SCHEDULE = 'USING CRON {feature_view.refresh_freq}'
                    AS ALTER DYNAMIC TABLE {fully_qualified_name} REFRESH
                """
            ).collect(statement_params=self._telemetry_stmp)
            self._session.sql(
                f"""
                ALTER TASK {fully_qualified_name}
                SET TAG {self._get_fully_qualified_name(_FEATURE_STORE_OBJECT_TAG)}='{task_obj_info.to_json()}'
            """
            ).collect(statement_params=self._telemetry_stmp)
            self._session.sql(f"ALTER TASK {fully_qualified_name} RESUME").collect(
                statement_params=self._telemetry_stmp
            )
        except Exception:
            self._session.sql(f"DROP DYNAMIC TABLE IF EXISTS {fully_qualified_name}").collect(
                statement_params=self._telemetry_stmp
            )
            self._session.sql(f"DROP TASK IF EXISTS {fully_qualified_name}").collect(
                statement_params=self._telemetry_stmp
            )
            raise

    def _create_rollup_feature_view(
        self,
        feature_view: FeatureView,
        feature_view_name: SqlIdentifier,
        fully_qualified_name: str,
        tagging_clause_str: str,
        overwrite: bool,
    ) -> list[tuple[_FeatureStoreObjTypes, str]]:
        """Create a rollup feature view Dynamic Table.

        Rollup feature views aggregate tiles from a parent tiled FV to a coarser
        entity level using a mapping table.

        Args:
            feature_view: The rollup feature view definition.
            feature_view_name: The physical name for the feature view.
            fully_qualified_name: Fully qualified name for the created DT.
            tagging_clause_str: Tagging clause for the CREATE statement.
            overwrite: Whether to replace existing objects.

        Returns:
            A list of tuples of created object types and their names for rollback.

        Raises:
            SnowflakeMLException: If rollup_config is invalid or DT creation fails.
        """
        created: list[tuple[_FeatureStoreObjTypes, str]] = []

        rollup_config = feature_view.rollup_config
        if rollup_config is None:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError("Rollup feature view must have rollup_config"),
            )

        parent_fv = rollup_config.source

        # Get parent tile table name
        physical_name = FeatureView._get_physical_name(parent_fv.name, parent_fv.version)  # type: ignore[arg-type]
        parent_tile_table = f"{parent_fv.database}.{parent_fv.schema}.{physical_name}"

        # Get join keys
        parent_join_keys = [str(k) for e in parent_fv.entities for k in e.join_keys]
        new_join_keys = [str(k) for e in feature_view.entities for k in e.join_keys]

        # Get mapping query from DataFrame
        mapping_query = rollup_config.mapping_df.queries["queries"][-1]

        # Build and store RollupMetadata on the feature view for PIT training support
        from snowflake.ml.feature_store.feature_view import RollupMetadata

        rollup_metadata = RollupMetadata(
            parent_tile_table=parent_tile_table,
            parent_join_keys=parent_join_keys,
            mapping_query=mapping_query,
            mapping_valid_from_col=rollup_config.mapping_valid_from_col,
            mapping_valid_to_col=rollup_config.mapping_valid_to_col,
        )
        feature_view._rollup_metadata = rollup_metadata

        # For the materialized DT (inference path), use a flat JOIN.
        # When temporal columns are set (SCD Type 2), filter to currently-active
        # mappings only. No ROW_NUMBER dedup — supports 1:N mappings where one
        # child entity maps to multiple parent entities simultaneously.
        flat_mapping_query = mapping_query
        if rollup_config.mapping_valid_from_col is not None and rollup_config.mapping_valid_to_col is not None:
            vfc = SqlIdentifier(rollup_config.mapping_valid_from_col).identifier()
            vtc = SqlIdentifier(rollup_config.mapping_valid_to_col).identifier()
            flat_mapping_query = (
                f"SELECT * FROM ({mapping_query}) "
                f"WHERE {vfc} <= CURRENT_TIMESTAMP() AND ({vtc} IS NULL OR {vtc} > CURRENT_TIMESTAMP())"
            )

        generator = RollupSqlGenerator(
            parent_tile_table=parent_tile_table,
            parent_join_keys=parent_join_keys,
            new_join_keys=new_join_keys,
            mapping_query=flat_mapping_query,
            aggregation_specs=feature_view.aggregation_specs or [],
        )
        rollup_sql = generator.generate()

        # Create the Dynamic Table
        warehouse = feature_view.warehouse if feature_view.warehouse is not None else self._default_warehouse
        refresh_freq = feature_view.refresh_freq or "DOWNSTREAM"
        overwrite_clause = " OR REPLACE" if overwrite else ""

        # Detect if refresh_freq is a cron expression (not a duration like '5m' or '1h')
        # If it's a cron, we need to set TARGET_LAG = 'DOWNSTREAM' and create a Task
        schedule_task = refresh_freq != "DOWNSTREAM" and timeparse(refresh_freq) is None
        target_lag = "DOWNSTREAM" if schedule_task else refresh_freq

        try:
            query = f"""CREATE{overwrite_clause} DYNAMIC TABLE {fully_qualified_name}
                TARGET_LAG = '{target_lag}'
                COMMENT = '{feature_view.desc}'
                TAG (
                    {tagging_clause_str}
                )
                WAREHOUSE = {warehouse}
                REFRESH_MODE = {feature_view.refresh_mode}
                INITIALIZE = {feature_view.initialize}
            """
            if feature_view.cluster_by:
                cluster_by_clause = f"CLUSTER BY ({', '.join(str(c) for c in feature_view.cluster_by)})"
                query += f"{cluster_by_clause}"

            query += f"""
                AS {rollup_sql}
            """
            self._session.sql(query).collect(statement_params=self._telemetry_stmp)
            created.append((_FeatureStoreObjTypes.MANAGED_FEATURE_VIEW, fully_qualified_name))

            # Create scheduled task after DT creation for cron-based refresh
            if schedule_task:
                task_overwrite_clause = " OR REPLACE" if overwrite else ""
                self._create_scheduled_refresh_task(
                    task_overwrite_clause,
                    feature_view,
                    fully_qualified_name,
                    warehouse,
                )
                created.append((_FeatureStoreObjTypes.FEATURE_VIEW_REFRESH_TASK, fully_qualified_name))
            elif overwrite:
                # Clean up any existing task when overwriting with a non-CRON feature view.
                # This handles the case: CRON rollup DT → duration/DOWNSTREAM rollup DT
                self._session.sql(f"DROP TASK IF EXISTS {fully_qualified_name}").collect(
                    statement_params=self._telemetry_stmp
                )

        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Create rollup dynamic table [\n{query}\n] failed: {e}."),
            ) from e

        return created

    def _create_offline_feature_view(
        self,
        feature_view: FeatureView,
        feature_view_name: SqlIdentifier,
        fully_qualified_name: str,
        column_descs: str,
        tagging_clause_str: str,
        block: bool,
        overwrite: bool,
    ) -> list[tuple[_FeatureStoreObjTypes, str]]:
        """Create the offline representation for a feature view.

        Depending on `refresh_freq`, this creates either a Dynamic Table (managed feature view)
        or a View (external feature view). Returns a list of created resources for rollback.

        Args:
            feature_view: The feature view definition to materialize.
            feature_view_name: The physical name object for the feature view.
            fully_qualified_name: Fully qualified name for the created view/dynamic table.
            column_descs: Column descriptions clause used in the CREATE statement.
            tagging_clause_str: Tagging clause used in the CREATE statement.
            block: Whether to block until the initial refresh completes when applicable.
            overwrite: Whether to replace existing objects if they already exist.

        Returns:
            A list of tuples of the created object types and their fully qualified names,
            used for potential rollback.

        Raises:
            SnowflakeMLException: [RuntimeError] If creating the view or dynamic table fails.
        """
        created: list[tuple[_FeatureStoreObjTypes, str]] = []
        refresh_freq = feature_view.refresh_freq

        # External feature view via View (no refresh schedule)
        if refresh_freq is None:
            overwrite_clause = " OR REPLACE" if overwrite else ""
            query = self._create_offline_feature_view_view_query(
                overwrite_clause,
                fully_qualified_name,
                column_descs,
                feature_view,
                tagging_clause_str,
            )
            try:
                self._session.sql(query).collect(statement_params=self._telemetry_stmp)
                created.append((_FeatureStoreObjTypes.EXTERNAL_FEATURE_VIEW, fully_qualified_name))
            except Exception as e:
                # Only check for type conflict when SQL_COMPILATION_ERROR is thrown
                if (
                    overwrite
                    and isinstance(e, SnowparkSQLException)
                    and e.error_code == error_codes.SQL_COMPILATION_ERROR
                    and self._get_existing_feature_view_object_type(feature_view_name) == "DYNAMIC TABLE"
                ):
                    # A DYNAMIC TABLE exists but we want to create a VIEW - use shadow swap
                    logger.info(
                        f"Existing DYNAMIC TABLE detected, performing shadow swap to VIEW for "
                        f"{fully_qualified_name}"
                    )
                    self._shadow_swap_to_view(
                        fully_qualified_name,
                        column_descs,
                        feature_view,
                        tagging_clause_str,
                        block,
                    )
                    created.append((_FeatureStoreObjTypes.EXTERNAL_FEATURE_VIEW, fully_qualified_name))
                else:
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                        original_exception=RuntimeError(f"Create view {fully_qualified_name} failed: {e}"),
                    ) from e
            if overwrite:
                # Clean up any existing task from a previous CRON-based DT registration.
                # This handles the case: CRON DT → View
                self._session.sql(f"DROP TASK IF EXISTS {fully_qualified_name}").collect(
                    statement_params=self._telemetry_stmp
                )
            return created
        # Managed feature view via Dynamic Table (and optional Task)
        #
        # Refresh behavior based on refresh_freq input type:
        # ┌────────────────────┬───────────────┬─────────────────┬──────────────────────────────────────────┐
        # │ Input Type         │ schedule_task │ TARGET_LAG      │ Who triggers the refresh?                │
        # ├────────────────────┼───────────────┼─────────────────┼──────────────────────────────────────────┤
        # │ Duration ('5m')    │ False         │ '5 minutes'     │ The Dynamic Table's internal scheduler.  │
        # │ CRON ('* * * UTC') │ True          │ 'DOWNSTREAM'    │ An external Snowflake Task.              │
        # │ DOWNSTREAM         │ False         │ 'DOWNSTREAM'    │ Only a consumer (or manual refresh).     │
        # └────────────────────┴───────────────┴─────────────────┴──────────────────────────────────────────┘
        #
        # Note: Dynamic Iceberg tables are managed with ALTER DYNAMIC TABLE (no ICEBERG keyword),
        # so CRON-based refresh works the same way as regular dynamic tables.
        schedule_task = refresh_freq != "DOWNSTREAM" and timeparse(refresh_freq) is None
        self._create_dynamic_table(
            feature_view_name,
            feature_view,
            fully_qualified_name,
            column_descs,
            tagging_clause_str,
            schedule_task,
            feature_view.warehouse if feature_view.warehouse is not None else self._default_warehouse,
            block,
            overwrite,
        )
        created.append((_FeatureStoreObjTypes.MANAGED_FEATURE_VIEW, fully_qualified_name))
        if schedule_task:
            created.append((_FeatureStoreObjTypes.FEATURE_VIEW_REFRESH_TASK, fully_qualified_name))
        return created

    def _shadow_replace(
        self, old_obj_fqn: str, old_obj_type: str, new_obj_fqn: str, new_obj_type: str, fully_qualified_name: str
    ) -> None:
        try:
            # Swap: drop old <object type>, rename new <object type> to target
            self._session.sql(
                f"""ALTER {old_obj_type} IF EXISTS {fully_qualified_name} RENAME TO {old_obj_fqn}"""
            ).collect()
            self._session.sql(
                f"""ALTER {new_obj_type} IF EXISTS {new_obj_fqn} RENAME TO {fully_qualified_name}"""
            ).collect()
            self._session.sql(f"""DROP {old_obj_type} IF EXISTS {old_obj_fqn}""").collect()
        except Exception as tx_e:
            # If rename fails, recover at best-effort
            self._session.sql(
                f"""ALTER {old_obj_type} IF EXISTS {old_obj_fqn} RENAME TO {fully_qualified_name}"""
            ).collect()
            self._session.sql(f"""DROP {new_obj_type} IF EXISTS {new_obj_fqn}""").collect()
            raise tx_e

        logger.info(f"Shadow swap for {fully_qualified_name} completed successfully.")

    def _get_existing_feature_view_object_type(self, feature_view_name: SqlIdentifier) -> Optional[str]:
        """Check if a VIEW or DYNAMIC TABLE with the given name already exists.

        Args:
            feature_view_name: The name of the feature view object to check.

        Returns:
            "VIEW" if a view exists, "DYNAMIC TABLE" if a dynamic table exists,
            or None if no object with that name exists.
        """
        # Check for existing VIEW
        found_views = self._find_object("VIEWS", feature_view_name)
        if len(found_views) > 0:
            return "VIEW"

        # Check for existing DYNAMIC TABLE
        found_dts = self._find_object("DYNAMIC TABLES", feature_view_name)
        if len(found_dts) > 0:
            return "DYNAMIC TABLE"

        return None

    def _shadow_swap_to_view(
        self,
        fully_qualified_name: str,
        column_descs: str,
        feature_view: FeatureView,
        tagging_clause_str: str,
        block: bool,
    ) -> None:
        """Replace an existing DYNAMIC TABLE with a VIEW using shadow swap.

        Creates a temporary VIEW, then atomically swaps it with the existing DYNAMIC TABLE.
        Also cleans up any scheduled refresh task and online feature table associated with the DYNAMIC TABLE.

        Args:
            fully_qualified_name: Fully qualified name for the target object.
            column_descs: Column descriptions clause used in the CREATE statement.
            feature_view: The feature view definition.
            tagging_clause_str: Tagging clause used in the CREATE statement.
            block: Whether to block until completion.

        Raises:
            SnowflakeMLException: [RuntimeError] Failed to replace dynamic table with view.
        """
        import uuid

        temp_suffix = uuid.uuid4().hex[:8]
        db, schema, obj = parse_fully_qualified_name(fully_qualified_name)
        new_view_name = identifier.concat_names([obj.identifier(), self._TMP_VIEW_PREFIX, temp_suffix])
        new_table_name = identifier.concat_names([obj.identifier(), self._TMP_DT_PREFIX, temp_suffix])
        temp_view_fqn = get_fully_qualified_name(db, schema, SqlIdentifier(new_view_name))
        temp_table_fqn = get_fully_qualified_name(db, schema, SqlIdentifier(new_table_name))

        # Create the new version as a shadow view first
        query = self._create_offline_feature_view_view_query(
            "",  # Don't use override_clause for temp objects
            temp_view_fqn,
            column_descs,
            feature_view,
            tagging_clause_str,
        )

        try:
            self._session.sql(query).collect(block=block, statement_params=self._telemetry_stmp)
            self._shadow_replace(temp_table_fqn, "DYNAMIC TABLE", temp_view_fqn, "VIEW", fully_qualified_name)

            logger.info(f"Successfully replaced DYNAMIC TABLE with VIEW for {fully_qualified_name}")
        except Exception as e:
            # Cleanup shadow object if creation failed
            self._session.sql(f"""DROP VIEW IF EXISTS {temp_view_fqn}""").collect()
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Shadow swap to VIEW for {fully_qualified_name} failed: {e}"),
            ) from e

    def _shadow_swap_to_dynamic_table(
        self,
        feature_view: FeatureView,
        fully_qualified_name: str,
        column_descs: str,
        tagging_clause_str: str,
        schedule_task: bool,
        warehouse: SqlIdentifier,
        block: bool,
    ) -> None:
        """Replace an existing VIEW with a DYNAMIC TABLE using shadow swap.

        Creates a temporary DYNAMIC TABLE, then atomically swaps it with the existing VIEW.

        Args:
            feature_view: The feature view definition.
            fully_qualified_name: Fully qualified name for the target object.
            column_descs: Column descriptions clause used in the CREATE statement.
            tagging_clause_str: Tagging clause used in the CREATE statement.
            schedule_task: Whether a scheduled refresh task will be created (affects TARGET_LAG).
            warehouse: The warehouse to use for the dynamic table.
            block: Whether to block until completion.

        raises:
            SnowflakeMLException: [RuntimeError] Failed to replace view with dynamic table.
        """
        import uuid

        temp_suffix = uuid.uuid4().hex[:8]
        db, schema, obj = parse_fully_qualified_name(fully_qualified_name)
        new_view_name = identifier.concat_names([obj.identifier(), self._TMP_VIEW_PREFIX, temp_suffix])
        new_table_name = identifier.concat_names([obj.identifier(), self._TMP_DT_PREFIX, temp_suffix])
        temp_view_fqn = get_fully_qualified_name(db, schema, SqlIdentifier(new_view_name))
        temp_table_fqn = get_fully_qualified_name(db, schema, SqlIdentifier(new_table_name))

        # Create the new version as a shadow dynamic table first
        query = self._create_dynamic_table_query(
            "",  # Don't use override_clause for temp objects
            temp_table_fqn,
            column_descs,
            schedule_task,
            feature_view,
            tagging_clause_str,
            warehouse,
        )

        try:
            self._session.sql(query).collect(block=block, statement_params=self._telemetry_stmp)
            self._shadow_replace(temp_view_fqn, "VIEW", temp_table_fqn, "TABLE", fully_qualified_name)

            logger.info(f"Successfully replaced VIEW with DYNAMIC TABLE for {fully_qualified_name}")
        except Exception as e:
            # Cleanup shadow object if creation failed
            self._session.sql(f"""DROP DYNAMIC TABLE IF EXISTS {temp_table_fqn}""").collect()
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWML_ERROR,
                original_exception=RuntimeError(f"Shadow swap to DYNAMIC TABLE for {fully_qualified_name} failed: {e}"),
            ) from e

    def _create_offline_feature_view_view_query(
        self,
        overwrite_clause: str,
        view_name: str,
        column_descs: str,
        feature_view: FeatureView,
        tagging_clause_str: str,
    ) -> str:
        return f"""CREATE{overwrite_clause} VIEW {view_name} ({column_descs})
            COMMENT = '{feature_view.desc}'
            TAG (
                {tagging_clause_str}
            )
            AS {feature_view.query}
        """

    def _check_dynamic_table_refresh_mode(self, feature_view_name: SqlIdentifier) -> None:
        found_dts = self._find_object("DYNAMIC TABLES", feature_view_name)
        if len(found_dts) != 1:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"Can not find dynamic table: `{feature_view_name}`."),
            )
        if found_dts[0]["refresh_mode"] != "INCREMENTAL":
            warnings.warn(
                "Your pipeline won't be incrementally refreshed due to: "
                + f"\"{found_dts[0]['refresh_mode_reason']}\".",
                stacklevel=2,
                category=UserWarning,
            )

    def _validate_entity_exists(self, name: SqlIdentifier) -> bool:
        full_entity_tag_name = self._get_entity_name(name)
        found_rows = self._find_object("TAGS", full_entity_tag_name)
        return len(found_rows) == 1

    def _get_feature_prefix(
        self,
        feature_view: Union[FeatureView, FeatureViewSlice],
        auto_prefix: bool,
    ) -> Optional[str]:
        """Get the prefix to apply for this feature view.

        Priority:
        1. Explicit name from with_name() - highest priority
        2. Auto prefix if auto_prefix=True
        3. No prefix (default)

        Args:
            feature_view: The feature view instance.
            auto_prefix: Whether to auto-generate prefix.

        Returns:
            Prefix string with trailing underscore, or None.
        """
        # Priority 1: Explicit name
        if hasattr(feature_view, "column_alias") and feature_view.column_alias is not None:
            if feature_view.column_alias == "":
                return None  # Explicit no-prefix
            return f"{feature_view.column_alias}_"

        # Priority 2: Auto prefix
        if auto_prefix:
            # For FeatureViewSlice, access name and version through feature_view_ref
            if isinstance(feature_view, FeatureViewSlice):
                return f"{feature_view.feature_view_ref.name}_{feature_view.feature_view_ref.version}_"
            return f"{feature_view.name}_{feature_view.version}_"

        # Priority 3: No prefix
        return None

    def _build_cte_query(
        self,
        feature_views: list[FeatureView],
        feature_columns: list[str],
        spine_ref: str,
        spine_timestamp_col: Optional[SqlIdentifier],
        include_feature_view_timestamp_col: bool = False,
        auto_prefix: bool = False,
        is_training: bool = False,
    ) -> str:
        """
        Build a CTE query with the spine query and the feature views.

        This method supports feature views with different join keys by:
        1. Creating a spine CTE that includes all possible join keys
        2. For each feature view, creating a deduplicated spine subquery with only that FV's join keys
        3. For tiled FVs: Using MergingSqlGenerator to generate tile merging CTEs
        4. For non-tiled FVs: Performing ASOF JOINs on the deduplicated spine when timestamp columns exist
        5. Performing LEFT JOINs on the deduplicated spine when timestamp columns are missing
        6. Combining results by LEFT JOINing each FV CTE back to the original SPINE

        For large numbers of feature views (> _CTE_MERGE_BATCH_SIZE), the final join is restructured
        into batched merge CTEs to bound the join depth per batch. FVs are grouped by entity key
        signature, and each group is chunked into batches. Non-primary batches use a deduplicated
        spine (SELECT DISTINCT on their entity keys) to reduce cardinality for narrower entity groups.

        For temporal rollup FVs in training mode (``is_training=True`` and
        ``rollup_metadata.mapping_valid_from_col`` is set), an additional CTE is
        injected that range JOINs the parent tile table with the temporal mapping to
        produce PIT-correct rollup tiles using bounded validity windows
        ``[valid_from, valid_to)``. This supports 1:N mappings. This CTE replaces
        the flat DT as input to MergingSqlGenerator.

        Args:
            feature_views: A list of feature views to join.
            feature_columns: A list of feature column strings for each feature view.
            spine_ref: The spine query.
            spine_timestamp_col: The timestamp column from spine. Can be None if spine has no timestamp column.
            include_feature_view_timestamp_col: Whether to include the timestamp column of
                the feature view in the result. Default to false.
            auto_prefix: Whether to automatically prefix feature columns.
            is_training: If True, use PIT-correct entity mappings for temporal rollup FVs.

        Returns:
            A SQL query string with CTE structure for joining feature views.
        """
        if not feature_views:
            return f"SELECT * FROM ({spine_ref})"

        # Create spine CTE with the spine query for reuse
        spine_cte = f"""SPINE AS (
            SELECT * FROM ({spine_ref})
        )"""

        ctes = [spine_cte]
        cte_names = []
        for i, feature_view in enumerate(feature_views):
            cte_name = f"FV{i:03d}"
            cte_names.append(cte_name)

            feature_timestamp_col = feature_view.timestamp_col

            # Get the specific join keys for this feature view
            fv_join_keys = list({k for e in feature_view.entities for k in e.join_keys})
            join_keys_str = ", ".join(fv_join_keys)

            # Handle tiled feature views using MergingSqlGenerator
            if feature_view.is_tiled and spine_timestamp_col is not None:
                assert feature_timestamp_col is not None
                tile_table = feature_view.fully_qualified_name()

                # For temporal rollup FVs in training mode, inject a PIT-correct
                # rollup CTE that range JOINs parent tiles with the temporal mapping
                # using bounded [valid_from, valid_to) windows. Supports 1:N mappings.
                rm = feature_view.rollup_metadata
                if is_training and rm is not None and rm.mapping_valid_from_col is not None:
                    logger.info(
                        f"Injecting PIT-correct rollup CTE for {feature_view.name} "
                        f"using range JOIN with mapping_valid_from_col={rm.mapping_valid_from_col}, "
                        f"mapping_valid_to_col={rm.mapping_valid_to_col}. "
                        f"Tiles outside the mapping validity window will be excluded."
                    )
                    new_join_keys = [str(k) for k in fv_join_keys]
                    pit_generator = RollupSqlGenerator(
                        parent_tile_table=rm.parent_tile_table,
                        parent_join_keys=rm.parent_join_keys,
                        new_join_keys=new_join_keys,
                        mapping_query=rm.mapping_query,
                        aggregation_specs=feature_view.aggregation_specs or [],
                        mapping_valid_from_col=rm.mapping_valid_from_col,
                        mapping_valid_to_col=rm.mapping_valid_to_col,
                    )
                    pit_cte_name = f"PIT_ROLLUP_FV{i}"
                    cte_name_str, cte_body = pit_generator.generate_as_cte(pit_cte_name)
                    ctes.append(f"{cte_name_str} AS (\n{cte_body}\n)")
                    tile_table = pit_cte_name

                generator = MergingSqlGenerator(
                    tile_table=tile_table,
                    join_keys=fv_join_keys,
                    timestamp_col=feature_timestamp_col,
                    feature_granularity=feature_view.feature_granularity,  # type: ignore[arg-type]
                    features=feature_view.aggregation_specs,  # type: ignore[arg-type]
                    spine_timestamp_col=spine_timestamp_col,
                    fv_index=i,
                )
                # Add all CTEs from the merging generator
                for cte_tuple in generator.generate_all_ctes():
                    ctes.append(f"{cte_tuple[0]} AS (\n{cte_tuple[1]}\n)")

            # Use ASOF JOIN if both spine and feature view have timestamp columns, otherwise use LEFT JOIN
            elif spine_timestamp_col is not None and feature_timestamp_col is not None:
                # Build the deduplicated spine columns set (join keys + timestamp)
                spine_dedup_cols_set = set(fv_join_keys)
                if spine_timestamp_col not in spine_dedup_cols_set:
                    spine_dedup_cols_set.add(spine_timestamp_col)
                spine_dedup_cols_str = ", ".join(col.identifier() for col in spine_dedup_cols_set)

                # Build the JOIN condition using only this feature view's join keys
                join_conditions_dedup = [
                    f"SPINE_DEDUP.{col.identifier()} = FEATURE.{col.identifier()}" for col in fv_join_keys
                ]

                quoted_spine_ts = spine_timestamp_col.identifier()
                quoted_fv_ts = feature_timestamp_col.identifier()

                if include_feature_view_timestamp_col:
                    f_ts_col_alias = identifier.concat_names(
                        [feature_view.name, "_", str(feature_view.version), "_", feature_timestamp_col]
                    )
                    f_ts_col_str = f"FEATURE.{feature_timestamp_col} AS {f_ts_col_alias},"
                else:
                    f_ts_col_str = ""
                ctes.append(
                    f"""{cte_name} AS (
    SELECT
        SPINE_DEDUP.*,
        {f_ts_col_str}
        FEATURE.* EXCLUDE ({join_keys_str}, {feature_timestamp_col})
    FROM (
        SELECT DISTINCT {spine_dedup_cols_str}
        FROM SPINE
    ) SPINE_DEDUP
    ASOF JOIN (
        SELECT {join_keys_str}, {feature_timestamp_col}, {feature_columns[i]}
        FROM {feature_view.fully_qualified_name()}
    ) FEATURE
    MATCH_CONDITION (SPINE_DEDUP.{quoted_spine_ts} >= FEATURE.{quoted_fv_ts})
    ON {" AND ".join(join_conditions_dedup)}
)"""
                )
            else:
                # Build the deduplicated spine columns list (just join keys, no timestamp)
                spine_dedup_cols_str = ", ".join(col.identifier() for col in fv_join_keys)

                # Build the JOIN condition using only this feature view's join keys
                join_conditions_dedup = [
                    f"SPINE_DEDUP.{col.identifier()} = FEATURE.{col.identifier()}" for col in fv_join_keys
                ]

                ctes.append(
                    f"""{cte_name} AS (
    SELECT
        SPINE_DEDUP.*,
        FEATURE.* EXCLUDE ({join_keys_str})
    FROM (
        SELECT DISTINCT {spine_dedup_cols_str}
        FROM SPINE
    ) SPINE_DEDUP
    LEFT JOIN (
        SELECT {join_keys_str}, {feature_columns[i]}
        FROM {feature_view.fully_qualified_name()}
    ) FEATURE
    ON {" AND ".join(join_conditions_dedup)}
)"""
                )

        # Collect per-FV metadata for the final join assembly
        fv_infos: list[_FvJoinInfo] = []
        for i, cte_name in enumerate(cte_names):
            feature_view = feature_views[i]
            fv_join_keys = list({k for e in feature_view.entities for k in e.join_keys})
            has_ts = spine_timestamp_col is not None and feature_view.timestamp_col is not None
            key_sig = (tuple(sorted(k.resolved() for k in fv_join_keys)), has_ts)

            select_cols: list[str] = []
            col_names: list[str] = []
            if (
                include_feature_view_timestamp_col
                and feature_view.timestamp_col is not None
                and not feature_view.is_tiled
            ):
                f_ts_col_alias = identifier.concat_names(
                    [feature_view.name, "_", str(feature_view.version), "_", feature_view.timestamp_col]
                )
                select_cols.append(f"{cte_name}.{f_ts_col_alias} AS {f_ts_col_alias}")
                col_names.append(f_ts_col_alias)

            prefix = self._get_feature_prefix(feature_view, auto_prefix)
            if feature_view.is_tiled and feature_view.aggregation_specs:
                for spec in feature_view.aggregation_specs:
                    col_name = spec.get_sql_column_name()
                    if prefix:
                        alias = identifier.concat_names([prefix, col_name])
                        select_cols.append(f"{cte_name}.{col_name} AS {alias}")
                        col_names.append(alias)
                    else:
                        select_cols.append(f"{cte_name}.{col_name}")
                        col_names.append(col_name)
            else:
                for col in feature_columns[i].split(", "):
                    col_clean = col.strip()
                    if prefix:
                        alias = identifier.concat_names([prefix, col_clean])
                        select_cols.append(f"{cte_name}.{col_clean} AS {alias}")
                        col_names.append(alias)
                    else:
                        select_cols.append(f"{cte_name}.{col_clean}")
                        col_names.append(col_clean)

            fv_infos.append(
                _FvJoinInfo(
                    cte_name=cte_name,
                    key_sig=key_sig,
                    join_keys=fv_join_keys,
                    has_ts=has_ts,
                    select_cols=select_cols,
                    col_names=col_names,
                )
            )

        # For small FV counts, use the existing flat join path
        if len(cte_names) <= _CTE_MERGE_BATCH_SIZE:
            all_select = [col for fi in fv_infos for col in fi.select_cols]
            all_joins = "".join(
                _make_fv_join_clause("SPINE", fi.cte_name, fi.join_keys, fi.has_ts, spine_timestamp_col)
                for fi in fv_infos
            )
            query = f"""WITH
{', '.join(ctes)}
SELECT
    SPINE.*,
    {', '.join(all_select)}
FROM SPINE{all_joins}
"""
            return query

        return self._build_batched_cte_merge_query(ctes, fv_infos, spine_timestamp_col)

    @staticmethod
    def _build_batched_cte_merge_query(
        ctes: list[str],
        fv_infos: list[_FvJoinInfo],
        spine_timestamp_col: Optional[SqlIdentifier],
    ) -> str:
        """Build a batched CTE merge query for large numbers of feature views.

        Groups FVs by entity key signature, chunks them into batches of at most
        _CTE_MERGE_BATCH_SIZE, and assembles batch CTEs that are joined in a final
        merge step.  BATCH0 carries all spine columns; subsequent batches deduplicate
        the spine to their entity keys via SELECT DISTINCT.

        Args:
            ctes: Accumulated list of CTE definition strings (modified in-place with batch CTEs).
            fv_infos: Per-feature-view join metadata collected by _build_cte_query.
            spine_timestamp_col: The timestamp column from the spine, or None.

        Returns:
            A SQL query string with batched CTE merge structure.
        """
        # Group FVs by entity key signature
        groups: dict[tuple[tuple[str, ...], bool], list[_FvJoinInfo]] = {}
        for fi in fv_infos:
            if fi.key_sig not in groups:
                groups[fi.key_sig] = []
            groups[fi.key_sig].append(fi)

        # BATCH0 gets the widest key set (most keys; ties broken by has_ts=True,
        # then lexicographic key order — deterministic regardless of insertion order).
        batch0_sig = max(groups.keys(), key=lambda sig: (len(sig[0]), sig[1], sig[0]))

        # Ordered list of (fv_chunk, key_sig): BATCH0 group first, then others
        # sorted for deterministic batch ordering across runs
        batches: list[tuple[list[_FvJoinInfo], tuple[tuple[str, ...], bool]]] = []
        batch0_fvs = groups.pop(batch0_sig)
        for start in range(0, len(batch0_fvs), _CTE_MERGE_BATCH_SIZE):
            batches.append((batch0_fvs[start : start + _CTE_MERGE_BATCH_SIZE], batch0_sig))
        for sig in sorted(groups.keys()):
            fvs = groups[sig]
            for start in range(0, len(fvs), _CTE_MERGE_BATCH_SIZE):
                batches.append((fvs[start : start + _CTE_MERGE_BATCH_SIZE], sig))

        batch_cte_names: list[str] = []
        batch_col_names: list[list[str]] = []
        batch_key_ids: list[list[SqlIdentifier]] = []
        batch_has_ts_flags: list[bool] = []

        for batch_idx, (chunk, key_sig) in enumerate(batches):
            batch_cte_name = f"_BATCH{batch_idx}"
            batch_cte_names.append(batch_cte_name)

            # All FVs in a group share the same resolved key signature, so chunk[0].join_keys
            # is a canonical SqlIdentifier list for SQL rendering (preserves case / quoting rules).
            group_key_ids = chunk[0].join_keys
            batch_key_ids.append(group_key_ids)
            batch_has_ts = key_sig[1]
            batch_has_ts_flags.append(batch_has_ts)

            batch_select = [col for fi in chunk for col in fi.select_cols]
            batch_col_names.append([cn for fi in chunk for cn in fi.col_names])

            if batch_idx == 0:
                batch_joins = "".join(
                    _make_fv_join_clause("SPINE", fi.cte_name, fi.join_keys, fi.has_ts, spine_timestamp_col)
                    for fi in chunk
                )
                cte_body = f"SELECT SPINE.*, {', '.join(batch_select)} FROM SPINE{batch_joins}"
            else:
                dedup_alias = f"_SD{batch_idx}"
                dedup_cols = [k.identifier() for k in group_key_ids]
                if batch_has_ts and spine_timestamp_col is not None:
                    dedup_cols.append(spine_timestamp_col.identifier())

                batch_joins = "".join(
                    _make_fv_join_clause(dedup_alias, fi.cte_name, fi.join_keys, fi.has_ts, spine_timestamp_col)
                    for fi in chunk
                )

                key_select = ", ".join(f"{dedup_alias}.{k.identifier()}" for k in group_key_ids)
                ts_select = (
                    f", {dedup_alias}.{spine_timestamp_col.identifier()}"
                    if batch_has_ts and spine_timestamp_col is not None
                    else ""
                )

                cte_body = (
                    f"SELECT {key_select}{ts_select}, {', '.join(batch_select)}\n"
                    f"    FROM (SELECT DISTINCT {', '.join(dedup_cols)} FROM SPINE) {dedup_alias}"
                    f"{batch_joins}"
                )

            ctes.append(f"{batch_cte_name} AS (\n{cte_body}\n)")

        # Final merge: BATCH0.* + feature columns from other batches
        merge_select_parts = [f"{batch_cte_names[0]}.*"]
        merge_join_parts: list[str] = []

        for bi in range(1, len(batches)):
            bcn = batch_cte_names[bi]
            for col_name in batch_col_names[bi]:
                merge_select_parts.append(f"{bcn}.{col_name}")
            merge_join_parts.append(
                _make_fv_join_clause(
                    batch_cte_names[0],
                    bcn,
                    batch_key_ids[bi],
                    batch_has_ts_flags[bi],
                    spine_timestamp_col,
                )
            )

        merge_select_str = ",\n    ".join(merge_select_parts)
        query = f"""WITH
{', '.join(ctes)}
SELECT
    {merge_select_str}
FROM {batch_cte_names[0]}{''.join(merge_join_parts)}
"""
        return query

    def _join_features(
        self,
        spine_df: DataFrame,
        features: list[Union[FeatureView, FeatureViewSlice]],
        spine_timestamp_col: Optional[SqlIdentifier],
        include_feature_view_timestamp_col: bool,
        auto_prefix: bool = False,
        join_method: Literal["sequential", "cte"] = "sequential",
        is_training: bool = False,
    ) -> tuple[DataFrame, list[SqlIdentifier]]:
        # Validate join_method parameter
        if join_method not in ["sequential", "cte"]:
            raise ValueError(f"Invalid join_method '{join_method}'. Must be 'sequential' or 'cte'.")

        # Check if any feature view is tiled - tiled FVs require CTE method and timestamp column
        has_tiled_fv = False
        for feature in features:
            fv = feature.feature_view_ref if isinstance(feature, FeatureViewSlice) else feature
            if fv.is_tiled:
                has_tiled_fv = True
                break

        if has_tiled_fv and join_method != "cte":
            raise ValueError(
                "Tiled feature views require join_method='cte'. "
                "Please set join_method='cte' when using feature views with tile-based aggregations."
            )

        if has_tiled_fv and spine_timestamp_col is None:
            raise ValueError(
                "Tiled feature views require a spine_timestamp_col for point-in-time joins. "
                "Please provide spine_timestamp_col when using feature views with tile-based aggregations."
            )

        feature_views: list[FeatureView] = []
        # Extract column selections for each feature view
        feature_columns: list[str] = []
        for feature in features:
            fv = feature.feature_view_ref if isinstance(feature, FeatureViewSlice) else feature
            if fv.status == FeatureViewStatus.DRAFT:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.NOT_FOUND,
                    original_exception=ValueError(f"FeatureView {fv.name} has not been registered."),
                )
            for e in fv.entities:
                for k in e.join_keys:
                    if k not in to_sql_identifiers(spine_df.columns):
                        raise snowml_exceptions.SnowflakeMLException(
                            error_code=error_codes.INVALID_ARGUMENT,
                            original_exception=ValueError(
                                f"join_key {k} from Entity {e.name} in FeatureView {fv.name} "
                                "is not found in spine_df."
                            ),
                        )
            feature_views.append(fv)
            if isinstance(feature, FeatureViewSlice):
                cols = feature.names
            else:
                cols = feature.feature_names
            feature_columns.append(", ".join(col.identifier() for col in cols))
        # TODO (SNOW-2396184): remove this check and the non-ASOF join path as ASOF join is enabled by default now.
        if self._asof_join_enabled is None:
            self._asof_join_enabled = self._is_asof_join_enabled()

        # TODO: leverage Snowpark dataframe for more concise syntax once it supports AsOfJoin
        query = spine_df.queries["queries"][-1]
        join_keys: list[SqlIdentifier] = []

        if join_method == "cte":
            logger.info(f"Using the CTE method with {len(features)} feature views")

            query = self._build_cte_query(
                feature_views,
                feature_columns,
                spine_df.queries["queries"][-1],
                spine_timestamp_col,
                include_feature_view_timestamp_col,
                auto_prefix,
                is_training,
            )
        else:
            # Use sequential joins layer by layer
            logger.info(f"Using the sequential join method with {len(features)} feature views")
            layer = 0
            for feature in features:
                if isinstance(feature, FeatureViewSlice):
                    cols = feature.names
                    feature = feature.feature_view_ref
                else:
                    cols = feature.feature_names

                join_keys = list({k for e in feature.entities for k in e.join_keys})
                join_keys_str = ", ".join(join_keys)
                assert feature.version is not None
                join_table_name = feature.fully_qualified_name()

                if spine_timestamp_col is not None and feature.timestamp_col is not None:
                    if self._asof_join_enabled:
                        if include_feature_view_timestamp_col:
                            f_ts_col_alias = identifier.concat_names(
                                [feature.name, "_", feature.version, "_", feature.timestamp_col]
                            )
                            f_ts_col_str = f"r_{layer}.{feature.timestamp_col} AS {f_ts_col_alias},"
                        else:
                            f_ts_col_str = ""

                        # Build feature column selection with optional prefix
                        prefix = self._get_feature_prefix(feature, auto_prefix)
                        if prefix:
                            feature_cols_list = []
                            for col in cols:
                                col_name = col.identifier()
                                alias = identifier.concat_names([prefix, col_name])
                                feature_cols_list.append(f"r_{layer}.{col_name} AS {alias}")
                            feature_cols_str = ", ".join(feature_cols_list)
                        else:
                            feature_cols_str = f"r_{layer}.* EXCLUDE ({join_keys_str}, {feature.timestamp_col})"

                        query = f"""
                            SELECT
                                l_{layer}.*,
                                {f_ts_col_str}
                                {feature_cols_str}
                            FROM ({query}) l_{layer}
                            ASOF JOIN (
                                SELECT {join_keys_str}, {feature.timestamp_col},
                                    {', '.join(col.identifier() for col in cols)}
                                FROM {join_table_name}
                            ) r_{layer}
                            MATCH_CONDITION (l_{layer}.{spine_timestamp_col} >= r_{layer}.{feature.timestamp_col})
                            ON {' AND '.join([f'l_{layer}.{k} = r_{layer}.{k}' for k in join_keys])}
                        """
                    else:
                        assert feature.feature_df is not None
                        query = self._composed_union_window_join_query(
                            layer=layer,
                            s_query=query,
                            s_ts_col=spine_timestamp_col,
                            f_df=feature.feature_df,
                            f_table_name=join_table_name,
                            f_ts_col=feature.timestamp_col,
                            join_keys=join_keys,
                        )
                else:
                    # Build feature column selection with optional prefix
                    prefix = self._get_feature_prefix(feature, auto_prefix)
                    if prefix:
                        feature_cols_list = []
                        for col in cols:
                            col_name = col.identifier()
                            alias = identifier.concat_names([prefix, col_name])
                            feature_cols_list.append(f"r_{layer}.{col_name} AS {alias}")
                        feature_cols_str = ", ".join(feature_cols_list)
                    else:
                        feature_cols_str = f"r_{layer}.* EXCLUDE ({join_keys_str})"

                    query = f"""
                        SELECT
                            l_{layer}.*,
                            {feature_cols_str}
                        FROM ({query}) l_{layer}
                        LEFT JOIN (
                            SELECT {join_keys_str}, {', '.join(col.identifier() for col in cols)}
                            FROM {join_table_name}
                        ) r_{layer}
                        ON {' AND '.join([f'l_{layer}.{k} = r_{layer}.{k}' for k in join_keys])}
                    """
                layer += 1

        # TODO: construct result dataframe with datframe APIs once ASOF join is supported natively.
        # Below code manually construct result dataframe from private members of spine dataframe, which
        # likely will cause unintentional issues. This setp is needed because spine_df might contains
        # prerequisite queries and post actions that must be carried over to result dataframe.
        result_df = self._session.sql(query)
        result_df._plan.queries = spine_df._plan.queries[:-1] + result_df._plan.queries
        result_df._plan.post_actions = spine_df._plan.post_actions

        return result_df, join_keys

    def _check_database_exists_or_throw(self) -> None:
        resolved_db_name = self._config.database.resolved()
        dbs = self._session.sql(
            f"""
            SHOW DATABASES LIKE '{resolved_db_name}' STARTS WITH '{resolved_db_name}'
        """
        ).collect(statement_params=self._telemetry_stmp)
        if len(dbs) == 0:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"Database {resolved_db_name} does not exist."),
            )

    def _check_internal_objects_exist_or_throw(self) -> None:
        schema_result = self._find_object("SCHEMAS", self._config.schema)
        if len(schema_result) == 0:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(
                    f"Feature store schema {self._config.schema} does not exist. "
                    "Use CreationMode.CREATE_IF_NOT_EXIST mode instead if you want to create one."
                ),
            )
        for tag_name in to_sql_identifiers(
            [
                _FEATURE_STORE_OBJECT_TAG,
                _FEATURE_VIEW_METADATA_TAG,
            ]
        ):
            tag_result = self._find_object("TAGS", tag_name)
            if len(tag_result) == 0:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.NOT_FOUND,
                    original_exception=ValueError(
                        f"Feature store internal tag {tag_name} does not exist. "
                        "Use CreationMode.CREATE_IF_NOT_EXIST mode instead if you want to create one."
                    ),
                )

    def _is_asof_join_enabled(self) -> bool:
        result = None
        try:
            result = self._session.sql(
                """
                WITH
                spine AS (
                    SELECT "ID", "TS" FROM ( SELECT $1 AS "ID", $2 AS "TS" FROM VALUES (1 :: INT, 100 :: INT))
                ),
                feature AS (
                    SELECT "ID", "TS" FROM ( SELECT $1 AS "ID", $2 AS "TS" FROM VALUES (1 :: INT, 100 :: INT))
                )
                SELECT * FROM spine
                ASOF JOIN feature
                MATCH_CONDITION ( spine.ts >= feature.ts )
                ON spine.id = feature.id;
            """
            ).collect(statement_params=self._telemetry_stmp)
        except SnowparkSQLException:
            return False
        return result is not None and len(result) == 1

    # Visualize how the query works:
    #   https://docs.google.com/presentation/d/15fT2F34OFp5RPv2-hZirHw6wliPRVRlPHvoCMIB00oY/edit#slide=id.g25ab53e6c8d_0_32
    def _composed_union_window_join_query(
        self,
        layer: int,
        s_query: str,
        s_ts_col: SqlIdentifier,
        f_df: DataFrame,
        f_table_name: str,
        f_ts_col: SqlIdentifier,
        join_keys: list[SqlIdentifier],
    ) -> str:
        s_df = self._session.sql(s_query)
        s_only_cols = [col for col in to_sql_identifiers(s_df.columns) if col not in [*join_keys, s_ts_col]]
        f_only_cols = [col for col in to_sql_identifiers(f_df.columns) if col not in [*join_keys, f_ts_col]]
        join_keys_str = ", ".join(join_keys)
        temp_prefix = "_FS_TEMP_"

        def join_cols(cols: list[SqlIdentifier], end_comma: bool, rename: bool, prefix: str = "") -> str:
            if not cols:
                return ""
            cols = [f"{prefix}{col}" for col in cols]  # type: ignore[misc]
            if rename:
                cols = [f"{col} AS {col.replace(temp_prefix, '')}" for col in cols]  # type: ignore[misc]
            line_end = "," if end_comma else ""
            return ", ".join(cols) + line_end

        # Part 1: CTE of spine query
        spine_cte = f"""
            WITH spine_{layer} AS (
                {s_query}
            ),"""

        # Part 2: create union of spine table and feature tables
        s_select = f"""
            SELECT
                'SPINE' {temp_prefix}src,
                {s_ts_col},
                {join_keys_str},
                {join_cols(s_only_cols, end_comma=True, rename=False)}
                {join_cols(f_only_cols, end_comma=False, rename=False, prefix='null AS ')}
            FROM ({s_query})"""
        f_select = f"""
            SELECT
                'FEATURE' {temp_prefix}src,
                {f_ts_col} {s_ts_col},
                {join_keys_str},
                {join_cols(s_only_cols, end_comma=True, rename=False, prefix='null AS ')}
                {join_cols(f_only_cols, end_comma=False, rename=False)}
            FROM {f_table_name}"""
        union_cte = f"""
            unioned_{layer} AS (
                {s_select}
                UNION ALL
                {f_select}
            ),"""

        # Part 3: create window cte and add window column
        window_select = f"SELECT {temp_prefix}src, {s_ts_col}, {join_keys_str}"
        for f_col in f_only_cols:
            window_select = (
                window_select
                + f"""
                ,last_value({f_col}) IGNORE NULLS OVER (
                    PARTITION BY {join_keys_str}
                    ORDER BY {s_ts_col} ASC, {temp_prefix}src ASC
                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                ) AS {temp_prefix}{f_col}"""
            )
        window_select = window_select + f" FROM unioned_{layer}"
        window_cte = f"""
            windowed_{layer} AS (
                {window_select}
            )"""

        # Part 4: join original spine table with window table
        prefix_f_only_cols = to_sql_identifiers(
            [f"{temp_prefix}{name.resolved()}" for name in f_only_cols],
            case_sensitive=True,
        )
        last_select = f"""
            SELECT
                {join_keys_str},
                {s_ts_col},
                {join_cols(s_only_cols, end_comma=True, rename=False)}
                {join_cols(prefix_f_only_cols, end_comma=False, rename=True)}
            FROM spine_{layer}
            JOIN windowed_{layer}
            USING ({join_keys_str}, {s_ts_col})
            WHERE windowed_{layer}.{temp_prefix}src = 'SPINE'"""

        # Part 5: complete query
        complete_query = spine_cte + union_cte + window_cte + last_select

        return complete_query

    def _resolve_task_schedule(self, fv_name: SqlIdentifier, fallback: str) -> str:
        """Look up the Task schedule for a cron-driven feature view.

        CRON-based FVs use ``TARGET_LAG = 'DOWNSTREAM'`` on the DT while the
        actual cron schedule lives on a companion Task with the same name.
        This helper retrieves that schedule so the reconstructed
        ``FeatureView`` carries the real cron expression instead of
        ``'DOWNSTREAM'``.

        Args:
            fv_name: Resolved physical name of the feature view (e.g. ``FV$V1``).
            fallback: Value to return when no Task is found (i.e. the FV was
                truly registered with ``refresh_freq='DOWNSTREAM'``).

        Returns:
            The cron expression from the Task (with the ``USING CRON `` prefix
            stripped), or ``fallback`` if no Task exists.
        """
        task_rows = self._session.sql(
            f"SHOW TASKS LIKE '{fv_name.resolved()}' IN SCHEMA {self._config.full_schema_path}"
        ).collect(statement_params=self._telemetry_stmp)
        if not task_rows:
            return fallback
        schedule: str = task_rows[0]["schedule"]
        if schedule.upper().startswith("USING CRON "):
            schedule = schedule[len("USING CRON ") :]
        return schedule

    def _get_entity_name(self, raw_name: SqlIdentifier) -> SqlIdentifier:
        return SqlIdentifier(identifier.concat_names([_ENTITY_TAG_PREFIX, raw_name]))

    def _get_fully_qualified_name(self, name: Union[SqlIdentifier, str]) -> str:
        # Do a quick check to see if we can skip regex operations
        if "." not in name:
            return f"{self._config.full_schema_path}.{name}"

        db_name, schema_name, object_name = identifier.parse_schema_level_object_identifier(name)
        return "{}.{}.{}".format(
            db_name or self._config.database,
            schema_name or self._config.schema,
            object_name,
        )

    def _resolve_storage_config(self, feature_view: FeatureView, fully_qualified_name: str) -> None:
        """Resolve storage_config with defaults for Iceberg tables.

        For Iceberg feature views:
        - If no external_volume is provided, use the default_iceberg_external_volume from FeatureStore.
        - If no base_location is provided, auto-generate one from the fully qualified name.

        Args:
            feature_view: The feature view whose storage config should be resolved.
            fully_qualified_name: The fully qualified name (DB.SCHEMA.TABLE) for path generation.

        Raises:
            SnowflakeMLException: If Iceberg storage is requested but no external_volume is available
                (neither in StorageConfig nor as FeatureStore default).
        """
        if feature_view.storage_config is not None and feature_view.storage_config.format == StorageFormat.ICEBERG:
            external_volume = feature_view.storage_config.external_volume
            base_location = feature_view.storage_config.base_location

            # Apply default external_volume if not set
            if external_volume is None:
                if self._default_iceberg_external_volume is not None:
                    external_volume = self._default_iceberg_external_volume
                else:
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.INVALID_ARGUMENT,
                        original_exception=ValueError(
                            "Iceberg storage requires an external_volume. Either provide external_volume in "
                            "StorageConfig or set default_iceberg_external_volume when creating FeatureStore."
                        ),
                    )

            # Auto-generate base_location if not set
            if base_location is None:
                base_location = f"snowflake/feature_store/iceberg/{fully_qualified_name.replace('.', '/')}"

            feature_view._storage_config = StorageConfig(
                format=feature_view.storage_config.format,
                external_volume=external_volume,
                base_location=base_location,
            )

    def _get_all_iceberg_storage_configs(self) -> dict[str, StorageConfig]:
        """Get storage configs for all Iceberg tables in the feature store schema.

        Executes a single SHOW ICEBERG TABLES IN SCHEMA query and returns a dictionary
        mapping table names to their StorageConfig. This is more efficient than calling
        _get_iceberg_storage_config for each table individually.

        Returns:
            Dictionary mapping table name (resolved, i.e. actual stored name) to StorageConfig.

        Raises:
            SnowflakeMLException: If the SHOW ICEBERG TABLES query fails.
        """
        query = f"SHOW ICEBERG TABLES IN SCHEMA {self._config.full_schema_path}"
        try:
            rows = self._session.sql(query).collect(statement_params=self._telemetry_stmp)
            return {
                row["name"]: StorageConfig(
                    format=StorageFormat.ICEBERG,
                    external_volume=row["external_volume_name"],
                    base_location=row["base_location"],
                )
                for row in rows
            }
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWML_ERROR,
                original_exception=RuntimeError(
                    f"Failed to retrieve Iceberg storage configs from schema {self._config.full_schema_path}: {e}"
                ),
            ) from e

    def _get_iceberg_storage_config(self, table_name: SqlIdentifier) -> Optional[StorageConfig]:
        """Get storage config for an Iceberg table using SHOW ICEBERG TABLES.

        Args:
            table_name: The table name to look up.

        Returns:
            StorageConfig with Iceberg format if found, None if not an Iceberg table.

        Raises:
            SnowflakeMLException: If the SHOW ICEBERG TABLES query fails.
        """
        # Use resolved() to get the actual stored name (without SQL quoting/escaping)
        raw_name = table_name.resolved()
        # Escape single quotes for SQL string literal safety.
        # The table name goes inside single quotes as a LIKE pattern (string literal),
        # so single quotes must be escaped as '' (e.g., "foo'bar" -> "foo''bar").
        # The schema path is a SQL identifier (not a string literal), and is already
        # properly formatted by full_schema_path using SqlIdentifier utilities.
        escaped_name = raw_name.replace("'", "''")
        query = f"SHOW ICEBERG TABLES LIKE '{escaped_name}' IN SCHEMA {self._config.full_schema_path}"

        try:
            iceberg_tables = self._session.sql(query).collect(statement_params=self._telemetry_stmp)
            if iceberg_tables:
                row = iceberg_tables[0]
                return StorageConfig(
                    format=StorageFormat.ICEBERG,
                    external_volume=row["external_volume_name"],
                    base_location=row["base_location"],
                )
            return None
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWML_ERROR,
                original_exception=RuntimeError(f"Failed to retrieve Iceberg storage config for {raw_name}: {e}"),
            ) from e

    # TODO: SHOW DYNAMIC TABLES is very slow while other show objects are fast, investigate with DT in SNOW-902804.
    def _get_fv_backend_representations(
        self, object_name: Optional[SqlIdentifier], prefix_match: bool = False
    ) -> list[tuple[Row, _FeatureStoreObjTypes]]:
        dynamic_table_results = [
            (d, _FeatureStoreObjTypes.MANAGED_FEATURE_VIEW)
            for d in self._find_object("DYNAMIC TABLES", object_name, prefix_match)
        ]
        view_results = [
            (d, _FeatureStoreObjTypes.EXTERNAL_FEATURE_VIEW)
            for d in self._find_object("VIEWS", object_name, prefix_match)
        ]
        return dynamic_table_results + view_results

    def _update_feature_view_status(
        self, feature_view: FeatureView, operation: str, store_type: Optional[fv_mod.StoreType] = None
    ) -> FeatureView:
        assert operation in [
            "RESUME",
            "SUSPEND",
            "REFRESH",
        ], f"Operation: {operation} not supported"
        if feature_view.status == FeatureViewStatus.DRAFT or feature_view.version is None:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_FOUND,
                original_exception=ValueError(f"FeatureView {feature_view.name} has not been registered."),
            )

        fully_qualified_name = feature_view.fully_qualified_name()

        # Handle offline feature view (default for suspend/resume, or when explicitly requested)
        if store_type is None or store_type == fv_mod.StoreType.OFFLINE:
            # Note: Dynamic Iceberg tables are managed with ALTER DYNAMIC TABLE (no ICEBERG keyword)
            # just like regular dynamic tables, so the same commands work.
            try:
                self._session.sql(f"ALTER DYNAMIC TABLE {fully_qualified_name} {operation}").collect(
                    statement_params=self._telemetry_stmp
                )
                if operation != "REFRESH":
                    self._session.sql(f"ALTER TASK IF EXISTS {fully_qualified_name} {operation}").collect(
                        statement_params=self._telemetry_stmp
                    )
            except Exception as e:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                    original_exception=RuntimeError(
                        f"Failed to update feature view {fully_qualified_name}'s status: {e}"
                    ),
                ) from e

        elif store_type == fv_mod.StoreType.ONLINE and operation in ["SUSPEND", "RESUME", "REFRESH"]:
            if feature_view.online:
                fully_qualified_online_name = feature_view.fully_qualified_online_table_name()
                try:
                    self._session.sql(f"ALTER ONLINE FEATURE TABLE {fully_qualified_online_name} {operation}").collect(
                        statement_params=self._telemetry_stmp
                    )
                    logger.info(
                        f"Successfully {operation.lower()}ed online feature table for "
                        f"{feature_view.name}/{feature_view.version}"
                    )
                except Exception as e:
                    # For refresh operations, raise the exception; for suspend/resume, just log warning
                    if operation == "REFRESH":
                        raise snowml_exceptions.SnowflakeMLException(
                            error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                            original_exception=RuntimeError(
                                f"Failed to refresh online feature table {fully_qualified_online_name}: {e}"
                            ),
                        ) from e
                    else:
                        # Log warning but don't fail the entire operation if online table operation
                        # fails for suspend/resume
                        logger.warning(f"Failed to {operation} online feature table {fully_qualified_online_name}: {e}")

        logger.info(f"Successfully {operation.lower()}ed FeatureView {feature_view.name}/{feature_view.version}.")
        return self.get_feature_view(feature_view.name, feature_view.version)

    def _optimized_find_feature_views(
        self, entity_name: SqlIdentifier, feature_view_name: Optional[SqlIdentifier]
    ) -> DataFrame:
        if not self._validate_entity_exists(entity_name):
            return self._session.create_dataframe([], schema=_LIST_FEATURE_VIEW_SCHEMA)

        # TODO: this can be optimized further by directly getting all possible FVs and filter by tag
        # it's easier to rewrite the code once we can remove the tag_reference path
        all_fvs = self._get_fv_backend_representations(object_name=None)
        fv_maps = {SqlIdentifier(r["name"], case_sensitive=True): r for r, _ in all_fvs}

        if len(fv_maps.keys()) == 0:
            return self._session.create_dataframe([], schema=_LIST_FEATURE_VIEW_SCHEMA)

        filters = [lambda d: d["entityName"].startswith(feature_view_name.resolved())] if feature_view_name else None
        res = self._lookup_tagged_objects(self._get_entity_name(entity_name), filters)

        output_values: list[list[Any]] = []
        iceberg_config_cache: dict[str, StorageConfig] = {}
        for r in res:
            row = fv_maps[SqlIdentifier(r["entityName"], case_sensitive=True)]
            self._extract_feature_view_info(row, output_values, iceberg_config_cache)

        return self._session.create_dataframe(output_values, schema=_LIST_FEATURE_VIEW_SCHEMA)

    def _extract_feature_view_info(
        self,
        row: Row,
        output_values: list[list[Any]],
        iceberg_config_cache: dict[str, StorageConfig],
    ) -> None:
        """Extract feature view information from a backend row.

        Args:
            row: Row from SHOW DYNAMIC TABLES or SHOW VIEWS.
            output_values: List to append extracted values to.
            iceberg_config_cache: Mutable dictionary mapping table names to StorageConfig.
                Populated lazily on first Iceberg FV encountered. Caller should pass the same
                dictionary instance across calls to avoid repeated SHOW ICEBERG TABLES queries.
        """
        name, version = row["name"].split(_FEATURE_VIEW_NAME_DELIMITER)
        fv_metadata, _ = self._lookup_feature_view_metadata(row, FeatureView._get_physical_name(name, version))

        values: list[Any] = []
        values.append(name)
        values.append(version)
        values.append(row["database_name"])
        values.append(row["schema_name"])
        values.append(row["created_on"])
        values.append(row["owner"])
        values.append(row["comment"])
        values.append(fv_metadata.entities)
        # CRON-based FVs use TARGET_LAG='DOWNSTREAM' on the DT and store the actual
        # cron expression on a companion Task. Recover it so list_feature_views()
        # surfaces the same value the user originally passed in (matching the
        # round-trip behavior of get_feature_view / register_feature_view).
        target_lag = row["target_lag"] if "target_lag" in row else None
        if target_lag == "DOWNSTREAM":
            target_lag = self._resolve_task_schedule(FeatureView._get_physical_name(name, version), target_lag)
        values.append(target_lag)
        values.append(row["refresh_mode"] if "refresh_mode" in row else None)
        values.append(row["scheduling_state"] if "scheduling_state" in row else None)
        values.append(row["warehouse"] if "warehouse" in row else None)
        values.append(json.dumps(self._extract_cluster_by_columns(row["cluster_by"])) if "cluster_by" in row else None)

        online_config_json = self._determine_online_config_from_oft(name, version, include_online_service_metadata=True)
        values.append(online_config_json)

        # Use fv_metadata.is_iceberg to skip iceberg lookup for non-Iceberg FVs
        if fv_metadata.is_iceberg:
            fv_name = FeatureView._get_physical_name(name, version)
            # Fetch iceberg configs lazily on first Iceberg FV encountered
            if not iceberg_config_cache:
                iceberg_config_cache.update(self._get_all_iceberg_storage_configs())
            storage_config = iceberg_config_cache.get(fv_name.resolved())

            if storage_config:
                storage_config_json = storage_config.to_json()
            else:
                # FV is marked as Iceberg but we couldn't retrieve its config - log warning
                logger.warning(
                    f"Feature view {name}/{version} is marked as Iceberg but SHOW ICEBERG TABLES "
                    "returned no results. Storage config details may be incomplete."
                )
                storage_config_json = _DEFAULT_ICEBERG_STORAGE_CONFIG_JSON
        else:
            storage_config_json = _DEFAULT_STORAGE_CONFIG_JSON
        values.append(storage_config_json)

        # Stream config from metadata table (only for streaming FVs).
        # Schema: {"stream_source": str, "transformation_fn": str,
        #          "backfill_start_time"?: str, "backfill_query_id"?: str}
        if fv_metadata.is_streaming:
            streaming_meta = self._metadata_manager.get_streaming_metadata(name, version)
            if streaming_meta:
                stream_config_data: dict[str, Any] = {
                    "stream_source": streaming_meta.stream_source_name,
                    "transformation_fn": streaming_meta.transformation_fn_name,
                }
                if streaming_meta.backfill_start_time is not None:
                    stream_config_data["backfill_start_time"] = streaming_meta.backfill_start_time
                if streaming_meta.backfill_query_id is not None:
                    stream_config_data["backfill_query_id"] = streaming_meta.backfill_query_id
                stream_config_json = json.dumps(stream_config_data)
            else:
                stream_config_json = json.dumps({"stream_source": "unknown"})
        else:
            stream_config_json = None
        values.append(stream_config_json)

        output_values.append(values)

    def _determine_online_config_from_oft(
        self, name: str, version: str, *, include_online_service_metadata: bool = False
    ) -> str:
        """Determine online configuration by checking for corresponding online feature table.

        When an online feature table exists, ``store_type`` is taken from the
        ``SHOW ONLINE FEATURE TABLES`` row when that column is present; otherwise
        ``OnlineStoreType.HYBRID_TABLE`` is used (same as older clients without the column).

        Args:
            name: Feature view name
            version: Feature view version
            include_online_service_metadata: If True, includes additional Online Service metadata
                (refresh_mode, scheduling_state) in the JSON for display purposes.
                If False, returns only OnlineConfig-compatible JSON.

        Returns:
            JSON string of OnlineConfig with enable=True, table's target_lag, and store_type
            (from SHOW when available) if online table exists,
            otherwise default config with enable=False. When include_online_service_metadata=True,
            may include additional fields not part of OnlineConfig.

        Raises:
            SnowflakeMLException: If multiple online feature tables found for the given name/version,
                or if the online feature table is missing required 'target_lag' column.
        """
        online_table_name = FeatureView._get_online_table_name(name, version)

        online_tables = self._find_object(object_type="ONLINE FEATURE TABLES", object_name=online_table_name)

        if online_tables:
            if len(online_tables) != 1:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWML_ERROR,
                    original_exception=RuntimeError(
                        f"Expected exactly 1 online feature table for {online_table_name}, "
                        f"but found {len(online_tables)}"
                    ),
                )

            oft_row = online_tables[0]

            def extract_field(row: Row, field_name: str) -> str:
                if field_name in row:
                    return str(row[field_name])
                elif field_name.upper() in row:
                    return str(row[field_name.upper()])
                else:
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.INTERNAL_SNOWML_ERROR,
                        original_exception=RuntimeError(
                            f"Online feature table {online_table_name} missing required '{field_name}' column"
                        ),
                    )

            # Extract required fields using consistent pattern
            target_lag = extract_field(oft_row, "target_lag")

            online_config = fv_mod.OnlineConfig(
                enable=True,
                target_lag=target_lag,
                store_type=_store_type_from_oft_show_row(oft_row),
            )

            if include_online_service_metadata:
                display_data = json.loads(online_config.to_json())

                display_data["refresh_mode"] = extract_field(oft_row, "refresh_mode")
                display_data["scheduling_state"] = extract_field(oft_row, "scheduling_state")

                return json.dumps(display_data)
            else:
                return online_config.to_json()
        else:
            # No online feature table found - return default disabled config
            online_config = fv_mod.OnlineConfig(enable=False, target_lag=fv_mod._DEFAULT_TARGET_LAG)
            return online_config.to_json()

    def _lookup_feature_view_metadata(self, row: Row, fv_name: str) -> tuple[_FeatureViewMetadata, str]:
        if len(row["text"]) == 0:
            # NOTE: if this is a shared feature view, then text column will be empty due to privacy constraints.
            # So instead of looking at original query text, we will obtain metadata by querying the tag value.
            # For query body, we will just use a simple select instead of original DDL query since shared feature views
            # are read-only.
            try:
                res = self._lookup_tags(
                    domain="table", obj_name=fv_name, filter_fns=[lambda d: d["tagName"] == _FEATURE_VIEW_METADATA_TAG]
                )
                fv_metadata = _FeatureViewMetadata.from_json(res[0]["tagValue"])
                query = f"SELECT * FROM {self._get_fully_qualified_name(fv_name)}"
                return (fv_metadata, query)
            except Exception as e:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWML_ERROR,
                    original_exception=RuntimeError(f"Failed to extract feature_view metadata for {fv_name}: {e}."),
                )
        else:
            # Parse the CREATE statement text to extract FeatureView metadata.
            # This regex expects FeatureStore-specific clauses (COMMENT, TAG with _FEATURE_VIEW_METADATA_TAG).
            # If a raw DYNAMIC TABLE/VIEW exists without these clauses (i.e., not created by FeatureStore),
            # the regex won't match and we'll raise an error. This is intentional - we can only
            # reconstruct FeatureViews that were created by FeatureStore with proper metadata tags.
            m = re.match(_DT_OR_VIEW_QUERY_PATTERN, row["text"])
            if m is None:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWML_ERROR,
                    original_exception=RuntimeError(f"Failed to parse query text for FeatureView {fv_name}: {row}."),
                )
            fv_metadata = _FeatureViewMetadata.from_json(m.group("fv_metadata"))
            query = m.group("query")

            return (fv_metadata, query)

    def _compose_feature_view(self, row: Row, obj_type: _FeatureStoreObjTypes, entity_list: list[Row]) -> FeatureView:
        def find_and_compose_entity(name: str) -> Entity:
            name = SqlIdentifier(name).resolved()
            for e in entity_list:
                if e["NAME"] == name:
                    return Entity(
                        name=SqlIdentifier(e["NAME"], case_sensitive=True).identifier(),
                        join_keys=[f'"{k}"' for k in json.loads(e["JOIN_KEYS"])],
                        desc=e["DESC"],
                    )
            raise RuntimeError(f"Cannot find entity {name} from retrieved entity list: {entity_list}")

        name, version = row["name"].split(_FEATURE_VIEW_NAME_DELIMITER)
        name = SqlIdentifier(name, case_sensitive=True)
        fv_name = FeatureView._get_physical_name(name, version)
        fv_metadata, query = self._lookup_feature_view_metadata(row, fv_name)

        infer_schema_df = self._session.sql(f"SELECT * FROM {self._get_fully_qualified_name(fv_name)}")
        desc = row["comment"]

        online_config_json = self._determine_online_config_from_oft(name.identifier(), version)
        online_config = fv_mod.OnlineConfig.from_json(online_config_json)

        # Get storage_config from SHOW ICEBERG TABLES if marked as Iceberg in metadata
        storage_config: Optional[StorageConfig] = None
        if fv_metadata.is_iceberg:
            storage_config = self._get_iceberg_storage_config(fv_name)
            if storage_config is None:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INTERNAL_SNOWML_ERROR,
                    original_exception=RuntimeError(
                        f"Failed to retrieve Iceberg storage config for {fv_name.resolved()}. "
                        "The feature view is marked as Iceberg but SHOW ICEBERG TABLES returned no results."
                    ),
                )

        # Load feature metadata if present (for tiled feature views)
        agg_metadata = self._metadata_manager.get_feature_specs(name.identifier(), version)
        feature_granularity = agg_metadata.feature_granularity if agg_metadata else None
        aggregation_specs = agg_metadata.features if agg_metadata else None
        is_tiled = agg_metadata is not None

        if obj_type == _FeatureStoreObjTypes.MANAGED_FEATURE_VIEW:
            df = self._session.sql(query)
            entities = [find_and_compose_entity(n) for n in fv_metadata.entities]
            ts_col = fv_metadata.timestamp_col
            timestamp_col = ts_col if ts_col not in _LEGACY_TIMESTAMP_COL_PLACEHOLDER_VALS else None
            re_initialize = re.match(_DT_INITIALIZE_PATTERN, row["text"])
            initialize = re_initialize.group("initialize") if re_initialize is not None else "ON_CREATE"

            # For tiled FVs, get descriptions from metadata table; otherwise from DT columns
            if is_tiled:
                feature_descs = self._metadata_manager.get_feature_descs(name.identifier(), version) or {}
            else:
                feature_descs = self._fetch_column_descs("DYNAMIC TABLE", fv_name)

            # CRON-based FVs use TARGET_LAG='DOWNSTREAM' on the DT and store the
            # actual cron expression on a companion Task. Recover it so the
            # round-trip (register → get → update) preserves what the user passed.
            refresh_freq = row["target_lag"]
            if refresh_freq == "DOWNSTREAM":
                refresh_freq = self._resolve_task_schedule(fv_name, refresh_freq)

            fv = FeatureView._construct_feature_view(
                name=name,
                entities=entities,
                feature_df=df,
                timestamp_col=timestamp_col,
                desc=desc,
                version=version,
                status=(
                    FeatureViewStatus(row["scheduling_state"])
                    if len(row["scheduling_state"]) > 0
                    else FeatureViewStatus.MASKED
                ),
                feature_descs=feature_descs,
                refresh_freq=refresh_freq,
                database=self._config.database.identifier(),
                schema=self._config.schema.identifier(),
                warehouse=(
                    SqlIdentifier(row["warehouse"], case_sensitive=True).identifier()
                    if len(row["warehouse"]) > 0
                    else None
                ),
                refresh_mode=row["refresh_mode"],
                refresh_mode_reason=row["refresh_mode_reason"],
                initialize=initialize,
                owner=row["owner"],
                infer_schema_df=infer_schema_df,
                session=self._session,
                cluster_by=self._extract_cluster_by_columns(row["cluster_by"]),
                online_config=online_config,
                storage_config=storage_config,
                feature_granularity=feature_granularity,
                aggregation_specs=aggregation_specs,
                is_streaming=fv_metadata.is_streaming,
            )
            self._hydrate_postgres_online_service(fv)

            if agg_metadata and agg_metadata.feature_aggregation_method:
                fv._feature_aggregation_method = FeatureAggregationMethod(agg_metadata.feature_aggregation_method)
            elif is_tiled:
                fv._feature_aggregation_method = FeatureAggregationMethod.TILES

            # For streaming FVs, attach the function source from metadata
            if fv_metadata.is_streaming:
                streaming_meta = self._metadata_manager.get_streaming_metadata(name.identifier(), version)
                if streaming_meta and streaming_meta.transformation_fn_source:
                    fv._transformation_fn_source = streaming_meta.transformation_fn_source

            # Load rollup metadata if this is a rollup FV
            if fv_metadata.is_rollup:
                from snowflake.ml.feature_store.feature_view import RollupMetadata

                rollup_data = self._metadata_manager.get_rollup_metadata(name.identifier(), version)
                if rollup_data is not None:
                    fv._rollup_metadata = RollupMetadata.from_dict(rollup_data)

            return fv
        else:
            df = self._session.sql(query)
            entities = [find_and_compose_entity(n) for n in fv_metadata.entities]
            ts_col = fv_metadata.timestamp_col
            timestamp_col = ts_col if ts_col not in _LEGACY_TIMESTAMP_COL_PLACEHOLDER_VALS else None

            fv = FeatureView._construct_feature_view(
                name=name,
                entities=entities,
                feature_df=df,
                timestamp_col=timestamp_col,
                desc=desc,
                version=version,
                status=FeatureViewStatus.STATIC,
                feature_descs=self._fetch_column_descs("VIEW", fv_name),
                refresh_freq=None,
                database=self._config.database.identifier(),
                schema=self._config.schema.identifier(),
                warehouse=None,
                refresh_mode=None,
                refresh_mode_reason=None,
                initialize="ON_CREATE",
                owner=row["owner"],
                infer_schema_df=infer_schema_df,
                session=self._session,
                online_config=online_config,
                feature_granularity=feature_granularity,
                aggregation_specs=aggregation_specs,
                storage_config=storage_config,
                is_streaming=fv_metadata.is_streaming,
            )
            self._hydrate_postgres_online_service(fv)
            return fv

    def _hydrate_postgres_online_service(self, fv: FeatureView) -> None:
        """Set ``_postgres_online_query_url`` and warn when Postgres online reads are not ready."""
        if not fv.online or fv.online_config is None or fv.online_config.store_type != OnlineStoreType.POSTGRES:
            return
        try:
            st = online_service.fetch_online_service_status(
                self._session,
                self._config.database,
                self._config.schema,
                statement_params=self._telemetry_stmp,
            )
        except Exception as ex:
            logger.warning("Could not fetch Online Service status during get_feature_view: %s", ex)
            fv._postgres_online_query_url = None
            warnings.warn(
                online_service.online_service_not_ready_message(),
                category=UserWarning,
                stacklevel=3,
            )
            return
        query_url = online_service.endpoint_url(st, "query")
        if st.status == "RUNNING" and query_url:
            # Temporary: SYSTEM$ may return host-only query URLs until server sends full https URLs.
            fv._postgres_online_query_url = query_url
            return
        fv._postgres_online_query_url = None
        warnings.warn(
            online_service.online_service_not_ready_message(),
            category=UserWarning,
            stacklevel=3,
        )

    def _fetch_column_descs(self, obj_type: str, obj_name: SqlIdentifier) -> dict[str, str]:
        res = self._session.sql(f"DESC {obj_type} {self._get_fully_qualified_name(obj_name)}").collect(
            statement_params=self._telemetry_stmp
        )

        descs = {}
        for r in res:
            if r["comment"] is not None:
                descs[SqlIdentifier(r["name"], case_sensitive=True).identifier()] = r["comment"]
        return descs

    @telemetry.send_api_usage_telemetry(project=_PROJECT)
    def _create_online_feature_table(
        self,
        feature_view: FeatureView,
        feature_view_name: SqlIdentifier,
        version: str,
        overwrite: bool = False,
    ) -> str:
        """Create online feature table for the feature view.

        For ``HYBRID_TABLE`` store type, creates the OFT via ``CREATE ... FROM <source_table>``.
        For ``POSTGRES`` store type, builds a :class:`~snowflake.ml.feature_store.spec.models.FeatureViewSpec`
        and creates the OFT via ``CREATE ... FROM SPECIFICATION $$<json>$$``.

        Args:
            feature_view: The FeatureView object for which to create the online feature table.
            feature_view_name: The physical name of the feature view (DT/View).
            version: The version string for the feature view.
            overwrite: Whether to overwrite existing online feature table. Defaults to False.

        Returns:
            The name of the created online table (without schema qualification).

        Raises:
            SnowflakeMLException: [ValueError] If OnlineConfig is required but not provided.
            SnowflakeMLException: If creating the online feature table fails.
        """
        online_table_name = FeatureView._get_online_table_name(feature_view_name)

        fully_qualified_online_name = self._get_fully_qualified_name(online_table_name)
        source_table_name = self._get_fully_qualified_name(feature_view_name)

        # Extract join keys for PRIMARY KEY (preserve order and ensure unique)
        ordered_join_keys: list[str] = []
        seen_join_keys: set[str] = set()
        for entity in feature_view.entities:
            for join_key in entity.join_keys:
                resolved_key = join_key.resolved()
                if resolved_key not in seen_join_keys:
                    seen_join_keys.add(resolved_key)
                    ordered_join_keys.append(resolved_key)
        quoted_join_keys = [f'"{key}"' for key in ordered_join_keys]
        primary_key_clause = f"PRIMARY KEY ({', '.join(quoted_join_keys)})"

        # Build online config clauses
        config = feature_view.online_config
        if not config:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError("OnlineConfig is required to create online feature table"),
            )
        target_lag_value = config.target_lag if config.target_lag is not None else fv_mod._DEFAULT_TARGET_LAG
        # StreamingFeatureView OFTs require TARGET_LAG='0 seconds' for real-time serving
        if feature_view.is_streaming:
            target_lag_value = "0 seconds"
        target_lag_clause = f"TARGET_LAG='{target_lag_value}'"

        warehouse_clause = ""
        if feature_view.warehouse:
            warehouse_clause = f"WAREHOUSE={feature_view.warehouse}"
        elif self._default_warehouse:
            warehouse_clause = f"WAREHOUSE={self._default_warehouse}"

        refresh_mode_clause = ""
        if feature_view.refresh_mode:
            refresh_mode_clause = f"REFRESH_MODE='{feature_view.refresh_mode}'"

        timestamp_clause = ""
        if feature_view.timestamp_col:
            timestamp_clause = f"TIMESTAMP_COLUMN='{feature_view.timestamp_col}'"

        # Determine source clause based on online store type
        store_type = config.store_type
        if store_type == OnlineStoreType.POSTGRES:
            online_service.assert_online_service_running_with_query_endpoint(
                self._session,
                self._config.database,
                self._config.schema,
                statement_params=self._telemetry_stmp,
            )
            # Validate offline columns for the OFT spec. Tiled FVs: introspect the materialized DT
            # so offline_configs match the table; reject ARRAY/BINARY/etc. per spec rules.
            pg_offline_dt_schema: Optional[StructType] = None
            try:
                if feature_view.is_tiled:
                    pg_offline_dt_schema = self._session.table(source_table_name).schema
                    validate_spec_oft_offline_table_schema(pg_offline_dt_schema)
                else:
                    validate_spec_oft_offline_table_schema(feature_view.output_schema)
            except ValueError as e:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        f"Feature view '{feature_view.name}' contains column types not supported by "
                        f"online store. {e} "
                        f"Consider casting unsupported columns to a supported type before creating the feature view."
                    ),
                ) from e

            if feature_view.is_streaming:
                from snowflake.ml.feature_store.streaming_registration import (
                    _build_streaming_feature_view_spec,
                )

                assert feature_view.stream_config is not None  # guaranteed by is_streaming
                stream_source = self.get_stream_source(feature_view.stream_config.get_stream_source_name())

                udf_table_name = FeatureView._get_udf_transformed_table_name(feature_view_name)
                fq_udf_table = self._get_fully_qualified_name(udf_table_name)
                if feature_view.is_tiled:
                    udf_transformed_schema = self._session.table(fq_udf_table).schema
                else:
                    udf_transformed_schema = feature_view.output_schema

                spec = _build_streaming_feature_view_spec(
                    feature_view=feature_view,
                    feature_view_name=feature_view_name,
                    version=version,
                    target_lag=target_lag_value,
                    stream_source=stream_source,
                    udf_transformed_schema=udf_transformed_schema,
                    tiled_materialized_schema=pg_offline_dt_schema,
                    database=self._config.database.resolved(),
                    schema=self._config.schema.resolved(),
                )
            else:
                spec = self._build_batch_feature_view_spec(
                    feature_view=feature_view,
                    feature_view_name=feature_view_name,
                    version=version,
                    target_lag=target_lag_value,
                    offline_materialized_schema=pg_offline_dt_schema,
                )
            spec_json = spec.to_json()
            source_clause = f"FROM SPECIFICATION $${spec_json}$$"
        else:
            source_clause = f"FROM {source_table_name}"

        # Create online feature table
        try:
            overwrite_clause = "OR REPLACE " if overwrite else ""

            query_parts = [
                f"CREATE {overwrite_clause}ONLINE FEATURE TABLE {fully_qualified_online_name}",
                primary_key_clause,
                refresh_mode_clause,
                timestamp_clause,
                warehouse_clause,
                target_lag_clause,
                source_clause,
            ]

            query = " ".join(part for part in query_parts if part)
            self._session.sql(query).collect(statement_params=self._telemetry_stmp)

            oft_obj_info = _FeatureStoreObjInfo(_FeatureStoreObjTypes.ONLINE_FEATURE_TABLE, snowml_version.VERSION)
            tag_clause = f"""
                ALTER ONLINE FEATURE TABLE {fully_qualified_online_name} SET TAG
                {self._get_fully_qualified_name(_FEATURE_STORE_OBJECT_TAG)} = '{oft_obj_info.to_json()}'
            """

            self._session.sql(tag_clause).collect(statement_params=self._telemetry_stmp)
        except Exception as e:
            logger.error(f"Failed to create online feature table for {feature_view.name}: {e}")
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(
                    f"Create online feature table {fully_qualified_online_name} failed: {e}"
                ),
            ) from e

        return online_table_name

    def _build_batch_feature_view_spec(
        self,
        feature_view: FeatureView,
        feature_view_name: SqlIdentifier,
        version: str,
        target_lag: str,
        *,
        offline_materialized_schema: Optional[StructType] = None,
    ) -> FeatureViewSpec:
        """Build a validated FeatureView spec for a batch feature view.

        Constructs a :class:`FeatureViewSpec` from the FeatureView metadata and
        the physical DT/View name.

        Args:
            feature_view: The FeatureView definition.
            feature_view_name: Physical name of the DT/View (already created).
            version: Feature view version string.
            target_lag: Resolved target lag string (e.g., ``"30s"``).
            offline_materialized_schema: For tiled batch FVs, Snowpark schema of the materialized
                dynamic table (from ``Session.table(fq_dt).schema``). Required when
                ``feature_view.is_tiled``; must be ``None`` for non-tiled batch.

        Returns:
            FeatureViewSpec instance ready for serialization.

        Raises:
            ValueError: If tiled batch is missing *offline_materialized_schema*, or non-tiled batch
                passes a non-``None`` *offline_materialized_schema*.
        """
        database = self._config.database.resolved()
        schema = self._config.schema.resolved()

        # Entity join key column names (deduplicated, preserving order)
        entity_columns: list[str] = []
        seen_entity_cols: set[str] = set()
        for entity in feature_view.entities:
            for jk in entity.join_keys:
                resolved = jk.resolved()
                if resolved not in seen_entity_cols:
                    seen_entity_cols.add(resolved)
                    entity_columns.append(resolved)

        if feature_view.is_tiled:
            if offline_materialized_schema is None:
                raise ValueError(
                    "Tiled batch feature view spec requires offline_materialized_schema "
                    "(Snowflake DT schema from Session.table(...).schema)."
                )
            offline_columns = offline_materialized_schema
        else:
            if offline_materialized_schema is not None:
                raise ValueError("Non-tiled batch feature view spec must not set offline_materialized_schema.")
            offline_columns = feature_view.output_schema
        # Batch FVs always register the materialized table as BatchSource; Tiled/UDFTransformed are streaming-only.
        offline_table_type = TableType.BATCH_SOURCE

        # Offline config: the DT/View that was just created
        offline_table_info = SnowflakeTableInfo(
            table_type=offline_table_type,
            database=database,
            schema=schema,
            table=feature_view_name.resolved(),
            columns=offline_columns,
        )

        builder = (
            FeatureViewSpecBuilder(
                FeatureViewKind.BatchFeatureView,
                database=database,
                schema=schema,
                name=feature_view.name.resolved(),
                version=version,
            )
            .set_offline_configs([offline_table_info])
            .set_properties(
                entity_columns=entity_columns,
                timestamp_field=(feature_view.timestamp_col.resolved() if feature_view.timestamp_col else None),
                granularity=feature_view.feature_granularity if feature_view.is_tiled else None,
                agg_method=FeatureAggregationMethod.TILES if feature_view.is_tiled else None,
                target_lag=target_lag,
            )
        )

        # For tiled batch FVs, set the raw source schema and aggregation specs.
        # Rollup FVs inherit agg specs from the parent; the raw source columns
        # that those specs reference live in the parent's feature_df.
        if feature_view.is_tiled and feature_view.aggregation_specs:
            if feature_view.is_rollup:
                assert feature_view.rollup_config is not None
                source_df = feature_view.rollup_config.source.feature_df
            else:
                source_df = feature_view.feature_df
            assert source_df is not None
            builder.set_sources([BatchSource(schema=source_df.schema)])
            builder.set_features(feature_view.aggregation_specs)

        return builder.build()

    def _find_object(
        self,
        object_type: str,
        object_name: Optional[SqlIdentifier],
        prefix_match: bool = False,
    ) -> list[Row]:
        """Try to find an object by given type and name pattern.

        Args:
            object_type: Type of the object. Could be TABLES, TAGS etc.
            object_name: Name of object. It will match everything of object_type is object_name is None.
            prefix_match: Will search all objects with object_name as prefix if set True. Otherwise
                will do exact on object_name. Default to false. If object_name is empty and prefix_match is
                True, then it will match everything of object_type.

        Raises:
            SnowflakeMLException: [RuntimeError] Failed to find resource.

        Returns:
            Return a list of rows round.
        """
        if object_name is None:
            match_name = "%"
        elif prefix_match:
            match_name = object_name.resolved() + "%"
        else:
            match_name = object_name.resolved()

        search_space, obj_domain = self._obj_search_spaces[object_type]
        all_rows = []
        fs_tag_objects = []
        tag_free_object_types = ["TAGS", "SCHEMAS", "WAREHOUSES", "DATASETS"]
        try:
            search_scope = f"IN {search_space}" if search_space is not None else ""
            all_rows = self._session.sql(f"SHOW {object_type} LIKE '{match_name}' {search_scope}").collect(
                statement_params=self._telemetry_stmp
            )
            # There could be non-FS objects under FS schema, thus filter on objects with FS special tag.
            if object_type not in tag_free_object_types and len(all_rows) > 0:
                fs_obj_rows = self._lookup_tagged_objects(
                    _FEATURE_STORE_OBJECT_TAG, [lambda d: d["domain"] == obj_domain]
                )
                fs_tag_objects = [row["entityName"] for row in fs_obj_rows]
        except Exception as e:
            # ONLINE FEATURE TABLE preview feature may raise SQL error if not enabled
            # Return empty list for discovery flows in this case
            if (
                object_type == "ONLINE FEATURE TABLES"
                and isinstance(e, SnowparkSQLException)
                and ("unexpected 'online'" in str(e).lower())
            ):
                return []
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to find object : {e}"),
            ) from e

        result = []
        for row in all_rows:
            found_name = row["name"]
            prefix = object_name.resolved() if object_name is not None else ""
            if found_name.startswith(prefix) and (object_type in tag_free_object_types or found_name in fs_tag_objects):
                result.append(row)
        return result

    def _load_serialized_feature_views(
        self, serialized_feature_views: list[str]
    ) -> list[Union[FeatureView, FeatureViewSlice]]:
        results: list[Union[FeatureView, FeatureViewSlice]] = []
        for obj in serialized_feature_views:
            try:
                obj_type = json.loads(obj)[_FEATURE_OBJ_TYPE]
            except Exception as e:
                raise ValueError(f"Malformed serialized feature object: {obj}") from e

            if obj_type == FeatureView.__name__:
                results.append(FeatureView.from_json(obj, self._session))
            elif obj_type == FeatureViewSlice.__name__:
                results.append(FeatureViewSlice.from_json(obj, self._session))
            else:
                raise ValueError(f"Unsupported feature object type: {obj_type}")
        return results

    def _load_compact_feature_views(
        self, compact_feature_views: list[str]
    ) -> list[Union[FeatureView, FeatureViewSlice]]:
        results: list[Union[FeatureView, FeatureViewSlice]] = []
        for obj in compact_feature_views:
            results.append(FeatureView._load_from_compact_repr(self._session, obj))
        return results

    def _exclude_columns(self, df: DataFrame, exclude_columns: list[str]) -> DataFrame:
        exclude_columns = to_sql_identifiers(exclude_columns)  # type: ignore[assignment]
        df_cols = to_sql_identifiers(df.columns)
        for col in exclude_columns:
            if col not in df_cols:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        f"{col} in exclude_columns not exists in dataframe columns: {df_cols}"
                    ),
                )
        return cast(DataFrame, df.drop(exclude_columns))  # type: ignore[redundant-cast]

    def _is_dataset_enabled(self) -> bool:
        try:
            self._session.sql(f"SHOW DATASETS IN SCHEMA {self._config.full_schema_path}").collect(
                statement_params=self._telemetry_stmp
            )
            return True
        except SnowparkSQLException:
            return False

    def _check_feature_store_object_versions(self) -> None:
        versions = self._collapse_object_versions()
        if len(versions) > 0 and pkg_version.parse(snowml_version.VERSION) < versions[0]:
            warnings.warn(
                "The current snowflake-ml-python version out of date, package upgrade recommended "
                + f"(current={snowml_version.VERSION}, recommended>={str(versions[0])})",
                stacklevel=2,
                category=UserWarning,
            )

    def _filter_results(
        self, results: list[dict[str, str]], filter_fns: Optional[list[Callable[[dict[str, str]], bool]]] = None
    ) -> list[dict[str, str]]:
        if filter_fns is None:
            return results

        filtered_results = []
        for r in results:
            if all([fn(r) for fn in filter_fns]):
                filtered_results.append(r)
        return filtered_results

    def _lookup_tags(
        self, domain: str, obj_name: str, filter_fns: Optional[list[Callable[[dict[str, str]], bool]]] = None
    ) -> list[dict[str, str]]:
        """
        Lookup tag values for a given object, optionally apply filters on the results.

        Args:
            domain: Domain of the obj to look for tag. E.g. table
            obj_name: Name of the obj.
            filter_fns: List of filter functions applied on the results.

        Returns:
            List of tag values in dictionary format.

        Raises:
            SnowflakeMLException: [RuntimeError] Failed to lookup tags.

        Example::

            self._lookup_tags("TABLE", "MY_FV", [lambda d: d["tagName"] == "TARGET_TAG_NAME"])

        """
        # NOTE: use ENTITY_DETAIL system fn to query tags for given object for it to work in
        # processes using owner's right. e.g. Streamlit, or stored procedure
        try:
            res = self._session.sql(
                f"""
                SELECT ENTITY_DETAIL('{domain}','{self._get_fully_qualified_name(obj_name)}', '["TAG_REFERENCES"]');
            """
            ).collect(statement_params=self._telemetry_stmp)
            entity_detail = json.loads(res[0][0])
            results = entity_detail["tagReferencesInfo"]["tagReferenceList"]
            return self._filter_results(results, filter_fns)
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to lookup tags for object for {obj_name}: {e}"),
            ) from e

    def _lookup_tagged_objects(
        self, tag_name: str, filter_fns: Optional[list[Callable[[dict[str, str]], bool]]] = None
    ) -> list[dict[str, str]]:
        """
        Lookup objects based on specified tag name, optionally apply filters on the results.

        Args:
            tag_name: Name of the tag.
            filter_fns: List of filter functions applied on the results.

        Returns:
            List of objects in dictionary format.

        Raises:
            SnowflakeMLException: [RuntimeError] Failed to lookup tagged objects.

        Example::

            self._lookup_tagged_objects("TARGET_TAG_NAME", [lambda d: d["entityName"] == "MY_FV"])

        """
        # NOTE: use ENTITY_DETAIL system fn to query objects from tag for it to work in
        # processes using owner's right. e.g. Streamlit, or stored procedure
        try:
            res = self._session.sql(
                f"""
                SELECT ENTITY_DETAIL('TAG','{self._get_fully_qualified_name(tag_name)}', '["TAG_REFERENCES_INTERNAL"]');
            """
            ).collect(statement_params=self._telemetry_stmp)
            entity_detail = json.loads(res[0][0])
            results = entity_detail["referencedEntities"]["tagReferenceList"]
            return self._filter_results(results, filter_fns)
        except Exception as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INTERNAL_SNOWPARK_ERROR,
                original_exception=RuntimeError(f"Failed to lookup tagged objects for {tag_name}: {e}"),
            ) from e

    def _collapse_object_versions(self) -> list[pkg_version.Version]:
        try:
            res = self._lookup_tagged_objects(_FEATURE_STORE_OBJECT_TAG)
        except Exception:
            # since this is a best effort user warning to upgrade pkg versions
            # we are treating failures as benign error
            return []
        versions = set()
        compatibility_breakage_detected = False
        for r in res:
            info = _FeatureStoreObjInfo.from_json(r["tagValue"])
            if info.type == _FeatureStoreObjTypes.UNKNOWN:
                compatibility_breakage_detected = True
            versions.add(pkg_version.parse(info.pkg_version))

        sorted_versions = sorted(versions, reverse=True)
        if compatibility_breakage_detected:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.SNOWML_PACKAGE_OUTDATED,
                original_exception=RuntimeError(
                    f"The current snowflake-ml-python version {snowml_version.VERSION} is out of date, "
                    + f"please upgrade to at least {sorted_versions[0]}."
                ),
            )
        return sorted_versions

    def _validate_feature_view_name_and_version_input(
        self, feature_view: Union[FeatureView, str], version: Optional[str] = None
    ) -> FeatureView:
        if isinstance(feature_view, str):
            if version is None:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError("Version must be provided when argument feature_view is a str."),
                )
            feature_view = self.get_feature_view(feature_view, version)
        elif not isinstance(feature_view, FeatureView):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    "Invalid type of argument feature_view. It must be either str or FeatureView type."
                ),
            )

        return feature_view

    @staticmethod
    def _extract_cluster_by_columns(cluster_by_clause: str) -> list[str]:
        # Use regex to extract elements inside the parentheses.
        match = re.search(r"\((.*?)\)", cluster_by_clause)
        if match:
            # Handle both quoted and unquoted column names.
            return re.findall(identifier.SF_IDENTIFIER_RE, match.group(1))
        return []

    def _build_select_clause_and_validate(
        self, feature_view: FeatureView, feature_names: Optional[list[str]], include_join_keys: bool = True
    ) -> str:
        """Build SELECT clause for feature view queries and validate feature names.

        Args:
            feature_view: The feature view to build the clause for
            feature_names: Optional list of feature names to include
            include_join_keys: Whether to include join keys in the select clause

        Returns:
            SELECT clause string

        Raises:
            SnowflakeMLException: If requested feature names don't exist
        """
        if feature_names:
            # Validate feature names exist
            available_features = [f.name for f in feature_view.output_schema.fields]
            for feature_name in feature_names:
                if feature_name not in available_features:
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.INVALID_ARGUMENT,
                        original_exception=ValueError(
                            f"Feature '{feature_name}' not found in feature view. "
                            f"Available features: {available_features}"
                        ),
                    )

            # Build select clause with join keys and requested features
            select_columns = []
            if include_join_keys:
                all_join_keys = []
                for entity in feature_view.entities:
                    all_join_keys.extend([key.resolved() for key in entity.join_keys])
                select_columns.extend([f'"{key}"' for key in all_join_keys])

            select_columns.extend([f'"{name}"' for name in feature_names])
            return ", ".join(select_columns)
        else:
            # Select all columns
            return "*"

    def _build_where_clause_for_keys(
        self, feature_view: FeatureView, keys: Optional[list[list[Any]]], use_binds: bool = False
    ) -> tuple[str, list[Any]]:
        """Build WHERE clause for key filtering.

        Args:
            feature_view: The feature view to build the clause for.
            keys: Optional list of key value lists to filter by.
            use_binds: If True, use ``?`` placeholders and return bind params.
                If False, interpolate values as string literals.

        Returns:
            Tuple of (WHERE clause string, bind params list). Params is empty
            when use_binds is False or no keys are provided.

        Raises:
            SnowflakeMLException: If key structure is invalid.
        """
        if not keys:
            return "", []

        all_join_keys = []
        for entity in feature_view.entities:
            all_join_keys.extend([key.resolved() for key in entity.join_keys])

        for key_values in keys:
            if len(key_values) != len(all_join_keys):
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        f"Each key must have {len(all_join_keys)} values for join keys {all_join_keys}, "
                        f"got {len(key_values)} values"
                    ),
                )

        params: list[Any] = []
        where_conditions = []
        for key_values in keys:
            key_conditions = []
            for join_key, value in zip(all_join_keys, key_values):
                if use_binds:
                    key_conditions.append(f'"{join_key}" = ?')
                    params.append(value)
                else:
                    safe_value = str(value).replace("'", "''")
                    key_conditions.append(f"\"{join_key}\" = '{safe_value}'")
            where_conditions.append(f"({' AND '.join(key_conditions)})")

        return f" WHERE {' OR '.join(where_conditions)}", params


def _get_store_type(store_type: Union[fv_mod.StoreType, str]) -> fv_mod.StoreType:
    """Return a StoreType enum from a Union[StoreType, str].

    Args:
        store_type: Store type enum or string value.

    Returns:
        StoreType enum value.
    """
    if isinstance(store_type, str):
        return fv_mod.StoreType(store_type.lower())
    return store_type
