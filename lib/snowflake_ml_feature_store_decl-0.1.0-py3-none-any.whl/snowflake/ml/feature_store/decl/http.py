"""Stdlib-only HTTP POST helper for Online Service REST endpoints.

No third-party dependencies — uses only urllib from the standard library.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

_MAX_RESPONSE_BYTES = 64 * 1024  # cap reads to prevent unbounded memory use


def post_json(
    url: str,
    pat: str,
    body: dict[str, Any],
    timeout: float = 120.0,
) -> dict[str, Any]:
    """POST JSON with Snowflake PAT bearer auth. Returns parsed response dict.

    Args:
        url: Full endpoint URL to POST to.
        pat: Snowflake Programmatic Access Token for bearer auth.
        body: Request body; will be JSON-serialised.
        timeout: Socket timeout in seconds (default 120).

    Returns:
        Parsed response dict.  On HTTP or network errors returns a dict with
        ``status="error"`` and an ``error`` key rather than raising.
    """
    payload = json.dumps(body).encode("utf-8")
    headers = {
        "Authorization": f'Snowflake Token="{pat}"',
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        try:
            raw = resp.read(_MAX_RESPONSE_BYTES)
            return json.loads(raw.decode("utf-8"))
        finally:
            resp.close()
    except urllib.error.HTTPError as exc:
        body_text = exc.read(_MAX_RESPONSE_BYTES).decode("utf-8", errors="replace")
        return {"status": "error", "http_status": exc.code, "error": body_text}
    except (urllib.error.URLError, OSError) as exc:
        return {
            "status": "error",
            "error": f"Feature store service is unreachable: {exc}",
        }
