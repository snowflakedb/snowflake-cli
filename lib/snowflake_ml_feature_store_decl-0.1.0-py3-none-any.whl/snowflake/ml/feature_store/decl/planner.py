"""Plan generator: diffs desired specs against applied state.

Produces a topologically-sorted list of ``PlanOp`` objects.
No side effects, no connection access.
"""

from __future__ import annotations

from snowflake.ml.feature_store.decl.dependencies import topological_sort
from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.invariants import (
    _compute_local_spec_hash,
    _fg_content_hash,
    _model_to_dict,
    _spec_key,
    _structural_fingerprint_hash,
    batch_feature_view_structural_equivalent,
)
from snowflake.ml.feature_store.decl.types import (
    AppliedState,
    Plan,
    PlanOp,
    PlanOptions,
    SpecBatch,
)

# Map spec kind to the appropriate OpKind for CREATE operations.
_CREATE_OP: dict[str, OpKind] = {
    "Entity": OpKind.CREATE_ENTITY,
    "StreamingSource": OpKind.CREATE_SOURCE,
    "BatchSource": OpKind.CREATE_SOURCE,
    "StreamingFeatureView": OpKind.CREATE_FV,
    "RealtimeFeatureView": OpKind.CREATE_FV,
    "BatchFeatureView": OpKind.CREATE_FV,
    "FeatureGroup": OpKind.CREATE_FG,
}

# Map spec kind to the appropriate OpKind for UPDATE operations.
_UPDATE_OP: dict[str, OpKind] = {
    "Entity": OpKind.UPDATE_ENTITY,
    "StreamingSource": OpKind.UPDATE_SOURCE,
    "BatchSource": OpKind.UPDATE_SOURCE,
    "StreamingFeatureView": OpKind.UPDATE_FV,
    "RealtimeFeatureView": OpKind.UPDATE_FV,
    "BatchFeatureView": OpKind.UPDATE_FV,
    "FeatureGroup": OpKind.CREATE_FG,
}

# Map spec kind to the appropriate OpKind for RECREATE operations.  Entities
# are NOT in this table — Snowflake's ``ALTER TAG`` supports both
# ``SET ALLOWED_VALUES`` and ``SET COMMENT``, so an entity hash mismatch
# becomes a non-destructive ``UPDATE_ENTITY`` rather than a drop+create.
# Falling through to ``RECREATE_FV`` (the default before this change) was
# misleading because it caused an Entity diff to surface as a feature-view
# operation in plan output.
_RECREATE_OP: dict[str, OpKind] = {
    "StreamingFeatureView": OpKind.RECREATE_FV,
    "RealtimeFeatureView": OpKind.RECREATE_FV,
    "BatchFeatureView": OpKind.RECREATE_FV,
}

# Feature view kinds eligible for DROP_FV.
_FV_KINDS: frozenset[str] = frozenset({"StreamingFeatureView", "RealtimeFeatureView", "BatchFeatureView"})

# Feature group kinds eligible for DROP_FG.  Singleton today; declared as a
# frozenset so the orphan-drop pass below can use the same membership-test
# style as ``_FV_KINDS`` and a future variant ``FeatureGroup`` family
# extension does not require structural changes here.
_FG_KINDS: frozenset[str] = frozenset({"FeatureGroup"})


def _batch_fv_operational_drift(
    local_authoring: dict,
    applied_payload: dict,
    database: str,
    schema: str,
) -> bool:
    """Detect refresh / online routing drift not visible after volatile hash stripping.

    Compares two independent operational knobs:

    * ``target_lag_sec`` on the compiled inner spec — the canonical
      surface that ``DESCRIBE … TYPE = SPECIFICATION`` returns.
    * The authoring-side ``batch_schedule`` (parsed to seconds) against
      the applied side's ``target_lag_sec``.  This second comparison is
      required because the BUG_BASH §5 YAML pattern sets BOTH
      ``target_lag`` and ``batch_schedule``; :func:`compile_to_spec`
      prefers ``target_lag`` for the compiled ``target_lag_sec``, so
      editing only ``batch_schedule`` leaves the compiled value
      unchanged even though the deployed Dynamic Table's
      ``refresh_freq`` (set from ``batch_schedule``) really did move.

    Robust to a failing :func:`compile_to_spec` on the local side — when
    compilation raises, the helper still emits ``True`` if the authoring
    dict carries any of ``batch_schedule`` / ``target_lag`` /
    ``target_lag_sec`` / ``online`` that differ from the applied payload.
    Returning ``False`` on a compile failure (the previous behaviour)
    silently collapsed every real operational edit into ``NO_CHANGE``.

    Args:
        local_authoring: The authoring-side spec dict (raw, pre-compile).
        applied_payload: The applied-side spec payload from the deployed
            FV (post-``fetch_applied_state`` normalisation).
        database: Snowflake database used for ``compile_to_spec``.
        schema: Snowflake schema used for ``compile_to_spec``.

    Returns:
        ``True`` when any operational knob (``target_lag_sec``,
        ``batch_schedule`` reduced to seconds, ``online_store_type``)
        differs between the local authoring view and the applied
        payload; ``False`` otherwise.
    """
    from snowflake.ml.feature_store.decl.compiler import parse_duration_to_seconds
    from snowflake.ml.feature_store.decl.spec_compiler import compile_to_spec

    rem_spec = applied_payload.get("spec") if isinstance(applied_payload.get("spec"), dict) else {}
    rem_target_lag_sec = rem_spec.get("target_lag_sec")

    local_schedule = local_authoring.get("batch_schedule")
    if local_schedule:
        try:
            local_schedule_sec = parse_duration_to_seconds(local_schedule)
            if rem_target_lag_sec is not None and rem_target_lag_sec != local_schedule_sec:
                return True
        except Exception:  # noqa: BLE001 — defensive: malformed authoring strings fall through
            pass

    try:
        loc = compile_to_spec(local_authoring, database, schema)
    except Exception:  # noqa: BLE001 — fall back to authoring-dict comparison
        local_online = bool(local_authoring.get("online", False))
        applied_online = (applied_payload.get("online_store_type") or "") != ""
        if local_online != applied_online:
            return True
        local_lag_sec = local_authoring.get("target_lag_sec")
        if local_lag_sec is None and local_authoring.get("target_lag") is not None:
            try:
                local_lag_sec = parse_duration_to_seconds(local_authoring["target_lag"])
            except Exception:  # noqa: BLE001
                local_lag_sec = None
        if local_lag_sec is not None and rem_target_lag_sec is not None and local_lag_sec != rem_target_lag_sec:
            return True
        return False

    loc_spec = loc.get("spec") if isinstance(loc.get("spec"), dict) else {}
    if loc_spec.get("target_lag_sec") != rem_target_lag_sec:
        return True
    if loc.get("online_store_type") != applied_payload.get("online_store_type"):
        return True
    if _warehouse_drifted(local_authoring, applied_payload):
        return True
    return False


def _warehouse_drifted(local_authoring: dict, applied_payload: dict) -> bool:
    """Detect a meaningful ``warehouse`` drift on the authoring side.

    The deployed ``DESCRIBE … TYPE = SPECIFICATION`` payload does not carry
    the refresh warehouse — it lives only on the offline Dynamic Table.
    State recovery may inject the recovered value into
    ``spec_payload.spec.warehouse`` (DT-text parsing), and the planner
    compares the authored value against whatever the applied side carries:

    * Local omits warehouse → no drift, regardless of applied (the
      imperative ``update_feature_view`` cannot clear a deployed
      warehouse, so a missing local value is a no-op by contract).
    * Local sets warehouse + applied has no recovered warehouse → drift
      (operator is explicitly setting it for the first time).
    * Local sets warehouse + applied recovered a different value → drift.
    * Local sets warehouse + applied recovered the same value → no drift.

    Comparison is case-insensitive because Snowflake identifiers are
    case-insensitive unless quoted; the authoring YAML and the recovered
    DT-text identifier almost always differ in case otherwise.

    Args:
        local_authoring: The authoring-side spec dict (raw, pre-compile).
        applied_payload: The applied-side spec payload from the deployed
            FV (post-``fetch_applied_state`` normalisation).

    Returns:
        ``True`` when the operator has authored a ``warehouse`` value that
        differs from the deployed value (or the deployed value is
        unknown / missing); ``False`` otherwise.
    """
    raw_local = local_authoring.get("warehouse")
    if raw_local is None or (isinstance(raw_local, str) and not raw_local.strip()):
        return False
    local_norm = str(raw_local).strip().upper()
    rem_inner = applied_payload.get("spec") if isinstance(applied_payload.get("spec"), dict) else {}
    raw_rem = rem_inner.get("warehouse") if isinstance(rem_inner, dict) else None
    if raw_rem is None:
        raw_rem = applied_payload.get("warehouse")
    if raw_rem is None or (isinstance(raw_rem, str) and not raw_rem.strip()):
        # Authored a value, deployed-side recovery has none — drift.
        return True
    return str(raw_rem).strip().upper() != local_norm


def generate_plan(
    batch: SpecBatch,
    applied_state: AppliedState,
    options: PlanOptions,
    database: str = "",
    schema: str = "",
) -> Plan:
    """Generate a dependency-ordered execution plan.

    Steps:
    1. Topologically sort the batch specs.
    2. For each spec, compare against ``applied_state``:
       - Not in applied state → ``CREATE`` op.
       - Content hash matches → ``NO_CHANGE`` (skip).
       - Hash differs, non-destructive → ``UPDATE`` op.
       - Hash differs, destructive, ``allow_recreate`` → ``RECREATE`` op.
       - Hash differs, destructive, no flag → warning, no op.
    3. If ``full_directory_mode``, scan applied_state for objects not in the
       batch and emit ``DROP_FV`` / ``DROP_ENTITY`` ops for each orphan.
    4. Return ``Plan`` with ordered ops and any warnings.

    For FeatureView kinds, when ``applied.from_specification`` is True the
    diff uses the **full spec** (compiled via
    :func:`spec_compiler.compile_to_spec` and hashed via
    :func:`invariants._full_spec_hash`).  This catches changes that the
    structural fingerprint misses — UDF source code, source-column schema,
    aggregation windows, and target_lag.  When ``from_specification`` is
    False the planner falls back to the structural fingerprint so existing
    behaviour is preserved.

    Args:
        batch: The validated spec batch.
        applied_state: Current applied-state snapshot.
        options: Plan generation flags.
        database: Snowflake database name used when compiling local specs
            for the full-spec diff path.  Falls back to the spec's own
            ``database`` field when empty.
        schema: Snowflake schema name used when compiling local specs for
            the full-spec diff path.  Falls back to the spec's own
            ``schema`` / ``schema_`` field when empty.

    Returns:
        Topologically-sorted execution plan.
    """
    ops: list[PlanOp] = []
    warnings: list[str] = []

    # Convert models to dicts and sort topologically.
    if batch.specs:
        spec_dicts = [_model_to_dict(s) for s in batch.specs]
        sorted_dicts = topological_sort(spec_dicts)
    else:
        sorted_dicts = []

    for data in sorted_dicts:
        kind = data.get("kind", "")
        name = data.get("name", "")
        # Thread connection context as a fallback so bare YAMLs (specs
        # lacking ``database:`` / ``schema:``) qualify against the active
        # ``snow`` connection — otherwise the lookup key (e.g. ``Entity::USER``)
        # never collides with the fully-qualified applied-state key
        # (``Entity:JKEW_DB.JKEW_SCHEMA:USER``) and the planner emits
        # phantom CREATE+DROP pairs on a clean round-trip.  See
        # :func:`invariants._spec_key` for the fallback semantics
        # (dict fields always win when present).
        key = _spec_key(data, database=database, schema=schema)
        applied = applied_state.objects.get(key)

        db_for_compile = database or data.get("database", "") or ""
        sch_for_compile = schema or data.get("schema", "") or data.get("schema_", "") or ""

        if applied is None:
            # New object — CREATE.
            op_kind = _CREATE_OP.get(kind, OpKind.CREATE_FV)
            ops.append(
                PlanOp(
                    kind=op_kind,
                    name=name,
                    depends_on=[],
                    destructive=False,
                    reason="New object: not found in applied state.",
                    payload=data,
                )
            )
            continue

        # Object exists — pick the diff strategy.
        # FeatureView kinds with a deployed full spec get a full-spec diff;
        # FeatureGroup uses its own (much simpler) content hash; everything
        # else stays on the structural fingerprint.
        used_full_spec = False
        if applied.from_specification and kind in _RECREATE_OP:
            try:
                current_hash = _compute_local_spec_hash(data, db_for_compile, sch_for_compile)
                used_full_spec = True
            except Exception as exc:  # noqa: BLE001 — defensive fallback
                warnings.append(
                    f"{name}: full-spec diff unavailable ({exc}); " "falling back to structural fingerprint."
                )
                current_hash = _structural_fingerprint_hash(data)
        elif kind == "FeatureGroup":
            # FG hash basis is a deliberately narrow tuple over (name,
            # version, desc, auto_prefix, sources[]).  No operational /
            # structural split — the imperative API has no
            # ``update_feature_group``, so every drift is a destructive
            # recreate by construction.  See ``decl/invariants._fg_content_hash``.
            current_hash = _fg_content_hash(data)
        else:
            current_hash = _structural_fingerprint_hash(data)

        if current_hash == applied.content_hash:
            if (
                kind == "BatchFeatureView"
                and used_full_spec
                and applied.from_specification
                and isinstance(applied.spec_payload, dict)
                and _batch_fv_operational_drift(data, applied.spec_payload, db_for_compile, sch_for_compile)
            ):
                ops.append(
                    PlanOp(
                        kind=OpKind.UPDATE_FV,
                        name=name,
                        depends_on=[],
                        destructive=False,
                        reason="Batch feature view: full-spec hash unchanged but operational fields "
                        "(refresh cadence or online store routing) differ; applying via "
                        "FeatureStore.update_feature_view().",
                        payload=data,
                    )
                )
                continue
            # FV-level backfill.overwrite=True against an existing FV is the
            # operator opt-in for forced re-materialisation.  ``backfill`` is
            # stripped from the structural hash (see invariants._full_spec_hash),
            # so without this branch the plan would be NO_CHANGE and a plain
            # ``snow feature apply`` would never call register_feature_view —
            # the imperative ``overwrite=True`` semantics would be unreachable.
            # We emit a destructive CREATE_FV (re-register with overwrite=True
            # at the executor boundary) so the existing --allow-recreate gate
            # in execute_plan refuses plain apply for this destructive intent.
            backfill_block = data.get("backfill") if isinstance(data.get("backfill"), dict) else None
            backfill_overwrite = bool(backfill_block.get("overwrite")) if backfill_block else False
            if backfill_overwrite and "FeatureView" in kind:
                ops.append(
                    PlanOp(
                        kind=OpKind.CREATE_FV,
                        name=name,
                        depends_on=[],
                        destructive=True,
                        reason="FV-level backfill.overwrite=True forces re-materialisation; "
                        "re-registering via FeatureStore.register_feature_view(overwrite=True). "
                        "Requires --allow-recreate.",
                        payload=data,
                    )
                )
                continue
            # NO_CHANGE — include in plan for display; excluded from SQL by api.py.
            no_change_reason = (
                "Already deployed: no full-spec changes detected."
                if used_full_spec
                else "Already deployed: no structural changes detected."
            )
            ops.append(
                PlanOp(
                    kind=OpKind.NO_CHANGE,
                    name=name,
                    depends_on=[],
                    destructive=False,
                    reason=no_change_reason,
                    payload=data,
                )
            )
            continue

        # Hash differs.  For feature-view kinds, OFTs cannot be updated
        # in place so we emit a destructive RECREATE op.  For Entity
        # kinds, ``ALTER TAG ... SET ALLOWED_VALUES / SET COMMENT`` is
        # supported by Snowflake, so we emit a non-destructive
        # ``UPDATE_ENTITY`` op (handled by ``imperative_executor``)
        # instead of falling through to ``RECREATE_FV``.
        if kind == "Entity":
            ops.append(
                PlanOp(
                    kind=OpKind.UPDATE_ENTITY,
                    name=name,
                    depends_on=[],
                    destructive=False,
                    reason="Entity definition changed (join keys or description); "
                    "applying via FeatureStore.update_entity().",
                    payload=data,
                )
            )
            continue

        if (
            kind == "BatchFeatureView"
            and used_full_spec
            and applied.from_specification
            and isinstance(applied.spec_payload, dict)
            and batch_feature_view_structural_equivalent(data, applied.spec_payload, db_for_compile, sch_for_compile)
        ):
            ops.append(
                PlanOp(
                    kind=OpKind.UPDATE_FV,
                    name=name,
                    depends_on=[],
                    destructive=False,
                    reason="Batch feature view: structural spec unchanged; applying operational "
                    "updates via FeatureStore.update_feature_view() (refresh cadence, warehouse, "
                    "description, or online configuration).",
                    payload=data,
                )
            )
            continue

        if kind == "FeatureGroup":
            # FG hash mismatch → destructive CREATE_FG.  Mirrors the FV-level
            # ``backfill.overwrite=True`` pattern that reuses ``CREATE_FV``
            # with ``destructive=True`` rather than minting a new
            # ``RECREATE_FG`` enum.  The imperative side is a delete +
            # register pair; the executor walks both at apply time.  Gated
            # by ``--allow-recreate`` via the existing ``execute_plan`` gate.
            ops.append(
                PlanOp(
                    kind=OpKind.CREATE_FG,
                    name=name,
                    depends_on=[],
                    destructive=True,
                    reason="FeatureGroup content hash changed (desc, auto_prefix, or "
                    "feature_views[]); dropping and re-registering "
                    "(no imperative update_feature_group). Requires --allow-recreate.",
                    payload=data,
                )
            )
            continue

        recreate_kind = _RECREATE_OP.get(kind, OpKind.RECREATE_FV)
        recreate_reason = (
            "Full-spec change detected (UDF source, source columns, "
            "aggregation, or target lag); dropping and recreating "
            "(OFTs cannot be updated in place)."
            if used_full_spec
            else "Structural change detected; dropping and recreating " "(OFTs cannot be updated in place)."
        )
        ops.append(
            PlanOp(
                kind=recreate_kind,
                name=name,
                depends_on=[],
                destructive=True,
                reason=recreate_reason,
                payload=data,
            )
        )
        if used_full_spec:
            warnings.append(f"{name}: change detected via full-spec diff " "(DESCRIBE ... TYPE = SPECIFICATION).")

    # --- Deletion detection pass (only in full_directory_mode) ---
    if options.full_directory_mode:
        # Build set of spec keys from the batch.  Connection context is
        # forwarded to ``_spec_key`` here too so the batch-key set
        # uses the same qualifier as the diff-lookup pass above —
        # otherwise an unqualified spec would round-trip cleanly in the
        # diff loop yet still get marked as a missing batch entry,
        # producing a phantom DROP for an object that's still present
        # in the user's source tree.
        batch_keys: set[str] = set()
        for data in sorted_dicts:
            batch_keys.add(_spec_key(data, database=database, schema=schema))

        # Scan applied_state for objects not in the batch → DROP ops
        for key, applied_obj in applied_state.objects.items():
            if key in batch_keys:
                continue  # already handled above
            # This object exists in Snowflake but not in local files → DROP
            kind = applied_obj.kind
            name = applied_obj.name
            version = applied_obj.version or "V1"

            if kind in _FV_KINDS:
                op_kind = OpKind.DROP_FV
            elif kind in _FG_KINDS:
                op_kind = OpKind.DROP_FG
            elif kind == "Entity":
                op_kind = OpKind.DROP_ENTITY
            else:
                continue  # skip sources for now

            ops.append(
                PlanOp(
                    kind=op_kind,
                    name=name,
                    depends_on=[],
                    destructive=True,
                    reason="Not present in local spec files: will be dropped.",
                    payload={"name": name, "version": version, "kind": kind},
                )
            )

    return Plan(ops=ops, warnings=warnings)
