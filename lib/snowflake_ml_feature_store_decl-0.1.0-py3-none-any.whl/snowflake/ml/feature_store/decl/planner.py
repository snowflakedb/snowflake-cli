"""Plan generator: diffs desired specs against applied state.

Produces a topologically-sorted list of ``PlanOp`` objects.
No side effects, no connection access.
"""

from __future__ import annotations

from snowflake.ml.feature_store.decl.dependencies import topological_sort
from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.invariants import (
    _compute_local_spec_hash,
    _model_to_dict,
    _spec_key,
    _structural_fingerprint_hash,
)
from snowflake.ml.feature_store.decl.types import (
    AppliedState,
    Plan,
    PlanOp,
    PlanOptions,
    SpecBatch,
)

# Map spec kind to the appropriate OpKind for CREATE operations.
_CREATE_OP: dict[str, OpKind] = {
    "Entity": OpKind.CREATE_ENTITY,
    "StreamingSource": OpKind.CREATE_SOURCE,
    "BatchSource": OpKind.CREATE_SOURCE,
    "SQLDataSource": OpKind.CREATE_SOURCE,
    "StreamingFeatureView": OpKind.CREATE_FV,
    "RealtimeFeatureView": OpKind.CREATE_FV,
    "BatchFeatureView": OpKind.CREATE_FV,
    "FeatureGroup": OpKind.CREATE_FG,
}

# Map spec kind to the appropriate OpKind for UPDATE operations.
_UPDATE_OP: dict[str, OpKind] = {
    "Entity": OpKind.CREATE_ENTITY,  # Re-create (no dedicated UPDATE_ENTITY)
    "StreamingSource": OpKind.UPDATE_SOURCE,
    "BatchSource": OpKind.UPDATE_SOURCE,
    "SQLDataSource": OpKind.UPDATE_SOURCE,
    "StreamingFeatureView": OpKind.UPDATE_FV,
    "RealtimeFeatureView": OpKind.UPDATE_FV,
    "BatchFeatureView": OpKind.UPDATE_FV,
    "FeatureGroup": OpKind.CREATE_FG,
}

# Map spec kind to the appropriate OpKind for RECREATE operations.
_RECREATE_OP: dict[str, OpKind] = {
    "StreamingFeatureView": OpKind.RECREATE_FV,
    "RealtimeFeatureView": OpKind.RECREATE_FV,
    "BatchFeatureView": OpKind.RECREATE_FV,
}

# Feature view kinds eligible for DROP_FV.
_FV_KINDS: frozenset[str] = frozenset({"StreamingFeatureView", "RealtimeFeatureView", "BatchFeatureView"})


def generate_plan(
    batch: SpecBatch,
    applied_state: AppliedState,
    options: PlanOptions,
    database: str = "",
    schema: str = "",
) -> Plan:
    """Generate a dependency-ordered execution plan.

    Steps:
    1. Topologically sort the batch specs.
    2. For each spec, compare against ``applied_state``:
       - Not in applied state → ``CREATE`` op.
       - Content hash matches → ``NO_CHANGE`` (skip).
       - Hash differs, non-destructive → ``UPDATE`` op.
       - Hash differs, destructive, ``allow_recreate`` → ``RECREATE`` op.
       - Hash differs, destructive, no flag → warning, no op.
    3. If ``full_directory_mode``, scan applied_state for objects not in the
       batch and emit ``DROP_FV`` / ``DROP_ENTITY`` ops for each orphan.
    4. Return ``Plan`` with ordered ops and any warnings.

    For FeatureView kinds, when ``applied.from_specification`` is True the
    diff uses the **full spec** (compiled via
    :func:`spec_compiler.compile_to_spec` and hashed via
    :func:`invariants._full_spec_hash`).  This catches changes that the
    structural fingerprint misses — UDF source code, source-column schema,
    aggregation windows, and target_lag.  When ``from_specification`` is
    False the planner falls back to the structural fingerprint so existing
    behaviour is preserved.

    Args:
        batch: The validated spec batch.
        applied_state: Current applied-state snapshot.
        options: Plan generation flags.
        database: Snowflake database name used when compiling local specs
            for the full-spec diff path.  Falls back to the spec's own
            ``database`` field when empty.
        schema: Snowflake schema name used when compiling local specs for
            the full-spec diff path.  Falls back to the spec's own
            ``schema`` / ``schema_`` field when empty.

    Returns:
        Topologically-sorted execution plan.
    """
    ops: list[PlanOp] = []
    warnings: list[str] = []

    # Convert models to dicts and sort topologically.
    if batch.specs:
        spec_dicts = [_model_to_dict(s) for s in batch.specs]
        sorted_dicts = topological_sort(spec_dicts)
    else:
        sorted_dicts = []

    for data in sorted_dicts:
        kind = data.get("kind", "")
        name = data.get("name", "")
        key = _spec_key(data)
        applied = applied_state.objects.get(key)

        if applied is None:
            # New object — CREATE.
            op_kind = _CREATE_OP.get(kind, OpKind.CREATE_FV)
            ops.append(
                PlanOp(
                    kind=op_kind,
                    name=name,
                    depends_on=[],
                    destructive=False,
                    reason="New object — not found in applied state.",
                    payload=data,
                )
            )
            continue

        # Object exists — pick the diff strategy.
        # FeatureView kinds with a deployed full spec get a full-spec diff;
        # everything else stays on the structural fingerprint.
        used_full_spec = False
        if applied.from_specification and kind in _RECREATE_OP:
            db_for_compile = database or data.get("database", "") or ""
            sch_for_compile = schema or data.get("schema", "") or data.get("schema_", "") or ""
            try:
                current_hash = _compute_local_spec_hash(data, db_for_compile, sch_for_compile)
                used_full_spec = True
            except Exception as exc:  # noqa: BLE001 — defensive fallback
                warnings.append(
                    f"{name}: full-spec diff unavailable ({exc}); " "falling back to structural fingerprint."
                )
                current_hash = _structural_fingerprint_hash(data)
        else:
            current_hash = _structural_fingerprint_hash(data)

        if current_hash == applied.content_hash:
            # NO_CHANGE — include in plan for display; excluded from SQL by api.py.
            no_change_reason = (
                "Already deployed — no full-spec changes detected."
                if used_full_spec
                else "Already deployed — no structural changes detected."
            )
            ops.append(
                PlanOp(
                    kind=OpKind.NO_CHANGE,
                    name=name,
                    depends_on=[],
                    destructive=False,
                    reason=no_change_reason,
                    payload=data,
                )
            )
            continue

        # Hash differs — OFTs cannot be updated in place, always recreate.
        recreate_kind = _RECREATE_OP.get(kind, OpKind.RECREATE_FV)
        recreate_reason = (
            "Full-spec change detected (UDF source, source columns, "
            "aggregation, or target lag); dropping and recreating "
            "(OFTs cannot be updated in place)."
            if used_full_spec
            else "Structural change detected; dropping and recreating " "(OFTs cannot be updated in place)."
        )
        ops.append(
            PlanOp(
                kind=recreate_kind,
                name=name,
                depends_on=[],
                destructive=True,
                reason=recreate_reason,
                payload=data,
            )
        )
        if used_full_spec:
            warnings.append(f"{name}: change detected via full-spec diff " "(DESCRIBE ... TYPE = SPECIFICATION).")

    # --- Deletion detection pass (only in full_directory_mode) ---
    if options.full_directory_mode:
        # Build set of spec keys from the batch
        batch_keys: set[str] = set()
        for data in sorted_dicts:
            batch_keys.add(_spec_key(data))

        # Scan applied_state for objects not in the batch → DROP ops
        for key, applied_obj in applied_state.objects.items():
            if key in batch_keys:
                continue  # already handled above
            # This object exists in Snowflake but not in local files → DROP
            kind = applied_obj.kind
            name = applied_obj.name
            version = applied_obj.version or "V1"

            if kind in _FV_KINDS:
                op_kind = OpKind.DROP_FV
            elif kind == "Entity":
                op_kind = OpKind.DROP_ENTITY
            else:
                continue  # skip sources, groups for now

            ops.append(
                PlanOp(
                    kind=op_kind,
                    name=name,
                    depends_on=[],
                    destructive=True,
                    reason="Not present in local spec files — will be dropped.",
                    payload={"name": name, "version": version, "kind": kind},
                )
            )

    return Plan(ops=ops, warnings=warnings)
