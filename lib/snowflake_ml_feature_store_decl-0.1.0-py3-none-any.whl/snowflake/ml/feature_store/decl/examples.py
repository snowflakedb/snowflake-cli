"""Example spec generation for the declarative feature store library.

Writes a set of starter YAML spec files under an output directory so users
can quickly explore the declarative workflow without writing specs from scratch.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

_EXAMPLE_SPECS: dict[str, dict[str, Any]] = {
    "entities/example_entity.yaml": {
        "kind": "Entity",
        "name": "user",
        "version": "v1",
        "join_keys": [{"name": "user_id", "type": "StringType"}],
    },
    "datasources/example_events_source.yaml": {
        "kind": "StreamingSource",
        "name": "user_events",
        "version": "v1",
        "type": "REST",
        "columns": [
            {"name": "user_id", "type": "StringType"},
            {"name": "event_type", "type": "StringType"},
            {"name": "event_value", "type": "DoubleType"},
            {"name": "timestamp", "type": "TimestampType"},
        ],
    },
    "feature_views/example_feature_view.yaml": {
        "kind": "StreamingFeatureView",
        "name": "user_event_features",
        "version": "v1",
        "online": True,
        "timestamp_field": "timestamp",
        "feature_granularity": "5m",
        "ordered_entity_column_names": ["user_id"],
        "sources": [{"name": "user_events", "source_type": "Stream"}],
        "udf": {
            "name": "compute_event_features",
            "engine": "pandas",
            "file": "./example_udf.py",
            "output_columns": [
                {"name": "user_id", "type": "StringType"},
                {"name": "timestamp", "type": "TimestampType"},
                {"name": "event_count", "type": "LongType"},
                {"name": "total_value", "type": "DoubleType"},
            ],
        },
        "features": [
            {
                "source_column": {"name": "event_count", "type": "LongType"},
                "output_column": {"name": "event_count_1h", "type": "LongType"},
                "function": "count",
                "window": "1h",
            },
            {
                "source_column": {"name": "total_value", "type": "DoubleType"},
                "output_column": {"name": "total_value_1h", "type": "DoubleType"},
                "function": "sum",
                "window": "1h",
            },
        ],
    },
}

_EXAMPLE_UDF = '''\
"""Example UDF for the declarative feature store.

This pandas UDF receives raw event rows and computes derived features.
The output columns must match the udf.output_columns in the YAML spec.
"""

import pandas as pd


def compute_event_features(df: pd.DataFrame) -> pd.DataFrame:
    """Compute event features from raw streaming events.

    Args:
        df: Input DataFrame with columns: user_id, event_type, event_value, timestamp.

    Returns:
        DataFrame with columns: user_id, timestamp, event_count, total_value.
    """
    return pd.DataFrame({
        "user_id": df["user_id"],
        "timestamp": df["timestamp"],
        "event_count": 1,
        "total_value": df["event_value"].fillna(0.0),
    })
'''


def generate_example(output_dir: str) -> dict[str, Any]:
    """Write example YAML spec files under *output_dir*.

    Creates ``entities/``, ``datasources/``, and ``feature_views/``
    subdirectories and writes one starter spec file in each.

    Args:
        output_dir: Base directory under which example files are written.
            Created automatically (including parents) if it does not exist.

    Returns:
        Dict with keys ``status`` (``"created"``) and ``files`` (list of
        absolute paths to the written files).
    """
    created: list[str] = []
    for rel_path, spec in _EXAMPLE_SPECS.items():
        dest = Path(output_dir) / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(yaml.dump(spec, default_flow_style=False))
        created.append(str(dest))

    # Write the example UDF file alongside the feature view spec
    udf_dest = Path(output_dir) / "feature_views" / "example_udf.py"
    udf_dest.parent.mkdir(parents=True, exist_ok=True)
    udf_dest.write_text(_EXAMPLE_UDF)
    created.append(str(udf_dest))

    return {"status": "created", "files": created}
