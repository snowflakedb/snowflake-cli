"""File loading utilities for the declarative feature store.

Handles loading spec files from disk (Python, YAML, JSON), applying
Jinja2 templating, running compilation passes, and assembling a
``SpecBatch`` for validation and planning.

All functions are self-contained — no imports from snowflake.ml.feature_store.spec,
snowflake.snowpark, or snowflake.connector.
"""

from __future__ import annotations

import ast
import glob
import importlib.util
import json
import os
import sys
from typing import Any, Optional

import yaml

from snowflake.ml.feature_store.decl.compiler import compile_spec
from snowflake.ml.feature_store.decl.serializer import spec_to_dict
from snowflake.ml.feature_store.decl.spec_models import (
    BatchSource,
    Entity,
    FeatureGroup,
    FeatureView,
    SpecBase,
    StreamingSource,
)
from snowflake.ml.feature_store.decl.templating import detect_and_render
from snowflake.ml.feature_store.decl.types import SpecBatch

_SPEC_EXTENSIONS = frozenset({".py", ".yaml", ".yml", ".json"})


def expand_input_files(patterns: list[str]) -> list[str]:
    """Expand a list of file patterns to a flat list of spec file paths.

    Supports:
    - ``./...`` or ``<dir>/...`` — recursive walk for ``.py``/``.yaml``/
      ``.yml``/``.json`` files.
    - Standard glob patterns (``*.yaml``, ``entities/*.py``).
    - Direct file paths.

    Non-spec file extensions are excluded from recursive glob results.

    Args:
        patterns: List of file paths or glob patterns.

    Returns:
        Sorted, de-duplicated list of resolved file paths.
    """
    result: list[str] = []
    for pattern in patterns:
        # A path that resolves to an existing directory (with no trailing
        # ``/...``) is treated as ``<dir>/...`` — a recursive walk.  Without
        # this rewrite the ``glob.glob`` branch below returns the directory
        # path itself, which then crashes ``process_file`` with
        # ``IsADirectoryError`` and the bare ``except Exception: pass`` in
        # :func:`load_specs` silently drops it, producing an empty
        # ``SpecBatch`` and a misleading "no changes" plan.  Auto-expansion
        # gives bare directories the same recursive semantics as ``./...``.
        normalized = pattern.rstrip("/")
        is_recursive_marker = pattern.endswith("/...") or pattern == "./..."
        if not is_recursive_marker and os.path.isdir(normalized):
            pattern = f"{normalized}/..."
            is_recursive_marker = True

        if is_recursive_marker:
            if pattern == "./...":
                root = "."
            else:
                root = pattern.rsplit("/...", 1)[0]
            for dirpath, _dirnames, filenames in os.walk(root):
                for fname in sorted(filenames):
                    if os.path.splitext(fname)[1] in _SPEC_EXTENSIONS:
                        result.append(os.path.join(dirpath, fname))
        else:
            expanded = glob.glob(pattern)
            if expanded:
                result.extend(sorted(expanded))
            else:
                result.append(pattern)

    # Deduplicate while preserving order
    seen: set[str] = set()
    deduped: list[str] = []
    for p in result:
        if p not in seen:
            seen.add(p)
            deduped.append(p)
    return deduped


def _get_defined_names(filepath: str) -> set[str]:
    """Get names of variables assigned at module level (not imported).

    Parses the file with ``ast`` to distinguish local assignments from
    import statements, so that imported objects are not mistakenly treated
    as locally-defined specs.

    Args:
        filepath: Path to the Python file.

    Returns:
        Set of names assigned at module level.
    """
    with open(filepath) as f:
        source = f.read()
    tree = ast.parse(source)
    names: set[str] = set()
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            names.add(node.name)
    return names


def load_python_file(filepath: str) -> list[tuple[str, Any]]:
    """Load a Python spec file and extract locally-defined spec objects.

    Supports two authoring styles:

    - **Pydantic style**: Module-level instances of :class:`Entity`,
      :class:`StreamingSource`, :class:`BatchSource`, :class:`FeatureView`,
      :class:`FeatureGroup`, or :class:`SpecBase`.
    - **Decorator style**: Functions decorated with ``@feature_view(...)``
      that have a ``_feature_view`` attribute.

    Only returns objects that are *locally defined* in the file (not imported).
    This allows spec files to import source objects for inline use without
    those sources being treated as new specs to apply.

    Sibling directories relative to the file's parent are added to
    ``sys.path`` so that cross-directory imports work (e.g. a feature view
    importing a data source from a sibling directory).

    Args:
        filepath: Absolute or relative path to the Python spec file.

    Returns:
        List of ``(name, spec_object)`` tuples for locally-defined specs.

    Raises:
        ValueError: If the file cannot be loaded as a Python module.
    """
    filepath = os.path.abspath(filepath)
    file_dir = os.path.dirname(filepath)
    module_name = os.path.splitext(os.path.basename(filepath))[0]

    # Add file's directory to sys.path
    if file_dir not in sys.path:
        sys.path.insert(0, file_dir)

    # Add sibling directories so cross-directory imports work
    parent_dir = os.path.dirname(file_dir)
    if os.path.isdir(parent_dir):
        for entry in sorted(os.listdir(parent_dir)):
            sibling = os.path.join(parent_dir, entry)
            if os.path.isdir(sibling) and sibling not in sys.path:
                sys.path.insert(0, sibling)

    spec = importlib.util.spec_from_file_location(module_name, filepath)
    if spec is None or spec.loader is None:
        raise ValueError(f"Could not load Python file: {filepath}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)  # type: ignore[union-attr]

    defined_names = _get_defined_names(filepath)
    known_types = (FeatureView, FeatureGroup, StreamingSource, BatchSource, Entity, SpecBase)
    objects: list[tuple[str, Any]] = []

    for attr_name in dir(module):
        if attr_name.startswith("_") or attr_name not in defined_names:
            continue
        obj = getattr(module, attr_name)
        if isinstance(obj, known_types):
            objects.append((attr_name, obj))
        elif callable(obj) and hasattr(obj, "_feature_view"):
            objects.append((attr_name, obj._feature_view))

    return objects


def process_file(
    filepath: str,
    config_source: Optional[str] = None,
) -> list[dict[str, Any]]:
    """Load a single spec file and return a list of compiled spec dicts.

    Steps:
    1. Read file content.
    2. Apply Jinja2 template rendering if needed (via ``templating.detect_and_render``).
    3. Dispatch by extension:
       - ``.py`` → :func:`load_python_file` then :func:`~compiler.compile_spec`
       - ``.yaml`` / ``.yml`` → ``yaml.safe_load`` then ``compile_spec``
       - ``.json`` → ``json.loads`` then ``compile_spec``

    Args:
        filepath: Path to the spec file.
        config_source: Jinja2 config source string (passed to :func:`load_config`),
            or ``None`` if no templating is needed.

    Returns:
        List of compiled spec dicts.
    """
    filepath = os.path.abspath(filepath)
    spec_dir = os.path.dirname(filepath)
    ext = os.path.splitext(filepath)[1].lower()

    with open(filepath) as f:
        raw = f.read()

    rendered = detect_and_render(raw, config_source, filepath)

    if ext == ".py":
        # For Python files with template rendering, write to a temp file
        if rendered != raw:
            import tempfile

            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix=".py",
                dir=spec_dir,
                prefix=f".{os.path.splitext(os.path.basename(filepath))[0]}_",
                delete=False,
            ) as tmp:
                tmp.write(rendered)
                tmp_path = tmp.name
            try:
                objects = load_python_file(tmp_path)
            finally:
                os.unlink(tmp_path)
        else:
            objects = load_python_file(filepath)

        results = []
        for _name, obj in objects:
            data = spec_to_dict(obj)
            data = compile_spec(data, spec_file_dir=spec_dir)
            results.append(data)
        return results

    elif ext in (".yaml", ".yml"):
        data = yaml.safe_load(rendered)
        if not isinstance(data, dict):
            return []
        data = compile_spec(data, spec_file_dir=spec_dir)
        return [data]

    elif ext == ".json":
        data = json.loads(rendered)
        if not isinstance(data, dict):
            return []
        data = compile_spec(data, spec_file_dir=spec_dir)
        return [data]

    else:
        return []


def _dict_to_spec(data: dict[str, Any]) -> SpecBase:
    """Convert a compiled spec dict to the appropriate SpecBase subclass."""
    from snowflake.ml.feature_store.decl.spec_models import (
        BatchSource,
        Entity,
        FeatureGroup,
        FeatureView,
        SQLDataSource,
        StreamingSource,
    )

    kind = data.get("kind", "")
    kind_map = {
        "Entity": Entity,
        "StreamingSource": StreamingSource,
        "BatchSource": BatchSource,
        "SQLDataSource": SQLDataSource,
        "StreamingFeatureView": FeatureView,
        "RealtimeFeatureView": FeatureView,
        "BatchFeatureView": FeatureView,
        "FeatureGroup": FeatureGroup,
    }
    cls = kind_map.get(kind, SpecBase)
    try:
        return cls.model_validate(data)
    except Exception:
        return SpecBase.model_validate({"kind": kind, "name": data.get("name", "")})


def load_specs(
    files: list[str],
    config: Optional[dict[str, Any]] = None,
) -> SpecBatch:
    """Load and parse spec files into a :class:`~types.SpecBatch`.

    Accepts ``.py``, ``.yaml``, ``.yml``, and ``.json`` files. Glob patterns
    and ``./...`` recursive expansion are resolved before loading.

    Files that fail due to unresolved imports are retried after all other
    files have been processed — this handles dependency ordering automatically
    (e.g. a feature group that imports a feature view from a sibling directory).

    Args:
        files: List of file paths or glob patterns.
        config: Jinja2 template variables as a dict. Converted to an inline
            JSON string for passing to :func:`process_file`. May be ``None``.

    Returns:
        SpecBatch with all loaded specs and source file paths.
    """
    import json as _json

    config_source: Optional[str] = None
    if config:
        config_source = _json.dumps(config)

    expanded = expand_input_files(files)
    all_specs: list[SpecBase] = []
    source_files: list[str] = []

    pending = [(fp, None) for fp in expanded]
    max_passes = len(pending) + 1

    for _ in range(max_passes):
        still_pending: list[tuple[str, Any]] = []
        made_progress = False

        for filepath, _prev_err in pending:
            if not os.path.exists(filepath):
                continue
            try:
                spec_dicts = process_file(filepath, config_source=config_source)
                for d in spec_dicts:
                    all_specs.append(_dict_to_spec(d))
                if filepath not in source_files:
                    source_files.append(filepath)
                made_progress = True
            except (ImportError, SyntaxError) as e:
                still_pending.append((filepath, e))
            except Exception:
                # Non-retryable errors are skipped
                pass

        if not still_pending:
            break
        if not made_progress:
            break
        pending = still_pending

    return SpecBatch(specs=all_specs, source_files=source_files)
