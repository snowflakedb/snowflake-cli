"""Applied-state parser for the declarative feature store library.

Parses raw Snowflake query results into ``AppliedState``.
No connection access — accepts pre-fetched data.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from snowflake.ml.feature_store.decl.invariants import _structural_fingerprint_hash
from snowflake.ml.feature_store.decl.types import AppliedObject, AppliedState

logger = logging.getLogger(__name__)

# OFT name separator character
_SEP = "$"
# Suffix appended to all online feature table names
_ONLINE_SUFFIX = "ONLINE"


def _parse_oft_name(name: str) -> tuple[str, str]:
    """Extract ``(base_name, version)`` from an OFT name.

    The naming convention is ``<base_name>$<version>$ONLINE``.
    Falls back to splitting on the last ``$`` if the ``$ONLINE``
    suffix is absent (handles malformed or legacy names gracefully).

    Args:
        name: The raw OFT name string from Snowflake.

    Returns:
        Tuple of ``(base_name, version)``.
    """
    parts = name.split(_SEP)
    if len(parts) >= 3 and parts[-1] == _ONLINE_SUFFIX:
        # Standard: BASE$VERSION$ONLINE
        version = parts[-2]
        base = _SEP.join(parts[:-2])
        return base, version
    if len(parts) >= 2:
        # Fallback: BASE$VERSION
        version = parts[-1]
        base = _SEP.join(parts[:-1])
        return base, version
    # No separator — treat whole name as base, empty version
    return name, ""


def _extract_spec_from_oft(row: dict[str, Any]) -> Optional[dict]:
    """Extract and parse the embedded JSON specification from an OFT row.

    Args:
        row: A single row from ``SHOW ONLINE FEATURE TABLES`` results.

    Returns:
        Parsed spec dict, or ``None`` if the specification column is missing
        or contains invalid JSON.
    """
    raw = row.get("specification", "")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        logger.debug("Could not parse specification JSON for row: %s", row.get("name", "?"))
        return None


def _build_spec_key(kind: str, spec: dict) -> str:
    """Build a canonical ``kind:database.schema:name`` key from spec metadata.

    Args:
        kind: The object kind string.
        spec: The parsed spec dict (may contain a ``metadata`` sub-dict).

    Returns:
        Canonical key string.
    """
    metadata = spec.get("metadata", spec)
    db = metadata.get("database", "") or spec.get("database", "")
    schema = metadata.get("schema", "") or spec.get("schema", "")
    name = metadata.get("name", "") or spec.get("name", "")
    qualifier = f"{db}.{schema}" if (db or schema) else ""
    return f"{kind}:{qualifier}:{name}"


def _describe_feature_cols(desc_rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Extract non-primary-key columns from ``DESCRIBE ONLINE FEATURE TABLE`` rows.

    Primary key columns are the entity/join-key columns.  The remaining columns
    are the feature output columns that form the structural fingerprint.

    Args:
        desc_rows: Rows from ``DESCRIBE ONLINE FEATURE TABLE``.

    Returns:
        List of ``{"name": col_name, "type": col_type}`` dicts for feature cols.
    """
    cols: list[dict[str, str]] = []
    for col in desc_rows:
        is_pk = False
        for pk_key in ("primary key", "PRIMARY KEY", "primary_key", "PRIMARY_KEY"):
            val = col.get(pk_key, "")
            if val and str(val).upper() in ("Y", "YES", "TRUE", "1"):
                is_pk = True
                break
        # Positional fallback: 5th value (index 4) == "Y" (mirrors exporter.py).
        if not is_pk:
            raw_vals = list(col.values())
            if len(raw_vals) >= 5 and raw_vals[4] == "Y":
                is_pk = True

        if not is_pk:
            col_name = col.get("name") or col.get("NAME") or ""
            col_type = col.get("type") or col.get("TYPE") or ""
            if col_name:
                cols.append({"name": col_name, "type": col_type})
    return cols


def fetch_applied_state(
    raw_show_results: list[dict[str, Any]],
    raw_table_results: Optional[list[dict[str, Any]]] = None,
    describe_map: Optional[dict[str, list[dict[str, Any]]]] = None,
) -> AppliedState:
    """Parse raw Snowflake query results into an ``AppliedState`` snapshot.

    Steps:

    1. Parse ``SHOW ONLINE FEATURE TABLES`` rows → extract name/version from
       the ``$version$ONLINE`` naming convention.
    2. Try to extract embedded spec JSON from the ``specification`` column
       (legacy path — Snowflake does not currently return this column).
    3. If no specification column, fall back to reconstructing state from
       ``describe_map`` using ``DESCRIBE ONLINE FEATURE TABLE`` column data.
    4. Compute a structural fingerprint hash from the reconstructed state so
       the planner can detect ``NO_CHANGE`` on subsequent applies.

    Args:
        raw_show_results: Rows from ``SHOW ONLINE FEATURE TABLES``.
        raw_table_results: Rows from ``SHOW TABLES`` for offline table
            existence checks (currently unused in v0, reserved for future
            use).
        describe_map: Optional mapping of OFT name (as it appears in SHOW
            results) → ``DESCRIBE ONLINE FEATURE TABLE`` rows.  When
            provided, rows without a ``specification`` column are built from
            these DESCRIBE results instead of being skipped.

    Returns:
        AppliedState snapshot with all deployed objects.
    """
    objects: dict[str, AppliedObject] = {}

    for row in raw_show_results:
        oft_name = row.get("name", "")
        if not oft_name:
            continue

        base_name, version = _parse_oft_name(oft_name)

        spec = _extract_spec_from_oft(row)
        if spec is None:
            # Specification column absent — fall back to DESCRIBE-based state.
            if describe_map is None:
                logger.debug("Skipping OFT row with no parseable specification: %s", oft_name)
                continue

            desc_rows = describe_map.get(oft_name)
            if not desc_rows:
                logger.debug(
                    "Skipping OFT row: no specification and no describe_map entry for %s",
                    oft_name,
                )
                continue

            db = row.get("database_name", "")
            schema_val = row.get("schema_name", "")

            # Build a minimal spec-like dict from DESCRIBE for fingerprinting.
            feature_cols = _describe_feature_cols(desc_rows)
            fp_spec: dict[str, Any] = {
                "name": base_name,
                "version": version,
                "features": [{"output_column": c} for c in feature_cols],
            }
            content_hash = _structural_fingerprint_hash(fp_spec)
            kind = "StreamingFeatureView"
            qualifier = f"{db}.{schema_val}" if (db or schema_val) else ""
            key = f"{kind}:{qualifier}:{base_name}"

            objects[key] = AppliedObject(
                key=key,
                kind=kind,
                name=base_name,
                version=version,
                content_hash=content_hash,
                spec_payload=fp_spec,
                columns=[],
            )
            continue

        # Legacy path: specification column present (not used by Snowflake today).
        kind = spec.get("kind", "StreamingFeatureView")

        metadata = spec.get("metadata", {})
        db = metadata.get("database", "")
        schema_val = metadata.get("schema", "")

        flat_spec: dict[str, Any] = {
            "kind": kind,
            "name": base_name,
            "version": version,
            "database": db,
            "schema": schema_val,
        }
        inner_spec = spec.get("spec", {})
        flat_spec.update(inner_spec)

        content_hash = _structural_fingerprint_hash(flat_spec)
        key = _build_spec_key(kind, flat_spec)

        objects[key] = AppliedObject(
            key=key,
            kind=kind,
            name=base_name,
            version=version,
            content_hash=content_hash,
            spec_payload=flat_spec,
            columns=[],
        )

    return AppliedState(objects=objects)
