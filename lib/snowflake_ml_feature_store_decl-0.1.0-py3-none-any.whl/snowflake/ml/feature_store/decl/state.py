"""Applied-state parser for the declarative feature store library.

Parses raw Snowflake query results into ``AppliedState``.
No connection access — accepts pre-fetched data.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from snowflake.ml.feature_store.decl.invariants import (
    _full_spec_hash,
    _structural_fingerprint_hash,
)
from snowflake.ml.feature_store.decl.types import (
    AppliedObject,
    AppliedState,
    ObjectKind,
)
from snowflake.ml.feature_store.spec.enums import ENTITY_TAG_PREFIX

logger = logging.getLogger(__name__)

# OFT name separator character
_SEP = "$"
# Suffix appended to all online feature table names
_ONLINE_SUFFIX = "ONLINE"

# Legacy alias.  The canonical value lives in
# :data:`snowflake.ml.feature_store.spec.enums.ENTITY_TAG_PREFIX` (imported
# above).  Existing internal callers
# (``decl/exporter.py``, ``decl/api.py``, tests) reference the
# leading-underscore name; keeping this alias as a thin re-export means we do
# not have to chase every callsite, while the cross-module identity test
# (``spec/enums_test.py``) still passes because both names point at the same
# string object.
_ENTITY_TAG_PREFIX = ENTITY_TAG_PREFIX


def _parse_oft_name(name: str) -> tuple[str, str]:
    """Extract ``(base_name, version)`` from an OFT name.

    The naming convention is ``<base_name>$<version>$ONLINE``.
    Falls back to splitting on the last ``$`` if the ``$ONLINE``
    suffix is absent (handles malformed or legacy names gracefully).

    Args:
        name: The raw OFT name string from Snowflake.

    Returns:
        Tuple of ``(base_name, version)``.
    """
    parts = name.split(_SEP)
    if len(parts) >= 3 and parts[-1] == _ONLINE_SUFFIX:
        # Standard: BASE$VERSION$ONLINE
        version = parts[-2]
        base = _SEP.join(parts[:-2])
        return base, version
    if len(parts) >= 2:
        # Fallback: BASE$VERSION
        version = parts[-1]
        base = _SEP.join(parts[:-1])
        return base, version
    # No separator — treat whole name as base, empty version
    return name, ""


def _extract_spec_from_oft(row: dict[str, Any]) -> Optional[dict]:
    """Extract and parse the embedded JSON specification from an OFT row.

    Args:
        row: A single row from ``SHOW ONLINE FEATURE TABLES`` results.

    Returns:
        Parsed spec dict, or ``None`` if the specification column is missing
        or contains invalid JSON.
    """
    raw = row.get("specification", "")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        logger.debug("Could not parse specification JSON for row: %s", row.get("name", "?"))
        return None


def _build_spec_key(kind: str, spec: dict) -> str:
    """Build a canonical ``kind:DATABASE.SCHEMA:NAME`` key from spec metadata.

    Mirrors :func:`snowflake.ml.feature_store.decl.invariants._spec_key` so
    the planner's batch-side keys (uppercased) and the applied-state side
    keys collide on identical objects.  Without this normalisation,
    full-directory mode treats every FV as both "new" *and* "orphaned"
    when the deployed name (e.g. ``user_profile_info``) and the local YAML
    name (e.g. ``USER_PROFILE_INFO``) differ only in case, which produces
    spurious ``CREATE_FV`` + ``DROP_FV`` ops on a clean round-trip.

    Args:
        kind: The object kind string.
        spec: The parsed spec dict (may contain a ``metadata`` sub-dict).

    Returns:
        Canonical key string with database, schema, and name uppercased.
    """
    metadata = spec.get("metadata", spec)
    db = (metadata.get("database", "") or spec.get("database", "") or "").upper()
    schema = (metadata.get("schema", "") or spec.get("schema", "") or "").upper()
    name = (metadata.get("name", "") or spec.get("name", "") or "").upper()
    qualifier = f"{db}.{schema}" if (db or schema) else ""
    return f"{kind}:{qualifier}:{name}"


def _describe_feature_cols(desc_rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Extract non-primary-key columns from ``DESCRIBE ONLINE FEATURE TABLE`` rows.

    Primary key columns are the entity/join-key columns.  The remaining columns
    are the feature output columns that form the structural fingerprint.

    Args:
        desc_rows: Rows from ``DESCRIBE ONLINE FEATURE TABLE``.

    Returns:
        List of ``{"name": col_name, "type": col_type}`` dicts for feature cols.
    """
    cols: list[dict[str, str]] = []
    for col in desc_rows:
        is_pk = False
        for pk_key in ("primary key", "PRIMARY KEY", "primary_key", "PRIMARY_KEY"):
            val = col.get(pk_key, "")
            if val and str(val).upper() in ("Y", "YES", "TRUE", "1"):
                is_pk = True
                break
        # Positional fallback: 5th value (index 4) == "Y" (mirrors exporter.py).
        if not is_pk:
            raw_vals = list(col.values())
            if len(raw_vals) >= 5 and raw_vals[4] == "Y":
                is_pk = True

        if not is_pk:
            col_name = col.get("name") or col.get("NAME") or ""
            col_type = col.get("type") or col.get("TYPE") or ""
            if col_name:
                cols.append({"name": col_name, "type": col_type})
    return cols


def parse_specification_rows(
    rows: Optional[list[dict[str, Any]]],
) -> Optional[dict[str, Any]]:
    """Parse rows returned by ``DESCRIBE ... TYPE = SPECIFICATION``.

    The new SQL primitive returns a single row carrying the original spec
    JSON used to create the Online Feature Table.  Different Snowflake
    cursor adapters expose the column under different names
    (``specification``, ``SPECIFICATION``, or simply the first string
    column), so this helper checks all of them and falls back to scanning
    for a single string value that parses as JSON.

    Args:
        rows: Raw rows (list of dicts) from the SQL execution.

    Returns:
        Parsed spec JSON dict, or ``None`` if no row contained a parseable
        spec.
    """
    if not rows:
        return None

    for row in rows:
        if not isinstance(row, dict):
            continue
        # Try the obvious column names first.
        candidates: list[Any] = []
        for col in ("specification", "SPECIFICATION", "Specification"):
            if col in row and row[col]:
                candidates.append(row[col])
        # Fall back to the first string-valued cell.
        if not candidates:
            for value in row.values():
                if isinstance(value, str) and value.strip():
                    candidates.append(value)
                    break
        for raw in candidates:
            if not isinstance(raw, str):
                continue
            try:
                parsed = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                continue
            if isinstance(parsed, dict):
                return parsed
    return None


def _build_entity_object(
    row: dict[str, Any],
    default_db: str,
    default_schema: str,
) -> Optional[AppliedObject]:
    """Build an Entity ``AppliedObject`` from a ``SHOW TAGS`` row."""
    raw_name = row.get("name") or row.get("NAME") or ""
    if not raw_name:
        return None
    if not raw_name.startswith(_ENTITY_TAG_PREFIX):
        return None
    # Entity names match the join-key column.  Uppercase for round-trip
    # parity with :func:`invariants._spec_key` (which uppercases names so
    # casing differences between authoring YAML and Snowflake identifiers
    # collapse to a single canonical key).
    entity_name = raw_name[len(_ENTITY_TAG_PREFIX) :].upper()
    db = (row.get("database_name") or row.get("DATABASE_NAME") or default_db or "").upper()
    schema_val = (row.get("schema_name") or row.get("SCHEMA_NAME") or default_schema or "").upper()
    qualifier = f"{db}.{schema_val}" if (db or schema_val) else ""
    key = f"{ObjectKind.ENTITY}:{qualifier}:{entity_name}"

    join_keys: list[str] = []
    raw_allowed = row.get("allowed_values") or row.get("ALLOWED_VALUES") or row.get("allowed_values_list")
    if raw_allowed:
        if isinstance(raw_allowed, list):
            join_keys = [str(v) for v in raw_allowed]
        elif isinstance(raw_allowed, str):
            try:
                parsed = json.loads(raw_allowed)
                if isinstance(parsed, list):
                    join_keys = [str(v) for v in parsed]
            except (json.JSONDecodeError, TypeError):
                join_keys = [v.strip() for v in raw_allowed.strip("[]").split(",") if v.strip()]

    details: dict[str, Any] = {"join_keys": join_keys}
    comment = row.get("comment") or row.get("COMMENT") or ""
    if comment:
        details["comment"] = comment

    spec_payload: dict[str, Any] = {
        "kind": ObjectKind.ENTITY,
        "name": entity_name,
        "database": db,
        "schema": schema_val,
        "join_keys": [{"name": jk, "type": "StringType"} for jk in join_keys],
    }
    # Surface the deployed tag's COMMENT under ``description`` so the
    # Entity-aware branch of :func:`_structural_fingerprint` (which folds
    # description into the hash) sees the same value the local YAML's
    # ``description:`` produces.  Without this an unedited re-plan would
    # emit a phantom ``UPDATE_ENTITY`` after the fingerprint widen — see
    # ``plans/step11_update_entity_bug_*.plan.md``.
    if comment:
        spec_payload["description"] = comment

    # Match the planner's diff strategy: it hashes Entity/Source specs via
    # :func:`_structural_fingerprint_hash`, so the applied side must use the
    # same so a re-applied YAML hashes identically and emits ``NO_CHANGE``.
    content_hash = _structural_fingerprint_hash(spec_payload)

    return AppliedObject(
        key=key,
        kind=ObjectKind.ENTITY,
        name=entity_name,
        version=None,
        content_hash=content_hash,
        spec_payload=spec_payload,
        columns=[],
        from_specification=False,
        details=details,
    )


def _datasource_objects_from_specs(
    fv_specs: list[dict[str, Any]],
    default_db: str,
    default_schema: str,
) -> list[AppliedObject]:
    """Derive Datasource AppliedObjects by unioning ``spec.sources[]``.

    Datasources are virtual: they are not separately registered in
    Snowflake.  The runtime contract for them lives inside each FV's
    ``spec.sources[]`` block.  This function deduplicates by name and emits
    one ``AppliedObject(kind="Datasource")`` per unique source.

    Args:
        fv_specs: Parsed feature view spec JSON documents (the return
            value of :func:`parse_specification_rows` for each OFT).
        default_db: Database to use when a source's metadata is missing.
        default_schema: Schema to use when a source's metadata is missing.

    Returns:
        List of ``AppliedObject`` instances, one per unique datasource.
    """
    by_name: dict[str, AppliedObject] = {}
    for fv_spec in fv_specs:
        if not isinstance(fv_spec, dict):
            continue
        inner = fv_spec.get("spec") if isinstance(fv_spec.get("spec"), dict) else fv_spec
        sources = inner.get("sources", []) if isinstance(inner, dict) else []
        if not isinstance(sources, list):
            continue
        metadata = fv_spec.get("metadata") if isinstance(fv_spec.get("metadata"), dict) else {}
        db = (metadata.get("database") or default_db or "").upper()
        schema_val = (metadata.get("schema") or default_schema or "").upper()
        qualifier = f"{db}.{schema_val}" if (db or schema_val) else ""

        for src in sources:
            if not isinstance(src, dict):
                continue
            src_name = src.get("name", "")
            if not src_name:
                continue
            # Uppercase for round-trip parity with :func:`invariants._spec_key`
            # — the same source name in two FVs (one upper, one lower)
            # canonicalises to one AppliedObject and one key.
            canonical_name = src_name.upper()
            dedupe_key = canonical_name
            if dedupe_key in by_name:
                continue
            source_type = src.get("source_type") or src.get("type") or ""
            columns = src.get("columns", [])
            details: dict[str, Any] = {"source_type": source_type}
            if isinstance(columns, list):
                details["column_count"] = len(columns)

            spec_payload: dict[str, Any] = {
                "kind": ObjectKind.DATASOURCE,
                "name": canonical_name,
                "database": db,
                "schema": schema_val,
                "source_type": source_type,
                "columns": columns,
            }
            # Match the planner's diff strategy: structural fingerprint, not
            # raw payload hash, so a re-applied YAML matches and emits
            # ``NO_CHANGE`` instead of a spurious recreate.
            content_hash = _structural_fingerprint_hash(spec_payload)
            key = f"{ObjectKind.DATASOURCE}:{qualifier}:{canonical_name}"

            by_name[dedupe_key] = AppliedObject(
                key=key,
                kind=ObjectKind.DATASOURCE,
                name=canonical_name,
                version=None,
                content_hash=content_hash,
                spec_payload=spec_payload,
                columns=[],
                from_specification=True,
                details=details,
            )
    return list(by_name.values())


def fetch_applied_state(
    raw_show_results: list[dict[str, Any]],
    raw_table_results: Optional[list[dict[str, Any]]] = None,
    describe_map: Optional[dict[str, list[dict[str, Any]]]] = None,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
    entity_rows: Optional[list[dict[str, Any]]] = None,
    default_database: str = "",
    default_schema: str = "",
) -> AppliedState:
    """Parse raw Snowflake query results into an ``AppliedState`` snapshot.

    Steps:

    1. Parse ``SHOW ONLINE FEATURE TABLES`` rows → extract name/version from
       the ``$version$ONLINE`` naming convention.
    2. If ``specification_map[name]`` is present, use the full spec JSON as
       the canonical ``spec_payload`` and mark
       ``from_specification=True``.  This enables full-spec diffs.
    3. Otherwise try to extract embedded spec JSON from the
       ``specification`` column on the SHOW row (legacy path), then fall
       back to reconstructing state from ``describe_map`` columns
       (structural-fingerprint path).
    4. If ``entity_rows`` is provided, build one ``AppliedObject`` per
       entity tag.
    5. Derive ``Datasource`` AppliedObjects from the union of
       ``spec.sources[]`` across all FV spec payloads recovered above.

    Args:
        raw_show_results: Rows from ``SHOW ONLINE FEATURE TABLES``.
        raw_table_results: Rows from ``SHOW TABLES`` for offline table
            existence checks (currently unused in v0, reserved for future
            use).
        describe_map: Optional mapping of OFT name → ``DESCRIBE ONLINE
            FEATURE TABLE`` rows (column-only).  Used as the fallback when
            a specification is unavailable.
        specification_map: Optional mapping of OFT name → parsed spec JSON
            from ``DESCRIBE ... TYPE = SPECIFICATION``.  When present, this
            is the authoritative source for the FV's spec_payload.
        entity_rows: Optional rows from
            ``SHOW TAGS LIKE 'SNOWML_FEATURE_STORE_ENTITY_%'``.  Each row
            becomes an ``AppliedObject(kind="Entity")``.
        default_database: Database to use when a row does not include one.
        default_schema: Schema to use when a row does not include one.

    Returns:
        AppliedState snapshot with all deployed objects (FVs + Entities +
        derived Datasources).
    """
    objects: dict[str, AppliedObject] = {}
    spec_payloads_for_datasources: list[dict[str, Any]] = []

    for row in raw_show_results:
        oft_name = row.get("name", "")
        if not oft_name:
            continue

        base_name, version = _parse_oft_name(oft_name)

        # Path 1: Full spec JSON via DESCRIBE TYPE = SPECIFICATION.
        spec = None
        from_spec = False
        if specification_map is not None:
            spec = specification_map.get(oft_name)
            if spec is not None:
                from_spec = True

        # Path 2: Legacy embedded specification column on the SHOW row.
        if spec is None:
            spec = _extract_spec_from_oft(row)

        if spec is not None:
            kind = spec.get("kind", "StreamingFeatureView")
            metadata = spec.get("metadata", {}) if isinstance(spec.get("metadata"), dict) else {}
            db = metadata.get("database", "") or row.get("database_name", "") or default_database
            schema_val = metadata.get("schema", "") or row.get("schema_name", "") or default_schema

            spec_payload: dict[str, Any]
            if from_spec:
                spec_payload = dict(spec)
                if "metadata" not in spec_payload:
                    spec_payload["metadata"] = {
                        "database": db,
                        "schema": schema_val,
                        "name": base_name,
                        "version": version,
                    }
                content_hash = _full_spec_hash(spec_payload)
                spec_payloads_for_datasources.append(spec_payload)
            else:
                # Legacy embedded-specification path → flatten for fingerprint.
                spec_payload = {
                    "kind": kind,
                    "name": base_name,
                    "version": version,
                    "database": db,
                    "schema": schema_val,
                }
                inner_spec = spec.get("spec", {})
                if isinstance(inner_spec, dict):
                    spec_payload.update(inner_spec)
                content_hash = _structural_fingerprint_hash(spec_payload)

            key = _build_spec_key(
                kind,
                {
                    "database": db,
                    "schema": schema_val,
                    "name": base_name,
                },
            )
            objects[key] = AppliedObject(
                key=key,
                kind=kind,
                name=base_name,
                version=version,
                content_hash=content_hash,
                spec_payload=spec_payload,
                columns=[],
                from_specification=from_spec,
            )
            continue

        # Path 3: DESCRIBE-only fallback (structural fingerprint).
        if describe_map is None:
            logger.debug("Skipping OFT row with no parseable specification: %s", oft_name)
            continue
        desc_rows = describe_map.get(oft_name)
        if not desc_rows:
            logger.debug(
                "Skipping OFT row: no specification and no describe_map entry for %s",
                oft_name,
            )
            continue

        db = row.get("database_name", "") or default_database
        schema_val = row.get("schema_name", "") or default_schema

        feature_cols = _describe_feature_cols(desc_rows)
        fp_spec: dict[str, Any] = {
            "name": base_name,
            "version": version,
            "features": [{"output_column": c} for c in feature_cols],
        }
        content_hash = _structural_fingerprint_hash(fp_spec)
        kind = "StreamingFeatureView"
        qualifier = f"{db}.{schema_val}" if (db or schema_val) else ""
        key = f"{kind}:{qualifier}:{base_name}"

        objects[key] = AppliedObject(
            key=key,
            kind=kind,
            name=base_name,
            version=version,
            content_hash=content_hash,
            spec_payload=fp_spec,
            columns=[],
            from_specification=False,
        )

    # Entity AppliedObjects from SHOW TAGS.
    if entity_rows:
        for entity_row in entity_rows:
            ent_obj = _build_entity_object(entity_row, default_database, default_schema)
            if ent_obj is not None:
                objects[ent_obj.key] = ent_obj

    # Datasource AppliedObjects derived from FV specs.
    for ds_obj in _datasource_objects_from_specs(spec_payloads_for_datasources, default_database, default_schema):
        objects[ds_obj.key] = ds_obj

    return AppliedState(objects=objects)
