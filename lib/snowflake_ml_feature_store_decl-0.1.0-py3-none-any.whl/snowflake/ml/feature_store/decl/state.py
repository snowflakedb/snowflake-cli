"""Applied-state parser for the declarative feature store library.

Parses raw Snowflake query results into ``AppliedState``.
No connection access — accepts pre-fetched data.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Optional, Sequence

from snowflake.ml.feature_store.decl.invariants import (
    _full_spec_hash,
    _structural_fingerprint_hash,
)
from snowflake.ml.feature_store.decl.types import (
    AppliedObject,
    AppliedState,
    ObjectKind,
)
from snowflake.ml.feature_store.spec.enums import ENTITY_TAG_PREFIX

logger = logging.getLogger(__name__)

# OFT name separator character
_SEP = "$"
# Suffix appended to all online feature table names
_ONLINE_SUFFIX = "ONLINE"

# Legacy alias.  The canonical value lives in
# :data:`snowflake.ml.feature_store.spec.enums.ENTITY_TAG_PREFIX` (imported
# above).  Existing internal callers
# (``decl/exporter.py``, ``decl/api.py``, tests) reference the
# leading-underscore name; keeping this alias as a thin re-export means we do
# not have to chase every callsite, while the cross-module identity test
# (``spec/enums_test.py``) still passes because both names point at the same
# string object.
_ENTITY_TAG_PREFIX = ENTITY_TAG_PREFIX


# ---------------------------------------------------------------------------
# Offline-DT FROM-clause parser
# ---------------------------------------------------------------------------
#
# The deployed BatchFV SPECIFICATION JSON returned by ``DESCRIBE … TYPE =
# SPECIFICATION`` always has ``spec.sources = []`` — snowml-core's FROM
# SPECIFICATION serializer encodes the source binding into the offline
# Dynamic Table's ``SELECT * FROM <table>`` body, not into the spec
# payload.  ``fetch_applied_state`` therefore parses the DT's ``text``
# column (the ``CREATE DYNAMIC TABLE … AS SELECT … FROM …`` literal
# Snowflake stores) to recover the source-table identifier so the planner
# can distinguish a schedule-only edit (UPDATE_FV) from a source-table
# swap (RECREATE_FV).  See docs/BATCH_FV_BUG_BASH.md §7/§8.
#
# The regex matches the first ``FROM <identifier>`` after a case-insensitive
# word boundary and captures a dotted-identifier sequence whose parts may
# be either bare (``RAW_EVENTS``) or quoted (``"DB"."SCH"."RAW_EVENTS"``).
# The last identifier-part is the table; preceding parts (database +
# schema) are dropped to match the local-compile ``BatchSource.table``
# authoring shape (``table: RAW_EVENTS``, not ``DB.SCH.RAW_EVENTS``).

_FROM_CLAUSE_PATTERN = re.compile(
    r"\bFROM\s+("
    r'(?:"[^"]+"|\w+)'  # first part (quoted or bare)
    r'(?:\.(?:"[^"]+"|\w+))*'  # zero or more ``.part`` continuations
    r")",
    re.IGNORECASE | re.DOTALL,
)

# AS-body extractor for SHOW DYNAMIC TABLES ``text``. Snowflake records the
# full ``CREATE DYNAMIC TABLE … AS <body>`` statement; this regex pulls
# just ``<body>`` so the classifier below can decide whether to emit a
# ``table:``-shape or ``query:``-shape source binding on recovery.
#
# The greedy ``.*`` consumes everything up to the LAST ``\bAS\s+(SELECT|WITH)``
# in the text — the engine backtracks to find a valid kickoff. Column
# aliases like ``col AS alias`` cannot match because ``alias`` is not the
# ``SELECT`` / ``WITH`` keyword. Defined locally — the imperative library's
# _DT_OR_VIEW_QUERY_PATTERN is intentionally NOT imported per the wheel-
# isolation rule (decl must not depend on feature_store.feature_store).
_DT_AS_BODY_PATTERN = re.compile(
    r".*\bAS\s+(?P<body>(?:SELECT|WITH)\b.*)",
    re.IGNORECASE | re.DOTALL,
)

# Flat ``SELECT * FROM <single qualified ident>`` shape used by the
# table-recovery path. The existing imperative library compiles every
# table-only BatchFeatureView to exactly this shape, so the recovery side
# treats anything else (joins, WHERE, LIMIT, CTE, projection lists) as a
# query-backed source. Whitespace is normalized BEFORE this regex runs
# so author-side and Snowflake-side formatting differences don't change
# the classification.
_FLAT_SELECT_STAR_PATTERN = re.compile(
    r"^SELECT\s+\*\s+FROM\s+(" r'(?:"[^"]+"|\w+)' r'(?:\.(?:"[^"]+"|\w+))*' r")\s*$",
    re.IGNORECASE,
)

# Tiled-aggregation SELECT shape used by snowml-core for BatchFVs with
# windowed ``features`` (with or without ``aggregation_secondary_keys``).
# snowml-core generates an outer projection-plus-GROUP_BY around an inner
# ``SELECT * FROM <fqn>`` against the authored table.  The classifier
# below extracts the underlying ``<fqn>`` so the source binding recovered
# from DT text matches the local-compile shape (``BatchSource.table``)
# instead of falling into the catch-all "query" path with a binding that
# carries the entire generated SQL body.  Without this recovery every
# tiled BFV plan reports a phantom structural diff and ``UPDATE_FV`` on
# operational drift (e.g. a ``warehouse:`` edit) can never fire.
_TILED_AGG_PATTERN = re.compile(
    r"^SELECT\s+.+?\s+FROM\s+\(\s*SELECT\s+\*\s+FROM\s+("
    r'(?:"[^"]+"|\w+)(?:\.(?:"[^"]+"|\w+))*'
    r")\s*\)\s+GROUP\s+BY\b",
    re.IGNORECASE | re.DOTALL,
)


def _extract_dt_body_from_text(text: Any) -> Optional[str]:
    """Return the ``AS <body>`` portion of a DT ``text`` column, or None.

    Mirrors the imperative library's recovery shape (``feature_store.py``
    ``_DT_OR_VIEW_QUERY_PATTERN``) without importing it — the decl
    package must stay wheel-isolated. The body is returned verbatim
    (no whitespace normalization) so the caller can decide how to
    canonicalize it.

    Args:
        text: A ``CREATE DYNAMIC TABLE …`` statement string, or any
            value (including ``None``) that should map to ``None``.

    Returns:
        The ``<body>`` substring (everything from the kickoff
        ``SELECT`` / ``WITH`` to the end of ``text``), or ``None`` when
        the input is missing or has no recognisable AS body.
    """
    if not isinstance(text, str) or not text.strip():
        return None
    match = _DT_AS_BODY_PATTERN.match(text)
    if match is None:
        return None
    return match.group("body").strip()


def _classify_dt_body(body: Any) -> tuple[str, str]:
    """Classify a recovered DT body as ``table``-shape or ``query``-shape.

    The classifier is the single decision point for the recovery layer:

    * ``("table", <unqualified_ident>)`` — the body is a flat
      ``SELECT * FROM <single qualified table>``. The existing recovery
      path emits a ``sources[0].table`` binding using the unqualified
      last segment of the FROM identifier (matching the local-compile
      shape ``BatchSource.table``).
    * ``("query", <normalized_body>)`` — anything else (JOINs, WHERE,
      LIMIT, CTE, projection lists). The new recovery path emits a
      ``sources[0].query`` binding with the whitespace-normalized body
      so the planner / hash compares equal against a local-compile of
      ``BatchSource.query`` (Phase 3 :func:`compiler.normalize_sql_whitespace`).

    Args:
        body: A SQL body (the AS-portion of a CREATE DYNAMIC TABLE).
            Empty / non-string input is treated as a query-shape with an
            empty body so the caller can no-op consistently.

    Returns:
        Tuple of ``(shape, value)`` where ``shape`` is ``"table"`` or
        ``"query"`` and ``value`` is the recovered identifier or the
        normalized SQL body.
    """
    from snowflake.ml.feature_store.decl.compiler import normalize_sql_whitespace

    if not isinstance(body, str):
        return ("query", "")
    normalized = normalize_sql_whitespace(body)
    if not normalized:
        return ("query", "")
    match = _FLAT_SELECT_STAR_PATTERN.match(normalized)
    if match is None:
        tiled = _TILED_AGG_PATTERN.match(normalized)
        if tiled is None:
            return ("query", normalized)
        match = tiled
    fqn = match.group(1)
    parts = re.split(r"\.(?=(?:[^\"]|\"[^\"]*\")*$)", fqn)
    last = parts[-1].strip().strip('"').strip()
    if not last:
        return ("query", normalized)
    return ("table", last.upper())


def _extract_source_table_from_dt_text(text: Any) -> Optional[str]:
    """Pull the source table identifier from a SHOW DYNAMIC TABLES ``text`` row.

    The ``text`` column carries the full ``CREATE DYNAMIC TABLE … AS
    SELECT * FROM <fqn>`` body Snowflake recorded at create time.  This
    helper returns the unquoted, unqualified last segment of the FROM
    clause (e.g. ``RAW_EVENTS_BATCH_DECL``) so it can be injected into
    the applied FV's ``sources[0].table`` for parity with the local
    ``BatchSource`` YAML.

    The parser is intentionally permissive:

    * Quoted (``"DB"."SCH"."T"``), unquoted (``DB.SCH.T``), and bare
      (``T``) identifiers all yield the same unqualified table name.
    * Subqueries / inline views are not handled — declarative BatchFVs
      always compile to a flat ``SELECT * FROM <table>``.
    * Returns ``None`` on empty / non-string / no-FROM input so the
      caller can fall back to the parity-tolerance path without raising.

    Args:
        text: The raw ``text`` column value from a ``SHOW DYNAMIC
            TABLES`` row (or any string containing a ``FROM`` clause).

    Returns:
        The unqualified table name (uppercased to match the
        ``BatchSource`` round-trip canonicalisation), or ``None`` when
        no FROM clause is present.
    """
    if not isinstance(text, str) or not text.strip():
        return None
    match = _FROM_CLAUSE_PATTERN.search(text)
    if match is None:
        return None
    fqn = match.group(1)
    # Strip the leading database / schema qualifier (everything before
    # the last ``.``) to match the local-authoring ``table:`` shape
    # (BatchSource YAMLs declare ``table: RAW_EVENTS``, never the FQN).
    parts = re.split(r"\.(?=(?:[^\"]|\"[^\"]*\")*$)", fqn)
    last = parts[-1].strip().strip('"').strip()
    if not last:
        return None
    return last


# ---------------------------------------------------------------------------
# Advanced BFV DT-text parsers (cluster_by / refresh_mode / initialize /
# warehouse / storage_config).  Phase 2 of the advanced BFV plan adds the
# ``cluster_by`` helper; subsequent phases will add the rest at the same
# insertion point so a single ``_inject_advanced_bfv_fields_from_dt_text``
# fan-out can lift them all into ``spec_payload.spec.*`` on round-trip.
# ---------------------------------------------------------------------------

# ``CLUSTER BY (...)`` may appear on its own line or inline between TARGET_LAG
# and AS-body.  The body inside the parens is a comma-separated list of
# identifier expressions — bare (``USER_ID``), quoted (``"USER_ID"``), or
# qualified (``DB.SC.T.col``).  This regex captures the inner body verbatim;
# the caller splits / strips quotes.
_CLUSTER_BY_PATTERN = re.compile(
    r"\bCLUSTER\s+BY\s*\(\s*(?P<body>[^)]*?)\s*\)",
    re.IGNORECASE,
)

# ``REFRESH_MODE = '...'`` (or bare ``REFRESH_MODE = AUTO`` for the values
# Snowflake accepts unquoted).  Captures the inner value, stripping any
# surrounding single quotes, and uppercases it to match the imperative
# ``FeatureView`` enum.
_REFRESH_MODE_PATTERN = re.compile(
    r"\bREFRESH_MODE\s*=\s*'?([A-Za-z_]+)'?",
    re.IGNORECASE,
)

# ``INITIALIZE = '...'`` / bare ``INITIALIZE = ON_CREATE`` — mirrors
# the REFRESH_MODE pattern.  Accepted values: ``ON_CREATE`` / ``ON_SCHEDULE``.
_INITIALIZE_PATTERN = re.compile(
    r"\bINITIALIZE\s*=\s*'?([A-Za-z_]+)'?",
    re.IGNORECASE,
)


def _parse_cluster_by_from_dt_text(text: Any) -> Optional[list[str]]:
    """Return the ``CLUSTER BY`` column list from a DT ``text`` value, or None.

    The deployed Dynamic Table's ``text`` column carries the full
    ``CREATE DYNAMIC TABLE`` body Snowflake recorded at create time
    (matching the recovery shape used by
    :func:`_extract_source_table_from_dt_text`).  When the BFV was
    authored with ``cluster_by: [USER_ID, SESSION_ID]`` the body
    contains a ``CLUSTER BY ("USER_ID", "SESSION_ID")`` clause; this
    helper returns ``["USER_ID", "SESSION_ID"]`` (quote-stripped,
    whitespace-trimmed, preserving order).

    The parser is intentionally permissive:

    * Quoted, bare, and even qualified identifiers all yield the
      bare last segment (matching the authoring shape).
    * Missing / empty clauses return ``None`` so callers can fall
      through to the no-op recovery path.

    Args:
        text: The raw ``text`` column value from a ``SHOW DYNAMIC
            TABLES`` row.

    Returns:
        Ordered list of bare column identifiers, or ``None`` when the
        DT has no ``CLUSTER BY`` clause (or input is empty / non-string).
    """
    if not isinstance(text, str) or not text.strip():
        return None
    match = _CLUSTER_BY_PATTERN.search(text)
    if match is None:
        return None
    body = match.group("body")
    if not body or not body.strip():
        return None
    parts: list[str] = []
    for raw in body.split(","):
        token = raw.strip()
        if not token:
            continue
        segments = re.split(r"\.(?=(?:[^\"]|\"[^\"]*\")*$)", token)
        last = segments[-1].strip().strip('"').strip()
        if last:
            parts.append(last)
    return parts or None


def _parse_refresh_mode_from_dt_text(text: Any) -> Optional[str]:
    """Return the ``REFRESH_MODE`` value from a DT ``text`` column, or None.

    Accepts both quoted (``REFRESH_MODE = 'FULL'``) and bare
    (``REFRESH_MODE = AUTO``) clause forms.  The result is uppercased
    to match the canonical enum the imperative ``FeatureView``
    constructor accepts: ``AUTO`` / ``FULL`` / ``INCREMENTAL``.

    Args:
        text: The raw ``text`` column from a ``SHOW DYNAMIC TABLES`` row.

    Returns:
        Uppercased mode string, or ``None`` when the DT has no
        ``REFRESH_MODE`` clause (or input is empty / non-string).
    """
    if not isinstance(text, str) or not text.strip():
        return None
    match = _REFRESH_MODE_PATTERN.search(text)
    if match is None:
        return None
    value = match.group(1).strip().upper()
    return value or None


def _parse_initialize_from_dt_text(text: Any) -> Optional[str]:
    """Return the ``INITIALIZE`` value from a DT ``text`` column, or None.

    Accepts both quoted (``INITIALIZE = 'ON_SCHEDULE'``) and bare
    (``INITIALIZE = ON_CREATE``) clause forms.  Uppercased to match
    the imperative ``FeatureView(initialize=...)`` enum.

    Args:
        text: The raw ``text`` column from a ``SHOW DYNAMIC TABLES`` row.

    Returns:
        Uppercased initialize string, or ``None`` when the DT has no
        ``INITIALIZE`` clause (or input is empty / non-string).
    """
    if not isinstance(text, str) or not text.strip():
        return None
    match = _INITIALIZE_PATTERN.search(text)
    if match is None:
        return None
    value = match.group(1).strip().upper()
    return value or None


def _inject_advanced_bfv_fields_from_dt_text(
    spec_payload: dict[str, Any],
    dt_text_map: dict[str, str],
) -> None:
    """Inject recovered advanced-BFV fields into a BatchFV ``spec_payload.spec``.

    Mirrors :func:`_inject_batch_fv_source_from_dt_text` for the
    structural/operational fields that snowml-core does not stamp into
    the SPECIFICATION JSON: ``cluster_by`` (Phase 2 — landed),
    ``refresh_mode`` (Phase 3 — landed), ``initialize`` / ``warehouse``
    / ``storage_config`` (Phases 4-5 — pending).  Each helper is
    purely additive (silently no-ops when the clause is absent), so
    the resulting hash matches the local-compile shape only when the
    operator actually authored the field.

    Args:
        spec_payload: A BatchFV spec dict (the ``specification_map``
            value), mutated in place.
        dt_text_map: Mapping of DT name → ``CREATE DYNAMIC TABLE`` text.
    """
    inner = spec_payload.get("spec") if isinstance(spec_payload.get("spec"), dict) else None
    if inner is None:
        return
    offline_configs = spec_payload.get("offline_configs") or []
    if not (isinstance(offline_configs, list) and offline_configs):
        return
    first = offline_configs[0]
    if not isinstance(first, dict):
        return
    dt_name = first.get("table")
    if not isinstance(dt_name, str) or not dt_name:
        return
    dt_text = dt_text_map.get(dt_name)
    if not dt_text:
        return
    cluster_by = _parse_cluster_by_from_dt_text(dt_text)
    if cluster_by is not None and "cluster_by" not in inner:
        inner["cluster_by"] = cluster_by
    refresh_mode = _parse_refresh_mode_from_dt_text(dt_text)
    if refresh_mode is not None and "refresh_mode" not in inner:
        inner["refresh_mode"] = refresh_mode
    initialize = _parse_initialize_from_dt_text(dt_text)
    if initialize is not None and "initialize" not in inner:
        inner["initialize"] = initialize


def _inject_batch_fv_source_from_dt_text(
    spec_payload: dict[str, Any],
    dt_text_map: dict[str, str],
    *,
    datasources_by_table: Optional[dict[str, Any]] = None,
) -> None:
    """Inject ``sources[0]`` into a BatchFV spec_payload from DT text.

    The applied side's ``spec.sources`` is always empty for a BatchFV
    deployed via FROM SPECIFICATION (see :func:`fetch_applied_state`
    step 5). This helper looks up the FV's offline Dynamic Table by
    ``offline_configs[0].table``, extracts the AS-body, and routes
    through :func:`_classify_dt_body` to decide the source shape:

    * **table-shape** — the body is a flat ``SELECT * FROM <table>``.
      Emits ``{name: <logical_or_ident>, source_type: Batch, table:
      <ident>}``.  When *datasources_by_table* has a unique match for
      the recovered ident the recovered ``name`` is the operator's
      authored logical ``BatchSource.name`` (preserving the
      operator-facing round-trip even though the wire SPECIFICATION
      JSON hardcodes ``name="batch"`` and loses it).  Falls back to
      ``name = <ident>`` when no lookup is provided or no entry
      matches (cold-start ``snow feature init`` against a never-seen
      schema).  Multi-match (two local ``BatchSource`` YAMLs claim the
      same physical table) is a ``ValueError`` — the recovery cannot
      pick a logical name without guessing.
    * **query-shape** — anything else (joins, WHERE, LIMIT, CTE,
      projection lists). Emits ``{name: <FV>__SOURCE, source_type:
      Batch, query: <normalized body>}`` so the spec matches a YAML
      with ``BatchSource(query=…)`` once the local query is itself
      whitespace-normalized at compile time. (Phase 4 round-trip path.)
      The lookup does NOT apply to query-shape bodies — only flat
      ``SELECT * FROM <table>`` bodies have an unambiguous table
      identity to participate in the lookup contract.

    The synthetic ``<FV_NAME>__SOURCE`` name for query-backed sources
    sidesteps the spec-key collision that would result if two FVs
    happened to use the same recovered identifier — the FV name is
    unique per the planner's spec key contract.

    Silently no-ops when:

    * ``spec_payload`` has no ``spec.sources`` slot (defensive).
    * ``offline_configs[0].table`` is missing or not in ``dt_text_map``.
    * The DT text has no parseable AS body.

    Args:
        spec_payload: A BatchFV spec dict (the ``specification_map``
            value), mutated in place.
        dt_text_map: Mapping of DT name → ``CREATE DYNAMIC TABLE`` text
            (the ``text`` column from ``SHOW DYNAMIC TABLES``).
        datasources_by_table: Optional mapping of uppercased unqualified
            table ident → operator-authored logical ``BatchSource.name``
            (string) or, on multi-match, the list of conflicting names
            so the caller can raise loudly. Built by
            :func:`_build_datasources_by_table` from the local
            ``sources/datasources/`` tree. ``None`` falls back to the
            existing table-as-name behaviour (cold-start contract).

    Raises:
        ValueError: When *datasources_by_table* signals a multi-match
            (its value for the recovered table is a non-string
            iterable). The message names the offending table and the
            conflicting logical names.
    """
    inner = spec_payload.get("spec") if isinstance(spec_payload.get("spec"), dict) else None
    if inner is None:
        return
    offline_configs = spec_payload.get("offline_configs") or []
    if not (isinstance(offline_configs, list) and offline_configs):
        return
    first = offline_configs[0]
    if not isinstance(first, dict):
        return
    dt_name = first.get("table")
    if not isinstance(dt_name, str) or not dt_name:
        return
    dt_text = dt_text_map.get(dt_name)
    if not dt_text:
        return
    body = _extract_dt_body_from_text(dt_text)
    if body is None:
        return
    shape, value = _classify_dt_body(body)
    if shape == "table":
        logical_name = _resolve_logical_source_name(value, datasources_by_table)
        inner["sources"] = [
            {
                "name": logical_name,
                "source_type": "Batch",
                "table": value,
            }
        ]
        return
    if not value:
        return
    metadata = spec_payload.get("metadata") if isinstance(spec_payload.get("metadata"), dict) else {}
    fv_name = (metadata.get("name") or "").upper()
    synthetic_name = f"{fv_name}__SOURCE" if fv_name else "QUERY__SOURCE"
    inner["sources"] = [
        {
            "name": synthetic_name,
            "source_type": "Batch",
            "query": value,
        }
    ]


def _resolve_logical_source_name(
    recovered_table: str,
    datasources_by_table: Optional[dict[str, Any]],
) -> str:
    """Pick the operator-authored logical source name for *recovered_table*.

    Implements the "local-wins" conflict policy:

    * No lookup map (or empty map) → table-as-name fallback.
    * Unique string match → return the logical name.
    * Multi-match marker (list of names) → ``ValueError`` so the
      operator notices the ambiguity rather than getting a silently
      corrupted round-trip.
    * No match → table-as-name fallback (cold-start contract).
    """
    if not datasources_by_table:
        return recovered_table
    entry = datasources_by_table.get(recovered_table)
    if entry is None:
        return recovered_table
    if isinstance(entry, str):
        return entry
    # Anything non-string (list, tuple, set …) is the multi-match
    # collision marker emitted by ``_build_datasources_by_table``.
    if not isinstance(entry, (list, tuple, set)):
        return recovered_table
    candidates = sorted(str(c) for c in entry)
    raise ValueError(
        f"BatchFeatureView source-name recovery: physical table "
        f"'{recovered_table}' is claimed by multiple local "
        f"BatchSource YAMLs ({', '.join(candidates)}). Rename one of "
        "the conflicting BatchSource specs (or point them at distinct "
        "tables) so the export round-trip can pick an unambiguous "
        "logical name."
    )


def _build_datasources_by_table(specs: Sequence[Any]) -> dict[str, Any]:
    """Build a physical-table → logical-source-name lookup from local specs.

    Walks every spec in *specs* and indexes every ``BatchSource``
    (skipping query- / query_file-backed sources, which have no
    physical table identity) by the uppercased unqualified last segment
    of its ``table`` attribute.  This is the convention
    :func:`_classify_dt_body` uses for the recovered ident, so the
    lookup keys collide on identical objects regardless of YAML-side
    casing or qualification.

    Multi-match (two ``BatchSource`` YAMLs declaring the same physical
    table) is signalled by storing the list of conflicting logical
    names so the downstream recovery in
    :func:`_inject_batch_fv_source_from_dt_text` raises with both
    candidates in the message.

    Args:
        specs: Iterable of loaded specs (the ``SpecBatch.specs`` list
            from :func:`loader.load_from_project` is the typical
            input).  Non-``BatchSource`` entries are walked through
            without effect on the result.

    Returns:
        Dict keyed by the uppercased unqualified table ident.  Values
        are either ``str`` (unique match — the operator's authored
        logical name) or ``list[str]`` (multi-match collision marker,
        consumed by ``_resolve_logical_source_name``).
    """
    lookup: dict[str, Any] = {}
    for spec in specs:
        if getattr(spec, "kind", None) != "BatchSource":
            continue
        table = getattr(spec, "table", None)
        if not isinstance(table, str) or not table:
            continue
        # Match the recovered-ident convention in ``_classify_dt_body``:
        # uppercased, unqualified last segment.
        key = table.split(".")[-1].strip().strip('"').upper()
        if not key:
            continue
        name = getattr(spec, "name", "") or ""
        if not name:
            continue
        existing = lookup.get(key)
        if existing is None:
            lookup[key] = name
            continue
        if isinstance(existing, str):
            if existing == name:
                continue
            lookup[key] = [existing, name]
            continue
        if isinstance(existing, list):
            if name not in existing:
                existing.append(name)
    return lookup


# Map between the imperative ``list_feature_views().kind`` discriminator
# values (``BATCH`` / ``STREAMING`` / ``REALTIME``) and the canonical
# spec-payload ``kind`` strings the planner branches on.  The full set
# is enumerated here so an unknown value falls through to ``None``
# (caller skips the row) instead of synthesising an invalid kind.
_FV_KIND_MAP: dict[str, str] = {
    "BATCH": "BatchFeatureView",
    "STREAMING": "StreamingFeatureView",
    "REALTIME": "RealtimeFeatureView",
}


def _build_offline_fv_object(
    fv_row: dict[str, Any],
    *,
    dt_text_map: Optional[dict[str, str]],
    default_database: str,
    default_schema: str,
    datasources_by_table: Optional[dict[str, Any]] = None,
) -> Optional[AppliedObject]:
    """Build an ``AppliedObject`` for an offline-only FV from a list-FV row.

    Reconstructs the SPECIFICATION-equivalent ``spec_payload`` from
    the imperative ``list_feature_views()`` row (see Phase 1 contract)
    + offline DT text (for source-table recovery) so the planner's
    BatchFV branches resolve identically against the offline subset
    they resolve for the online (OFT-backed) subset.

    The reconstruction satisfies the hash-equivalence invariant
    ``_full_spec_hash(applied_payload) == _compute_local_spec_hash(local)``
    on a clean round-trip — the gating condition for ``NO_CHANGE``
    detection on the second plan after a successful offline-only
    apply.

    Args:
        fv_row: A row dict in the Phase-1 contract shape.  Must carry
            ``name``, ``version``, ``database_name``, ``schema_name``,
            ``kind``, ``entities``, ``physical_dt_name``, and
            ``target_lag``.
        dt_text_map: Optional mapping of DT name → ``CREATE DYNAMIC
            TABLE`` text.  Used to recover ``spec.sources[0].table``
            when present; absent / empty falls through to a sourceless
            payload that still hash-equals an unchanged local YAML
            once the planner's ``_normalise_fv_sources_for_hash``
            normalisation projects both sides to ``[]``.
        default_database: Fallback database when the row omits one.
        default_schema: Fallback schema when the row omits one.
        datasources_by_table: Optional physical → logical source-name
            lookup. Forwarded to
            :func:`_inject_batch_fv_source_from_dt_text` so the
            recovered ``sources[0].name`` preserves the operator's
            authored ``BatchSource.name`` instead of stamping the
            recovered physical table identifier.

    Returns:
        An ``AppliedObject(from_specification=True)`` carrying a
        BatchFV-shaped ``spec_payload``, or ``None`` when the row is
        missing required fields or the kind is unrecognised.
    """
    from snowflake.ml.feature_store.decl.compiler import parse_duration_to_seconds

    name = fv_row.get("name") or ""
    version = fv_row.get("version") or ""
    if not name or not version:
        logger.debug("Skipping offline FV row with missing name/version: %r", fv_row)
        return None

    kind_raw = (fv_row.get("kind") or "").upper()
    kind = _FV_KIND_MAP.get(kind_raw)
    if kind is None:
        logger.debug("Skipping offline FV row with unknown kind=%r: %s/%s", kind_raw, name, version)
        return None

    db = fv_row.get("database_name") or default_database
    schema_val = fv_row.get("schema_name") or default_schema
    physical_dt = fv_row.get("physical_dt_name") or f"{name}{_SEP}{version}"

    entities_raw = fv_row.get("entities") or []
    if isinstance(entities_raw, str):
        try:
            entities_list = json.loads(entities_raw)
        except (TypeError, ValueError):
            entities_list = []
    elif isinstance(entities_raw, list):
        entities_list = entities_raw
    else:
        entities_list = []
    entities = [str(e) for e in entities_list if e is not None]

    target_lag_sec: Optional[int] = None
    target_lag_raw: Optional[str] = None
    # The imperative ``list_feature_views()`` row reports the deployed DT
    # cadence under ``REFRESH_FREQ`` (the column ``SHOW DYNAMIC TABLES``
    # populates).  Older callers shipped ``target_lag`` directly on the
    # row.  Accept both, preferring an explicit ``target_lag`` when set
    # — the live shape always populates ``refresh_freq`` and leaves
    # ``target_lag`` empty, so without this fallback ``_build_offline_fv_object``
    # would emit a payload missing the DT cadence and the planner
    # would surface a phantom ``UPDATE_FV`` on every replan after a clean
    # offline-only apply.
    raw_value = fv_row.get("target_lag") or fv_row.get("refresh_freq")
    if raw_value:
        target_lag_raw = str(raw_value)
        try:
            target_lag_sec = parse_duration_to_seconds(raw_value)
        except Exception:  # noqa: BLE001 — defensive: malformed cadence string
            target_lag_sec = None

    inner_spec: dict[str, Any] = {
        "ordered_entity_column_names": entities,
        "sources": [],
        "features": [],
    }
    # Surface the deployed DT cadence in BOTH keys on the applied side
    # so downstream consumers see what they expect:
    # * ``target_lag_sec`` — the wire-form key the planner's full-spec
    #   hash already understands (``_full_spec_hash`` reads it).  Kept
    #   for hash-equivalence with deployed SPECIFICATION payloads.
    # * ``batch_schedule`` — the authoring-form key the exporter writes
    #   to YAML and ``_batch_fv_operational_drift`` compares against
    #   the local authoring spec.  Without this, an exported BFV YAML
    #   would lose its DT-refresh cadence on round-trip.
    if target_lag_sec is not None:
        inner_spec["target_lag_sec"] = target_lag_sec
    if target_lag_raw is not None:
        inner_spec["batch_schedule"] = target_lag_raw

    # When the imperative-side enrichment supplied a full FeatureViewSpec
    # dict (``spec_text``), use it verbatim — it carries the same shape
    # ``DESCRIBE … TYPE = SPECIFICATION`` would have returned for the
    # online subset (entities, sources, features, timestamp_field,
    # feature_granularity_sec, aggregation_secondary_keys, cluster_by,
    # refresh_mode, initialize, target_lag_sec).  This closes the hash
    # round-trip gap for offline-only BatchFVs that otherwise hash an
    # empty ``features`` list against a fully-populated local-compile.
    spec_text = fv_row.get("spec_text") if isinstance(fv_row, dict) else None
    if isinstance(spec_text, dict) and spec_text:
        spec_payload: dict[str, Any] = dict(spec_text)
        # Ensure ``offline_configs[0].table`` matches the physical DT name
        # so the DT-text helpers can look it up.  The enrichment path
        # already populates this from ``_build_batch_fv_spec``; we set it
        # defensively here for the corner case where the metadata is
        # absent.
        if not spec_payload.get("offline_configs"):
            spec_payload["offline_configs"] = [
                {
                    "store_type": "snowflake",
                    "table_type": "BatchTable",
                    "database": db,
                    "schema": schema_val,
                    "table": physical_dt,
                    "columns": [],
                }
            ]
    else:
        # Reconstruct ``offline_configs[0].table = <physical_dt_name>`` so
        # the existing ``_inject_batch_fv_source_from_dt_text`` helper can
        # look the offline DT up by the same key the manager populates in
        # ``dt_text_map``.  ``offline_configs`` is stripped before hashing
        # by ``_DERIVED_TOP_LEVEL_KEYS`` so it never contributes to
        # ``content_hash``; its only purpose is the source-recovery
        # lookup.
        spec_payload = {
            "kind": kind,
            "metadata": {
                "database": db,
                "schema": schema_val,
                "name": name,
                "version": version,
                "spec_format_version": "1",
                "internal_data_version": "1",
                "client_version": "0.1.0",
            },
            "offline_configs": [
                {
                    "store_type": "snowflake",
                    "table_type": "BatchTable",
                    "database": db,
                    "schema": schema_val,
                    "table": physical_dt,
                    "columns": [],
                }
            ],
            "spec": inner_spec,
        }

    if kind == "BatchFeatureView" and dt_text_map:
        _inject_batch_fv_source_from_dt_text(
            spec_payload,
            dt_text_map,
            datasources_by_table=datasources_by_table,
        )
        _inject_advanced_bfv_fields_from_dt_text(spec_payload, dt_text_map)

    content_hash = _full_spec_hash(spec_payload)
    key = _build_spec_key(kind, spec_payload)
    return AppliedObject(
        key=key,
        kind=kind,
        name=name,
        version=version,
        content_hash=content_hash,
        spec_payload=spec_payload,
        columns=[],
        from_specification=True,
    )


def _parse_oft_name(name: str) -> tuple[str, str]:
    """Extract ``(base_name, version)`` from an OFT name.

    The naming convention is ``<base_name>$<version>$ONLINE``.
    Falls back to splitting on the last ``$`` if the ``$ONLINE``
    suffix is absent (handles malformed or legacy names gracefully).

    Args:
        name: The raw OFT name string from Snowflake.

    Returns:
        Tuple of ``(base_name, version)``.
    """
    parts = name.split(_SEP)
    if len(parts) >= 3 and parts[-1] == _ONLINE_SUFFIX:
        # Standard: BASE$VERSION$ONLINE
        version = parts[-2]
        base = _SEP.join(parts[:-2])
        return base, version
    if len(parts) >= 2:
        # Fallback: BASE$VERSION
        version = parts[-1]
        base = _SEP.join(parts[:-1])
        return base, version
    # No separator — treat whole name as base, empty version
    return name, ""


def _extract_spec_from_oft(row: dict[str, Any]) -> Optional[dict]:
    """Extract and parse the embedded JSON specification from an OFT row.

    Args:
        row: A single row from ``SHOW ONLINE FEATURE TABLES`` results.

    Returns:
        Parsed spec dict, or ``None`` if the specification column is missing
        or contains invalid JSON.
    """
    raw = row.get("specification", "")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        logger.debug("Could not parse specification JSON for row: %s", row.get("name", "?"))
        return None


def _build_spec_key(kind: str, spec: dict) -> str:
    """Build a canonical ``kind:DATABASE.SCHEMA:NAME`` key from spec metadata.

    Mirrors :func:`snowflake.ml.feature_store.decl.invariants._spec_key` so
    the planner's batch-side keys (uppercased) and the applied-state side
    keys collide on identical objects.  Without this normalisation,
    full-directory mode treats every FV as both "new" *and* "orphaned"
    when the deployed name (e.g. ``user_profile_info``) and the local YAML
    name (e.g. ``USER_PROFILE_INFO``) differ only in case, which produces
    spurious ``CREATE_FV`` + ``DROP_FV`` ops on a clean round-trip.

    Args:
        kind: The object kind string.
        spec: The parsed spec dict (may contain a ``metadata`` sub-dict).

    Returns:
        Canonical key string with database, schema, and name uppercased.
    """
    metadata = spec.get("metadata", spec)
    db = (metadata.get("database", "") or spec.get("database", "") or "").upper()
    schema = (metadata.get("schema", "") or spec.get("schema", "") or "").upper()
    name = (metadata.get("name", "") or spec.get("name", "") or "").upper()
    qualifier = f"{db}.{schema}" if (db or schema) else ""
    return f"{kind}:{qualifier}:{name}"


def _describe_feature_cols(desc_rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Extract non-primary-key columns from ``DESCRIBE ONLINE FEATURE TABLE`` rows.

    Primary key columns are the entity/join-key columns.  The remaining columns
    are the feature output columns that form the structural fingerprint.

    Args:
        desc_rows: Rows from ``DESCRIBE ONLINE FEATURE TABLE``.

    Returns:
        List of ``{"name": col_name, "type": col_type}`` dicts for feature cols.
    """
    cols: list[dict[str, str]] = []
    for col in desc_rows:
        is_pk = False
        for pk_key in ("primary key", "PRIMARY KEY", "primary_key", "PRIMARY_KEY"):
            val = col.get(pk_key, "")
            if val and str(val).upper() in ("Y", "YES", "TRUE", "1"):
                is_pk = True
                break
        # Positional fallback: 5th value (index 4) == "Y" (mirrors exporter.py).
        if not is_pk:
            raw_vals = list(col.values())
            if len(raw_vals) >= 5 and raw_vals[4] == "Y":
                is_pk = True

        if not is_pk:
            col_name = col.get("name") or col.get("NAME") or ""
            col_type = col.get("type") or col.get("TYPE") or ""
            if col_name:
                cols.append({"name": col_name, "type": col_type})
    return cols


def parse_specification_rows(
    rows: Optional[list[dict[str, Any]]],
) -> Optional[dict[str, Any]]:
    """Parse rows returned by ``DESCRIBE ... TYPE = SPECIFICATION``.

    The new SQL primitive returns a single row carrying the original spec
    JSON used to create the Online Feature Table.  Different Snowflake
    cursor adapters expose the column under different names
    (``specification``, ``SPECIFICATION``, or simply the first string
    column), so this helper checks all of them and falls back to scanning
    for a single string value that parses as JSON.

    Args:
        rows: Raw rows (list of dicts) from the SQL execution.

    Returns:
        Parsed spec JSON dict, or ``None`` if no row contained a parseable
        spec.
    """
    if not rows:
        return None

    for row in rows:
        if not isinstance(row, dict):
            continue
        # Try the obvious column names first.
        candidates: list[Any] = []
        for col in ("specification", "SPECIFICATION", "Specification"):
            if col in row and row[col]:
                candidates.append(row[col])
        # Fall back to the first string-valued cell.
        if not candidates:
            for value in row.values():
                if isinstance(value, str) and value.strip():
                    candidates.append(value)
                    break
        for raw in candidates:
            if not isinstance(raw, str):
                continue
            try:
                parsed = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                continue
            if isinstance(parsed, dict):
                return parsed
    return None


def _build_entity_object(
    row: dict[str, Any],
    default_db: str,
    default_schema: str,
) -> Optional[AppliedObject]:
    """Build an Entity ``AppliedObject`` from a ``SHOW TAGS`` row."""
    raw_name = row.get("name") or row.get("NAME") or ""
    if not raw_name:
        return None
    if not raw_name.startswith(_ENTITY_TAG_PREFIX):
        return None
    # Entity names match the join-key column.  Uppercase for round-trip
    # parity with :func:`invariants._spec_key` (which uppercases names so
    # casing differences between authoring YAML and Snowflake identifiers
    # collapse to a single canonical key).
    entity_name = raw_name[len(_ENTITY_TAG_PREFIX) :].upper()
    db = (row.get("database_name") or row.get("DATABASE_NAME") or default_db or "").upper()
    schema_val = (row.get("schema_name") or row.get("SCHEMA_NAME") or default_schema or "").upper()
    qualifier = f"{db}.{schema_val}" if (db or schema_val) else ""
    key = f"{ObjectKind.ENTITY}:{qualifier}:{entity_name}"

    join_keys: list[str] = []
    raw_allowed = row.get("allowed_values") or row.get("ALLOWED_VALUES") or row.get("allowed_values_list")
    if raw_allowed:
        if isinstance(raw_allowed, list):
            join_keys = [str(v) for v in raw_allowed]
        elif isinstance(raw_allowed, str):
            try:
                parsed = json.loads(raw_allowed)
                if isinstance(parsed, list):
                    join_keys = [str(v) for v in parsed]
            except (json.JSONDecodeError, TypeError):
                join_keys = [v.strip() for v in raw_allowed.strip("[]").split(",") if v.strip()]

    details: dict[str, Any] = {"join_keys": join_keys}
    comment = row.get("comment") or row.get("COMMENT") or ""
    if comment:
        details["comment"] = comment

    spec_payload: dict[str, Any] = {
        "kind": ObjectKind.ENTITY,
        "name": entity_name,
        "database": db,
        "schema": schema_val,
        "join_keys": [{"name": jk, "type": "StringType"} for jk in join_keys],
    }
    # Surface the deployed tag's COMMENT under ``description`` so the
    # Entity-aware branch of :func:`_structural_fingerprint` (which folds
    # description into the hash) sees the same value the local YAML's
    # ``description:`` produces.  Without this an unedited re-plan would
    # emit a phantom ``UPDATE_ENTITY`` after the fingerprint widen — see
    # ``plans/step11_update_entity_bug_*.plan.md``.
    if comment:
        spec_payload["description"] = comment

    # Match the planner's diff strategy: it hashes Entity/Source specs via
    # :func:`_structural_fingerprint_hash`, so the applied side must use the
    # same so a re-applied YAML hashes identically and emits ``NO_CHANGE``.
    content_hash = _structural_fingerprint_hash(spec_payload)

    return AppliedObject(
        key=key,
        kind=ObjectKind.ENTITY,
        name=entity_name,
        version=None,
        content_hash=content_hash,
        spec_payload=spec_payload,
        columns=[],
        from_specification=False,
        details=details,
    )


def _build_stream_source_object(
    row: dict[str, Any],
    default_db: str,
    default_schema: str,
) -> AppliedObject:
    """Build a Datasource ``AppliedObject`` from a runtime stream-source row.

    Companion to :func:`_datasource_objects_from_specs`: that function
    derives ``Datasource`` entries by unioning ``spec.sources[]`` across
    every recovered FV; this one reifies a single row produced by
    :func:`imperative_executor.fetch_stream_source_rows` (i.e. by
    ``FeatureStore.list_stream_sources()``).  The returned object's
    ``key`` and ``spec_payload`` shape match the FV-derived counterpart
    so that a downstream merge step in :func:`fetch_applied_state` can
    dedup the two paths by ``AppliedObject.key`` without any field-level
    coercion.  See ``plans/stream_source_contract.md`` §5a for the
    pinned contract.

    The ``"type"`` (REST vs other producer-protocol) key is deliberately
    omitted because the runtime metadata does not record it.  The diff
    helper ``invariants._compute_source_diff_kind`` strips ``"type"``
    from the local payload before the structural-fingerprint comparison
    so a clean round-trip still resolves to ``"no_change"`` (see
    contract §2 and §5a).

    Args:
        row: A single canonical row dict with keys ``name`` (str),
            ``schema`` (list of ``{"name", "type"}`` dicts), ``desc``
            (str), ``owner`` (str).  Missing ``desc`` is treated as
            empty string.
        default_db: Database to use for the canonical key (uppercased).
            Sourced from the active connection context by every other
            applied-state builder.
        default_schema: Schema to use for the canonical key
            (uppercased).

    Returns:
        ``AppliedObject(kind="Datasource")`` whose ``spec_payload``
        matches the shape :func:`_datasource_objects_from_specs`
        produces for the same logical source.
    """
    name_upper = (row.get("name") or "").upper()
    db_upper = (default_db or "").upper()
    schema_upper = (default_schema or "").upper()
    columns = row.get("schema") or []
    description = row.get("desc", "") or ""

    spec_payload: dict[str, Any] = {
        "kind": ObjectKind.DATASOURCE,
        "name": name_upper,
        "database": db_upper,
        "schema": schema_upper,
        "source_type": "Stream",
        "columns": columns,
        "description": description,
    }
    content_hash = _structural_fingerprint_hash(spec_payload)
    key = f"{ObjectKind.DATASOURCE}:{db_upper}.{schema_upper}:{name_upper}"
    details: dict[str, Any] = {
        "source_type": "Stream",
        "column_count": len(columns) if isinstance(columns, list) else 0,
    }
    return AppliedObject(
        key=key,
        kind=ObjectKind.DATASOURCE,
        name=name_upper,
        version=None,
        content_hash=content_hash,
        spec_payload=spec_payload,
        columns=[],
        from_specification=True,
        details=details,
    )


def _datasource_objects_from_specs(
    fv_specs: list[dict[str, Any]],
    default_db: str,
    default_schema: str,
) -> list[AppliedObject]:
    """Derive Datasource AppliedObjects by unioning ``spec.sources[]``.

    Datasources are virtual: they are not separately registered in
    Snowflake.  The runtime contract for them lives inside each FV's
    ``spec.sources[]`` block.  This function deduplicates by name and emits
    one ``AppliedObject(kind="Datasource")`` per unique source.

    Args:
        fv_specs: Parsed feature view spec JSON documents (the return
            value of :func:`parse_specification_rows` for each OFT).
        default_db: Database to use when a source's metadata is missing.
        default_schema: Schema to use when a source's metadata is missing.

    Returns:
        List of ``AppliedObject`` instances, one per unique datasource.
    """
    by_name: dict[str, AppliedObject] = {}
    for fv_spec in fv_specs:
        if not isinstance(fv_spec, dict):
            continue
        inner = fv_spec.get("spec") if isinstance(fv_spec.get("spec"), dict) else fv_spec
        sources = inner.get("sources", []) if isinstance(inner, dict) else []
        if not isinstance(sources, list):
            continue
        metadata = fv_spec.get("metadata") if isinstance(fv_spec.get("metadata"), dict) else {}
        db = (metadata.get("database") or default_db or "").upper()
        schema_val = (metadata.get("schema") or default_schema or "").upper()
        qualifier = f"{db}.{schema_val}" if (db or schema_val) else ""

        for src in sources:
            if not isinstance(src, dict):
                continue
            src_name = src.get("name", "")
            if not src_name:
                continue
            # Uppercase for round-trip parity with :func:`invariants._spec_key`
            # — the same source name in two FVs (one upper, one lower)
            # canonicalises to one AppliedObject and one key.
            canonical_name = src_name.upper()
            dedupe_key = canonical_name
            if dedupe_key in by_name:
                continue
            source_type = src.get("source_type") or src.get("type") or ""
            columns = src.get("columns", [])
            details: dict[str, Any] = {"source_type": source_type}
            if isinstance(columns, list):
                details["column_count"] = len(columns)

            # ``table`` is preserved on the Datasource AppliedObject so a
            # downstream ``BatchSource`` YAML with a matching ``table:``
            # round-trips to ``NO_CHANGE``.  For BatchFVs the value comes
            # from :func:`_inject_batch_fv_source_from_dt_text` (parsed
            # from the offline DT's ``SELECT … FROM …`` body); for
            # streaming sources the spec already preserves it.  Falls
            # through to absent when neither path supplied a binding.
            table = src.get("table") if isinstance(src.get("table"), str) else ""

            spec_payload: dict[str, Any] = {
                "kind": ObjectKind.DATASOURCE,
                "name": canonical_name,
                "database": db,
                "schema": schema_val,
                "source_type": source_type,
                "columns": columns,
            }
            if table:
                spec_payload["table"] = table
            # Match the planner's diff strategy: structural fingerprint, not
            # raw payload hash, so a re-applied YAML matches and emits
            # ``NO_CHANGE`` instead of a spurious recreate.
            content_hash = _structural_fingerprint_hash(spec_payload)
            key = f"{ObjectKind.DATASOURCE}:{qualifier}:{canonical_name}"

            by_name[dedupe_key] = AppliedObject(
                key=key,
                kind=ObjectKind.DATASOURCE,
                name=canonical_name,
                version=None,
                content_hash=content_hash,
                spec_payload=spec_payload,
                columns=[],
                from_specification=True,
                details=details,
            )
    return list(by_name.values())


def fetch_applied_state(
    raw_show_results: list[dict[str, Any]],
    raw_table_results: Optional[list[dict[str, Any]]] = None,
    describe_map: Optional[dict[str, list[dict[str, Any]]]] = None,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
    entity_rows: Optional[list[dict[str, Any]]] = None,
    dt_text_map: Optional[dict[str, str]] = None,
    feature_view_rows: Optional[list[dict[str, Any]]] = None,
    feature_group_rows: Optional[list[dict[str, Any]]] = None,
    stream_source_rows: Optional[list[dict[str, Any]]] = None,
    datasources_by_table: Optional[dict[str, Any]] = None,
    default_database: str = "",
    default_schema: str = "",
) -> AppliedState:
    """Parse raw Snowflake query results into an ``AppliedState`` snapshot.

    Steps:

    1. Parse ``SHOW ONLINE FEATURE TABLES`` rows → extract name/version from
       the ``$version$ONLINE`` naming convention.
    2. If ``specification_map[name]`` is present, use the full spec JSON as
       the canonical ``spec_payload`` and mark
       ``from_specification=True``.  This enables full-spec diffs.
    3. Otherwise try to extract embedded spec JSON from the
       ``specification`` column on the SHOW row (legacy path), then fall
       back to reconstructing state from ``describe_map`` columns
       (structural-fingerprint path).
    4. If ``entity_rows`` is provided, build one ``AppliedObject`` per
       entity tag.
    5. **BatchFV source-binding recovery**: when ``dt_text_map`` resolves
       the offline DT for an FV (matched on ``offline_configs[0].table``),
       parse the FROM clause out of the DT body and inject
       ``sources[0].table`` into the FV's ``spec_payload`` before
       hashing.  This is the parity fix for the deployed BatchFV
       ``DESCRIBE TYPE = SPECIFICATION`` JSON, which always returns
       ``spec.sources = []`` (snowml-core's FROM SPECIFICATION serializer
       encodes the source into the DT's SELECT body, not the spec).
       Without this step ``_full_spec_hash(local) != applied.content_hash``
       *always* and the planner can't distinguish a schedule-only edit
       (UPDATE_FV) from a source-table swap (RECREATE_FV).  See
       docs/BATCH_FV_BUG_BASH.md §7/§8.
    6. Derive ``Datasource`` AppliedObjects from a runtime-authoritative
       merge of two sources (see ``plans/stream_source_contract.md``
       §5b): first, one ``Datasource`` per row in ``stream_source_rows``
       via :func:`_build_stream_source_object` (registered stream
       sources from :func:`FeatureStore.list_stream_sources`); then
       the FV-derived entries from
       :func:`_datasource_objects_from_specs` are inserted only when
       their key is not already taken (runtime wins on collision).
       ``stream_source_rows=None`` falls back to the FV-derived-only
       behaviour so every existing call site that does not yet
       thread the new kwarg works unchanged.

    Args:
        raw_show_results: Rows from ``SHOW ONLINE FEATURE TABLES``.
        raw_table_results: Rows from ``SHOW TABLES`` for offline table
            existence checks (currently unused in v0, reserved for future
            use).
        describe_map: Optional mapping of OFT name → ``DESCRIBE ONLINE
            FEATURE TABLE`` rows (column-only).  Used as the fallback when
            a specification is unavailable.
        specification_map: Optional mapping of OFT name → parsed spec JSON
            from ``DESCRIBE ... TYPE = SPECIFICATION``.  When present, this
            is the authoritative source for the FV's spec_payload.
        entity_rows: Optional rows from
            ``SHOW TAGS LIKE 'SNOWML_FEATURE_STORE_ENTITY_%'``.  Each row
            becomes an ``AppliedObject(kind="Entity")``.
        dt_text_map: Optional mapping of Dynamic-Table name → the ``text``
            column from ``SHOW DYNAMIC TABLES``.  Used to recover the
            BatchFV source-table binding the deployed SPECIFICATION JSON
            drops (see step 5).  Passing an empty map (or ``None``)
            falls through to the legacy lossy behaviour — the planner's
            ``batch_feature_view_structural_equivalent`` then handles the
            parity tolerance.
        feature_view_rows: Optional list of FV rows in the Phase-1
            contract shape (see
            :func:`imperative_executor.fetch_feature_view_rows` and
            ``plans/offline_bfv_state_fix_b9da0006.plan.md`` Section 7).
            Surfaces offline-only ``BatchFeatureView``s that
            ``SHOW ONLINE FEATURE TABLES`` cannot enumerate.  When the
            same FV appears in both ``raw_show_results`` and
            ``feature_view_rows``, the OFT-derived path is
            authoritative and the ``feature_view_rows`` entry is
            silently skipped — the new path is purely additive for
            the offline subset.
        feature_group_rows: Optional list of FG rows in the contract
            shape returned by
            :func:`imperative_executor.fetch_feature_group_rows`.
            Each row becomes an ``AppliedObject(kind="FeatureGroup")``.
            ``None`` and ``[]`` are equivalent (no FG entries
            contributed to the snapshot).  The kind is fully
            imperative — there is no ``SHOW FEATURE GROUPS`` SQL —
            so without this kwarg an FG that exists in the runtime
            never makes it into the applied-state snapshot and the
            planner re-emits a spurious ``CREATE_FG`` on every plan.
        stream_source_rows: Optional list of registered stream-source
            rows in the canonical shape returned by
            :func:`imperative_executor.fetch_stream_source_rows`
            (``{"name", "schema", "desc", "owner"}``).  Each row is
            reified as one ``AppliedObject(kind="Datasource")`` via
            :func:`_build_stream_source_object` and merged with the
            FV-derived ``Datasource`` entries from
            :func:`_datasource_objects_from_specs`.  The merge is
            runtime-authoritative: when both paths surface the same
            ``Datasource:DB.SCHEMA:NAME`` key, the runtime row wins
            and the FV-derived shape is skipped.  ``None`` (the
            default) falls back to the FV-derived-only behaviour for
            back-compat with every existing call site.  ``None`` and
            ``[]`` are equivalent — both contribute zero runtime
            ``Datasource`` entries.
        datasources_by_table: Optional mapping of uppercased
            unqualified physical table ident → operator-authored
            logical ``BatchSource.name``. Built by
            :func:`_build_datasources_by_table` from the local
            ``sources/datasources/`` tree. When provided, the BatchFV
            source-binding recovery (step 5) prefers the local logical
            name over the recovered physical table identifier — closing
            the export round-trip where operators saw ``MISSING_SOURCE``
            on every re-plan after ``snow feature init`` rewrote
            ``sources[0].name`` to the underlying table name.  ``None``
            (the default) falls back to the legacy table-as-name
            behaviour, preserving cold-start ``init`` against a
            never-seen schema.
        default_database: Database to use when a row does not include one.
        default_schema: Schema to use when a row does not include one.

    Returns:
        AppliedState snapshot with all deployed objects (FVs + Entities +
        derived Datasources).
    """
    objects: dict[str, AppliedObject] = {}
    spec_payloads_for_datasources: list[dict[str, Any]] = []

    for row in raw_show_results:
        oft_name = row.get("name", "")
        if not oft_name:
            continue

        base_name, version = _parse_oft_name(oft_name)

        # Path 1: Full spec JSON via DESCRIBE TYPE = SPECIFICATION.
        spec = None
        from_spec = False
        if specification_map is not None:
            spec = specification_map.get(oft_name)
            if spec is not None:
                from_spec = True

        # Path 2: Legacy embedded specification column on the SHOW row.
        if spec is None:
            spec = _extract_spec_from_oft(row)

        if spec is not None:
            kind = spec.get("kind", "StreamingFeatureView")
            metadata = spec.get("metadata", {}) if isinstance(spec.get("metadata"), dict) else {}
            db = metadata.get("database", "") or row.get("database_name", "") or default_database
            schema_val = metadata.get("schema", "") or row.get("schema_name", "") or default_schema

            spec_payload: dict[str, Any]
            if from_spec:
                spec_payload = dict(spec)
                if "metadata" not in spec_payload:
                    spec_payload["metadata"] = {
                        "database": db,
                        "schema": schema_val,
                        "name": base_name,
                        "version": version,
                    }
                # BatchFV source-binding recovery (see step 5 above).  We
                # mutate ``spec_payload["spec"]["sources"]`` BEFORE
                # hashing so the resulting ``content_hash`` reflects the
                # injected ``table`` — that is what makes
                # ``_full_spec_hash(local) == applied.content_hash`` hold
                # on a clean round trip for BatchFVs.
                if kind == "BatchFeatureView" and dt_text_map:
                    _inject_batch_fv_source_from_dt_text(
                        spec_payload,
                        dt_text_map,
                        datasources_by_table=datasources_by_table,
                    )
                    _inject_advanced_bfv_fields_from_dt_text(spec_payload, dt_text_map)
                content_hash = _full_spec_hash(spec_payload)
                spec_payloads_for_datasources.append(spec_payload)
            else:
                # Legacy embedded-specification path → flatten for fingerprint.
                spec_payload = {
                    "kind": kind,
                    "name": base_name,
                    "version": version,
                    "database": db,
                    "schema": schema_val,
                }
                inner_spec = spec.get("spec", {})
                if isinstance(inner_spec, dict):
                    spec_payload.update(inner_spec)
                content_hash = _structural_fingerprint_hash(spec_payload)

            key = _build_spec_key(
                kind,
                {
                    "database": db,
                    "schema": schema_val,
                    "name": base_name,
                },
            )
            objects[key] = AppliedObject(
                key=key,
                kind=kind,
                name=base_name,
                version=version,
                content_hash=content_hash,
                spec_payload=spec_payload,
                columns=[],
                from_specification=from_spec,
            )
            continue

        # Path 3: DESCRIBE-only fallback (structural fingerprint).
        if describe_map is None:
            logger.debug("Skipping OFT row with no parseable specification: %s", oft_name)
            continue
        desc_rows = describe_map.get(oft_name)
        if not desc_rows:
            logger.debug(
                "Skipping OFT row: no specification and no describe_map entry for %s",
                oft_name,
            )
            continue

        db = row.get("database_name", "") or default_database
        schema_val = row.get("schema_name", "") or default_schema

        feature_cols = _describe_feature_cols(desc_rows)
        fp_spec: dict[str, Any] = {
            "name": base_name,
            "version": version,
            "features": [{"output_column": c} for c in feature_cols],
        }
        content_hash = _structural_fingerprint_hash(fp_spec)
        kind = "StreamingFeatureView"
        qualifier = f"{db}.{schema_val}" if (db or schema_val) else ""
        key = f"{kind}:{qualifier}:{base_name}"

        objects[key] = AppliedObject(
            key=key,
            kind=kind,
            name=base_name,
            version=version,
            content_hash=content_hash,
            spec_payload=fp_spec,
            columns=[],
            from_specification=False,
        )

    # Offline FV AppliedObjects from FeatureStore.list_feature_views().
    #
    # Surfaces FVs that have no Online Feature Table — primarily
    # offline-only ``BatchFeatureView``s (``online: false``).  The OFT
    # loop above already populated ``objects`` for online FVs; entries
    # here are skipped on key-collision so the OFT-derived
    # ``spec_payload`` (the authoritative DESCRIBE-TYPE-SPECIFICATION
    # JSON) always wins.
    if feature_view_rows:
        for fv_row in feature_view_rows:
            offline_obj = _build_offline_fv_object(
                fv_row,
                dt_text_map=dt_text_map,
                default_database=default_database,
                default_schema=default_schema,
                datasources_by_table=datasources_by_table,
            )
            if offline_obj is None:
                continue
            if offline_obj.key in objects:
                continue
            objects[offline_obj.key] = offline_obj
            spec_payloads_for_datasources.append(offline_obj.spec_payload)

    # Entity AppliedObjects from SHOW TAGS.
    if entity_rows:
        for entity_row in entity_rows:
            ent_obj = _build_entity_object(entity_row, default_database, default_schema)
            if ent_obj is not None:
                objects[ent_obj.key] = ent_obj

    # FeatureGroup AppliedObjects from FeatureStore.list_feature_groups().
    #
    # Each row is reified as one ``AppliedObject(kind="FeatureGroup")``
    # whose ``content_hash`` matches the planner's ``_fg_content_hash``
    # by construction (decl-shape spec_payload built from the imperative
    # row, with FvSourceRef ``fv_name`` / ``fv_version`` translated to the
    # declarative ``name`` / ``version`` keys).  ``from_specification``
    # is False — FG state lives in the metadata table, not in an OFT
    # specification.
    if feature_group_rows:
        for fg_row in feature_group_rows:
            fg_obj = _build_feature_group_object(fg_row, default_database, default_schema)
            if fg_obj is not None:
                objects[fg_obj.key] = fg_obj

    # Datasource AppliedObjects — runtime-authoritative merge per
    # ``plans/stream_source_contract.md`` §5b.
    #
    # Step 1: insert one ``AppliedObject`` per registered stream-source
    # row (``FeatureStore.list_stream_sources()``) FIRST so its
    # ``content_hash`` / ``spec_payload`` wins on key collision.  The
    # runtime row carries metadata the FV-derived path cannot recover
    # (notably the registered ``description``), so it is the source
    # of truth whenever both sides surface the same Datasource key.
    for runtime_row in stream_source_rows or []:
        runtime_obj = _build_stream_source_object(
            runtime_row,
            default_database,
            default_schema,
        )
        objects[runtime_obj.key] = runtime_obj

    # Step 2: walk the FV-derived ``Datasource`` entries unioned from
    # ``spec.sources[]`` across every recovered FV.  Skip on key
    # collision so the runtime entry remains authoritative; insert
    # otherwise so sources that no FV references still emerge (and
    # so do FV-only sources that have no registered runtime row,
    # e.g. virtual ``BatchSource`` entries derived from BatchFV DT
    # text).
    for ds_obj in _datasource_objects_from_specs(spec_payloads_for_datasources, default_database, default_schema):
        if ds_obj.key in objects:
            continue
        objects[ds_obj.key] = ds_obj

    return AppliedState(objects=objects)


def _build_feature_group_object(
    fg_row: dict[str, Any],
    default_database: str,
    default_schema: str,
) -> Optional[AppliedObject]:
    """Reify one FG row from :func:`imperative_executor.fetch_feature_group_rows`
    as an ``AppliedObject(kind="FeatureGroup")``.

    The applied-state spec_payload is built in **declarative shape**
    (``feature_views[].name`` / ``.version`` rather than the imperative
    ``fv_name`` / ``fv_version``) so the planner's hash basis matches a
    local YAML by construction.  Both ``name`` / ``version`` and the
    optional ``slice_columns`` / ``alias`` are translated; ``alias = ""``
    survives as the literal empty string (semantically: "no prefix").

    Args:
        fg_row: A row dict in the shape produced by
            :func:`imperative_executor.fetch_feature_group_rows`.
        default_database: Database to use when the row does not include one.
        default_schema: Schema to use when the row does not include one.

    Returns:
        An :class:`AppliedObject` with ``kind="FeatureGroup"`` and a
        content_hash matching :func:`invariants._fg_content_hash`, or
        ``None`` when ``fg_row`` is missing a name / version.
    """
    # Lazy import to avoid widening the import surface of this module
    # (matches the rest of the per-kind builder helpers in this file).
    from snowflake.ml.feature_store.decl.invariants import _fg_content_hash

    name = fg_row.get("name") or ""
    version = fg_row.get("version") or ""
    if not name or not version:
        return None

    db = fg_row.get("database_name") or default_database
    schema = fg_row.get("schema_name") or default_schema

    decl_sources: list[dict[str, Any]] = []
    for src in fg_row.get("sources") or []:
        if not isinstance(src, dict):
            continue
        fv_name = src.get("fv_name") or src.get("name") or ""
        fv_version = src.get("fv_version") or src.get("version") or ""
        if not fv_name or not fv_version:
            continue
        decl_src: dict[str, Any] = {"name": fv_name, "version": fv_version}
        if "slice_columns" in src and src["slice_columns"] is not None:
            decl_src["slice_columns"] = list(src["slice_columns"])
        if "alias" in src and src["alias"] is not None:
            # Preserve alias="" as the literal empty string.
            decl_src["alias"] = src["alias"]
        decl_sources.append(decl_src)

    spec_payload: dict[str, Any] = {
        "kind": "FeatureGroup",
        "name": name,
        "version": version,
        "database": db,
        "schema": schema,
        "desc": fg_row.get("desc") or "",
        "auto_prefix": bool(fg_row.get("auto_prefix", True)),
        "feature_views": decl_sources,
    }

    content_hash = _fg_content_hash(spec_payload)
    qualifier_db = (db or "").upper()
    qualifier_schema = (schema or "").upper()
    name_upper = name.upper()
    qualifier = f"{qualifier_db}.{qualifier_schema}" if (qualifier_db or qualifier_schema) else ""
    key = f"FeatureGroup:{qualifier}:{name_upper}"

    return AppliedObject(
        key=key,
        kind="FeatureGroup",
        name=name,
        version=version,
        content_hash=content_hash,
        spec_payload=spec_payload,
        columns=[],
        from_specification=False,
        details={},
    )
