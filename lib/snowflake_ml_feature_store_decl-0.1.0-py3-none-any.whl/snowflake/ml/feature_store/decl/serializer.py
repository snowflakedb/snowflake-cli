"""Serialization utilities for decl spec model instances.

Converts Pydantic spec models to plain dicts, YAML, and JSON.
All functions are self-contained — no imports from snowflake.ml.feature_store.spec,
snowflake.snowpark, or snowflake.connector.
"""

from __future__ import annotations

import inspect
import json
import textwrap
from typing import Any, Callable

import yaml

from snowflake.ml.feature_store.decl.spec_models import (
    BatchSource,
    Entity,
    FeatureView,
    FeatureViewRef,
    SpecBase,
    StreamingSource,
)

# Mapping from a SpecBase ``kind`` to the canonical ``source_type`` value
# emitted on ``SourceRef`` dicts. Values match
# :class:`snowflake.ml.feature_store.spec.enums.SourceType` (``Stream``,
# ``Batch``, etc.). The decl/spec consolidation collapsed the previous
# decl-only ``SQLDataSource`` kind, and the legacy ``BatchSource`` source
# type value was retired in favour of the canonical ``Batch`` (matching
# the imperative SourceType enum). The exporter's
# ``_SOURCE_TYPE_TO_KIND`` still accepts the legacy ``BatchSource``
# string for plan-file backward compatibility.
_SOURCE_KIND_TO_TYPE: dict[str, str] = {
    "StreamingSource": "Stream",
    "BatchSource": "Batch",
}


def callable_to_source(func: Callable) -> str:  # type: ignore[type-arg]
    """Extract Python source code from a callable, stripping decorator lines.

    Args:
        func: A callable whose source code should be extracted.

    Returns:
        Dedented source string starting from the ``def`` line.
    """
    source = inspect.getsource(func)
    lines = source.splitlines(keepends=True)

    # Walk past decorator lines (handles multi-line decorators via paren depth)
    idx = 0
    while idx < len(lines):
        stripped = lines[idx].lstrip()
        if stripped.startswith("@"):
            depth = stripped.count("(") - stripped.count(")")
            idx += 1
            while depth > 0 and idx < len(lines):
                depth += lines[idx].count("(") - lines[idx].count(")")
                idx += 1
        elif stripped.startswith("def ") or stripped.startswith("async def "):
            break
        else:
            idx += 1

    return textwrap.dedent("".join(lines[idx:]))


def spec_to_dict(spec: SpecBase) -> dict[str, Any]:
    """Convert a spec model instance to a plain dict.

    Rules applied during conversion:
    - ``None`` values are excluded from the output.
    - Empty lists and dicts are excluded from the output.
    - ``False`` boolean values are excluded.
    - ``function_definition`` callables are replaced with their source code.
    - ``StreamingSource`` / ``BatchSource`` instances in a ``sources`` list are
      collapsed to ``SourceRef`` dicts (``{"name": ..., "source_type": ...}``).
    - ``Entity`` objects in ``ordered_entity_column_names`` are expanded to their
      join-key column name strings.
    - ``FeatureView`` instances in ``feature_views`` are collapsed to name-only
      ref dicts (``{"name": ...}``).

    Args:
        spec: A ``SpecBase`` subclass instance to serialize.

    Returns:
        A plain dict suitable for JSON/YAML serialization.
    """
    raw = spec.model_dump()
    return _clean_dict(spec, raw)


def _clean_dict(spec: SpecBase, raw: dict[str, Any]) -> dict[str, Any]:
    """Walk the raw model_dump() result and apply serialization rules."""
    result: dict[str, Any] = {}
    for key, value in raw.items():
        if value is None:
            continue
        if value is False:
            continue
        if isinstance(value, list) and not value:
            continue
        if isinstance(value, dict) and not value:
            continue

        # Special handling for known spec fields
        if key == "function_definition":
            # Get the original object to check if it's a callable
            orig_value = _get_nested_attr(spec, key)
            if callable(orig_value):
                result[key] = callable_to_source(orig_value)
            else:
                result[key] = value
            continue

        if key == "ordered_entity_column_names" and isinstance(value, list):
            result[key] = _expand_entity_column_names(spec, value)
            continue

        if key == "sources" and isinstance(value, list):
            result[key] = _collapse_sources(spec, value)
            continue

        if key == "feature_views" and isinstance(value, list):
            result[key] = _collapse_feature_views(spec, value)
            continue

        if isinstance(value, dict):
            result[key] = _clean_nested_dict(value)
        elif isinstance(value, list):
            result[key] = [_clean_value(item) for item in value]
        else:
            result[key] = value

    return result


def _get_nested_attr(spec: SpecBase, key: str) -> Any:
    """Retrieve a direct attribute from the spec object."""
    return getattr(spec, key, None)


def _clean_nested_dict(d: dict[str, Any]) -> dict[str, Any]:
    """Recursively clean a nested dict, excluding None/False/empty values."""
    result = {}
    for k, v in d.items():
        if v is None:
            continue
        if v is False:
            continue
        if isinstance(v, list) and not v:
            continue
        if isinstance(v, dict) and not v:
            result[k] = _clean_nested_dict(v)
            continue
        # Callables (e.g. function_definition inside udf) → extract source
        if k == "function_definition" and callable(v):
            result[k] = callable_to_source(v)
            continue
        if isinstance(v, dict):
            result[k] = _clean_nested_dict(v)
        elif isinstance(v, list):
            result[k] = [_clean_value(item) for item in v]
        else:
            result[k] = v
    return result


def _clean_value(item: Any) -> Any:
    """Clean a single list element."""
    if isinstance(item, dict):
        return _clean_nested_dict(item)
    return item


def _expand_entity_column_names(spec: SpecBase, raw_list: list[Any]) -> list[str]:
    """Expand Entity objects in ordered_entity_column_names to join-key name strings."""
    # Work from the original spec object for accurate type checking
    original_list = getattr(spec, "ordered_entity_column_names", raw_list)
    names: list[str] = []
    for item in original_list:
        if isinstance(item, Entity):
            names.extend(jk.name for jk in item.join_keys)
        else:
            names.append(str(item))
    return names


def _collapse_sources(spec: SpecBase, raw_list: list[Any]) -> list[dict[str, Any]]:
    """Collapse source objects in sources list to SourceRef dicts."""
    original_list = getattr(spec, "sources", raw_list)
    result = []
    for item in original_list:
        if isinstance(item, (StreamingSource, BatchSource)):
            source_type = _SOURCE_KIND_TO_TYPE.get(item.kind, item.kind)
            result.append({"name": item.name, "source_type": source_type})
        elif isinstance(item, dict) and "name" in item and "source_type" in item:
            result.append({"name": item["name"], "source_type": item["source_type"]})
        elif isinstance(item, dict):
            result.append(_clean_nested_dict(item))
        elif hasattr(item, "name") and hasattr(item, "source_type"):
            # SourceRef or similar model instance
            result.append({"name": item.name, "source_type": item.source_type})
        else:
            result.append(item)
    return result


def _collapse_feature_views(spec: SpecBase, raw_list: list[Any]) -> list[dict[str, Any]]:
    """Collapse FeatureView objects in feature_views to name-only ref dicts."""
    original_list = getattr(spec, "feature_views", raw_list)
    result = []
    for item in original_list:
        if isinstance(item, FeatureView):
            result.append({"name": item.name})
        elif isinstance(item, FeatureViewRef):
            result.append({"name": item.name})
        elif isinstance(item, dict):
            result.append({"name": item["name"]})
        else:
            result.append(item)
    return result


def spec_to_yaml(spec: SpecBase) -> str:
    """Convert a spec model instance to a YAML string.

    Args:
        spec: A ``SpecBase`` subclass instance to serialize.

    Returns:
        YAML representation of the spec.
    """
    d = spec_to_dict(spec)
    return yaml.dump(d, default_flow_style=False, sort_keys=False, allow_unicode=True)


def spec_to_json(spec: SpecBase) -> str:
    """Convert a spec model instance to a JSON string.

    Args:
        spec: A ``SpecBase`` subclass instance to serialize.

    Returns:
        JSON representation of the spec.
    """
    d = spec_to_dict(spec)
    return json.dumps(d, indent=2, ensure_ascii=False)
