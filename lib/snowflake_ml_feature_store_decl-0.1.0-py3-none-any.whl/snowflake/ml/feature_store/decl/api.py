"""Top-level facade functions for the declarative feature store library.

This module is the **only** entry point for the CLI plugin. It must never
be bypassed in favour of importing internal modules (``invariants``,
``planner``, ``state``, etc.) directly. This keeps the substitution surface
small when individual responsibilities are migrated to Global Services.
"""

from __future__ import annotations

from typing import Any, Optional

from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.types import (
    AppliedState,
    Plan,
    PlanFile,
    PlanOptions,
    SpecBatch,
    ValidationResult,
)

# ---------------------------------------------------------------------------
# Service / HTTP facades
# ---------------------------------------------------------------------------


def parse_service_status(raw_json: str) -> dict:
    """Parse the JSON string from SYSTEM$GET_FEATURE_STORE_RUNTIME_STATUS.

    Delegates to :func:`decl.service.parse_service_status`.

    Args:
        raw_json: JSON string returned by the system function.

    Returns:
        Parsed status dict.
    """
    from snowflake.ml.feature_store.decl.service import parse_service_status as _parse

    return _parse(raw_json)


def get_service_endpoint(status: dict, name: str) -> Optional[str]:
    """Extract an endpoint URL by name from a parsed status dict.

    Args:
        status: Dict returned by :func:`parse_service_status`.
        name: Endpoint name (e.g. ``"ingest"`` or ``"query"``).

    Returns:
        URL string, or ``None`` if the endpoint is not found.
    """
    from snowflake.ml.feature_store.decl.service import get_service_endpoint as _get

    return _get(status, name)


def format_status_display(
    status: dict,
    user: str = "",
    database: str = "",
    schema: str = "",
) -> str:
    """Format the parsed runtime status into a rich multi-line display.

    Args:
        status: Dict returned by :func:`parse_service_status`.
        user: Current Snowflake user.
        database: Current database.
        schema: Current schema.

    Returns:
        Formatted multi-line string.
    """
    from snowflake.ml.feature_store.decl.service import format_status_display as _fmt

    return _fmt(status, user, database, schema)


def format_describe_display(
    fv_name: str,
    version: str,
    database: str,
    schema: str,
    oft_name: str,
    entities: list[str],
    describe_rows: list[dict],
    show_row: Optional[dict] = None,
    spec: Optional[dict] = None,
    examples: Optional[list[str]] = None,
) -> str:
    """Format a rich describe display for a feature view."""
    from snowflake.ml.feature_store.decl.service import format_describe_display as _fmt

    return _fmt(
        fv_name,
        version,
        database,
        schema,
        oft_name,
        entities,
        describe_rows,
        show_row,
        spec,
        examples,
    )


def service_sql(
    database: str,
    schema: str,
    producer_role: str = "ACCOUNTADMIN",
    consumer_role: str = "PUBLIC",
) -> dict[str, str]:
    """Return SQL strings for service management, keyed by operation.

    Args:
        database: Snowflake database name.
        schema: Snowflake schema name.
        producer_role: Snowflake role for producing features.
        consumer_role: Snowflake role for consuming features.

    Returns:
        Dict with keys: get_status, create, drop, show_ofts,
        drop_oft_template.
    """
    from snowflake.ml.feature_store.decl.service import service_sql as _sql

    return _sql(database, schema, producer_role, consumer_role)


def build_ingest_request(source_name: str, records: list[dict]) -> dict:
    """Build the JSON body for POST /api/v1/ingest.

    Args:
        source_name: Name of the streaming source to ingest into.
        records: List of record dicts to ingest.

    Returns:
        Request body dict.
    """
    from snowflake.ml.feature_store.decl.service import build_ingest_request as _build

    return _build(source_name, records)


def build_query_request(fv_name: str, keys: list[dict]) -> dict:
    """Build the JSON body for POST /api/v1/query.

    Args:
        fv_name: Feature view name to query.
        keys: List of key dicts identifying the entities to fetch.

    Returns:
        Request body dict.
    """
    from snowflake.ml.feature_store.decl.service import build_query_request as _build

    return _build(fv_name, keys)


def build_describe_examples(
    fv_name: str,
    version: str,
    source_name: str,
    describe_rows: list[dict],
    ingest_url: Optional[str],
    query_url: Optional[str],
    spec: Optional[dict] = None,
) -> list[str]:
    """Build example curl commands for ingest and query.

    When a *spec* dict (parsed YAML) is provided, examples use the UDF
    output columns for ingest and the entity columns for query.

    Args:
        fv_name: Feature view name (user-facing, lowercase).
        version: Feature view version (e.g. ``"v1"``).
        source_name: Source name for ingest (e.g. ``"user_events"``).
        describe_rows: Rows from DESCRIBE ONLINE FEATURE TABLE (fallback).
        ingest_url: Base ingest endpoint URL, or ``None``.
        query_url: Base query endpoint URL, or ``None``.
        spec: Optional parsed YAML spec dict for the feature view.

    Returns:
        List of example strings (may be empty if no endpoints available).
    """
    from snowflake.ml.feature_store.decl.service import (
        build_describe_examples as _build,
    )

    return _build(fv_name, version, source_name, describe_rows, ingest_url, query_url, spec)


def post_service_json(url: str, pat: str, body: dict) -> dict:
    """POST JSON to an Online Service REST endpoint with PAT bearer auth.

    Delegates to :func:`decl.http.post_json`.

    Args:
        url: Full endpoint URL.
        pat: Snowflake Programmatic Access Token.
        body: Request body dict; will be JSON-serialised.

    Returns:
        Parsed response dict.
    """
    from snowflake.ml.feature_store.decl.http import post_json

    return post_json(url, pat, body)


def load_specs(files: list[str], config: Optional[dict[str, Any]] = None) -> SpecBatch:
    """Load and parse spec files into a ``SpecBatch``.

    Accepts ``.py``, ``.yaml``, ``.yml``, and ``.json`` files. Applies Jinja2
    templating if ``config`` is provided and the file contains template syntax.
    Glob patterns and ``./...`` recursive expansion are resolved automatically.

    Args:
        files: Paths to spec files. Glob patterns and ``./...`` recursive
            expansion are resolved before loading.
        config: Jinja2 template variables. May be ``None`` if no templating
            is needed.

    Returns:
        SpecBatch containing all loaded and compiled spec objects.
    """
    from snowflake.ml.feature_store.decl import loader

    return loader.load_specs(files, config=config)


def validate_specs(batch: SpecBatch, applied_state: AppliedState) -> list[ValidationResult]:
    """Validate a spec batch against invariant rules and applied state.

    Runs all invariant checks defined in ``DevExAndSchemaAndCICD.md``,
    including version management, column evolution, dependency resolution,
    and state synchronization.

    Args:
        batch: The parsed spec batch to validate.
        applied_state: The current applied state snapshot from Snowflake.

    Returns:
        Combined list of ``ValidationResult`` objects (ERRORRs and WARNINGGs).
    """
    from snowflake.ml.feature_store.decl.invariants import (
        validate_specs as _validate_specs,
    )

    return _validate_specs(batch, applied_state)


def generate_plan(
    batch: SpecBatch,
    applied_state: AppliedState,
    options: PlanOptions,
    database: str = "",
    schema: str = "",
) -> Plan:
    """Generate a dependency-ordered execution plan.

    Diffs the incoming ``SpecBatch`` against ``AppliedState`` to classify
    each spec as CREATE, UPDATE, RECREATE, or NO_CHANGE. Returns a
    topologically-sorted ``Plan`` with one ``PlanOp`` per operation.

    For FeatureView kinds whose ``AppliedObject`` carries a full spec
    (``from_specification=True``) the diff is computed against the
    compiled full spec.  This catches changes the structural fingerprint
    misses — UDF code, source-column schema, aggregation windows, and
    target lag.  ``database`` and ``schema`` parameterise the local
    compile step; when empty the planner falls back to each spec's own
    ``database``/``schema`` fields.

    Args:
        batch: The validated spec batch.
        applied_state: The current applied state snapshot from Snowflake.
        options: Flags that control plan generation (dev_mode, overwrite, etc.).
        database: Snowflake database name for compiling local FV specs.
        schema: Snowflake schema name for compiling local FV specs.

    Returns:
        Topologically-sorted execution plan.
    """
    from snowflake.ml.feature_store.decl.planner import generate_plan as _generate_plan

    return _generate_plan(batch, applied_state, options, database=database, schema=schema)


def generate_example(output_dir: str) -> dict[str, Any]:
    """Write example YAML spec files under *output_dir*.

    Creates ``entities/``, ``datasources/``, and ``feature_views/``
    subdirectories and writes one starter spec file in each.

    Args:
        output_dir: Base directory under which example files are written.
            Created automatically (including parents) if it does not exist.

    Returns:
        Dict with keys ``status`` (``"created"``) and ``files`` (list of
        absolute paths to the written files).
    """
    from snowflake.ml.feature_store.decl.examples import (
        generate_example as _generate_example,
    )

    return _generate_example(output_dir)


def export_specs(
    show_rows: list[dict[str, Any]],
    describe_rows_by_oft: dict[str, list[dict[str, Any]]],
    output_dir: str,
    database: str,
    schema: str,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
) -> dict[str, Any]:
    """Reconstruct YAML specs from raw SHOW/DESCRIBE results and write to disk.

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES`` (list of dicts).
        describe_rows_by_oft: Map of OFT name → ``DESCRIBE`` rows (list of
            dicts).
        output_dir: Base output directory.
        database: Connection database name.
        schema: Connection schema name.
        specification_map: Optional map of OFT name → parsed spec JSON
            returned by ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE =
            SPECIFICATION``.  When an entry is present for an OFT, the
            corresponding YAML is written in full-fidelity mode (UDF source,
            source columns, feature aggregations preserved).  Missing
            entries fall back to the legacy partial-export path.

    Returns:
        Dict with keys ``status``, ``directory``, and ``files``.
    """
    from snowflake.ml.feature_store.decl.exporter import export_specs as _export_specs

    return _export_specs(
        show_rows,
        describe_rows_by_oft,
        output_dir,
        database,
        schema,
        specification_map=specification_map,
    )


def fetch_applied_state(
    raw_show_results: list[dict[str, Any]],
    raw_table_results: Optional[list[dict[str, Any]]] = None,
    describe_map: Optional[dict[str, list[dict[str, Any]]]] = None,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
    entity_rows: Optional[list[dict[str, Any]]] = None,
    default_database: str = "",
    default_schema: str = "",
) -> AppliedState:
    """Parse raw Snowflake query results into an ``AppliedState`` snapshot.

    The CLI is responsible for executing the SQL queries and passing the
    raw results to this function. This design allows GS to provide the data
    via a REST API in the future without changing this function's signature.

    Args:
        raw_show_results: Rows from ``SHOW ONLINE FEATURE TABLES``.
        raw_table_results: Rows from ``SHOW TABLES`` (offline backing tables).
        describe_map: Mapping of OFT name → ``DESCRIBE ONLINE FEATURE TABLE``
            rows.  Used as the structural-fingerprint fallback when a
            specification is unavailable.
        specification_map: Mapping of OFT name → parsed spec JSON returned by
            ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE = SPECIFICATION``.
            When provided, the FV's ``spec_payload`` is populated from this
            authoritative source and ``from_specification=True`` is set.
        entity_rows: Rows from
            ``SHOW TAGS LIKE 'SNOWML_FEATURE_STORE_ENTITY_%'``.  Each row
            becomes an Entity ``AppliedObject``.
        default_database: Database name used when a row does not include one.
        default_schema: Schema name used when a row does not include one.

    Returns:
        AppliedState snapshot parsed from the raw query results, including
        FeatureView objects, Entity objects (from ``entity_rows``), and
        derived Datasource objects (unioned across all FV
        ``spec.sources[]`` lists).
    """
    from snowflake.ml.feature_store.decl.state import (
        fetch_applied_state as _fetch_applied_state,
    )

    return _fetch_applied_state(
        raw_show_results,
        raw_table_results,
        describe_map=describe_map,
        specification_map=specification_map,
        entity_rows=entity_rows,
        default_database=default_database,
        default_schema=default_schema,
    )


def parse_specification_rows(
    rows: Optional[list[dict[str, Any]]],
) -> Optional[dict[str, Any]]:
    """Parse rows from ``DESCRIBE ... TYPE = SPECIFICATION`` into spec JSON.

    Delegates to :func:`decl.state.parse_specification_rows`.

    Args:
        rows: Raw rows (list of dicts) returned by the SQL execution.

    Returns:
        Parsed spec JSON dict, or ``None`` if no row contained a parseable
        spec.
    """
    from snowflake.ml.feature_store.decl.state import (
        parse_specification_rows as _parse,
    )

    return _parse(rows)


def compile_to_spec(
    spec_dict: dict[str, Any],
    database: str,
    schema: str,
) -> dict[str, Any]:
    """Compile a YAML authoring-format spec into imperative FeatureViewSpec format.

    Args:
        spec_dict: The loaded/compiled spec dict from the authoring YAML.
        database: Snowflake database name (from connection context).
        schema: Snowflake schema name (from connection context).

    Returns:
        Dict matching FeatureViewSpec.to_dict() output, ready for
        JSON serialization in FROM SPECIFICATION $$ ... $$.
    """
    from snowflake.ml.feature_store.decl.spec_compiler import (
        compile_to_spec as _compile,
    )

    return _compile(spec_dict, database, schema)


# ---------------------------------------------------------------------------
# Query string factories (CLI should use these instead of hardcoded SQL)
# ---------------------------------------------------------------------------


def state_queries(database: str, schema: str) -> dict[str, str]:
    """Return SQL strings for fetching applied state."""
    from snowflake.ml.feature_store.decl.queries import state_queries as _sq

    return _sq(database, schema)


def list_query(database: str, schema: str) -> str:
    """Return the SHOW ONLINE FEATURE TABLES SQL string."""
    from snowflake.ml.feature_store.decl.queries import list_query as _lq

    return _lq(database, schema)


def describe_query(name: str, database: str, schema: str) -> str:
    """Return the SHOW ... LIKE SQL string for a named object."""
    from snowflake.ml.feature_store.decl.queries import describe_query as _dq

    return _dq(name, database, schema)


def describe_columns_query(name: str, database: str, schema: str) -> str:
    """Return the DESCRIBE ONLINE FEATURE TABLE SQL string."""
    from snowflake.ml.feature_store.decl.queries import describe_columns_query as _dcq

    return _dcq(name, database, schema)


def drop_queries(names: list[str], database: str, schema: str) -> list[str]:
    """Return DROP SQL strings for the named objects."""
    from snowflake.ml.feature_store.decl.queries import drop_queries as _dqs

    return _dqs(names, database, schema)


def export_queries(database: str, schema: str) -> dict[str, str]:
    """Return SQL strings for the export workflow."""
    from snowflake.ml.feature_store.decl.queries import export_queries as _eq

    return _eq(database, schema)


def describe_specification_query(database: str, schema: str, name: str) -> str:
    """Return the ``DESCRIBE ... TYPE = SPECIFICATION`` SQL string."""
    from snowflake.ml.feature_store.decl.queries import (
        describe_specification_query as _q,
    )

    return _q(database, schema, name)


def list_entities_query(database: str, schema: str) -> str:
    """Return the ``SHOW TAGS LIKE 'SNOWML_FEATURE_STORE_ENTITY_%'`` SQL."""
    from snowflake.ml.feature_store.decl.queries import (
        list_entities_query as _q,
    )

    return _q(database, schema)


def list_state_queries(database: str, schema: str) -> dict[str, str]:
    """Return the SQL set used by ``snow feature list``.

    Includes ``show_ofts``, ``show_entities``, and the
    ``describe_specification_template`` (a ``{name}``-format string for
    per-OFT spec retrieval).
    """
    from snowflake.ml.feature_store.decl.queries import (
        list_state_queries as _q,
    )

    return _q(database, schema)


def enrich_list_results(
    show_rows: list[dict[str, Any]],
    describe_map: Optional[dict[str, list[dict[str, Any]]]] = None,
    *,
    entity_rows: Optional[list[dict[str, Any]]] = None,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
) -> list[dict[str, Any]]:
    """Enrich raw SHOW/DESCRIBE/TAG rows into a multi-kind list output.

    Produces a single, ordered list of display dicts that the CLI can
    render in a table with a ``type`` column.  The output covers three
    kinds: ``FeatureView``, ``Entity``, and ``Datasource``.

    Ordering: FeatureView rows in input order, then Entity rows in input
    order, then Datasource rows sorted by name for deterministic output.

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES``.
        describe_map: Optional mapping of OFT name → ``DESCRIBE`` column
            rows.  Used as the fallback for the ``entities`` column when
            ``specification_map`` does not contain an entry for that OFT.
        entity_rows: Optional rows from
            ``SHOW TAGS LIKE 'SNOWML_FEATURE_STORE_ENTITY_%'``.  Each row
            becomes one Entity output row.
        specification_map: Optional mapping of OFT name → parsed spec
            JSON returned by ``DESCRIBE ... TYPE = SPECIFICATION``.  When
            present, the FV's ``entities`` column comes from
            ``ordered_entity_column_names`` and Datasource rows are
            derived from the union of ``spec.sources[]``.

    Returns:
        Ordered list of enriched row dicts.  Each dict carries a
        ``type`` column plus the columns used by the CLI's table
        projection (``feature_view``, ``version``, ``entities``,
        ``database_name``, ``schema_name``) and a ``details`` dict for
        kind-specific extras.
    """
    import json as _json

    from snowflake.ml.feature_store.decl.state import _parse_oft_name
    from snowflake.ml.feature_store.decl.types import ObjectKind

    _ENTITY_TAG_PREFIX = "SNOWML_FEATURE_STORE_ENTITY_"

    describe_lookup = describe_map or {}
    enriched: list[dict[str, Any]] = []

    # 1. FeatureView rows (preserve original SHOW columns).
    for row in show_rows:
        r = dict(row)
        oft_name = r.get("name", "") or r.get("NAME", "")
        base_name, version = _parse_oft_name(oft_name)
        r["type"] = ObjectKind.FEATURE_VIEW
        # Surface the user-facing name as ``name`` for consistent table
        # display across all kinds; the raw OFT name is preserved in
        # ``oft_name`` for any downstream consumers.
        r["oft_name"] = oft_name
        r["name"] = base_name.lower()
        r["feature_view"] = base_name.lower()
        r["version"] = version.lower()

        entities_str = ""
        spec = specification_map.get(oft_name) if specification_map else None
        if spec is not None:
            inner = spec.get("spec") if isinstance(spec.get("spec"), dict) else spec
            cols = (
                inner.get("ordered_entity_column_names")
                if isinstance(inner, dict)
                else None
            )
            if isinstance(cols, list) and cols:
                entities_str = ", ".join(str(c) for c in cols)

        if not entities_str:
            desc_rows = describe_lookup.get(oft_name, [])
            pk_cols: list[str] = []
            for col in desc_rows:
                is_pk = False
                for pk_key in ("primary key", "PRIMARY KEY", "primary_key"):
                    val = col.get(pk_key, "")
                    if val and str(val).upper() in ("Y", "YES", "TRUE", "1"):
                        is_pk = True
                        break
                if is_pk:
                    pk_cols.append(col.get("name", col.get("NAME", "")))
            entities_str = ", ".join(pk_cols) if pk_cols else ""

        r["entities"] = entities_str
        if "database_name" not in r:
            r["database_name"] = r.get("DATABASE_NAME", "") or ""
        if "schema_name" not in r:
            r["schema_name"] = r.get("SCHEMA_NAME", "") or ""
        r["details"] = {"scheduling_state": r.get("scheduling_state", "")}
        enriched.append(r)

    # 2. Entity rows.
    if entity_rows:
        for ent_row in entity_rows:
            raw_name = ent_row.get("name") or ent_row.get("NAME") or ""
            if not raw_name or not raw_name.startswith(_ENTITY_TAG_PREFIX):
                continue
            entity_name = raw_name[len(_ENTITY_TAG_PREFIX):].lower()
            db = ent_row.get("database_name") or ent_row.get("DATABASE_NAME") or ""
            schema_val = (
                ent_row.get("schema_name") or ent_row.get("SCHEMA_NAME") or ""
            )

            join_keys: list[str] = []
            raw_allowed = (
                ent_row.get("allowed_values")
                or ent_row.get("ALLOWED_VALUES")
                or ent_row.get("allowed_values_list")
            )
            if raw_allowed:
                if isinstance(raw_allowed, list):
                    join_keys = [str(v) for v in raw_allowed]
                elif isinstance(raw_allowed, str):
                    try:
                        parsed = _json.loads(raw_allowed)
                        if isinstance(parsed, list):
                            join_keys = [str(v) for v in parsed]
                    except (ValueError, TypeError):
                        join_keys = [
                            v.strip()
                            for v in raw_allowed.strip("[]").split(",")
                            if v.strip()
                        ]

            details: dict[str, Any] = {}
            comment_val = ent_row.get("comment") or ent_row.get("COMMENT")
            if comment_val:
                details["comment"] = comment_val

            enriched.append(
                {
                    "type": ObjectKind.ENTITY,
                    "name": entity_name,
                    "feature_view": "",
                    "version": "",
                    "entities": ", ".join(join_keys),
                    "database_name": db,
                    "schema_name": schema_val,
                    "details": details,
                }
            )

    # 3. Datasource rows: union spec.sources[] across all FVs, dedupe by
    # lowercase name, then sort for deterministic output.
    if specification_map:
        ds_by_name: dict[str, dict[str, Any]] = {}
        for spec in specification_map.values():
            if not isinstance(spec, dict):
                continue
            inner = spec.get("spec") if isinstance(spec.get("spec"), dict) else spec
            sources = inner.get("sources", []) if isinstance(inner, dict) else []
            if not isinstance(sources, list):
                continue
            metadata = (
                spec.get("metadata") if isinstance(spec.get("metadata"), dict) else {}
            )
            db = metadata.get("database", "") or ""
            schema_val = metadata.get("schema", "") or ""

            for src in sources:
                if not isinstance(src, dict):
                    continue
                src_name = src.get("name", "")
                if not src_name:
                    continue
                normalized = src_name.lower()
                if normalized in ds_by_name:
                    continue
                src_type = src.get("source_type") or src.get("type") or ""
                cols = src.get("columns", [])
                col_count = len(cols) if isinstance(cols, list) else 0
                ds_by_name[normalized] = {
                    "type": ObjectKind.DATASOURCE,
                    "name": normalized,
                    "feature_view": "",
                    "version": "",
                    "entities": "",
                    "database_name": db,
                    "schema_name": schema_val,
                    "details": {
                        "source_type": src_type,
                        "column_count": col_count,
                    },
                }

        for ds_name in sorted(ds_by_name):
            enriched.append(ds_by_name[ds_name])

    return enriched


# ---------------------------------------------------------------------------
# Plan file serialization
# ---------------------------------------------------------------------------


def serialize_plan(
    plan: Plan,
    database: str,
    schema: str,
    source_files: list[str],
) -> str:
    """Serialize a Plan to a JSON string for writing to a plan file.

    Wraps the plan in a :class:`PlanFile` envelope, computes an op-kind
    summary, stamps a UTC ISO-8601 timestamp, and returns the result as a
    pretty-printed JSON string.

    Args:
        plan: The execution plan to serialize.
        database: Target Snowflake database name.
        schema: Target Snowflake schema name.
        source_files: Input spec file paths that produced the plan.

    Returns:
        JSON string representing the plan file.
    """
    import json
    from datetime import datetime, timezone

    # Build summary: count ops by kind
    summary: dict[str, int] = {}
    for op in getattr(plan, "ops", []):
        kind_val = op.kind.value if hasattr(op.kind, "value") else str(op.kind)
        summary[kind_val] = summary.get(kind_val, 0) + 1

    pf = PlanFile(
        created_at=datetime.now(timezone.utc).isoformat(),
        target_database=database,
        target_schema=schema,
        source_files=list(source_files),
        plan=plan,
        summary=summary,
    )
    return json.dumps(pf.model_dump(mode="json"), indent=2)


def deserialize_plan(json_str: str) -> PlanFile:
    """Deserialize a JSON plan file string into a :class:`PlanFile`.

    Args:
        json_str: JSON string previously produced by :func:`serialize_plan`.

    Returns:
        PlanFile instance deserialized from the JSON string.

    Raises:
        ValueError: If *json_str* is not valid JSON or cannot be parsed into a
            :class:`PlanFile`.
    """
    import json

    try:
        data = json.loads(json_str)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid plan file JSON: {exc}") from exc
    return PlanFile.model_validate(data)


# ---------------------------------------------------------------------------
# Combined apply pipeline
# ---------------------------------------------------------------------------


def _resolve_datasource_columns(batch: Any) -> None:
    """Resolve datasource columns into feature view source references.

    Scans the batch for ``StreamingSource`` specs (which have ``columns``),
    then for each FV spec's ``sources`` list, if a source matches by name
    and has no columns, injects the datasource's columns.

    Mutates specs in place.

    Args:
        batch: A compiled batch containing specs to resolve.
    """
    # Build a map: source name → columns from StreamingSource specs
    ds_columns: dict[str, list] = {}
    for spec in getattr(batch, "specs", []):
        if getattr(spec, "kind", "") in ("StreamingSource", "BatchSource", "SQLDataSource"):
            name = getattr(spec, "name", "")
            columns = getattr(spec, "columns", [])
            if name and columns:
                # Convert FSColumn Pydantic models to dicts, keeping only name+type
                col_dicts = []
                for c in columns:
                    if hasattr(c, "dict"):
                        d = c.dict()
                        col_dicts.append({k: v for k, v in d.items() if v is not None})
                    elif isinstance(c, dict):
                        col_dicts.append({k: v for k, v in c.items() if v is not None})
                ds_columns[name.lower()] = col_dicts

    if not ds_columns:
        return

    # Inject columns into FV source references that lack them
    for spec in getattr(batch, "specs", []):
        kind = getattr(spec, "kind", "")
        if kind not in ("StreamingFeatureView", "RealtimeFeatureView", "BatchFeatureView"):
            continue
        sources = getattr(spec, "sources", [])
        for _i, src in enumerate(sources):
            if isinstance(src, dict):
                src_name = src.get("name", "")
                src_cols = src.get("columns")
            else:
                src_name = getattr(src, "name", "")
                src_cols = getattr(src, "columns", None)

            if src_cols:
                continue

            # Look up from datasource specs
            resolved = ds_columns.get(src_name.lower())
            if resolved:
                if isinstance(src, dict):
                    src["columns"] = resolved
                else:
                    try:
                        src.columns = resolved
                    except (AttributeError, ValueError):
                        pass


def generate_apply_sql(
    batch: Any,
    applied_state: Any,
    options: Any,
    database: str,
    schema: str,
    warehouse: str = "",
) -> Any:
    """Validate specs, generate plan, produce SQL — all in one call.

    Args:
        batch: SpecBatch from load_specs().
        applied_state: AppliedState from fetch_applied_state().
        options: PlanOptions controlling plan generation.
        database: Snowflake database name.
        schema: Snowflake schema name.
        warehouse: Snowflake warehouse name.

    Returns:
        ApplyResult with status, ops, sql_statements, warnings, errors.
    """
    from snowflake.ml.feature_store.decl.sql_generator import generate_sql
    from snowflake.ml.feature_store.decl.types import ApplyResult

    # 1. Inject connection context into specs that lack database/schema
    for spec in getattr(batch, "specs", []):
        if hasattr(spec, "database") and not getattr(spec, "database", None):
            try:
                spec.database = database
            except (AttributeError, ValueError):
                pass
        # Pydantic models use schema_ to avoid conflict with BaseModel.schema()
        if hasattr(spec, "schema_") and not getattr(spec, "schema_", None):
            try:
                spec.schema_ = schema
            except (AttributeError, ValueError):
                pass

    # 1b. Resolve datasource columns into feature view source references
    _resolve_datasource_columns(batch)

    # 2. Validate
    validation_results = validate_specs(batch, applied_state)
    errors = [r for r in validation_results if getattr(r, "severity", "") == "ERROR"]
    if errors:
        return ApplyResult(
            status="validation_failed",
            errors=[str(e) for e in errors],
        )

    # 2. Generate plan
    plan = generate_plan(batch, applied_state, options)
    ops = getattr(plan, "ops", [])

    # 3. Generate SQL — exclude NO_CHANGE ops (informational only)
    executable_plan = Plan(
        ops=[op for op in ops if op.kind != OpKind.NO_CHANGE],
        warnings=list(getattr(plan, "warnings", [])),
    )
    sql_stmts = generate_sql(executable_plan, database=database, schema=schema, warehouse=warehouse)

    return ApplyResult(
        status="ready",
        ops=[
            {
                "operation": op.kind.value,
                "name": op.name.lower(),
                "reason": op.reason,
                "destructive": op.destructive,
            }
            for op in ops  # all ops including NO_CHANGE (for display)
        ],
        sql_statements=sql_stmts,
        warnings=list(getattr(plan, "warnings", [])),
    )


# ---------------------------------------------------------------------------
# Imperative execution
# ---------------------------------------------------------------------------


def execute_plan(
    plan: Any,
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: Any,
) -> Any:
    """Execute a Plan by delegating each PlanOp to FeatureStore methods.

    This is the primary execution path for ``snow feature apply``.  The
    executor lazy-imports ``FeatureStore``, ``FeatureView``, and ``Entity``
    from ``snowflake.ml.feature_store`` — after upstream lazy-import fixes,
    these imports do NOT pull in numpy/pandas/pyarrow.

    Args:
        plan: Plan from ``generate_plan()``.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name.
        schema: Snowflake schema name.
        warehouse: Snowflake warehouse name.
        options: PlanOptions controlling execution (overwrite, etc.).

    Returns:
        ApplyResult with per-operation status.
    """
    from snowflake.ml.feature_store.decl.imperative_executor import (
        execute_plan as _execute,
    )

    return _execute(plan, session, database, schema, warehouse, options)
