"""Top-level facade functions for the declarative feature store library.

This module is the **only** entry point for the CLI plugin. It must never
be bypassed in favour of importing internal modules (``invariants``,
``planner``, ``state``, etc.) directly. This keeps the substitution surface
small when individual responsibilities are migrated to Global Services.
"""

from __future__ import annotations

from typing import Any, Optional

from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.types import (
    AppliedState,
    Plan,
    PlanOptions,
    SpecBatch,
    ValidationResult,
)

# ---------------------------------------------------------------------------
# Service / HTTP facades
# ---------------------------------------------------------------------------


def parse_service_status(raw_json: str) -> dict:
    """Parse the JSON string from SYSTEM$GET_FEATURE_STORE_RUNTIME_STATUS.

    Delegates to :func:`decl.service.parse_service_status`.

    Args:
        raw_json: JSON string returned by the system function.

    Returns:
        Parsed status dict.
    """
    from snowflake.ml.feature_store.decl.service import parse_service_status as _parse

    return _parse(raw_json)


def get_service_endpoint(status: dict, name: str) -> Optional[str]:
    """Extract an endpoint URL by name from a parsed status dict.

    Args:
        status: Dict returned by :func:`parse_service_status`.
        name: Endpoint name (e.g. ``"ingest"`` or ``"query"``).

    Returns:
        URL string, or ``None`` if the endpoint is not found.
    """
    from snowflake.ml.feature_store.decl.service import get_service_endpoint as _get

    return _get(status, name)


def format_status_display(
    status: dict,
    user: str = "",
    database: str = "",
    schema: str = "",
) -> str:
    """Format the parsed runtime status into a rich multi-line display.

    Args:
        status: Dict returned by :func:`parse_service_status`.
        user: Current Snowflake user.
        database: Current database.
        schema: Current schema.

    Returns:
        Formatted multi-line string.
    """
    from snowflake.ml.feature_store.decl.service import format_status_display as _fmt

    return _fmt(status, user, database, schema)


def format_describe_display(
    fv_name: str,
    version: str,
    database: str,
    schema: str,
    oft_name: str,
    entities: list[str],
    describe_rows: list[dict],
    show_row: Optional[dict] = None,
    spec: Optional[dict] = None,
    examples: Optional[list[str]] = None,
) -> str:
    """Format a rich describe display for a feature view."""
    from snowflake.ml.feature_store.decl.service import format_describe_display as _fmt

    return _fmt(
        fv_name, version, database, schema, oft_name,
        entities, describe_rows, show_row, spec, examples,
    )


def service_sql(
    database: str,
    schema: str,
    producer_role: str = "ACCOUNTADMIN",
    consumer_role: str = "PUBLIC",
) -> dict[str, str]:
    """Return SQL strings for service management, keyed by operation.

    Args:
        database: Snowflake database name.
        schema: Snowflake schema name.
        producer_role: Snowflake role for producing features.
        consumer_role: Snowflake role for consuming features.

    Returns:
        Dict with keys: get_status, create, drop, show_ofts,
        drop_oft_template.
    """
    from snowflake.ml.feature_store.decl.service import service_sql as _sql

    return _sql(database, schema, producer_role, consumer_role)


def build_ingest_request(source_name: str, records: list[dict]) -> dict:
    """Build the JSON body for POST /api/v1/ingest.

    Args:
        source_name: Name of the streaming source to ingest into.
        records: List of record dicts to ingest.

    Returns:
        Request body dict.
    """
    from snowflake.ml.feature_store.decl.service import build_ingest_request as _build

    return _build(source_name, records)


def build_query_request(fv_name: str, keys: list[dict]) -> dict:
    """Build the JSON body for POST /api/v1/query.

    Args:
        fv_name: Feature view name to query.
        keys: List of key dicts identifying the entities to fetch.

    Returns:
        Request body dict.
    """
    from snowflake.ml.feature_store.decl.service import build_query_request as _build

    return _build(fv_name, keys)


def build_describe_examples(
    fv_name: str,
    version: str,
    source_name: str,
    describe_rows: list[dict],
    ingest_url: Optional[str],
    query_url: Optional[str],
    spec: Optional[dict] = None,
) -> list[str]:
    """Build example curl commands for ingest and query.

    When a *spec* dict (parsed YAML) is provided, examples use the UDF
    output columns for ingest and the entity columns for query.

    Args:
        fv_name: Feature view name (user-facing, lowercase).
        version: Feature view version (e.g. ``"v1"``).
        source_name: Source name for ingest (e.g. ``"user_events"``).
        describe_rows: Rows from DESCRIBE ONLINE FEATURE TABLE (fallback).
        ingest_url: Base ingest endpoint URL, or ``None``.
        query_url: Base query endpoint URL, or ``None``.
        spec: Optional parsed YAML spec dict for the feature view.

    Returns:
        List of example strings (may be empty if no endpoints available).
    """
    from snowflake.ml.feature_store.decl.service import (
        build_describe_examples as _build,
    )

    return _build(fv_name, version, source_name, describe_rows, ingest_url, query_url, spec)


def post_service_json(url: str, pat: str, body: dict) -> dict:
    """POST JSON to an Online Service REST endpoint with PAT bearer auth.

    Delegates to :func:`decl.http.post_json`.

    Args:
        url: Full endpoint URL.
        pat: Snowflake Programmatic Access Token.
        body: Request body dict; will be JSON-serialised.

    Returns:
        Parsed response dict.
    """
    from snowflake.ml.feature_store.decl.http import post_json

    return post_json(url, pat, body)


def load_specs(files: list[str], config: Optional[dict[str, Any]] = None) -> SpecBatch:
    """Load and parse spec files into a ``SpecBatch``.

    Accepts ``.py``, ``.yaml``, ``.yml``, and ``.json`` files. Applies Jinja2
    templating if ``config`` is provided and the file contains template syntax.
    Glob patterns and ``./...`` recursive expansion are resolved automatically.

    Args:
        files: Paths to spec files. Glob patterns and ``./...`` recursive
            expansion are resolved before loading.
        config: Jinja2 template variables. May be ``None`` if no templating
            is needed.

    Returns:
        SpecBatch containing all loaded and compiled spec objects.
    """
    from snowflake.ml.feature_store.decl import loader

    return loader.load_specs(files, config=config)


def validate_specs(batch: SpecBatch, applied_state: AppliedState) -> list[ValidationResult]:
    """Validate a spec batch against invariant rules and applied state.

    Runs all invariant checks defined in ``DevExAndSchemaAndCICD.md``,
    including version management, column evolution, dependency resolution,
    and state synchronization.

    Args:
        batch: The parsed spec batch to validate.
        applied_state: The current applied state snapshot from Snowflake.

    Returns:
        Combined list of ``ValidationResult`` objects (ERRORRs and WARNINGGs).
    """
    from snowflake.ml.feature_store.decl.invariants import (
        validate_specs as _validate_specs,
    )

    return _validate_specs(batch, applied_state)


def generate_plan(
    batch: SpecBatch,
    applied_state: AppliedState,
    options: PlanOptions,
) -> Plan:
    """Generate a dependency-ordered execution plan.

    Diffs the incoming ``SpecBatch`` against ``AppliedState`` to classify
    each spec as CREATE, UPDATE, RECREATE, or NO_CHANGE. Returns a
    topologically-sorted ``Plan`` with one ``PlanOp`` per operation.

    Args:
        batch: The validated spec batch.
        applied_state: The current applied state snapshot from Snowflake.
        options: Flags that control plan generation (dev_mode, overwrite, etc.).

    Returns:
        Topologically-sorted execution plan.
    """
    from snowflake.ml.feature_store.decl.planner import generate_plan as _generate_plan

    return _generate_plan(batch, applied_state, options)


def generate_example(output_dir: str) -> dict[str, Any]:
    """Write example YAML spec files under *output_dir*.

    Creates ``entities/``, ``datasources/``, and ``feature_views/``
    subdirectories and writes one starter spec file in each.

    Args:
        output_dir: Base directory under which example files are written.
            Created automatically (including parents) if it does not exist.

    Returns:
        Dict with keys ``status`` (``"created"``) and ``files`` (list of
        absolute paths to the written files).
    """
    from snowflake.ml.feature_store.decl.examples import (
        generate_example as _generate_example,
    )

    return _generate_example(output_dir)


def export_specs(
    show_rows: list[dict[str, Any]],
    describe_rows_by_oft: dict[str, list[dict[str, Any]]],
    output_dir: str,
    database: str,
    schema: str,
) -> dict[str, Any]:
    """Reconstruct YAML specs from raw SHOW/DESCRIBE results and write to disk.

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES`` (list of dicts).
        describe_rows_by_oft: Map of OFT name → ``DESCRIBE`` rows (list of
            dicts).
        output_dir: Base output directory.
        database: Connection database name.
        schema: Connection schema name.

    Returns:
        Dict with keys ``status``, ``directory``, and ``files``.
    """
    from snowflake.ml.feature_store.decl.exporter import export_specs as _export_specs

    return _export_specs(show_rows, describe_rows_by_oft, output_dir, database, schema)


def fetch_applied_state(
    raw_show_results: list[dict[str, Any]],
    raw_table_results: Optional[list[dict[str, Any]]] = None,
    describe_map: Optional[dict[str, list[dict[str, Any]]]] = None,
) -> AppliedState:
    """Parse raw Snowflake query results into an ``AppliedState`` snapshot.

    The CLI is responsible for executing the SQL queries and passing the
    raw results to this function. This design allows GS to provide the data
    via a REST API in the future without changing this function's signature.

    Args:
        raw_show_results: Rows from ``SHOW ONLINE FEATURE TABLES``.
        raw_table_results: Rows from ``SHOW TABLES`` (offline backing tables).
        describe_map: Mapping of OFT name → ``DESCRIBE ONLINE FEATURE TABLE``
            rows.  When provided, deployed objects without a ``specification``
            column in SHOW results are reconstructed from DESCRIBE data so that
            idempotency checks can detect ``NO_CHANGE`` correctly.

    Returns:
        AppliedState snapshot parsed from the raw query results.
    """
    from snowflake.ml.feature_store.decl.state import (
        fetch_applied_state as _fetch_applied_state,
    )

    return _fetch_applied_state(raw_show_results, raw_table_results, describe_map=describe_map)


def compile_to_spec(
    spec_dict: dict[str, Any],
    database: str,
    schema: str,
) -> dict[str, Any]:
    """Compile a YAML authoring-format spec into imperative FeatureViewSpec format.

    Args:
        spec_dict: The loaded/compiled spec dict from the authoring YAML.
        database: Snowflake database name (from connection context).
        schema: Snowflake schema name (from connection context).

    Returns:
        Dict matching FeatureViewSpec.to_dict() output, ready for
        JSON serialization in FROM SPECIFICATION $$ ... $$.
    """
    from snowflake.ml.feature_store.decl.spec_compiler import (
        compile_to_spec as _compile,
    )

    return _compile(spec_dict, database, schema)


# ---------------------------------------------------------------------------
# Query string factories (CLI should use these instead of hardcoded SQL)
# ---------------------------------------------------------------------------


def state_queries(database: str, schema: str) -> dict[str, str]:
    """Return SQL strings for fetching applied state."""
    from snowflake.ml.feature_store.decl.queries import state_queries as _sq

    return _sq(database, schema)


def list_query(database: str, schema: str) -> str:
    """Return the SHOW ONLINE FEATURE TABLES SQL string."""
    from snowflake.ml.feature_store.decl.queries import list_query as _lq

    return _lq(database, schema)


def describe_query(name: str, database: str, schema: str) -> str:
    """Return the SHOW ... LIKE SQL string for a named object."""
    from snowflake.ml.feature_store.decl.queries import describe_query as _dq

    return _dq(name, database, schema)


def describe_columns_query(name: str, database: str, schema: str) -> str:
    """Return the DESCRIBE ONLINE FEATURE TABLE SQL string."""
    from snowflake.ml.feature_store.decl.queries import describe_columns_query as _dcq

    return _dcq(name, database, schema)


def drop_queries(names: list[str], database: str, schema: str) -> list[str]:
    """Return DROP SQL strings for the named objects."""
    from snowflake.ml.feature_store.decl.queries import drop_queries as _dqs

    return _dqs(names, database, schema)


def export_queries(database: str, schema: str) -> dict[str, str]:
    """Return SQL strings for the export workflow."""
    from snowflake.ml.feature_store.decl.queries import export_queries as _eq

    return _eq(database, schema)


def enrich_list_results(
    show_rows: list[dict[str, Any]],
    describe_map: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Enrich SHOW ONLINE FEATURE TABLES rows with parsed names and entities.

    Adds ``feature_view``, ``version``, and ``entities`` columns to each row
    by parsing the OFT name convention and extracting primary key columns
    from DESCRIBE results.

    Args:
        show_rows: Raw rows from SHOW ONLINE FEATURE TABLES.
        describe_map: Mapping of OFT name → DESCRIBE rows.

    Returns:
        Enriched list of row dicts with added columns.
    """
    from snowflake.ml.feature_store.decl.state import _parse_oft_name

    enriched = []
    for row in show_rows:
        r = dict(row)
        oft_name = r.get("name", "")
        base_name, version = _parse_oft_name(oft_name)
        r["feature_view"] = base_name.lower()
        r["version"] = version.lower()

        # Extract entity columns from DESCRIBE (primary key columns)
        desc_rows = describe_map.get(oft_name, [])
        pk_cols = []
        for col in desc_rows:
            # Try multiple key variants for the primary key indicator
            is_pk = False
            for pk_key in ("primary key", "PRIMARY KEY", "primary_key"):
                val = col.get(pk_key, "")
                if val and str(val).upper() in ("Y", "YES", "TRUE", "1"):
                    is_pk = True
                    break
            if is_pk:
                pk_cols.append(col.get("name", col.get("NAME", "")))
        r["entities"] = ", ".join(pk_cols) if pk_cols else ""
        enriched.append(r)
    return enriched


# ---------------------------------------------------------------------------
# Combined apply pipeline
# ---------------------------------------------------------------------------


def _resolve_datasource_columns(batch: Any) -> None:
    """Resolve datasource columns into feature view source references.

    Scans the batch for ``StreamingSource`` specs (which have ``columns``),
    then for each FV spec's ``sources`` list, if a source matches by name
    and has no columns, injects the datasource's columns.

    Mutates specs in place.
    """
    # Build a map: source name → columns from StreamingSource specs
    ds_columns: dict[str, list] = {}
    for spec in getattr(batch, "specs", []):
        if getattr(spec, "kind", "") in ("StreamingSource", "BatchSource", "SQLDataSource"):
            name = getattr(spec, "name", "")
            columns = getattr(spec, "columns", [])
            if name and columns:
                # Convert FSColumn Pydantic models to dicts, keeping only name+type
                col_dicts = []
                for c in columns:
                    if hasattr(c, "dict"):
                        d = c.dict()
                        col_dicts.append({k: v for k, v in d.items() if v is not None})
                    elif isinstance(c, dict):
                        col_dicts.append({k: v for k, v in c.items() if v is not None})
                ds_columns[name.lower()] = col_dicts

    if not ds_columns:
        return

    # Inject columns into FV source references that lack them
    for spec in getattr(batch, "specs", []):
        kind = getattr(spec, "kind", "")
        if kind not in ("StreamingFeatureView", "RealtimeFeatureView", "BatchFeatureView"):
            continue
        sources = getattr(spec, "sources", [])
        for i, src in enumerate(sources):
            if isinstance(src, dict):
                src_name = src.get("name", "")
                src_cols = src.get("columns")
            else:
                src_name = getattr(src, "name", "")
                src_cols = getattr(src, "columns", None)

            if src_cols:
                continue

            # Look up from datasource specs
            resolved = ds_columns.get(src_name.lower())
            if resolved:
                if isinstance(src, dict):
                    src["columns"] = resolved
                else:
                    try:
                        src.columns = resolved
                    except (AttributeError, ValueError):
                        pass


def generate_apply_sql(
    batch: Any,
    applied_state: Any,
    options: Any,
    database: str,
    schema: str,
    warehouse: str = "",
) -> Any:
    """Validate specs, generate plan, produce SQL — all in one call.

    Args:
        batch: SpecBatch from load_specs().
        applied_state: AppliedState from fetch_applied_state().
        options: PlanOptions controlling plan generation.
        database: Snowflake database name.
        schema: Snowflake schema name.
        warehouse: Snowflake warehouse name.

    Returns:
        ApplyResult with status, ops, sql_statements, warnings, errors.
    """
    from snowflake.ml.feature_store.decl.sql_generator import generate_sql
    from snowflake.ml.feature_store.decl.types import ApplyResult

    # 1. Inject connection context into specs that lack database/schema
    for spec in getattr(batch, "specs", []):
        if hasattr(spec, "database") and not getattr(spec, "database", None):
            try:
                spec.database = database
            except (AttributeError, ValueError):
                pass
        # Pydantic models use schema_ to avoid conflict with BaseModel.schema()
        if hasattr(spec, "schema_") and not getattr(spec, "schema_", None):
            try:
                spec.schema_ = schema
            except (AttributeError, ValueError):
                pass

    # 1b. Resolve datasource columns into feature view source references
    _resolve_datasource_columns(batch)

    # 2. Validate
    validation_results = validate_specs(batch, applied_state)
    errors = [r for r in validation_results if getattr(r, "severity", "") == "ERROR"]
    if errors:
        return ApplyResult(
            status="validation_failed",
            errors=[str(e) for e in errors],
        )

    # 2. Generate plan
    plan = generate_plan(batch, applied_state, options)
    ops = getattr(plan, "ops", [])

    # 3. Generate SQL — exclude NO_CHANGE ops (informational only)
    executable_plan = Plan(
        ops=[op for op in ops if op.kind != OpKind.NO_CHANGE],
        warnings=list(getattr(plan, "warnings", [])),
    )
    sql_stmts = generate_sql(executable_plan, database=database, schema=schema, warehouse=warehouse)

    return ApplyResult(
        status="ready",
        ops=[
            {
                "operation": op.kind.value,
                "name": op.name.lower(),
                "reason": op.reason,
                "destructive": op.destructive,
            }
            for op in ops  # all ops including NO_CHANGE (for display)
        ],
        sql_statements=sql_stmts,
        warnings=list(getattr(plan, "warnings", [])),
    )


# ---------------------------------------------------------------------------
# Imperative execution
# ---------------------------------------------------------------------------


def execute_plan(
    plan: Any,
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: Any,
) -> Any:
    """Execute a Plan by delegating each PlanOp to FeatureStore methods.

    This is the primary execution path for ``snow feature apply``.  The
    executor lazy-imports ``FeatureStore``, ``FeatureView``, and ``Entity``
    from ``snowflake.ml.feature_store`` — after upstream lazy-import fixes,
    these imports do NOT pull in numpy/pandas/pyarrow.

    Args:
        plan: Plan from ``generate_plan()``.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name.
        schema: Snowflake schema name.
        warehouse: Snowflake warehouse name.
        options: PlanOptions controlling execution (overwrite, etc.).

    Returns:
        ApplyResult with per-operation status.
    """
    from snowflake.ml.feature_store.decl.imperative_executor import (
        execute_plan as _execute,
    )

    return _execute(plan, session, database, schema, warehouse, options)
