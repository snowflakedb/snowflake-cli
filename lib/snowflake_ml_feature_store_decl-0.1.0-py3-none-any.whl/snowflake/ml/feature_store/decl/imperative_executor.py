"""Imperative executor for the declarative feature store.

Maps ``PlanOp`` objects to ``FeatureStore`` method calls.  All imports from
``snowflake.ml.feature_store`` are **lazy** (inside functions) so this module
can be included in the standalone ``decl`` wheel without pulling in heavy
transitive dependencies at import time.

This module MUST NOT import from ``snowflake.ml.dataset``,
``snowflake.ml.data``, or any other heavy snowml package.
"""

from __future__ import annotations

import logging
from typing import Any

from snowflake.ml.feature_store.decl import session_setup
from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.types import ApplyResult, Plan, PlanOptions

logger = logging.getLogger(__name__)


def execute_plan(
    plan: Plan,
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> ApplyResult:
    """Execute a Plan by delegating each PlanOp to FeatureStore methods.

    All ``snowflake.ml.feature_store`` imports are lazy — they happen here,
    not at module level.  After the upstream lazy-import fixes (dataset and
    circular feature_store imports made lazy), importing these classes does
    NOT pull in numpy/pandas/pyarrow.

    Args:
        plan: The execution plan from ``generate_plan``.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name.
        schema: Snowflake schema name (FeatureStore "name").
        warehouse: Snowflake warehouse name.
        options: Plan options (overwrite, dev_mode, etc.).

    Returns:
        ApplyResult with per-operation status.

    Raises:
        Exception: If any plan operation fails during execution.
    """
    session_setup.apply_to_session(session)

    # Lazy imports — lightweight after upstream fixes
    from snowflake.ml.feature_store.feature_store import CreationMode, FeatureStore

    fs = FeatureStore(
        session,
        database,
        schema,
        warehouse,
        creation_mode=CreationMode.FAIL_IF_NOT_EXIST,
    )

    ops: list[dict[str, Any]] = []
    errors: list[str] = []

    for op in plan.ops:
        if op.kind == OpKind.NO_CHANGE:
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        # Sources and groups are virtual — no imperative action needed.
        if op.kind in (
            OpKind.CREATE_SOURCE,
            OpKind.UPDATE_SOURCE,
            OpKind.DROP_SOURCE,
            OpKind.CREATE_FG,
            OpKind.DROP_FG,
        ):
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        try:
            _execute_op(fs, session, op, database, schema, warehouse, options)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "success",
                }
            )
        except Exception as e:
            logger.error("Failed to execute %s for %s: %s", op.kind.value, op.name, e)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "error",
                    "error": str(e),
                }
            )
            errors.append(f"{op.kind.value} {op.name}: {e}")
            raise

    status = "applied" if not errors else "partial_failure"
    return ApplyResult(
        status=status,
        ops=ops,
        sql_statements=[],  # deprecated — imperative API handles SQL internally
        warnings=list(plan.warnings),
        errors=errors,
    )


def _execute_op(
    fs: Any,
    session: Any,
    op: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> None:
    """Dispatch a single PlanOp to the appropriate FeatureStore method."""
    if op.kind == OpKind.CREATE_ENTITY:
        entity = _build_entity(op.payload)
        fs.register_entity(entity)

    elif op.kind == OpKind.DROP_ENTITY:
        # No imperative drop_entity yet — skip
        logger.warning("DROP_ENTITY is not yet supported; skipping %s", op.name)

    elif op.kind == OpKind.CREATE_FV:
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse)
        fs.register_feature_view(fv, version, overwrite=options.overwrite)

    elif op.kind == OpKind.UPDATE_FV:
        # UPDATE_FV — use update_feature_view for supported properties
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse)
        fs.register_feature_view(fv, version, overwrite=True)

    elif op.kind == OpKind.RECREATE_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        try:
            fs.delete_feature_view(name, version)
        except Exception as e:
            logger.warning("delete_feature_view(%s, %s) failed during RECREATE: %s", name, version, e)
        fv, new_version = _build_feature_view(op.payload, session, database, schema, warehouse)
        fs.register_feature_view(fv, new_version)

    elif op.kind == OpKind.DROP_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        fs.delete_feature_view(name, version)


def _build_entity(payload: dict[str, Any]) -> Any:
    """Construct an Entity from a spec payload dict.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_ENTITY.
            Expected keys: name, join_keys (list of dicts with "name").

    Returns:
        An ``Entity`` instance.
    """
    from snowflake.ml.feature_store.entity import Entity

    name = payload.get("name", "")
    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or ""
    return Entity(name=name, join_keys=join_keys, desc=desc)


def _build_feature_view(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
) -> tuple[Any, str]:
    """Construct a FeatureView from a spec payload dict.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_FV/RECREATE_FV.
        session: Snowpark Session for DataFrame construction.
        database: Default database.
        schema: Default schema.
        warehouse: Default warehouse.

    Returns:
        Tuple of (FeatureView, version_string).
    """
    from snowflake.ml.feature_store.entity import Entity
    from snowflake.ml.feature_store.feature_view import (
        FeatureView,
        OnlineConfig,
        OnlineStoreType,
    )

    name = payload.get("name", "")
    version = payload.get("version", "V1")

    # Build entities from ordered_entity_column_names
    entity_cols = payload.get("ordered_entity_column_names", [])
    entity_names = [col["name"] if isinstance(col, dict) else str(col) for col in entity_cols]
    # Create a single entity with all join keys (declarative specs flatten entities)
    entities = [Entity(name=f"{name}_entity", join_keys=entity_names)] if entity_names else []

    # Build feature_df from sources
    feature_df = _build_feature_df(payload, session, database, schema)

    # Optional parameters
    kwargs: dict[str, Any] = {}
    if payload.get("timestamp_field"):
        kwargs["timestamp_col"] = payload["timestamp_field"]
    if payload.get("batch_schedule"):
        kwargs["refresh_freq"] = payload["batch_schedule"]
    if payload.get("warehouse", warehouse):
        kwargs["warehouse"] = payload.get("warehouse", warehouse)
    if payload.get("description"):
        kwargs["desc"] = payload["description"]
    if payload.get("feature_granularity"):
        fg = payload["feature_granularity"]
        kwargs["feature_granularity"] = str(fg) if isinstance(fg, int) else fg

    # Online config
    if payload.get("online", False):
        target_lag = payload.get("target_lag")
        if isinstance(target_lag, int):
            target_lag = f"{target_lag} seconds"
        kwargs["online_config"] = OnlineConfig(
            enable=True,
            target_lag=target_lag or "0 seconds",
            store_type=OnlineStoreType.POSTGRES,
        )

    fv = FeatureView(
        name=name,
        entities=entities,
        feature_df=feature_df,
        **kwargs,
    )

    return fv, version


def _build_feature_df(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
) -> Any:
    """Construct a Snowpark DataFrame from the spec's source references.

    For batch sources with a table reference, returns ``session.table(name)``.
    For SQL-based sources, returns ``session.sql(query)``.
    For streaming sources, returns a minimal DataFrame from the UDF-transformed
    table if available.

    Falls back to a simple ``SELECT`` query built from entity and feature columns
    when no direct source table is available.

    Args:
        payload: Parsed feature view spec dict with sources, entities, and features.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name for resolving unqualified tables.
        schema: Snowflake schema name for resolving unqualified tables.

    Returns:
        A Snowpark DataFrame representing the feature view's source query.
    """
    sources = payload.get("sources", [])

    for src in sources:
        if isinstance(src, dict):
            # BatchSource with table reference
            table = src.get("table")
            if table:
                src_db = src.get("source_database", database)
                src_schema = src.get("source_schema", schema)
                fqn = f"{src_db}.{src_schema}.{table}"
                return session.table(fqn)

            # SQLDataSource with query
            query = src.get("query")
            if query:
                return session.sql(query)

    # Fallback: build a SELECT from entity + feature columns on a placeholder
    # This handles streaming sources where the backing table is created by
    # the FeatureStore during registration.
    entity_cols = payload.get("ordered_entity_column_names", [])
    col_names = [col["name"] if isinstance(col, dict) else str(col) for col in entity_cols]

    # Add feature output columns
    for feat in payload.get("features", []):
        oc = feat.get("output_column", {})
        if isinstance(oc, dict) and oc.get("name"):
            col_names.append(oc["name"])

    # Add UDF output columns if present
    udf = payload.get("udf")
    if udf and isinstance(udf, dict):
        for oc in udf.get("output_columns", []):
            if isinstance(oc, dict) and oc.get("name"):
                col_names.append(oc["name"])

    if not col_names:
        col_names = ["*"]

    col_list = ", ".join(col_names)
    # Use a dummy query that defines the schema — FeatureStore uses the
    # DataFrame's schema/query to create the backing Dynamic Table.
    query = f"SELECT {col_list} FROM {database}.{schema}.PLACEHOLDER WHERE 1=0"
    return session.sql(query)
