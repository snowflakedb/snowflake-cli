"""Imperative executor for the declarative feature store.

Maps ``PlanOp`` objects to ``FeatureStore`` method calls.  All imports from
``snowflake.ml.feature_store`` are **lazy** (inside functions) so this module
can be included in the standalone ``decl`` wheel without pulling in heavy
transitive dependencies at import time.

This module MUST NOT import from ``snowflake.ml.dataset``,
``snowflake.ml.data``, or any other heavy snowml package.
"""

from __future__ import annotations

import logging
from typing import Any

from snowflake.ml.feature_store.decl import session_setup
from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.errors import (
    DependencyError,
    FeatureStoreNotInitializedError,
)
from snowflake.ml.feature_store.decl.types import ApplyResult, Plan, PlanOptions
from snowflake.ml.feature_store.spec.enums import ENTITY_TAG_PREFIX

logger = logging.getLogger(__name__)


def assert_feature_store_initialized(
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
) -> Any:
    """Construct a ``FeatureStore(FAIL_IF_NOT_EXIST)`` or raise a clean
    init-required error pointing operators at ``snow feature init``.

    This is the single enforcement point for the declarative client's
    init-first invariant: every ``snow feature`` command except ``init``
    must fail fast if the target schema lacks the bootstrap tags
    (``SNOWML_FEATURE_STORE_OBJECT`` / ``SNOWML_FEATURE_VIEW_METADATA``).
    The snowml-core ``FeatureStore`` constructor already enforces that
    invariant by raising a ``NOT_FOUND`` ``SnowflakeMLException`` when
    either tag is absent (see ``_check_internal_objects_exist_or_throw``);
    we catch that specific error code and rewrap it as
    :class:`FeatureStoreNotInitializedError` so the CLI can render a
    one-line, actionable error instead of leaking snowml-core internals.

    Args:
        session: Snowpark ``Session`` to bind to the new ``FeatureStore``.
        database: Snowflake database name.
        schema: Snowflake schema name (the ``FeatureStore`` "name").
        warehouse: Default warehouse for the ``FeatureStore``.

    Returns:
        A constructed ``FeatureStore`` bound to ``database.schema`` so
        callers can reuse it without paying for a second
        ``FAIL_IF_NOT_EXIST`` check.

    Raises:
        FeatureStoreNotInitializedError: If the schema is missing the
            internal bootstrap tags or does not exist as a feature store.
        Exception: Any other exception raised by
            ``FeatureStore.__init__`` (e.g. auth, permissions, warehouse)
            is propagated verbatim — only the snowml-core ``NOT_FOUND``
            error (whether surfaced as a raw ``SnowflakeMLException`` or
            as the inner ``ValueError`` the telemetry decorator
            re-raises) is rewrapped as the init-required error.
    """
    from snowflake.ml._internal.exceptions import (
        error_codes,
        exceptions as snowml_exceptions,
    )
    from snowflake.ml.feature_store.feature_store import CreationMode, FeatureStore

    not_found_prefix = f"({error_codes.NOT_FOUND})"

    try:
        return FeatureStore(
            session,
            database,
            schema,
            warehouse,
            creation_mode=CreationMode.FAIL_IF_NOT_EXIST,
        )
    except snowml_exceptions.SnowflakeMLException as exc:
        # Direct (un-telemetry-wrapped) path: ``FeatureStore.__init__``
        # raised the typed snowml-core exception verbatim.  Happens in
        # unit tests and when the imperative codepath is invoked
        # without telemetry context.
        if exc.error_code == error_codes.NOT_FOUND:
            raise FeatureStoreNotInitializedError(database, schema, exc) from exc
        raise
    except ValueError as exc:
        # Telemetry-unwrapped path: in real execution
        # ``snowflake.ml._internal.telemetry`` catches the
        # ``SnowflakeMLException`` raised by
        # ``_check_internal_objects_exist_or_throw`` and re-raises
        # ``e.original_exception`` (a ``ValueError`` whose ``str()``
        # starts with the ``(<error_code>)`` marker).  We match the
        # ``(2101)`` prefix because ``error_code`` is no longer
        # available on the unwrapped exception.
        if str(exc).startswith(not_found_prefix):
            raise FeatureStoreNotInitializedError(database, schema, exc) from exc
        raise


def fetch_entity_rows(
    session: Any,
    database: str,
    schema: str,
    warehouse: str = "",
) -> list[dict[str, Any]]:
    """Fetch entity tag rows by delegating to ``FeatureStore.list_entities()``.

    The read-path counterpart to the entity-DDL ops in
    :func:`execute_plan` — both route through the imperative
    ``FeatureStore`` API so the declarative module never emits raw
    entity-tag SQL.  When the target schema lacks the bootstrap
    tags, :func:`assert_feature_store_initialized` rewraps the
    snowml-core ``NOT_FOUND`` as
    :class:`FeatureStoreNotInitializedError` so the CLI surfaces a
    clear "run ``snow feature init``" message.

    The imperative ``list_entities()`` returns a Snowpark DataFrame whose
    rows have keys ``NAME`` (with the ``SNOWML_FEATURE_STORE_ENTITY_``
    prefix already stripped), ``JOIN_KEYS`` (a JSON-decodable string),
    ``DESC``, and ``OWNER``.  The legacy CLI applied-state parser
    (:func:`state._build_entity_object`) and the list-renderer
    (:func:`api.enrich_list_results`) both expect the raw ``SHOW TAGS``
    shape (``name`` *with* the prefix, ``database_name``, ``schema_name``,
    ``allowed_values``, ``comment``).  This function translates between
    those two shapes so existing consumers keep working unchanged.

    Args:
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name to scope the listing to.
        schema: Snowflake schema name (the FeatureStore "name") to scope
            the listing to.
        warehouse: Default warehouse for the imperative ``FeatureStore``
            constructor.  ``list_entities()`` itself only issues a
            ``SHOW TAGS`` so the warehouse is not actually used; an
            empty string is accepted, but a real value is recommended
            when the caller has one available so future imperative
            calls work without re-priming.

    Returns:
        A list of row dicts in the SHOW TAGS shape.  Returns an empty
        list when no entities are registered.
    """
    fs = assert_feature_store_initialized(session, database, schema, warehouse)
    listed = fs.list_entities().collect()

    translated: list[dict[str, Any]] = []
    for row in listed:
        if hasattr(row, "as_dict"):
            data = row.as_dict()
        elif isinstance(row, dict):
            data = dict(row)
        else:
            try:
                data = dict(row)
            except (TypeError, ValueError):
                logger.debug("Skipping un-mappable entity row: %r", row)
                continue

        # ``FeatureStore.list_entities()`` returns rows with the
        # ``SNOWML_FEATURE_STORE_ENTITY_`` prefix already stripped, plus
        # ``JOIN_KEYS`` (JSON string), ``DESC``, ``OWNER``.  Re-add the
        # prefix and copy the JSON join_keys / desc into the SHOW TAGS
        # column names that downstream consumers
        # (``state._build_entity_object``, ``api.enrich_list_results``)
        # expect.
        raw_name = data.get("NAME") or data.get("name") or ""
        if not raw_name:
            continue
        tag_name = f"{ENTITY_TAG_PREFIX}{raw_name}"
        allowed = data.get("JOIN_KEYS") or data.get("join_keys") or ""
        comment = data.get("DESC") or data.get("desc") or ""
        owner = data.get("OWNER") or data.get("owner") or ""

        translated.append(
            {
                "name": tag_name,
                "database_name": database,
                "schema_name": schema,
                "allowed_values": allowed,
                "comment": comment,
                "owner": owner,
            }
        )

    return translated


def execute_plan(
    plan: Plan,
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> ApplyResult:
    """Execute a Plan by delegating each PlanOp to FeatureStore methods.

    All ``snowflake.ml.feature_store`` imports are lazy — they happen here,
    not at module level.  After the upstream lazy-import fixes (dataset and
    circular feature_store imports made lazy), importing these classes does
    NOT pull in numpy/pandas/pyarrow.

    Args:
        plan: The execution plan from ``generate_plan``.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name.
        schema: Snowflake schema name (FeatureStore "name").
        warehouse: Snowflake warehouse name.
        options: Plan options (overwrite, dev_mode, etc.).

    Returns:
        ApplyResult with per-operation status.

    Raises:
        Exception: If any plan operation fails during execution.
    """
    session_setup.apply_to_session(session)

    # Destructive-op guard (apply-time policy enforcement).
    #
    # The planner is policy-free: it always emits ``RECREATE_FV`` /
    # ``DROP_FV`` / ``DROP_ENTITY`` for destructive diffs so operators
    # can see them in the ``snow feature plan`` output before deciding
    # whether to apply.  The ``allow_recreate`` flag is the operator
    # opt-in that gates *apply*, not plan generation — refusing here
    # (before any FV side-effect or even ``FeatureStore`` construction)
    # leaves the plan file unrenamed under L5 (Mark-Failed-Stays-
    # Unapplied) so a follow-up ``snow feature apply --allow-recreate``
    # consumes the same plan.  See BUG_BASH §14 and
    # plans/apply_allow_recreate_destructive_gate_*.plan.md.
    if not options.allow_recreate:
        destructive_ops = [op for op in plan.ops if op.destructive]
        if destructive_ops:
            refused_rows = [
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": True,
                    "status": "refused",
                }
                for op in destructive_ops
            ]
            skipped_rows = [
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": False,
                    "status": "skipped",
                }
                for op in plan.ops
                if not op.destructive
            ]
            return ApplyResult(
                status="refused",
                ops=refused_rows + skipped_rows,
                warnings=list(plan.warnings),
                errors=[
                    f"Apply refused: {len(destructive_ops)} destructive "
                    f"operation(s) require --allow-recreate. "
                    f"Re-run with `snow feature apply --allow-recreate <path>`."
                ],
            )

    # Eager ``FeatureStore`` construction.  Every entity + FV op now
    # routes through the imperative API (no raw entity-tag SQL
    # remains in this module), so the init-first invariant must fire
    # uniformly across entity-only, FV-only, and mixed plans:
    # ``assert_feature_store_initialized`` rewraps the snowml-core
    # ``NOT_FOUND`` as :class:`FeatureStoreNotInitializedError` so
    # the CLI's outer handler can surface the
    # "run ``snow feature init``" guidance.
    fs = assert_feature_store_initialized(session, database, schema, warehouse)

    ops: list[dict[str, Any]] = []
    errors: list[str] = []

    for op in plan.ops:
        if op.kind == OpKind.NO_CHANGE:
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        # ``CREATE_SOURCE`` for ``StreamingSource`` lands as a real
        # ``FeatureStore.register_stream_source`` call so the streaming
        # preamble's ``get_stream_source`` lookup succeeds when a
        # downstream ``CREATE_FV`` runs.  ``BatchSource`` and
        # feature-group ops remain virtual — there is no imperative
        # analogue for them.
        if op.kind == OpKind.CREATE_SOURCE and op.payload.get("kind") == "StreamingSource":
            try:
                _execute_create_stream_source(fs, op.payload)
                ops.append(
                    {
                        "operation": op.kind.value,
                        "name": op.name,
                        "reason": op.reason,
                        "destructive": op.destructive,
                        "status": "success",
                    }
                )
            except Exception as e:
                logger.error("Failed to execute %s for %s: %s", op.kind.value, op.name, e)
                ops.append(
                    {
                        "operation": op.kind.value,
                        "name": op.name,
                        "reason": op.reason,
                        "destructive": op.destructive,
                        "status": "error",
                        "error": str(e),
                    }
                )
                errors.append(f"{op.kind.value} {op.name}: {e}")
                raise
            continue

        if op.kind in (
            OpKind.CREATE_SOURCE,
            OpKind.UPDATE_SOURCE,
            OpKind.DROP_SOURCE,
            OpKind.CREATE_FG,
            OpKind.DROP_FG,
        ):
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        try:
            _execute_op(fs, session, op, database, schema, warehouse, options)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "success",
                }
            )
        except Exception as e:
            logger.error("Failed to execute %s for %s: %s", op.kind.value, op.name, e)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "error",
                    "error": str(e),
                }
            )
            errors.append(f"{op.kind.value} {op.name}: {e}")
            raise

    status = "applied" if not errors else "partial_failure"
    return ApplyResult(
        status=status,
        ops=ops,
        warnings=list(plan.warnings),
        errors=errors,
    )


def _execute_op(
    fs: Any,
    session: Any,
    op: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> None:
    """Dispatch a single PlanOp to the appropriate executor.

    All entity + FV ops route through the imperative ``FeatureStore``
    instance ``fs`` — no raw entity-tag SQL is issued from this
    module.  The ``fs`` is constructed eagerly by
    :func:`execute_plan` via
    :func:`assert_feature_store_initialized`, so the init-first
    invariant has already fired by the time this dispatcher runs.

    Args:
        fs: The constructed ``FeatureStore`` instance bound to
            ``database.schema``.  Reused across every op in the plan.
        session: Snowpark session for ``_build_feature_view`` /
            ``_build_feature_df`` (DataFrame construction).
        op: The plan op to execute.
        database: Default database for entity / FV resolution.
        schema: Default schema for entity / FV resolution.
        warehouse: Default warehouse forwarded to FV constructors.
        options: Plan-wide execution options (e.g. ``overwrite``).
    """
    if op.kind == OpKind.CREATE_ENTITY:
        _execute_create_entity(fs, op)

    elif op.kind == OpKind.DROP_ENTITY:
        _execute_drop_entity(fs, op)

    elif op.kind == OpKind.UPDATE_ENTITY:
        _execute_update_entity(fs, op)

    elif op.kind == OpKind.CREATE_FV:
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse, fs=fs)
        fs.register_feature_view(fv, version, overwrite=options.overwrite)

    elif op.kind == OpKind.UPDATE_FV:
        # UPDATE_FV — use update_feature_view for supported properties
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse, fs=fs)
        fs.register_feature_view(fv, version, overwrite=True)

    elif op.kind == OpKind.RECREATE_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        try:
            fs.delete_feature_view(name, version)
        except Exception as e:
            logger.warning("delete_feature_view(%s, %s) failed during RECREATE: %s", name, version, e)
        fv, new_version = _build_feature_view(op.payload, session, database, schema, warehouse, fs=fs)
        fs.register_feature_view(fv, new_version)

    elif op.kind == OpKind.DROP_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        fs.delete_feature_view(name, version)


def _build_entity(payload: dict[str, Any]) -> Any:
    """Construct an Entity from a spec payload dict.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_ENTITY.
            Expected keys: name, join_keys (list of dicts with "name").

    Returns:
        An ``Entity`` instance.
    """
    from snowflake.ml.feature_store.entity import Entity

    name = payload.get("name", "")
    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or ""
    return Entity(name=name, join_keys=join_keys, desc=desc)


def _spec_columns_to_struct_type(columns: list[Any]) -> Any:
    """Translate a spec ``columns:`` list to a Snowpark ``StructType``.

    The spec compiler normalises column types to the
    ``snowflake.snowpark.types`` class names listed in
    :data:`snowflake.ml.feature_store.stream_source._TYPE_NAME_TO_CLASS`
    (``StringType``, ``LongType``, ``DoubleType``, ``DecimalType``,
    ``BooleanType``, ``TimestampType``).  This helper maps that
    string-typed authoring shape onto the real Snowpark types that
    ``StreamSource``'s schema validator expects.

    Args:
        columns: List of spec column dicts; each carries ``name`` and
            ``type`` plus optional precision / scale / length / tz.

    Returns:
        A ``snowflake.snowpark.types.StructType`` matching ``columns``.

    Raises:
        ValueError: If a column carries an unsupported type name.
        RuntimeError: If ``snowflake-snowpark-python`` is not installed —
            the decl wheel does not pull it in transitively, so streaming
            registration requires the imperative feature-store stack.
    """
    try:
        from snowflake.snowpark.types import (
            BooleanType,
            DecimalType,
            DoubleType,
            LongType,
            StringType,
            StructField,
            StructType,
            TimestampType,
        )
    except ImportError as e:
        raise RuntimeError(
            "snowflake-snowpark-python is required to register streaming sources "
            "or streaming feature views from a declarative spec; install it via the "
            "imperative feature-store wheel."
        ) from e

    type_map: dict[str, Any] = {
        "StringType": StringType,
        "LongType": LongType,
        "DoubleType": DoubleType,
        "DecimalType": DecimalType,
        "BooleanType": BooleanType,
        "TimestampType": TimestampType,
    }

    fields: list[Any] = []
    for col in columns:
        if not isinstance(col, dict):
            raise ValueError(f"Stream-source column entry is not a dict: {col!r}")
        col_name = col.get("name", "")
        type_name = col.get("type", "")
        cls = type_map.get(type_name)
        if cls is None:
            raise ValueError(
                f"Unsupported column type '{type_name}' for stream-source field '{col_name}'. "
                f"Supported: {sorted(type_map)}"
            )
        if type_name == "DecimalType":
            dt = cls(col.get("precision", 38), col.get("scale", 0))
        elif type_name == "StringType":
            dt = cls(col.get("length")) if col.get("length") else cls()
        else:
            dt = cls()
        fields.append(StructField(col_name, dt))
    return StructType(fields)


def _execute_create_stream_source(fs: Any, payload: dict[str, Any]) -> Any:
    """Register a streaming source in Snowflake's feature-store metadata.

    Mirrors the imperative form: ``fs.register_stream_source(StreamSource
    (name, schema, desc=...))``.  Idempotent — if the source is already
    registered, snowml-core emits a ``UserWarning`` and returns the
    existing object without raising.

    Args:
        fs: A ``FeatureStore`` instance.
        payload: ``CREATE_SOURCE`` op payload with ``name``, ``columns``,
            and optional ``description``.

    Returns:
        The registered ``StreamSource`` (or the pre-existing one when
        idempotency triggers).

    Raises:
        ValueError: If ``payload['name']`` is empty.
    """
    from snowflake.ml.feature_store.stream_source import StreamSource

    name = payload.get("name", "")
    if not name:
        raise ValueError("CREATE_SOURCE for StreamingSource requires a non-empty 'name'.")
    desc = payload.get("description", "") or payload.get("desc", "") or ""
    schema = _spec_columns_to_struct_type(payload.get("columns", []))
    stream_source = StreamSource(name=name, schema=schema, desc=desc)
    return fs.register_stream_source(stream_source)


def _execute_create_entity(fs: Any, op: Any) -> None:
    """Materialise an ``OpKind.CREATE_ENTITY`` via ``FeatureStore.register_entity``.

    Delegates fully to the imperative API.  ``register_entity`` is
    idempotent: when the entity tag already exists snowml-core emits
    a ``UserWarning`` and returns the pre-existing object instead of
    raising, which means re-applying an unchanged plan is a no-op
    (matching the planner's ``NO_CHANGE`` contract for entities).

    Args:
        fs: The constructed ``FeatureStore`` instance (built in
            :func:`execute_plan` via
            :func:`assert_feature_store_initialized`).
        op: The ``CREATE_ENTITY`` plan op carrying the entity payload.

    Raises:
        ValueError: When ``op.payload`` does not carry an entity name.
    """
    from snowflake.ml.feature_store.entity import Entity

    payload = op.payload
    name = payload.get("name", "") or op.name
    if not name:
        raise ValueError(f"CREATE_ENTITY op {op.name} has no entity name in its payload.")

    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or payload.get("desc", "") or ""

    entity = Entity(name=name, join_keys=join_keys, desc=desc)
    fs.register_entity(entity)


def _execute_drop_entity(fs: Any, op: Any) -> None:
    """Materialise an ``OpKind.DROP_ENTITY`` via ``FeatureStore.delete_entity``.

    Delegates fully to the imperative API.  Two snowml-core failure
    modes need rewrapping for the declarative caller:

    * ``NOT_FOUND`` — the entity was already deleted out-of-band (or
      a previous partial apply removed it).  Treat as a soft skip so
      re-applying the plan stays idempotent; the planner's
      ``NO_CHANGE`` contract assumes drops are best-effort.
    * ``SNOWML_DELETE_FAILED`` — Snowflake rejected the underlying
      ``DROP TAG`` because an active feature view still references
      the entity.  Rewrap as :class:`DependencyError` so the CLI can
      surface a clear "drop the FV first" message instead of a
      generic backend error.

    Args:
        fs: The constructed ``FeatureStore`` instance (built in
            :func:`execute_plan` via
            :func:`assert_feature_store_initialized`).
        op: The ``DROP_ENTITY`` plan op carrying the entity payload.

    Raises:
        DependencyError: When the entity is still referenced by an
            active feature view.  The original exception is chained.
        snowml_exceptions.SnowflakeMLException: Any other
            ``SnowflakeMLException`` raised by ``delete_entity`` (e.g.
            permissions / connection errors) is propagated verbatim.
    """
    from snowflake.ml._internal.exceptions import (
        error_codes,
        exceptions as snowml_exceptions,
    )

    payload = op.payload or {}
    name = payload.get("name", "") or op.name

    try:
        fs.delete_entity(name)
    except snowml_exceptions.SnowflakeMLException as exc:
        if exc.error_code == error_codes.NOT_FOUND:
            logger.info(
                "delete_entity(%s) — entity already absent; treating DROP_ENTITY as no-op.",
                name,
            )
            return
        if exc.error_code == error_codes.SNOWML_DELETE_FAILED:
            raise DependencyError(
                f"Cannot drop entity {name!r} because it is still referenced "
                "by one or more deployed feature views. Drop the FV first, "
                f"then re-apply. Underlying error: {exc}"
            ) from exc
        raise


def _execute_update_entity(fs: Any, op: Any) -> None:
    """Materialise an ``OpKind.UPDATE_ENTITY`` via ``FeatureStore.update_entity``.

    Delegates fully to the imperative API.  The ``update_entity``
    method was extended in this refactor to accept a ``join_keys=``
    keyword so the declarative layer can update both ``DESC`` and
    ``ALLOWED_VALUES`` through a single call (previously only
    ``DESC`` was supported, which forced declarative join-key edits
    through raw ``ALTER TAG`` SQL).

    Args:
        fs: The constructed ``FeatureStore`` instance (built in
            :func:`execute_plan` via
            :func:`assert_feature_store_initialized`).
        op: The ``UPDATE_ENTITY`` plan op carrying the new payload.

    Raises:
        ValueError: When ``op.payload`` does not carry an entity name.
    """
    payload = op.payload
    name = payload.get("name", "") or op.name
    if not name:
        raise ValueError(f"UPDATE_ENTITY op {op.name} has no entity name in its payload.")

    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or ""

    fs.update_entity(name, desc=desc, join_keys=join_keys or None)


def _build_features(raw: list[dict[str, Any]]) -> list[Any]:
    """Convert planner-payload feature dicts to imperative Feature objects.

    The planner payload encodes each aggregated feature as a dict shaped
    like::

        {
            "function": "sum",
            "window_sec": 3600,
            "offset_sec": 0,                  # optional
            "function_params": {"n": 10},     # optional, e.g. last_n
            "source_column": {"name": "AMOUNT", "type": "DoubleType"},
            "output_column": {"name": "AMOUNT_SUM_1H", "type": "DoubleType"},
        }

    The imperative ``Feature`` builder accepts ``window`` / ``offset`` as
    duration strings (``"3600s"``, ``"60s"``) which round-trip through
    ``interval_to_seconds`` to identical seconds — choosing the
    seconds-suffix form means we never have to pretty-print durations
    here, and matches the shape ``DESCRIBE ... TYPE = SPECIFICATION``
    returns.  ``function`` strings map to ``AggregationType`` via the
    enum's value (case-insensitive lookup so the BUG_BASH-style
    lower-case ``"sum"`` / ``"max"`` payloads work as-is).  Any
    ``function_params`` dict is forwarded as ``**params`` to support
    ``last_n``-family / ``approx_percentile`` aggregations.

    Both ``Feature`` and ``AggregationType`` are imported lazily so
    importing this module does not pull in numpy/pandas/pyarrow at
    package load time — the architectural decl-isolation rule.

    Args:
        raw: The payload's ``features`` list (post-compile, with
            ``window_sec`` integers rather than authoring strings).

    Returns:
        A list of imperative ``Feature`` builders, each with its alias
        set to the payload's ``output_column.name``.  An empty input
        produces an empty list (the caller skips the kwarg entirely in
        that case so non-aggregated streaming FVs stay on the existing
        ``stream_config``-only path).
    """
    from snowflake.ml.feature_store.aggregation import AggregationType
    from snowflake.ml.feature_store.feature import Feature

    features: list[Any] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        fn_name = entry.get("function")
        if not fn_name:
            continue

        agg_type = AggregationType(str(fn_name).lower())

        src_col_raw = entry.get("source_column", "")
        if isinstance(src_col_raw, dict):
            column = src_col_raw.get("name", "")
        else:
            column = str(src_col_raw)
        if not column:
            continue

        window_sec = entry.get("window_sec")
        if window_sec is None:
            continue
        window = f"{int(window_sec)}s"

        offset_sec = entry.get("offset_sec")
        offset = f"{int(offset_sec)}s" if offset_sec else "0"

        params = entry.get("function_params") or {}
        if not isinstance(params, dict):
            params = {}

        feat = Feature(agg_type, column, window, offset, **params)

        out_col_raw = entry.get("output_column")
        if isinstance(out_col_raw, dict):
            alias = out_col_raw.get("name", "")
        else:
            alias = str(out_col_raw or "")
        if alias:
            feat = feat.alias(alias)

        features.append(feat)

    return features


def _build_feature_view(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    *,
    fs: Any,
) -> tuple[Any, str]:
    """Construct a FeatureView from a spec payload dict.

    Resolves every name in ``ordered_entity_column_names`` against the
    live ``FeatureStore`` registry via ``fs.get_entity(name)``.  The
    planner topologically orders ``CREATE_ENTITY`` ops before any
    ``CREATE_FV`` op that depends on them
    (see :func:`snowflake.ml.feature_store.decl.dependencies.topological_sort`),
    so by the time this runs the entity tag exists.  This avoids
    fabricating a synthetic ``Entity(name=f"{fv_name}_entity", ...)``
    whose name never matches anything ``register_feature_view``
    validates against, which previously surfaced as
    ``(2101) Entity <FV>_ENTITY has not been registered`` on apply.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_FV/UPDATE_FV/RECREATE_FV.
        session: Snowpark Session for DataFrame construction.
        database: Default database.
        schema: Default schema.
        warehouse: Default warehouse.
        fs: The ``FeatureStore`` instance constructed eagerly by
            :func:`execute_plan`.  Used to look up each declared
            entity by name.

    Returns:
        Tuple of (FeatureView, version_string).
    """
    from snowflake.ml.feature_store.feature_view import (
        FeatureView,
        OnlineConfig,
        OnlineStoreType,
    )

    name = payload.get("name", "")
    version = payload.get("version", "V1")

    entity_cols = payload.get("ordered_entity_column_names", [])
    entity_names = [col["name"] if isinstance(col, dict) else str(col) for col in entity_cols]
    if entity_names:
        entities = [fs.get_entity(entity_name) for entity_name in entity_names]
    else:
        entities = []

    # Optional parameters
    kwargs: dict[str, Any] = {}
    if payload.get("timestamp_field"):
        kwargs["timestamp_col"] = payload["timestamp_field"]
    # ``refresh_freq`` resolution: prefer explicit ``batch_schedule``
    # (free-form Dynamic-Table cadence string), fall back to the
    # imperative-shape ``target_lag_sec`` integer (matches what
    # ``DESCRIBE TYPE = SPECIFICATION`` returns and what the spec
    # compiler normalises ``target_lag:`` strings to).  Tiled streaming
    # FVs add a final granularity-based default below — snowml-core
    # raises ``refresh_freq is required for tile-based aggregations``
    # unless one of these resolves, and the BUG_BASH §5 YAML
    # deliberately omits the field on the assumption that the tooling
    # picks a sensible default.
    if payload.get("batch_schedule"):
        kwargs["refresh_freq"] = payload["batch_schedule"]
    elif payload.get("target_lag_sec"):
        kwargs["refresh_freq"] = f"{int(payload['target_lag_sec'])} seconds"
    if payload.get("warehouse", warehouse):
        kwargs["warehouse"] = payload.get("warehouse", warehouse)
    if payload.get("description"):
        kwargs["desc"] = payload["description"]
    if payload.get("feature_granularity"):
        fg = payload["feature_granularity"]
        kwargs["feature_granularity"] = str(fg) if isinstance(fg, int) else fg

    # Online config
    if payload.get("online", False):
        target_lag = payload.get("target_lag")
        if isinstance(target_lag, int):
            target_lag = f"{target_lag} seconds"
        kwargs["online_config"] = OnlineConfig(
            enable=True,
            target_lag=target_lag or "0 seconds",
            store_type=OnlineStoreType.POSTGRES,
        )

    # Streaming feature views go through StreamConfig — snowml-core's
    # streaming preamble (run_streaming_preamble) requires it to create
    # the udf_transformed and $BACKFILL tables.  Passing a stub
    # ``feature_df`` here would fall back to the batch CREATE VIEW path
    # and emit ``CREATE VIEW name () ... AS query`` (empty column list)
    # because schema introspection on an unresolvable placeholder
    # silently sets ``feature_descs = None``.
    if payload.get("kind") == "StreamingFeatureView":
        kwargs["stream_config"] = _build_stream_config(payload, session, database, schema, fs=fs)

        # Aggregation triple (BUG_BASH step 7) — when the planner
        # payload carries ``features`` + ``feature_granularity_sec`` +
        # ``feature_aggregation_method`` (the canonical streaming-FV
        # tiled aggregation shape), thread all three through to the
        # imperative ``FeatureView`` constructor so snowml-core's
        # ``is_tiled`` branch fires and ``_feature_desc`` is keyed off
        # the windowed-aggregation outputs (e.g. ``TOTAL_ENGAGEMENT_1H``)
        # instead of the UDF's raw output columns
        # (e.g. ``ENGAGEMENT_SCORE``).  See
        # :func:`_build_features` for the per-feature conversion.
        feature_granularity_sec = payload.get("feature_granularity_sec")
        if feature_granularity_sec:
            kwargs["feature_granularity"] = f"{int(feature_granularity_sec)}s"

        aggregation_method = payload.get("feature_aggregation_method")
        if aggregation_method:
            # ``FeatureAggregationMethod`` lives in ``feature_store.spec.enums``,
            # which the wheel-isolation tests forbid this module from
            # importing directly.  ``feature_view.py`` already re-exports
            # the enum (it imports it at module top-level for type hints),
            # so we go through that allowed path — same module we already
            # import ``FeatureView`` from on the line above.
            from snowflake.ml.feature_store.feature_view import FeatureAggregationMethod

            kwargs["feature_aggregation_method"] = FeatureAggregationMethod(aggregation_method)

        features = _build_features(payload.get("features", []) or [])
        if features:
            kwargs["features"] = features

        # Tiled streaming FVs require ``refresh_freq`` (snowml-core's
        # ``FeatureView`` constructor raises otherwise — see
        # ``feature_view.py`` lines 1615–1619).  When the YAML omits
        # ``target_lag`` / ``batch_schedule`` (the BUG_BASH §5 spec
        # explicitly does), default to the feature granularity so the
        # Dynamic Table refreshes at the same cadence the aggregation
        # tiles roll up.  This matches the BUG_BASH doc's "the
        # ``target_lag`` is implicit; the dynamic table refresh has to
        # fire" note, and gives non-tiled streaming FVs the existing
        # explicit-only behaviour back (the default only triggers when
        # both ``features`` and ``feature_granularity`` are set).
        if features and "feature_granularity" in kwargs and "refresh_freq" not in kwargs:
            kwargs["refresh_freq"] = kwargs["feature_granularity"]

        fv = FeatureView(
            name=name,
            entities=entities,
            **kwargs,
        )
        return fv, version

    feature_df = _build_feature_df(payload, session, database, schema)
    fv = FeatureView(
        name=name,
        entities=entities,
        feature_df=feature_df,
        **kwargs,
    )

    return fv, version


def _build_stream_config(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
    *,
    fs: Any,
) -> Any:
    """Construct a snowml-core ``StreamConfig`` from a streaming-FV payload.

    Wires three concerns:

    - ``stream_source``: the ``sources[0].name`` from the FV spec.  The
      stream source is eagerly registered in snowml-core's metadata
      via ``fs.register_stream_source`` (idempotent — warns and
      returns the existing source if already registered).  This is a
      defensive registration: the planner derives ``Datasource``
      AppliedObjects from each FV's ``sources[]`` (see
      :func:`state._datasource_objects_from_specs`) and may emit
      ``NO_CHANGE`` for a streaming source that another FV references
      even though snowml-core's stream-source table has never seen it.
      Re-registering here closes the gap so the streaming preamble's
      ``get_stream_source`` lookup always succeeds.
    - ``transformation_fn``: a real Python callable compiled from
      ``payload['udf']['function_definition']`` via
      :func:`udf_loader.compile_udf_callable`.  ``inspect.getsource``
      succeeds on the result so ``StreamConfig.__post_init__``'s AST
      import-guard runs end-to-end.
    - ``backfill_df``: a Snowpark DataFrame.  Resolved from the
      stream source's ``backfill_table`` FQN when declared, else
      synthesized as a typed one-row in-memory DataFrame from the
      source's ``columns:`` so the streaming preamble's
      ``.limit(10).to_pandas()`` probe is non-empty.

    Args:
        payload: ``CREATE_FV`` payload with ``kind == 'StreamingFeatureView'``.
        session: Snowpark session used for ``session.table`` /
            ``session.create_dataframe``.
        database: Default database (unused today; reserved for future
            use when stream sources gain DB / schema qualification).
        schema: Default schema (same as ``database``).
        fs: The ``FeatureStore`` instance constructed eagerly by
            :func:`execute_plan`.  Used for the defensive
            ``register_stream_source`` call.

    Returns:
        A ``StreamConfig`` instance.

    Raises:
        ValueError: If the spec is missing required fields (no streaming
            source in ``sources[]`` or no UDF / function_definition).
    """
    from snowflake.ml.feature_store.decl.udf_loader import compile_udf_callable
    from snowflake.ml.feature_store.stream_config import StreamConfig

    del database, schema  # reserved for future qualification

    sources = payload.get("sources", []) or []
    stream_source_spec = next(
        (s for s in sources if isinstance(s, dict)),
        None,
    )
    if stream_source_spec is None or not stream_source_spec.get("name"):
        raise ValueError(
            f"StreamingFeatureView '{payload.get('name', '')}' must declare a "
            "stream source in 'sources[]' with a 'name'."
        )
    stream_source_name: str = str(stream_source_spec["name"])

    # Defensive: ensure the stream source is registered in snowml-core's
    # stream-source table.  See the docstring above for why the planner's
    # NO_CHANGE classification is not authoritative for this layer.
    if stream_source_spec.get("columns"):
        try:
            _execute_create_stream_source(fs, stream_source_spec)
        except Exception as e:  # noqa: BLE001 — degrade rather than mask FV error
            logger.warning(
                "Defensive register_stream_source(%s) failed; "
                "FeatureView registration may surface a clearer error: %s",
                stream_source_name,
                e,
            )

    udf = payload.get("udf") or {}
    if not isinstance(udf, dict):
        raise ValueError(
            f"StreamingFeatureView '{payload.get('name', '')}' has a malformed "
            "'udf' field — expected a dict with 'name' and 'function_definition'."
        )
    function_definition = udf.get("function_definition")
    udf_name = udf.get("name", "")
    if not function_definition or not udf_name:
        raise ValueError(
            f"StreamingFeatureView '{payload.get('name', '')}' must declare a "
            "'udf' with both 'name' and inlined 'function_definition' source."
        )
    if not isinstance(function_definition, str):
        # The compiler ordinarily inlines the .py file as a string; if a
        # caller passed an already-compiled callable, accept it verbatim.
        if callable(function_definition):
            transformation_fn = function_definition
        else:
            raise ValueError(
                f"StreamingFeatureView '{payload.get('name', '')}': "
                "'udf.function_definition' must be a Python source string "
                "(the spec compiler inlines udf.file as text)."
            )
    else:
        transformation_fn = compile_udf_callable(function_definition, udf_name)

    backfill_df = _build_streaming_backfill_df(stream_source_spec, session)
    return StreamConfig(
        stream_source=stream_source_name,
        transformation_fn=transformation_fn,
        backfill_df=backfill_df,
    )


def _build_streaming_backfill_df(stream_source_spec: dict[str, Any], session: Any) -> Any:
    """Return a Snowpark DataFrame to use as ``StreamConfig.backfill_df``.

    Two-tier resolution:

    1. If ``stream_source_spec['backfill_table']`` is set, resolve via
       ``session.table(<fqn>)`` so backfill rows come from a real
       historical table.
    2. Otherwise synthesize a single typed-sentinel row from the spec's
       ``columns:`` and return ``session.create_dataframe([row], schema=...)``.
       This satisfies the streaming preamble's ``.limit(10).to_pandas()``
       probe (which fails on zero rows) without requiring a Snowflake
       round-trip — REST stream sources without a historical backfill
       table still register cleanly.

    Args:
        stream_source_spec: The dict for the streaming source as it
            appears in the FV's ``sources[]`` list (carries ``name``,
            ``columns``, optional ``backfill_table``).
        session: Snowpark session.

    Returns:
        A Snowpark DataFrame suitable as ``StreamConfig.backfill_df``.
    """
    backfill_table = stream_source_spec.get("backfill_table")
    if backfill_table:
        return session.table(backfill_table)

    columns = stream_source_spec.get("columns", []) or []
    schema = _spec_columns_to_struct_type(columns)
    sentinel_row = _typed_sentinel_row(columns)
    return session.create_dataframe([sentinel_row], schema)


def _typed_sentinel_row(columns: list[Any]) -> list[Any]:
    """Return one type-zero sentinel value per column for synthetic backfill.

    snowml-core's streaming preamble probes ``backfill_df.limit(10).to_pandas()``
    and rejects empty frames; one synthetic row is enough to pass.  Using
    ``None`` for every column would lose type information at the Snowpark
    serialisation boundary, so we emit type-zero values instead — empty
    string, ``0`` / ``0.0``, ``False``, and a real ``datetime`` — which
    snowml's pandas-dtype inference can resolve.

    Args:
        columns: The spec's ``columns:`` list (each entry has ``type``).

    Returns:
        A list of one Python value per column, in spec order.
    """
    import datetime
    from decimal import Decimal

    sentinels: dict[str, Any] = {
        "StringType": "",
        "LongType": 0,
        "DoubleType": 0.0,
        "BooleanType": False,
        "TimestampType": datetime.datetime.now(),
        "DecimalType": Decimal(0),
    }
    row: list[Any] = []
    for col in columns:
        type_name = col.get("type", "") if isinstance(col, dict) else ""
        row.append(sentinels.get(type_name, ""))
    return row


def _build_feature_df(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
) -> Any:
    """Construct a Snowpark DataFrame from a non-streaming FV's sources.

    For ``BatchSource`` with a table reference, returns
    ``session.table(<fqn>)``.  A spec dict that still carries a raw
    SQL ``query`` field (from the legacy ``SQLDataSource`` kind, which
    has been retired) is degraded to ``session.sql(query)`` for plan-
    file backward compatibility.

    Streaming feature views never reach this function — they go through
    :func:`_build_stream_config` instead.  An older revision of this code
    fell back to a synthetic ``SELECT cols FROM <db>.<schema>.PLACEHOLDER
    WHERE 1=0`` query for streaming sources without a table; that query
    is unresolvable at registration time and caused snowml-core to emit
    ``CREATE VIEW name () AS query`` (empty column list) — see
    BUG_BASH §6 for the original bug.  The fallback is removed; a
    non-streaming FV without a resolvable source now fails loudly.

    Args:
        payload: Parsed feature view spec dict.  Must NOT have
            ``kind == 'StreamingFeatureView'`` — caller routes streaming
            FVs through :func:`_build_stream_config`.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name for resolving unqualified tables.
        schema: Snowflake schema name for resolving unqualified tables.

    Returns:
        A Snowpark DataFrame representing the feature view's source query.

    Raises:
        ValueError: If no source declares a usable ``table`` or ``query``.
    """
    sources = payload.get("sources", [])

    for src in sources:
        if isinstance(src, dict):
            table = src.get("table")
            if table:
                src_db = src.get("source_database", database)
                src_schema = src.get("source_schema", schema)
                fqn = f"{src_db}.{src_schema}.{table}"
                return session.table(fqn)

            query = src.get("query")
            if query:
                return session.sql(query)

    raise ValueError(
        f"FeatureView '{payload.get('name', '')}' (kind={payload.get('kind', '')}) "
        "has no resolvable source: at least one entry in 'sources[]' must "
        "declare 'table' or 'query', or the spec must declare "
        "'kind: StreamingFeatureView' (which uses a StreamConfig instead)."
    )
