"""Imperative executor for the declarative feature store.

Maps ``PlanOp`` objects to ``FeatureStore`` method calls.  All imports from
``snowflake.ml.feature_store`` are **lazy** (inside functions) so this module
can be included in the standalone ``decl`` wheel without pulling in heavy
transitive dependencies at import time.

This module MUST NOT import from ``snowflake.ml.dataset``,
``snowflake.ml.data``, or any other heavy snowml package.
"""

from __future__ import annotations

import logging
from typing import Any

from snowflake.ml.feature_store.decl import session_setup
from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.errors import DependencyError
from snowflake.ml.feature_store.decl.types import ApplyResult, Plan, PlanOptions

logger = logging.getLogger(__name__)

# Tag prefix that ``FeatureStore.register_entity`` prepends to entity names
# when persisting them as Snowflake tags.  Mirrored in ``state.py`` so the
# applied-state parser can recognise entity rows; mirrored here so the
# row-shape translator below can re-add the prefix when translating
# ``list_entities()`` output to the SHOW TAGS shape that
# :func:`state._build_entity_object` consumes.
_ENTITY_TAG_PREFIX = "SNOWML_FEATURE_STORE_ENTITY_"


def fetch_entity_rows(
    session: Any,
    database: str,
    schema: str,
    warehouse: str = "",
) -> list[dict[str, Any]]:
    """Fetch entity tag rows by delegating to ``FeatureStore.list_entities()``.

    This is the read-path counterpart to the entity-DDL ops in
    :func:`execute_plan` — both replace the previous raw ``SHOW TAGS``
    SQL path with a single call into the imperative library, so the
    declarative module stops carrying its own copy of the entity-tag
    query shape.

    The imperative ``list_entities()`` returns a Snowpark DataFrame whose
    rows have keys ``NAME`` (with the ``SNOWML_FEATURE_STORE_ENTITY_``
    prefix already stripped), ``JOIN_KEYS`` (a JSON-decodable string),
    ``DESC``, and ``OWNER``.  The legacy CLI applied-state parser
    (:func:`state._build_entity_object`) and the list-renderer
    (:func:`api.enrich_list_results`) both expect the raw ``SHOW TAGS``
    shape (``name`` *with* the prefix, ``database_name``, ``schema_name``,
    ``allowed_values``, ``comment``).  This function translates between
    those two shapes so existing consumers keep working unchanged.

    Args:
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name to scope the listing to.
        schema: Snowflake schema name (the FeatureStore "name") to scope
            the listing to.
        warehouse: Default warehouse for the imperative ``FeatureStore``
            constructor.  ``list_entities()`` itself only issues a
            ``SHOW TAGS`` so the warehouse is not actually used; an
            empty string is accepted, but a real value is recommended
            when the caller has one available so future imperative
            calls work without re-priming.

    Returns:
        A list of row dicts in the SHOW TAGS shape.  Returns an empty
        list when no entities are registered.
    """
    from snowflake.ml.feature_store.feature_store import CreationMode, FeatureStore

    listed: list[Any]
    try:
        fs = FeatureStore(
            session,
            database,
            schema,
            warehouse,
            creation_mode=CreationMode.FAIL_IF_NOT_EXIST,
        )
        listed = fs.list_entities().collect()
    except Exception as exc:  # noqa: BLE001 — read-path graceful fallback
        # ``FeatureStore.__init__`` enforces full SnowML feature-store
        # init (presence of ``SNOWML_FEATURE_STORE_OBJECT`` /
        # ``SNOWML_FEATURE_VIEW_METADATA`` tags) and a non-empty
        # warehouse identifier.  Neither prerequisite was required by
        # the previous raw-``SHOW TAGS`` path used by
        # ``snow feature list``; failing hard here would regress the
        # read-only listing for users who manage feature views via the
        # CLI but have not yet run ``snow feature init`` (or who manage
        # their entity tags out-of-band) and for connections that
        # don't pin a default warehouse.
        #
        # Fall back to a direct ``SHOW TAGS LIKE
        # 'SNOWML_FEATURE_STORE_ENTITY_%'`` issued from this module —
        # raw SQL is permitted in ``imperative_executor.py`` per the
        # architectural rules; what's forbidden is putting that SQL in
        # ``decl_api`` / ``queries.py`` / ``state.py``.  If the
        # fallback itself fails (auth/permissions/etc.), let the
        # exception propagate so the CLI's outer try/except can
        # convert it into an empty list with a clear log message.
        logger.debug(
            "FeatureStore.list_entities() unavailable (%s); falling back to " "direct SHOW TAGS for entity listing.",
            exc,
        )
        listed = list(session.sql(f"SHOW TAGS LIKE '{_ENTITY_TAG_PREFIX}%' IN SCHEMA {database}.{schema}").collect())

    translated: list[dict[str, Any]] = []
    for row in listed:
        if hasattr(row, "as_dict"):
            data = row.as_dict()
        elif isinstance(row, dict):
            data = dict(row)
        else:
            try:
                data = dict(row)
            except (TypeError, ValueError):
                logger.debug("Skipping un-mappable entity row: %r", row)
                continue

        # Two row shapes can flow through here:
        #   1. ``FeatureStore.list_entities()`` output — bare ``NAME``
        #      (already prefix-stripped), ``JOIN_KEYS`` (JSON string),
        #      ``DESC``, ``OWNER``.
        #   2. Fallback raw ``SHOW TAGS`` output — ``name`` *with* the
        #      ``SNOWML_FEATURE_STORE_ENTITY_`` prefix, ``allowed_values``
        #      (JSON string or comma-joined), ``comment``, ``owner``.
        # Detect the shape by checking for the prefix on the name field
        # and emit the SHOW TAGS shape consistently for downstream
        # consumers.
        raw_name = data.get("name") or data.get("NAME") or ""
        if not raw_name:
            continue

        if raw_name.startswith(_ENTITY_TAG_PREFIX):
            tag_name = raw_name
            allowed = data.get("allowed_values") or data.get("ALLOWED_VALUES") or ""
            comment = data.get("comment") or data.get("COMMENT") or ""
            owner = data.get("owner") or data.get("OWNER") or ""
            db_val = data.get("database_name") or data.get("DATABASE_NAME") or database
            schema_val = data.get("schema_name") or data.get("SCHEMA_NAME") or schema
        else:
            tag_name = f"{_ENTITY_TAG_PREFIX}{raw_name}"
            allowed = data.get("JOIN_KEYS") or data.get("join_keys") or ""
            comment = data.get("DESC") or data.get("desc") or ""
            owner = data.get("OWNER") or data.get("owner") or ""
            db_val = database
            schema_val = schema

        translated.append(
            {
                "name": tag_name,
                "database_name": db_val,
                "schema_name": schema_val,
                "allowed_values": allowed,
                "comment": comment,
                "owner": owner,
            }
        )

    return translated


def execute_plan(
    plan: Plan,
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> ApplyResult:
    """Execute a Plan by delegating each PlanOp to FeatureStore methods.

    All ``snowflake.ml.feature_store`` imports are lazy — they happen here,
    not at module level.  After the upstream lazy-import fixes (dataset and
    circular feature_store imports made lazy), importing these classes does
    NOT pull in numpy/pandas/pyarrow.

    Args:
        plan: The execution plan from ``generate_plan``.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name.
        schema: Snowflake schema name (FeatureStore "name").
        warehouse: Snowflake warehouse name.
        options: Plan options (overwrite, dev_mode, etc.).

    Returns:
        ApplyResult with per-operation status.

    Raises:
        Exception: If any plan operation fails during execution.
    """
    session_setup.apply_to_session(session)

    # ``FeatureStore`` is needed for FV ops (register_feature_view /
    # delete_feature_view) but NOT for entity ops — those are pure
    # tag DDL that can be issued via raw SQL from this module.
    # Constructing it eagerly forces ``FAIL_IF_NOT_EXIST`` checks for
    # internal feature-store tags, which regresses entity-only plans
    # against schemas that haven't been initialised as SnowML feature
    # stores yet (matching the read-path fallback in
    # :func:`fetch_entity_rows`).  Defer construction until the first
    # FV op actually needs it.
    _fs_box: list[Any] = []

    def _get_fs() -> Any:
        if not _fs_box:
            from snowflake.ml.feature_store.feature_store import (
                CreationMode,
                FeatureStore,
            )

            _fs_box.append(
                FeatureStore(
                    session,
                    database,
                    schema,
                    warehouse,
                    creation_mode=CreationMode.FAIL_IF_NOT_EXIST,
                )
            )
        return _fs_box[0]

    ops: list[dict[str, Any]] = []
    errors: list[str] = []

    for op in plan.ops:
        if op.kind == OpKind.NO_CHANGE:
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        # Sources and groups are virtual — no imperative action needed.
        if op.kind in (
            OpKind.CREATE_SOURCE,
            OpKind.UPDATE_SOURCE,
            OpKind.DROP_SOURCE,
            OpKind.CREATE_FG,
            OpKind.DROP_FG,
        ):
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        try:
            _execute_op(_get_fs, session, op, database, schema, warehouse, options)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "success",
                }
            )
        except Exception as e:
            logger.error("Failed to execute %s for %s: %s", op.kind.value, op.name, e)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "error",
                    "error": str(e),
                }
            )
            errors.append(f"{op.kind.value} {op.name}: {e}")
            raise

    status = "applied" if not errors else "partial_failure"
    return ApplyResult(
        status=status,
        ops=ops,
        sql_statements=[],  # deprecated — imperative API handles SQL internally
        warnings=list(plan.warnings),
        errors=errors,
    )


def _execute_op(
    get_fs: Any,
    session: Any,
    op: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> None:
    """Dispatch a single PlanOp to the appropriate executor.

    ``get_fs`` is a zero-arg callable that lazily constructs (and caches)
    the imperative ``FeatureStore`` instance.  Entity ops never invoke
    it — they emit raw tag DDL directly — so entity-only plans run
    against schemas that don't have a SnowML feature store initialised.

    Args:
        get_fs: Zero-arg callable returning a (cached) ``FeatureStore``;
            only invoked for FV ops.
        session: Snowpark session for raw entity DDL.
        op: The plan op to execute.
        database: Default database for entity tag FQNs.
        schema: Default schema for entity tag FQNs.
        warehouse: Default warehouse forwarded to FV constructors.
        options: Plan-wide execution options (e.g. ``overwrite``).
    """
    if op.kind == OpKind.CREATE_ENTITY:
        _execute_create_entity(session, op, database, schema)

    elif op.kind == OpKind.DROP_ENTITY:
        _execute_drop_entity(session, op, database, schema)

    elif op.kind == OpKind.UPDATE_ENTITY:
        _execute_update_entity(session, op, database, schema)

    elif op.kind == OpKind.CREATE_FV:
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse)
        get_fs().register_feature_view(fv, version, overwrite=options.overwrite)

    elif op.kind == OpKind.UPDATE_FV:
        # UPDATE_FV — use update_feature_view for supported properties
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse)
        get_fs().register_feature_view(fv, version, overwrite=True)

    elif op.kind == OpKind.RECREATE_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        fs = get_fs()
        try:
            fs.delete_feature_view(name, version)
        except Exception as e:
            logger.warning("delete_feature_view(%s, %s) failed during RECREATE: %s", name, version, e)
        fv, new_version = _build_feature_view(op.payload, session, database, schema, warehouse)
        fs.register_feature_view(fv, new_version)

    elif op.kind == OpKind.DROP_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        get_fs().delete_feature_view(name, version)


def _build_entity(payload: dict[str, Any]) -> Any:
    """Construct an Entity from a spec payload dict.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_ENTITY.
            Expected keys: name, join_keys (list of dicts with "name").

    Returns:
        An ``Entity`` instance.
    """
    from snowflake.ml.feature_store.entity import Entity

    name = payload.get("name", "")
    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or ""
    return Entity(name=name, join_keys=join_keys, desc=desc)


def _execute_create_entity(
    session: Any,
    op: Any,
    database: str,
    schema: str,
) -> None:
    """Materialise an ``OpKind.CREATE_ENTITY`` via raw ``CREATE TAG`` SQL.

    Mirrors the SQL emitted by ``FeatureStore.register_entity`` —
    ``CREATE TAG IF NOT EXISTS`` with ``ALLOWED_VALUES`` and
    ``COMMENT`` — but without requiring a fully-initialised SnowML
    feature store.  This keeps entity-only plans applicable against
    schemas that haven't been bootstrapped via
    ``CreationMode.CREATE_IF_NOT_EXIST``, matching the read-path
    fallback in :func:`fetch_entity_rows`.

    Raw SQL is permitted in this module per the architecture rules
    (only ``imperative_executor.py`` and ``session_setup.py`` may emit
    side-effecting SQL outside of the imperative ``FeatureStore`` API).

    Args:
        session: Snowpark session used to issue the ``CREATE TAG`` SQL.
        op: The ``CREATE_ENTITY`` plan op carrying the entity payload.
        database: Default database for the tag FQN if the payload does
            not pin one.
        schema: Default schema for the tag FQN if the payload does not
            pin one.

    Raises:
        ValueError: When ``op.payload`` does not carry an entity name.
    """
    payload = op.payload
    name = payload.get("name", "") or op.name
    if not name:
        raise ValueError(f"CREATE_ENTITY op {op.name} has no entity name in its payload.")

    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or payload.get("desc", "") or ""

    db = payload.get("database", database) or database
    sch = payload.get("schema", schema) or schema
    tag_fqn = f"{db}.{sch}.{_ENTITY_TAG_PREFIX}{name}"

    # Mirror the imperative form: a single comma-joined string inside
    # one ``ALLOWED_VALUES`` literal.  See
    # ``FeatureStore.register_entity`` for the canonical shape.
    join_keys_str = ",".join(join_keys)
    escaped_desc = desc.replace("'", "''")
    sql = (
        f"CREATE TAG IF NOT EXISTS {tag_fqn}\n"
        f"    ALLOWED_VALUES '{join_keys_str}'\n"
        f"    COMMENT = '{escaped_desc}'"
    )
    session.sql(sql).collect()


def _execute_drop_entity(
    session: Any,
    op: Any,
    database: str,
    schema: str,
) -> None:
    """Materialise an ``OpKind.DROP_ENTITY`` via raw ``DROP TAG`` SQL.

    Mirrors ``FeatureStore.delete_entity`` (``DROP TAG IF EXISTS``)
    without requiring a fully-initialised SnowML feature store.  When
    the tag is still referenced by an active feature view, Snowflake
    rejects the ``DROP TAG`` with a dependency error; rewrap that case
    as a :class:`DependencyError` so the CLI can surface a clear,
    actionable "drop the FV first" message instead of a generic
    backend error.

    Args:
        session: Snowpark session used to issue the ``DROP TAG`` SQL.
        op: The ``DROP_ENTITY`` plan op carrying the entity payload.
        database: Default database for the tag FQN if the payload does
            not pin one.
        schema: Default schema for the tag FQN if the payload does not
            pin one.

    Raises:
        DependencyError: When the tag is still referenced by an active
            feature view.  The original exception is chained.
    """
    payload = op.payload or {}
    name = payload.get("name", "") or op.name

    db = payload.get("database", database) or database
    sch = payload.get("schema", schema) or schema
    tag_fqn = f"{db}.{sch}.{_ENTITY_TAG_PREFIX}{name}"

    try:
        session.sql(f"DROP TAG IF EXISTS {tag_fqn}").collect()
    except Exception as exc:
        message = str(exc)
        is_dependency = (
            "is associated with masking policy" in message
            or "active FeatureView" in message
            or "active feature view" in message.lower()
            or "due to active" in message
            or "depends on" in message.lower()
            or "is still being referenced" in message.lower()
        )
        if is_dependency:
            raise DependencyError(
                f"Cannot drop entity {name!r} because it is still referenced "
                "by one or more deployed feature views. Drop the FV first, "
                f"then re-apply. Underlying error: {exc}"
            ) from exc
        raise


def _execute_update_entity(
    session: Any,
    op: Any,
    database: str,
    schema: str,
) -> None:
    """Materialise an ``OpKind.UPDATE_ENTITY`` via direct ``ALTER TAG`` SQL.

    The imperative ``FeatureStore.update_entity`` only mutates ``COMMENT``;
    join-key changes require ``ALTER TAG ... SET ALLOWED_VALUES (...)``,
    which Snowflake supports for tags created by ``register_entity``.
    Issue both statements unconditionally (the second is a no-op when
    description matches) so the deployed tag matches the local spec end
    to end.

    Raw SQL is permitted in this module per the architecture rules
    (only ``imperative_executor.py`` and ``session_setup.py`` may emit
    side-effecting SQL outside of the imperative ``FeatureStore`` API).

    Args:
        session: Snowpark session used to issue the ``ALTER TAG`` SQL.
        op: The ``UPDATE_ENTITY`` plan op carrying the new payload.
        database: Default database for the tag FQN if the payload does
            not pin one.
        schema: Default schema for the tag FQN if the payload does not
            pin one.

    Raises:
        ValueError: When ``op.payload`` does not carry an entity name.
    """
    payload = op.payload
    name = payload.get("name", "") or op.name
    if not name:
        raise ValueError(f"UPDATE_ENTITY op {op.name} has no entity name in its payload.")

    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or ""

    db = payload.get("database", database) or database
    sch = payload.get("schema", schema) or schema
    tag_fqn = f"{db}.{sch}.{_ENTITY_TAG_PREFIX}{name}"

    if join_keys:
        joined = ",".join(f"'{jk}'" for jk in join_keys)
        session.sql(f"ALTER TAG {tag_fqn} SET ALLOWED_VALUES {joined}").collect()

    escaped_desc = desc.replace("'", "''")
    session.sql(f"ALTER TAG {tag_fqn} SET COMMENT = '{escaped_desc}'").collect()


def _build_feature_view(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
) -> tuple[Any, str]:
    """Construct a FeatureView from a spec payload dict.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_FV/RECREATE_FV.
        session: Snowpark Session for DataFrame construction.
        database: Default database.
        schema: Default schema.
        warehouse: Default warehouse.

    Returns:
        Tuple of (FeatureView, version_string).
    """
    from snowflake.ml.feature_store.entity import Entity
    from snowflake.ml.feature_store.feature_view import (
        FeatureView,
        OnlineConfig,
        OnlineStoreType,
    )

    name = payload.get("name", "")
    version = payload.get("version", "V1")

    # Build entities from ordered_entity_column_names
    entity_cols = payload.get("ordered_entity_column_names", [])
    entity_names = [col["name"] if isinstance(col, dict) else str(col) for col in entity_cols]
    # Create a single entity with all join keys (declarative specs flatten entities)
    entities = [Entity(name=f"{name}_entity", join_keys=entity_names)] if entity_names else []

    # Build feature_df from sources
    feature_df = _build_feature_df(payload, session, database, schema)

    # Optional parameters
    kwargs: dict[str, Any] = {}
    if payload.get("timestamp_field"):
        kwargs["timestamp_col"] = payload["timestamp_field"]
    if payload.get("batch_schedule"):
        kwargs["refresh_freq"] = payload["batch_schedule"]
    if payload.get("warehouse", warehouse):
        kwargs["warehouse"] = payload.get("warehouse", warehouse)
    if payload.get("description"):
        kwargs["desc"] = payload["description"]
    if payload.get("feature_granularity"):
        fg = payload["feature_granularity"]
        kwargs["feature_granularity"] = str(fg) if isinstance(fg, int) else fg

    # Online config
    if payload.get("online", False):
        target_lag = payload.get("target_lag")
        if isinstance(target_lag, int):
            target_lag = f"{target_lag} seconds"
        kwargs["online_config"] = OnlineConfig(
            enable=True,
            target_lag=target_lag or "0 seconds",
            store_type=OnlineStoreType.POSTGRES,
        )

    fv = FeatureView(
        name=name,
        entities=entities,
        feature_df=feature_df,
        **kwargs,
    )

    return fv, version


def _build_feature_df(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
) -> Any:
    """Construct a Snowpark DataFrame from the spec's source references.

    For batch sources with a table reference, returns ``session.table(name)``.
    For SQL-based sources, returns ``session.sql(query)``.
    For streaming sources, returns a minimal DataFrame from the UDF-transformed
    table if available.

    Falls back to a simple ``SELECT`` query built from entity and feature columns
    when no direct source table is available.

    Args:
        payload: Parsed feature view spec dict with sources, entities, and features.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name for resolving unqualified tables.
        schema: Snowflake schema name for resolving unqualified tables.

    Returns:
        A Snowpark DataFrame representing the feature view's source query.
    """
    sources = payload.get("sources", [])

    for src in sources:
        if isinstance(src, dict):
            # BatchSource with table reference
            table = src.get("table")
            if table:
                src_db = src.get("source_database", database)
                src_schema = src.get("source_schema", schema)
                fqn = f"{src_db}.{src_schema}.{table}"
                return session.table(fqn)

            # SQLDataSource with query
            query = src.get("query")
            if query:
                return session.sql(query)

    # Fallback: build a SELECT from entity + feature columns on a placeholder
    # This handles streaming sources where the backing table is created by
    # the FeatureStore during registration.
    entity_cols = payload.get("ordered_entity_column_names", [])
    col_names = [col["name"] if isinstance(col, dict) else str(col) for col in entity_cols]

    # Add feature output columns
    for feat in payload.get("features", []):
        oc = feat.get("output_column", {})
        if isinstance(oc, dict) and oc.get("name"):
            col_names.append(oc["name"])

    # Add UDF output columns if present
    udf = payload.get("udf")
    if udf and isinstance(udf, dict):
        for oc in udf.get("output_columns", []):
            if isinstance(oc, dict) and oc.get("name"):
                col_names.append(oc["name"])

    if not col_names:
        col_names = ["*"]

    col_list = ", ".join(col_names)
    # Use a dummy query that defines the schema — FeatureStore uses the
    # DataFrame's schema/query to create the backing Dynamic Table.
    query = f"SELECT {col_list} FROM {database}.{schema}.PLACEHOLDER WHERE 1=0"
    return session.sql(query)
