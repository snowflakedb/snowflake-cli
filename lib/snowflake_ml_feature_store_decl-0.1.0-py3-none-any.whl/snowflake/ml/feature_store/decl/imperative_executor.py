"""Imperative executor for the declarative feature store.

Maps ``PlanOp`` objects to ``FeatureStore`` method calls.  All imports from
``snowflake.ml.feature_store`` are **lazy** (inside functions) so this module
can be included in the standalone ``decl`` wheel without pulling in heavy
transitive dependencies at import time.

This module MUST NOT import from ``snowflake.ml.dataset``,
``snowflake.ml.data``, or any other heavy snowml package.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from snowflake.ml.feature_store.decl import session_setup
from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.errors import DependencyError
from snowflake.ml.feature_store.decl.types import ApplyResult, Plan, PlanOptions

logger = logging.getLogger(__name__)

# Tag prefix that ``FeatureStore.register_entity`` prepends to entity names
# when persisting them as Snowflake tags.  Mirrored in ``state.py`` so the
# applied-state parser can recognise entity rows; mirrored here so the
# row-shape translator below can re-add the prefix when translating
# ``list_entities()`` output to the SHOW TAGS shape that
# :func:`state._build_entity_object` consumes.
_ENTITY_TAG_PREFIX = "SNOWML_FEATURE_STORE_ENTITY_"


def fetch_entity_rows(
    session: Any,
    database: str,
    schema: str,
    warehouse: str = "",
) -> list[dict[str, Any]]:
    """Fetch entity tag rows by delegating to ``FeatureStore.list_entities()``.

    This is the read-path counterpart to the entity-DDL ops in
    :func:`execute_plan` — both replace the previous raw ``SHOW TAGS``
    SQL path with a single call into the imperative library, so the
    declarative module stops carrying its own copy of the entity-tag
    query shape.

    The imperative ``list_entities()`` returns a Snowpark DataFrame whose
    rows have keys ``NAME`` (with the ``SNOWML_FEATURE_STORE_ENTITY_``
    prefix already stripped), ``JOIN_KEYS`` (a JSON-decodable string),
    ``DESC``, and ``OWNER``.  The legacy CLI applied-state parser
    (:func:`state._build_entity_object`) and the list-renderer
    (:func:`api.enrich_list_results`) both expect the raw ``SHOW TAGS``
    shape (``name`` *with* the prefix, ``database_name``, ``schema_name``,
    ``allowed_values``, ``comment``).  This function translates between
    those two shapes so existing consumers keep working unchanged.

    Args:
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name to scope the listing to.
        schema: Snowflake schema name (the FeatureStore "name") to scope
            the listing to.
        warehouse: Default warehouse for the imperative ``FeatureStore``
            constructor.  ``list_entities()`` itself only issues a
            ``SHOW TAGS`` so the warehouse is not actually used; an
            empty string is accepted, but a real value is recommended
            when the caller has one available so future imperative
            calls work without re-priming.

    Returns:
        A list of row dicts in the SHOW TAGS shape.  Returns an empty
        list when no entities are registered.
    """
    from snowflake.ml.feature_store.feature_store import CreationMode, FeatureStore

    listed: list[Any]
    try:
        fs = FeatureStore(
            session,
            database,
            schema,
            warehouse,
            creation_mode=CreationMode.FAIL_IF_NOT_EXIST,
        )
        listed = fs.list_entities().collect()
    except Exception as exc:  # noqa: BLE001 — read-path graceful fallback
        # ``FeatureStore.__init__`` enforces full SnowML feature-store
        # init (presence of ``SNOWML_FEATURE_STORE_OBJECT`` /
        # ``SNOWML_FEATURE_VIEW_METADATA`` tags) and a non-empty
        # warehouse identifier.  Neither prerequisite was required by
        # the previous raw-``SHOW TAGS`` path used by
        # ``snow feature list``; failing hard here would regress the
        # read-only listing for users who manage feature views via the
        # CLI but have not yet run ``snow feature init`` (or who manage
        # their entity tags out-of-band) and for connections that
        # don't pin a default warehouse.
        #
        # Fall back to a direct ``SHOW TAGS LIKE
        # 'SNOWML_FEATURE_STORE_ENTITY_%'`` issued from this module —
        # raw SQL is permitted in ``imperative_executor.py`` per the
        # architectural rules; what's forbidden is putting that SQL in
        # ``decl_api`` / ``queries.py`` / ``state.py``.  If the
        # fallback itself fails (auth/permissions/etc.), let the
        # exception propagate so the CLI's outer try/except can
        # convert it into an empty list with a clear log message.
        logger.debug(
            "FeatureStore.list_entities() unavailable (%s); falling back to " "direct SHOW TAGS for entity listing.",
            exc,
        )
        listed = list(session.sql(f"SHOW TAGS LIKE '{_ENTITY_TAG_PREFIX}%' IN SCHEMA {database}.{schema}").collect())

    translated: list[dict[str, Any]] = []
    for row in listed:
        if hasattr(row, "as_dict"):
            data = row.as_dict()
        elif isinstance(row, dict):
            data = dict(row)
        else:
            try:
                data = dict(row)
            except (TypeError, ValueError):
                logger.debug("Skipping un-mappable entity row: %r", row)
                continue

        # Two row shapes can flow through here:
        #   1. ``FeatureStore.list_entities()`` output — bare ``NAME``
        #      (already prefix-stripped), ``JOIN_KEYS`` (JSON string),
        #      ``DESC``, ``OWNER``.
        #   2. Fallback raw ``SHOW TAGS`` output — ``name`` *with* the
        #      ``SNOWML_FEATURE_STORE_ENTITY_`` prefix, ``allowed_values``
        #      (JSON string or comma-joined), ``comment``, ``owner``.
        # Detect the shape by checking for the prefix on the name field
        # and emit the SHOW TAGS shape consistently for downstream
        # consumers.
        raw_name = data.get("name") or data.get("NAME") or ""
        if not raw_name:
            continue

        if raw_name.startswith(_ENTITY_TAG_PREFIX):
            tag_name = raw_name
            allowed = data.get("allowed_values") or data.get("ALLOWED_VALUES") or ""
            comment = data.get("comment") or data.get("COMMENT") or ""
            owner = data.get("owner") or data.get("OWNER") or ""
            db_val = data.get("database_name") or data.get("DATABASE_NAME") or database
            schema_val = data.get("schema_name") or data.get("SCHEMA_NAME") or schema
        else:
            tag_name = f"{_ENTITY_TAG_PREFIX}{raw_name}"
            allowed = data.get("JOIN_KEYS") or data.get("join_keys") or ""
            comment = data.get("DESC") or data.get("desc") or ""
            owner = data.get("OWNER") or data.get("owner") or ""
            db_val = database
            schema_val = schema

        translated.append(
            {
                "name": tag_name,
                "database_name": db_val,
                "schema_name": schema_val,
                "allowed_values": allowed,
                "comment": comment,
                "owner": owner,
            }
        )

    return translated


def execute_plan(
    plan: Plan,
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> ApplyResult:
    """Execute a Plan by delegating each PlanOp to FeatureStore methods.

    All ``snowflake.ml.feature_store`` imports are lazy — they happen here,
    not at module level.  After the upstream lazy-import fixes (dataset and
    circular feature_store imports made lazy), importing these classes does
    NOT pull in numpy/pandas/pyarrow.

    Args:
        plan: The execution plan from ``generate_plan``.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name.
        schema: Snowflake schema name (FeatureStore "name").
        warehouse: Snowflake warehouse name.
        options: Plan options (overwrite, dev_mode, etc.).

    Returns:
        ApplyResult with per-operation status.

    Raises:
        Exception: If any plan operation fails during execution.
    """
    session_setup.apply_to_session(session)

    # Destructive-op guard (apply-time policy enforcement).
    #
    # The planner is policy-free: it always emits ``RECREATE_FV`` /
    # ``DROP_FV`` / ``DROP_ENTITY`` for destructive diffs so operators
    # can see them in the ``snow feature plan`` output before deciding
    # whether to apply.  The ``allow_recreate`` flag is the operator
    # opt-in that gates *apply*, not plan generation — refusing here
    # (before any FV side-effect or even ``FeatureStore`` construction)
    # leaves the plan file unrenamed under L5 (Mark-Failed-Stays-
    # Unapplied) so a follow-up ``snow feature apply --allow-recreate``
    # consumes the same plan.  See BUG_BASH §14 and
    # plans/apply_allow_recreate_destructive_gate_*.plan.md.
    if not options.allow_recreate:
        destructive_ops = [op for op in plan.ops if op.destructive]
        if destructive_ops:
            refused_rows = [
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": True,
                    "status": "refused",
                }
                for op in destructive_ops
            ]
            skipped_rows = [
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": False,
                    "status": "skipped",
                }
                for op in plan.ops
                if not op.destructive
            ]
            return ApplyResult(
                status="refused",
                ops=refused_rows + skipped_rows,
                warnings=list(plan.warnings),
                errors=[
                    f"Apply refused: {len(destructive_ops)} destructive "
                    f"operation(s) require --allow-recreate. "
                    f"Re-run with `snow feature apply --allow-recreate <path>`."
                ],
            )

    # ``FeatureStore`` is needed for FV ops (register_feature_view /
    # delete_feature_view) but NOT for entity ops — those are pure
    # tag DDL that can be issued via raw SQL from this module.
    # Constructing it eagerly forces ``FAIL_IF_NOT_EXIST`` checks for
    # internal feature-store tags, which regresses entity-only plans
    # against schemas that haven't been initialised as SnowML feature
    # stores yet (matching the read-path fallback in
    # :func:`fetch_entity_rows`).  Defer construction until the first
    # FV op actually needs it.
    _fs_box: list[Any] = []

    def _get_fs() -> Any:
        if not _fs_box:
            from snowflake.ml.feature_store.feature_store import (
                CreationMode,
                FeatureStore,
            )

            _fs_box.append(
                FeatureStore(
                    session,
                    database,
                    schema,
                    warehouse,
                    creation_mode=CreationMode.FAIL_IF_NOT_EXIST,
                )
            )
        return _fs_box[0]

    ops: list[dict[str, Any]] = []
    errors: list[str] = []

    for op in plan.ops:
        if op.kind == OpKind.NO_CHANGE:
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        # ``CREATE_SOURCE`` for ``StreamingSource`` lands as a real
        # ``FeatureStore.register_stream_source`` call so the streaming
        # preamble's ``get_stream_source`` lookup succeeds when a
        # downstream ``CREATE_FV`` runs.  All other source kinds
        # (``BatchSource`` / ``SQLDataSource``) and feature-group ops
        # remain virtual — there is no imperative analogue for them.
        if op.kind == OpKind.CREATE_SOURCE and op.payload.get("kind") == "StreamingSource":
            try:
                _execute_create_stream_source(_get_fs(), op.payload)
                ops.append(
                    {
                        "operation": op.kind.value,
                        "name": op.name,
                        "reason": op.reason,
                        "destructive": op.destructive,
                        "status": "success",
                    }
                )
            except Exception as e:
                logger.error("Failed to execute %s for %s: %s", op.kind.value, op.name, e)
                ops.append(
                    {
                        "operation": op.kind.value,
                        "name": op.name,
                        "reason": op.reason,
                        "destructive": op.destructive,
                        "status": "error",
                        "error": str(e),
                    }
                )
                errors.append(f"{op.kind.value} {op.name}: {e}")
                raise
            continue

        if op.kind in (
            OpKind.CREATE_SOURCE,
            OpKind.UPDATE_SOURCE,
            OpKind.DROP_SOURCE,
            OpKind.CREATE_FG,
            OpKind.DROP_FG,
        ):
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "skipped",
                }
            )
            continue

        try:
            _execute_op(_get_fs, session, op, database, schema, warehouse, options)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "success",
                }
            )
        except Exception as e:
            logger.error("Failed to execute %s for %s: %s", op.kind.value, op.name, e)
            ops.append(
                {
                    "operation": op.kind.value,
                    "name": op.name,
                    "reason": op.reason,
                    "destructive": op.destructive,
                    "status": "error",
                    "error": str(e),
                }
            )
            errors.append(f"{op.kind.value} {op.name}: {e}")
            raise

    status = "applied" if not errors else "partial_failure"
    return ApplyResult(
        status=status,
        ops=ops,
        warnings=list(plan.warnings),
        errors=errors,
    )


def _execute_op(
    get_fs: Any,
    session: Any,
    op: Any,
    database: str,
    schema: str,
    warehouse: str,
    options: PlanOptions,
) -> None:
    """Dispatch a single PlanOp to the appropriate executor.

    ``get_fs`` is a zero-arg callable that lazily constructs (and caches)
    the imperative ``FeatureStore`` instance.  Entity ops never invoke
    it — they emit raw tag DDL directly — so entity-only plans run
    against schemas that don't have a SnowML feature store initialised.

    Args:
        get_fs: Zero-arg callable returning a (cached) ``FeatureStore``;
            only invoked for FV ops.
        session: Snowpark session for raw entity DDL.
        op: The plan op to execute.
        database: Default database for entity tag FQNs.
        schema: Default schema for entity tag FQNs.
        warehouse: Default warehouse forwarded to FV constructors.
        options: Plan-wide execution options (e.g. ``overwrite``).
    """
    if op.kind == OpKind.CREATE_ENTITY:
        _execute_create_entity(session, op, database, schema)

    elif op.kind == OpKind.DROP_ENTITY:
        _execute_drop_entity(session, op, database, schema)

    elif op.kind == OpKind.UPDATE_ENTITY:
        _execute_update_entity(session, op, database, schema)

    elif op.kind == OpKind.CREATE_FV:
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse, get_fs=get_fs)
        get_fs().register_feature_view(fv, version, overwrite=options.overwrite)

    elif op.kind == OpKind.UPDATE_FV:
        # UPDATE_FV — use update_feature_view for supported properties
        fv, version = _build_feature_view(op.payload, session, database, schema, warehouse, get_fs=get_fs)
        get_fs().register_feature_view(fv, version, overwrite=True)

    elif op.kind == OpKind.RECREATE_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        fs = get_fs()
        try:
            fs.delete_feature_view(name, version)
        except Exception as e:
            logger.warning("delete_feature_view(%s, %s) failed during RECREATE: %s", name, version, e)
        fv, new_version = _build_feature_view(op.payload, session, database, schema, warehouse, get_fs=get_fs)
        fs.register_feature_view(fv, new_version)

    elif op.kind == OpKind.DROP_FV:
        name = op.payload.get("name", "")
        version = op.payload.get("version", "V1")
        get_fs().delete_feature_view(name, version)


def _build_entity(payload: dict[str, Any]) -> Any:
    """Construct an Entity from a spec payload dict.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_ENTITY.
            Expected keys: name, join_keys (list of dicts with "name").

    Returns:
        An ``Entity`` instance.
    """
    from snowflake.ml.feature_store.entity import Entity

    name = payload.get("name", "")
    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or ""
    return Entity(name=name, join_keys=join_keys, desc=desc)


def _spec_columns_to_struct_type(columns: list[Any]) -> Any:
    """Translate a spec ``columns:`` list to a Snowpark ``StructType``.

    The spec compiler normalises column types to the
    ``snowflake.snowpark.types`` class names listed in
    :data:`snowflake.ml.feature_store.stream_source._TYPE_NAME_TO_CLASS`
    (``StringType``, ``LongType``, ``DoubleType``, ``DecimalType``,
    ``BooleanType``, ``TimestampType``).  This helper maps that
    string-typed authoring shape onto the real Snowpark types that
    ``StreamSource``'s schema validator expects.

    Args:
        columns: List of spec column dicts; each carries ``name`` and
            ``type`` plus optional precision / scale / length / tz.

    Returns:
        A ``snowflake.snowpark.types.StructType`` matching ``columns``.

    Raises:
        ValueError: If a column carries an unsupported type name.
        RuntimeError: If ``snowflake-snowpark-python`` is not installed —
            the decl wheel does not pull it in transitively, so streaming
            registration requires the imperative feature-store stack.
    """
    try:
        from snowflake.snowpark.types import (
            BooleanType,
            DecimalType,
            DoubleType,
            LongType,
            StringType,
            StructField,
            StructType,
            TimestampType,
        )
    except ImportError as e:
        raise RuntimeError(
            "snowflake-snowpark-python is required to register streaming sources "
            "or streaming feature views from a declarative spec; install it via the "
            "imperative feature-store wheel."
        ) from e

    type_map: dict[str, Any] = {
        "StringType": StringType,
        "LongType": LongType,
        "DoubleType": DoubleType,
        "DecimalType": DecimalType,
        "BooleanType": BooleanType,
        "TimestampType": TimestampType,
    }

    fields: list[Any] = []
    for col in columns:
        if not isinstance(col, dict):
            raise ValueError(f"Stream-source column entry is not a dict: {col!r}")
        col_name = col.get("name", "")
        type_name = col.get("type", "")
        cls = type_map.get(type_name)
        if cls is None:
            raise ValueError(
                f"Unsupported column type '{type_name}' for stream-source field '{col_name}'. "
                f"Supported: {sorted(type_map)}"
            )
        if type_name == "DecimalType":
            dt = cls(col.get("precision", 38), col.get("scale", 0))
        elif type_name == "StringType":
            dt = cls(col.get("length")) if col.get("length") else cls()
        else:
            dt = cls()
        fields.append(StructField(col_name, dt))
    return StructType(fields)


def _execute_create_stream_source(fs: Any, payload: dict[str, Any]) -> Any:
    """Register a streaming source in Snowflake's feature-store metadata.

    Mirrors the imperative form: ``fs.register_stream_source(StreamSource
    (name, schema, desc=...))``.  Idempotent — if the source is already
    registered, snowml-core emits a ``UserWarning`` and returns the
    existing object without raising.

    Args:
        fs: A ``FeatureStore`` instance.
        payload: ``CREATE_SOURCE`` op payload with ``name``, ``columns``,
            and optional ``description``.

    Returns:
        The registered ``StreamSource`` (or the pre-existing one when
        idempotency triggers).

    Raises:
        ValueError: If ``payload['name']`` is empty.
    """
    from snowflake.ml.feature_store.stream_source import StreamSource

    name = payload.get("name", "")
    if not name:
        raise ValueError("CREATE_SOURCE for StreamingSource requires a non-empty 'name'.")
    desc = payload.get("description", "") or payload.get("desc", "") or ""
    schema = _spec_columns_to_struct_type(payload.get("columns", []))
    stream_source = StreamSource(name=name, schema=schema, desc=desc)
    return fs.register_stream_source(stream_source)


def _execute_create_entity(
    session: Any,
    op: Any,
    database: str,
    schema: str,
) -> None:
    """Materialise an ``OpKind.CREATE_ENTITY`` via raw ``CREATE TAG`` SQL.

    Mirrors the SQL emitted by ``FeatureStore.register_entity`` —
    ``CREATE TAG IF NOT EXISTS`` with ``ALLOWED_VALUES`` and
    ``COMMENT`` — but without requiring a fully-initialised SnowML
    feature store.  This keeps entity-only plans applicable against
    schemas that haven't been bootstrapped via
    ``CreationMode.CREATE_IF_NOT_EXIST``, matching the read-path
    fallback in :func:`fetch_entity_rows`.

    Raw SQL is permitted in this module per the architecture rules
    (only ``imperative_executor.py`` and ``session_setup.py`` may emit
    side-effecting SQL outside of the imperative ``FeatureStore`` API).

    Args:
        session: Snowpark session used to issue the ``CREATE TAG`` SQL.
        op: The ``CREATE_ENTITY`` plan op carrying the entity payload.
        database: Default database for the tag FQN if the payload does
            not pin one.
        schema: Default schema for the tag FQN if the payload does not
            pin one.

    Raises:
        ValueError: When ``op.payload`` does not carry an entity name.
    """
    payload = op.payload
    name = payload.get("name", "") or op.name
    if not name:
        raise ValueError(f"CREATE_ENTITY op {op.name} has no entity name in its payload.")

    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or payload.get("desc", "") or ""

    db = payload.get("database", database) or database
    sch = payload.get("schema", schema) or schema
    tag_fqn = f"{db}.{sch}.{_ENTITY_TAG_PREFIX}{name}"

    # Mirror the imperative form: a single comma-joined string inside
    # one ``ALLOWED_VALUES`` literal.  See
    # ``FeatureStore.register_entity`` for the canonical shape.
    join_keys_str = ",".join(join_keys)
    escaped_desc = desc.replace("'", "''")
    sql = (
        f"CREATE TAG IF NOT EXISTS {tag_fqn}\n"
        f"    ALLOWED_VALUES '{join_keys_str}'\n"
        f"    COMMENT = '{escaped_desc}'"
    )
    session.sql(sql).collect()


def _execute_drop_entity(
    session: Any,
    op: Any,
    database: str,
    schema: str,
) -> None:
    """Materialise an ``OpKind.DROP_ENTITY`` via raw ``DROP TAG`` SQL.

    Mirrors ``FeatureStore.delete_entity`` (``DROP TAG IF EXISTS``)
    without requiring a fully-initialised SnowML feature store.  When
    the tag is still referenced by an active feature view, Snowflake
    rejects the ``DROP TAG`` with a dependency error; rewrap that case
    as a :class:`DependencyError` so the CLI can surface a clear,
    actionable "drop the FV first" message instead of a generic
    backend error.

    Args:
        session: Snowpark session used to issue the ``DROP TAG`` SQL.
        op: The ``DROP_ENTITY`` plan op carrying the entity payload.
        database: Default database for the tag FQN if the payload does
            not pin one.
        schema: Default schema for the tag FQN if the payload does not
            pin one.

    Raises:
        DependencyError: When the tag is still referenced by an active
            feature view.  The original exception is chained.
    """
    payload = op.payload or {}
    name = payload.get("name", "") or op.name

    db = payload.get("database", database) or database
    sch = payload.get("schema", schema) or schema
    tag_fqn = f"{db}.{sch}.{_ENTITY_TAG_PREFIX}{name}"

    try:
        session.sql(f"DROP TAG IF EXISTS {tag_fqn}").collect()
    except Exception as exc:
        message = str(exc)
        is_dependency = (
            "is associated with masking policy" in message
            or "active FeatureView" in message
            or "active feature view" in message.lower()
            or "due to active" in message
            or "depends on" in message.lower()
            or "is still being referenced" in message.lower()
        )
        if is_dependency:
            raise DependencyError(
                f"Cannot drop entity {name!r} because it is still referenced "
                "by one or more deployed feature views. Drop the FV first, "
                f"then re-apply. Underlying error: {exc}"
            ) from exc
        raise


def _execute_update_entity(
    session: Any,
    op: Any,
    database: str,
    schema: str,
) -> None:
    """Materialise an ``OpKind.UPDATE_ENTITY`` via direct ``ALTER TAG`` SQL.

    The imperative ``FeatureStore.update_entity`` only mutates ``COMMENT``;
    join-key changes require ``ALTER TAG ... SET ALLOWED_VALUES (...)``,
    which Snowflake supports for tags created by ``register_entity``.
    Issue both statements unconditionally (the second is a no-op when
    description matches) so the deployed tag matches the local spec end
    to end.

    Raw SQL is permitted in this module per the architecture rules
    (only ``imperative_executor.py`` and ``session_setup.py`` may emit
    side-effecting SQL outside of the imperative ``FeatureStore`` API).

    Args:
        session: Snowpark session used to issue the ``ALTER TAG`` SQL.
        op: The ``UPDATE_ENTITY`` plan op carrying the new payload.
        database: Default database for the tag FQN if the payload does
            not pin one.
        schema: Default schema for the tag FQN if the payload does not
            pin one.

    Raises:
        ValueError: When ``op.payload`` does not carry an entity name.
    """
    payload = op.payload
    name = payload.get("name", "") or op.name
    if not name:
        raise ValueError(f"UPDATE_ENTITY op {op.name} has no entity name in its payload.")

    join_keys_raw = payload.get("join_keys", [])
    join_keys = [jk["name"] if isinstance(jk, dict) else str(jk) for jk in join_keys_raw]
    desc = payload.get("description", "") or ""

    db = payload.get("database", database) or database
    sch = payload.get("schema", schema) or schema
    tag_fqn = f"{db}.{sch}.{_ENTITY_TAG_PREFIX}{name}"

    if join_keys:
        joined = ",".join(f"'{jk}'" for jk in join_keys)
        session.sql(f"ALTER TAG {tag_fqn} SET ALLOWED_VALUES {joined}").collect()

    escaped_desc = desc.replace("'", "''")
    session.sql(f"ALTER TAG {tag_fqn} SET COMMENT = '{escaped_desc}'").collect()


def _build_features(raw: list[dict[str, Any]]) -> list[Any]:
    """Convert planner-payload feature dicts to imperative Feature objects.

    The planner payload encodes each aggregated feature as a dict shaped
    like::

        {
            "function": "sum",
            "window_sec": 3600,
            "offset_sec": 0,                  # optional
            "function_params": {"n": 10},     # optional, e.g. last_n
            "source_column": {"name": "AMOUNT", "type": "DoubleType"},
            "output_column": {"name": "AMOUNT_SUM_1H", "type": "DoubleType"},
        }

    The imperative ``Feature`` builder accepts ``window`` / ``offset`` as
    duration strings (``"3600s"``, ``"60s"``) which round-trip through
    ``interval_to_seconds`` to identical seconds — choosing the
    seconds-suffix form means we never have to pretty-print durations
    here, and matches the shape ``DESCRIBE ... TYPE = SPECIFICATION``
    returns.  ``function`` strings map to ``AggregationType`` via the
    enum's value (case-insensitive lookup so the BUG_BASH-style
    lower-case ``"sum"`` / ``"max"`` payloads work as-is).  Any
    ``function_params`` dict is forwarded as ``**params`` to support
    ``last_n``-family / ``approx_percentile`` aggregations.

    Both ``Feature`` and ``AggregationType`` are imported lazily so
    importing this module does not pull in numpy/pandas/pyarrow at
    package load time — the architectural decl-isolation rule.

    Args:
        raw: The payload's ``features`` list (post-compile, with
            ``window_sec`` integers rather than authoring strings).

    Returns:
        A list of imperative ``Feature`` builders, each with its alias
        set to the payload's ``output_column.name``.  An empty input
        produces an empty list (the caller skips the kwarg entirely in
        that case so non-aggregated streaming FVs stay on the existing
        ``stream_config``-only path).
    """
    from snowflake.ml.feature_store.aggregation import AggregationType
    from snowflake.ml.feature_store.feature import Feature

    features: list[Any] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        fn_name = entry.get("function")
        if not fn_name:
            continue

        agg_type = AggregationType(str(fn_name).lower())

        src_col_raw = entry.get("source_column", "")
        if isinstance(src_col_raw, dict):
            column = src_col_raw.get("name", "")
        else:
            column = str(src_col_raw)
        if not column:
            continue

        window_sec = entry.get("window_sec")
        if window_sec is None:
            continue
        window = f"{int(window_sec)}s"

        offset_sec = entry.get("offset_sec")
        offset = f"{int(offset_sec)}s" if offset_sec else "0"

        params = entry.get("function_params") or {}
        if not isinstance(params, dict):
            params = {}

        feat = Feature(agg_type, column, window, offset, **params)

        out_col_raw = entry.get("output_column")
        if isinstance(out_col_raw, dict):
            alias = out_col_raw.get("name", "")
        else:
            alias = str(out_col_raw or "")
        if alias:
            feat = feat.alias(alias)

        features.append(feat)

    return features


def _build_feature_view(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
    warehouse: str,
    *,
    get_fs: Callable[[], Any],
) -> tuple[Any, str]:
    """Construct a FeatureView from a spec payload dict.

    Resolves every name in ``ordered_entity_column_names`` against the
    live ``FeatureStore`` registry via ``fs.get_entity(name)``.  The
    planner topologically orders ``CREATE_ENTITY`` ops before any
    ``CREATE_FV`` op that depends on them
    (see :func:`snowflake.ml.feature_store.decl.dependencies.topological_sort`),
    so by the time this runs the entity tag exists.  This avoids
    fabricating a synthetic ``Entity(name=f"{fv_name}_entity", ...)``
    whose name never matches anything ``register_feature_view``
    validates against, which previously surfaced as
    ``(2101) Entity <FV>_ENTITY has not been registered`` on apply.

    Args:
        payload: Dict from a PlanOp with kind=CREATE_FV/UPDATE_FV/RECREATE_FV.
        session: Snowpark Session for DataFrame construction.
        database: Default database.
        schema: Default schema.
        warehouse: Default warehouse.
        get_fs: Zero-arg callable returning a (cached) ``FeatureStore``.
            Used to look up each declared entity by name; mirrors the
            pattern in :func:`_execute_op` so the FS construction stays
            lazy and shared across the plan.

    Returns:
        Tuple of (FeatureView, version_string).
    """
    from snowflake.ml.feature_store.feature_view import (
        FeatureView,
        OnlineConfig,
        OnlineStoreType,
    )

    name = payload.get("name", "")
    version = payload.get("version", "V1")

    entity_cols = payload.get("ordered_entity_column_names", [])
    entity_names = [col["name"] if isinstance(col, dict) else str(col) for col in entity_cols]
    if entity_names:
        fs = get_fs()
        entities = [fs.get_entity(entity_name) for entity_name in entity_names]
    else:
        entities = []

    # Optional parameters
    kwargs: dict[str, Any] = {}
    if payload.get("timestamp_field"):
        kwargs["timestamp_col"] = payload["timestamp_field"]
    # ``refresh_freq`` resolution: prefer explicit ``batch_schedule``
    # (free-form Dynamic-Table cadence string), fall back to the
    # imperative-shape ``target_lag_sec`` integer (matches what
    # ``DESCRIBE TYPE = SPECIFICATION`` returns and what the spec
    # compiler normalises ``target_lag:`` strings to).  Tiled streaming
    # FVs add a final granularity-based default below — snowml-core
    # raises ``refresh_freq is required for tile-based aggregations``
    # unless one of these resolves, and the BUG_BASH §5 YAML
    # deliberately omits the field on the assumption that the tooling
    # picks a sensible default.
    if payload.get("batch_schedule"):
        kwargs["refresh_freq"] = payload["batch_schedule"]
    elif payload.get("target_lag_sec"):
        kwargs["refresh_freq"] = f"{int(payload['target_lag_sec'])} seconds"
    if payload.get("warehouse", warehouse):
        kwargs["warehouse"] = payload.get("warehouse", warehouse)
    if payload.get("description"):
        kwargs["desc"] = payload["description"]
    if payload.get("feature_granularity"):
        fg = payload["feature_granularity"]
        kwargs["feature_granularity"] = str(fg) if isinstance(fg, int) else fg

    # Online config
    if payload.get("online", False):
        target_lag = payload.get("target_lag")
        if isinstance(target_lag, int):
            target_lag = f"{target_lag} seconds"
        kwargs["online_config"] = OnlineConfig(
            enable=True,
            target_lag=target_lag or "0 seconds",
            store_type=OnlineStoreType.POSTGRES,
        )

    # Streaming feature views go through StreamConfig — snowml-core's
    # streaming preamble (run_streaming_preamble) requires it to create
    # the udf_transformed and $BACKFILL tables.  Passing a stub
    # ``feature_df`` here would fall back to the batch CREATE VIEW path
    # and emit ``CREATE VIEW name () ... AS query`` (empty column list)
    # because schema introspection on an unresolvable placeholder
    # silently sets ``feature_descs = None``.
    if payload.get("kind") == "StreamingFeatureView":
        kwargs["stream_config"] = _build_stream_config(payload, session, database, schema, get_fs=get_fs)

        # Aggregation triple (BUG_BASH step 7) — when the planner
        # payload carries ``features`` + ``feature_granularity_sec`` +
        # ``feature_aggregation_method`` (the canonical streaming-FV
        # tiled aggregation shape), thread all three through to the
        # imperative ``FeatureView`` constructor so snowml-core's
        # ``is_tiled`` branch fires and ``_feature_desc`` is keyed off
        # the windowed-aggregation outputs (e.g. ``TOTAL_ENGAGEMENT_1H``)
        # instead of the UDF's raw output columns
        # (e.g. ``ENGAGEMENT_SCORE``).  See
        # :func:`_build_features` for the per-feature conversion.
        feature_granularity_sec = payload.get("feature_granularity_sec")
        if feature_granularity_sec:
            kwargs["feature_granularity"] = f"{int(feature_granularity_sec)}s"

        aggregation_method = payload.get("feature_aggregation_method")
        if aggregation_method:
            # ``FeatureAggregationMethod`` lives in ``feature_store.spec.enums``,
            # which the wheel-isolation tests forbid this module from
            # importing directly.  ``feature_view.py`` already re-exports
            # the enum (it imports it at module top-level for type hints),
            # so we go through that allowed path — same module we already
            # import ``FeatureView`` from on the line above.
            from snowflake.ml.feature_store.feature_view import FeatureAggregationMethod

            kwargs["feature_aggregation_method"] = FeatureAggregationMethod(aggregation_method)

        features = _build_features(payload.get("features", []) or [])
        if features:
            kwargs["features"] = features

        # Tiled streaming FVs require ``refresh_freq`` (snowml-core's
        # ``FeatureView`` constructor raises otherwise — see
        # ``feature_view.py`` lines 1615–1619).  When the YAML omits
        # ``target_lag`` / ``batch_schedule`` (the BUG_BASH §5 spec
        # explicitly does), default to the feature granularity so the
        # Dynamic Table refreshes at the same cadence the aggregation
        # tiles roll up.  This matches the BUG_BASH doc's "the
        # ``target_lag`` is implicit; the dynamic table refresh has to
        # fire" note, and gives non-tiled streaming FVs the existing
        # explicit-only behaviour back (the default only triggers when
        # both ``features`` and ``feature_granularity`` are set).
        if features and "feature_granularity" in kwargs and "refresh_freq" not in kwargs:
            kwargs["refresh_freq"] = kwargs["feature_granularity"]

        fv = FeatureView(
            name=name,
            entities=entities,
            **kwargs,
        )
        return fv, version

    feature_df = _build_feature_df(payload, session, database, schema)
    fv = FeatureView(
        name=name,
        entities=entities,
        feature_df=feature_df,
        **kwargs,
    )

    return fv, version


def _build_stream_config(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
    *,
    get_fs: Callable[[], Any],
) -> Any:
    """Construct a snowml-core ``StreamConfig`` from a streaming-FV payload.

    Wires three concerns:

    - ``stream_source``: the ``sources[0].name`` from the FV spec.  The
      stream source is eagerly registered in snowml-core's metadata
      via ``fs.register_stream_source`` (idempotent — warns and
      returns the existing source if already registered).  This is a
      defensive registration: the planner derives ``Datasource``
      AppliedObjects from each FV's ``sources[]`` (see
      :func:`state._datasource_objects_from_specs`) and may emit
      ``NO_CHANGE`` for a streaming source that another FV references
      even though snowml-core's stream-source table has never seen it.
      Re-registering here closes the gap so the streaming preamble's
      ``get_stream_source`` lookup always succeeds.
    - ``transformation_fn``: a real Python callable compiled from
      ``payload['udf']['function_definition']`` via
      :func:`udf_loader.compile_udf_callable`.  ``inspect.getsource``
      succeeds on the result so ``StreamConfig.__post_init__``'s AST
      import-guard runs end-to-end.
    - ``backfill_df``: a Snowpark DataFrame.  Resolved from the
      stream source's ``backfill_table`` FQN when declared, else
      synthesized as a typed one-row in-memory DataFrame from the
      source's ``columns:`` so the streaming preamble's
      ``.limit(10).to_pandas()`` probe is non-empty.

    Args:
        payload: ``CREATE_FV`` payload with ``kind == 'StreamingFeatureView'``.
        session: Snowpark session used for ``session.table`` /
            ``session.create_dataframe``.
        database: Default database (unused today; reserved for future
            use when stream sources gain DB / schema qualification).
        schema: Default schema (same as ``database``).
        get_fs: Zero-arg callable returning a (cached) ``FeatureStore``.
            Used for the defensive ``register_stream_source`` call.

    Returns:
        A ``StreamConfig`` instance.

    Raises:
        ValueError: If the spec is missing required fields (no streaming
            source in ``sources[]`` or no UDF / function_definition).
    """
    from snowflake.ml.feature_store.decl.udf_loader import compile_udf_callable
    from snowflake.ml.feature_store.stream_config import StreamConfig

    del database, schema  # reserved for future qualification

    sources = payload.get("sources", []) or []
    stream_source_spec = next(
        (s for s in sources if isinstance(s, dict)),
        None,
    )
    if stream_source_spec is None or not stream_source_spec.get("name"):
        raise ValueError(
            f"StreamingFeatureView '{payload.get('name', '')}' must declare a "
            "stream source in 'sources[]' with a 'name'."
        )
    stream_source_name: str = str(stream_source_spec["name"])

    # Defensive: ensure the stream source is registered in snowml-core's
    # stream-source table.  See the docstring above for why the planner's
    # NO_CHANGE classification is not authoritative for this layer.
    if stream_source_spec.get("columns"):
        try:
            _execute_create_stream_source(get_fs(), stream_source_spec)
        except Exception as e:  # noqa: BLE001 — degrade rather than mask FV error
            logger.warning(
                "Defensive register_stream_source(%s) failed; "
                "FeatureView registration may surface a clearer error: %s",
                stream_source_name,
                e,
            )

    udf = payload.get("udf") or {}
    if not isinstance(udf, dict):
        raise ValueError(
            f"StreamingFeatureView '{payload.get('name', '')}' has a malformed "
            "'udf' field — expected a dict with 'name' and 'function_definition'."
        )
    function_definition = udf.get("function_definition")
    udf_name = udf.get("name", "")
    if not function_definition or not udf_name:
        raise ValueError(
            f"StreamingFeatureView '{payload.get('name', '')}' must declare a "
            "'udf' with both 'name' and inlined 'function_definition' source."
        )
    if not isinstance(function_definition, str):
        # The compiler ordinarily inlines the .py file as a string; if a
        # caller passed an already-compiled callable, accept it verbatim.
        if callable(function_definition):
            transformation_fn = function_definition
        else:
            raise ValueError(
                f"StreamingFeatureView '{payload.get('name', '')}': "
                "'udf.function_definition' must be a Python source string "
                "(the spec compiler inlines udf.file as text)."
            )
    else:
        transformation_fn = compile_udf_callable(function_definition, udf_name)

    backfill_df = _build_streaming_backfill_df(stream_source_spec, session)
    return StreamConfig(
        stream_source=stream_source_name,
        transformation_fn=transformation_fn,
        backfill_df=backfill_df,
    )


def _build_streaming_backfill_df(stream_source_spec: dict[str, Any], session: Any) -> Any:
    """Return a Snowpark DataFrame to use as ``StreamConfig.backfill_df``.

    Two-tier resolution:

    1. If ``stream_source_spec['backfill_table']`` is set, resolve via
       ``session.table(<fqn>)`` so backfill rows come from a real
       historical table.
    2. Otherwise synthesize a single typed-sentinel row from the spec's
       ``columns:`` and return ``session.create_dataframe([row], schema=...)``.
       This satisfies the streaming preamble's ``.limit(10).to_pandas()``
       probe (which fails on zero rows) without requiring a Snowflake
       round-trip — REST stream sources without a historical backfill
       table still register cleanly.

    Args:
        stream_source_spec: The dict for the streaming source as it
            appears in the FV's ``sources[]`` list (carries ``name``,
            ``columns``, optional ``backfill_table``).
        session: Snowpark session.

    Returns:
        A Snowpark DataFrame suitable as ``StreamConfig.backfill_df``.
    """
    backfill_table = stream_source_spec.get("backfill_table")
    if backfill_table:
        return session.table(backfill_table)

    columns = stream_source_spec.get("columns", []) or []
    schema = _spec_columns_to_struct_type(columns)
    sentinel_row = _typed_sentinel_row(columns)
    return session.create_dataframe([sentinel_row], schema)


def _typed_sentinel_row(columns: list[Any]) -> list[Any]:
    """Return one type-zero sentinel value per column for synthetic backfill.

    snowml-core's streaming preamble probes ``backfill_df.limit(10).to_pandas()``
    and rejects empty frames; one synthetic row is enough to pass.  Using
    ``None`` for every column would lose type information at the Snowpark
    serialisation boundary, so we emit type-zero values instead — empty
    string, ``0`` / ``0.0``, ``False``, and a real ``datetime`` — which
    snowml's pandas-dtype inference can resolve.

    Args:
        columns: The spec's ``columns:`` list (each entry has ``type``).

    Returns:
        A list of one Python value per column, in spec order.
    """
    import datetime
    from decimal import Decimal

    sentinels: dict[str, Any] = {
        "StringType": "",
        "LongType": 0,
        "DoubleType": 0.0,
        "BooleanType": False,
        "TimestampType": datetime.datetime.now(),
        "DecimalType": Decimal(0),
    }
    row: list[Any] = []
    for col in columns:
        type_name = col.get("type", "") if isinstance(col, dict) else ""
        row.append(sentinels.get(type_name, ""))
    return row


def _build_feature_df(
    payload: dict[str, Any],
    session: Any,
    database: str,
    schema: str,
) -> Any:
    """Construct a Snowpark DataFrame from a non-streaming FV's sources.

    For ``BatchSource`` with a table reference, returns
    ``session.table(<fqn>)``.  For ``SQLDataSource`` with a query,
    returns ``session.sql(query)``.

    Streaming feature views never reach this function — they go through
    :func:`_build_stream_config` instead.  An older revision of this code
    fell back to a synthetic ``SELECT cols FROM <db>.<schema>.PLACEHOLDER
    WHERE 1=0`` query for streaming sources without a table; that query
    is unresolvable at registration time and caused snowml-core to emit
    ``CREATE VIEW name () AS query`` (empty column list) — see
    BUG_BASH §6 for the original bug.  The fallback is removed; a
    non-streaming FV without a resolvable source now fails loudly.

    Args:
        payload: Parsed feature view spec dict.  Must NOT have
            ``kind == 'StreamingFeatureView'`` — caller routes streaming
            FVs through :func:`_build_stream_config`.
        session: A ``snowflake.snowpark.Session`` instance.
        database: Snowflake database name for resolving unqualified tables.
        schema: Snowflake schema name for resolving unqualified tables.

    Returns:
        A Snowpark DataFrame representing the feature view's source query.

    Raises:
        ValueError: If no source declares a usable ``table`` or ``query``.
    """
    sources = payload.get("sources", [])

    for src in sources:
        if isinstance(src, dict):
            table = src.get("table")
            if table:
                src_db = src.get("source_database", database)
                src_schema = src.get("source_schema", schema)
                fqn = f"{src_db}.{src_schema}.{table}"
                return session.table(fqn)

            query = src.get("query")
            if query:
                return session.sql(query)

    raise ValueError(
        f"FeatureView '{payload.get('name', '')}' (kind={payload.get('kind', '')}) "
        "has no resolvable source: at least one entry in 'sources[]' must "
        "declare 'table' or 'query', or the spec must declare "
        "'kind: StreamingFeatureView' (which uses a StreamConfig instead)."
    )
