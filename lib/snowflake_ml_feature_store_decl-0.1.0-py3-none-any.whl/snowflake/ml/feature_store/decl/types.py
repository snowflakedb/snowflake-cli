"""Pydantic v2 models for the planning and execution pipeline.

All types in this module serialize cleanly to JSON via ``model_dump()``.
They carry no connection handles, cursors, or runtime state — this makes
them suitable as REST request/response bodies when GS capabilities are added.
"""

from typing import Any, Literal, Optional

from pydantic import BaseModel

from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.spec_models import FSColumn, SpecBase


class AppliedObject(BaseModel):
    """A single object as it exists in Snowflake (applied state snapshot).

    Attributes:
        key: Unique identifier in the form ``kind:database.schema:name``.
        kind: Object kind string (e.g. ``"Entity"``, ``"FeatureView"``).
        name: Object name.
        version: Deployed version string, or ``None`` if not versioned.
        content_hash: SHA-256 of the deployed spec (for idempotency checks).
        spec_payload: The full spec as deployed (reconstructed from Snowflake).
        columns: Column schemas for column-evolution comparison.
    """

    key: str
    kind: str
    name: str
    version: Optional[str] = None
    content_hash: str = ""
    spec_payload: dict[str, Any] = {}
    columns: list[FSColumn] = []


class AppliedState(BaseModel):
    """A point-in-time snapshot of all deployed feature store objects.

    Attributes:
        objects: Mapping from ``kind:database.schema:name`` to ``AppliedObject``.
    """

    objects: dict[str, AppliedObject] = {}


class PlanOp(BaseModel):
    """A single operation in an execution plan.

    Attributes:
        kind: The operation type (CREATE_ENTITY, UPDATE_FV, etc.).
        name: The object name this operation targets.
        depends_on: Names of objects this operation depends on.
        destructive: Whether this is a breaking/destructive change.
        reason: Human-readable explanation of why this op was generated.
        payload: The spec payload dict for this operation.
    """

    kind: OpKind
    name: str
    depends_on: list[str] = []
    destructive: bool = False
    reason: str = ""
    payload: dict[str, Any] = {}


class Plan(BaseModel):
    """An ordered, validated execution plan.

    Attributes:
        ops: Topologically-sorted list of operations to execute.
        warnings: Non-blocking warnings generated during plan creation.
    """

    ops: list[PlanOp] = []
    warnings: list[str] = []


class ValidationResult(BaseModel):
    """A single validation finding (error or warning).

    Attributes:
        severity: Either ``"ERROR"`` (blocking) or ``"WARNING"`` (non-blocking).
        code: A short machine-readable code (e.g. ``"COLUMN_MISSING_DEFAULT"``).
        message: Human-readable description of the finding.
        object_name: The name of the object that triggered the finding.
    """

    severity: Literal["ERROR", "WARNING"]
    code: str
    message: str
    object_name: str = ""


class PlanOptions(BaseModel):
    """Options that control plan generation behaviour.

    Attributes:
        dev_mode: Auto-generate timestamp versions; skip version conflict checks.
        overwrite: Force apply even when version or column checks fail.
        allow_recreate: Allow destructive schema changes that require re-materialization.
        dry_run: Validate and plan only — do not execute DDL.
    """

    dev_mode: bool = False
    overwrite: bool = False
    allow_recreate: bool = False
    dry_run: bool = False
    full_directory_mode: bool = False  # Only True when ./... is specified; enables deletion detection


class SpecBatch(BaseModel):
    """A parsed batch of specs ready for validation and planning.

    Attributes:
        specs: The parsed spec objects (``SpecBase`` subclass instances).
        source_files: The file paths that were loaded to produce this batch.
    """

    specs: list[SpecBase] = []
    source_files: list[str] = []


class PlanFile(BaseModel):
    """A serializable plan file that can be saved to disk and loaded by apply.

    Attributes:
        version: File format version (currently ``"1"``).
        created_at: ISO 8601 timestamp when the plan was generated.
        target_database: The Snowflake database the plan targets.
        target_schema: The Snowflake schema the plan targets.
        source_files: Input spec file paths used to generate the plan.
        plan: The generated execution plan.
        summary: Op-kind counts (e.g. ``{"CREATE_ENTITY": 1, "CREATE_FV": 2}``).
    """

    version: str = "1"
    created_at: str = ""
    target_database: str = ""
    target_schema: str = ""
    source_files: list[str] = []
    plan: Plan = Plan()
    summary: dict[str, int] = {}


class ApplyResult(BaseModel):
    """Result of a validate → plan → generate-SQL pipeline.

    Returned by ``api.generate_apply_sql()`` so the CLI can display the
    plan and execute the SQL without knowing anything about the SQL format.

    Attributes:
        status: ``"dry_run"`` | ``"ready"`` | ``"validation_failed"``.
        ops: Per-operation details for display.
        sql_statements: Ordered DDL statements to execute.
        warnings: Non-blocking warnings from planning.
        errors: Blocking validation errors (only when status is ``"validation_failed"``).
    """

    status: str = "ready"
    ops: list[dict[str, Any]] = []
    sql_statements: list[str] = []
    warnings: list[str] = []
    errors: list[str] = []
