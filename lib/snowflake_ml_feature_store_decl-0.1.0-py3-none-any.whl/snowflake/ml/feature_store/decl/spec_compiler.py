"""Compiler: authoring-format spec dict → imperative FeatureViewSpec format dict.

Transforms a loaded/compiled spec dict (human-friendly YAML authoring format,
with UDF source already inlined by ``compiler.py``) into a dict matching the
``FeatureViewSpec.to_dict()`` output structure expected by
``CREATE ONLINE FEATURE TABLE ... FROM SPECIFICATION``.

All functions are self-contained — no imports from snowflake.ml.feature_store.spec,
snowflake.snowpark, or snowflake.connector.
"""

from __future__ import annotations

import json
from typing import Any

from snowflake.ml.feature_store.decl.compiler import parse_duration_to_seconds

_CLIENT_VERSION = "0.1.0"


def sanitize_json_for_dollar_quoting(payload: str) -> str:
    """Replace ``$$`` with ``$\\u0024`` to make JSON safe for SQL ``$$`` quoting.

    ``\\u0024`` is the JSON unicode escape for ``$``; every conformant JSON
    parser decodes it back to ``$`` automatically.

    Args:
        payload: A JSON-encoded string.

    Returns:
        The same string with every ``$$`` replaced by ``$\\u0024``.
    """
    return payload.replace("$$", "$\\u0024")


def _resolve_duration(obj: dict[str, Any], key: str) -> int | None:
    """Read ``key`` or ``key_sec`` from *obj* and return integer seconds.

    If ``key`` is present (string/int) it is converted via
    :func:`~snowflake.ml.feature_store.decl.compiler.parse_duration_to_seconds`.
    If ``key_sec`` is already present (post-normalize_durations pass) it is
    returned directly.  Returns ``None`` if neither key is found.

    Args:
        obj: A dict that may contain ``key`` or ``{key}_sec``.
        key: The base key name (without ``_sec`` suffix).

    Returns:
        Integer seconds or ``None``.
    """
    if key in obj:
        return parse_duration_to_seconds(obj[key])
    sec_key = f"{key}_sec"
    if sec_key in obj:
        val = obj[sec_key]
        return int(val) if val is not None else None
    return None


def _compile_features(raw_features: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert feature dicts, normalizing ``window``/``offset`` to ``*_sec`` ints.

    Args:
        raw_features: List of feature dicts in authoring or normalized format.

    Returns:
        New list of feature dicts with ``window_sec`` / ``offset_sec`` integers
        and the original string keys removed.
    """
    result = []
    for feat in raw_features:
        compiled: dict[str, Any] = {}
        for k, v in feat.items():
            if k in ("window", "offset"):
                compiled[f"{k}_sec"] = parse_duration_to_seconds(v)
            elif k in ("window_sec", "offset_sec"):
                compiled[k] = int(v) if v is not None else v
            else:
                compiled[k] = v
        result.append(compiled)
    return result


def _compile_udf(udf: dict[str, Any]) -> dict[str, Any]:
    """Build the ``spec.udf`` sub-dict from an authoring-format UDF dict.

    The live ``DESCRIBE ONLINE FEATURE TABLE ... TYPE = SPECIFICATION``
    payload uses the authoring-shape keys ``name`` and ``engine`` directly
    (verified against captured fixtures in
    ``tests/golden_specs/USER_CLICK_STATS.json``).  An earlier symmetric
    rename to ``function_name`` / ``language`` inverted the round-trip
    invariant — the compiled local hash never matched the deployed hash —
    so we now keep ``name`` and ``engine`` as-is.  Only ``source`` is
    renamed to ``function_definition`` (the legacy alias the live payload
    uses for the inlined Python source).  ``file`` is dropped because the
    YAML loader has already inlined it as ``function_definition``.

    Args:
        udf: Authoring-format UDF dict.

    Returns:
        Compiled UDF dict matching the SPECIFICATION JSON shape.
    """
    rename = {"source": "function_definition"}
    compiled: dict[str, Any] = {}
    for k, v in udf.items():
        if k == "file":
            continue  # already inlined; drop the path
        compiled[rename.get(k, k)] = v
    return compiled


def compile_to_spec(spec_dict: dict[str, Any], database: str, schema: str) -> dict[str, Any]:
    """Compile a YAML authoring-format spec dict into imperative FeatureViewSpec format.

    Accepts the spec dict produced by ``decl/loader.py`` + ``compiler.py``
    (i.e., with UDF source already inlined as ``udf.function_definition`` and
    type aliases normalized, but duration strings may still be raw strings or
    already converted ``*_sec`` integers).

    Args:
        spec_dict: The loaded/compiled spec dict from the authoring YAML.
        database: Snowflake database name (from connection context).
        schema: Snowflake schema name (from connection context).

    Returns:
        Dict matching ``FeatureViewSpec.to_dict()`` output, ready for
        JSON serialization in ``FROM SPECIFICATION $$ ... $$``.
    """
    name: str = spec_dict["name"]
    version: str = spec_dict["version"]
    kind: str = spec_dict.get("kind", "StreamingFeatureView")

    # 1. metadata -------------------------------------------------------
    metadata: dict[str, Any] = {
        "database": database,
        "schema": schema,
        "name": name,
        "version": version,
        "spec_format_version": "1",
        "internal_data_version": "1",
        "client_version": _CLIENT_VERSION,
    }

    # 2. offline_configs ------------------------------------------------
    udf = spec_dict.get("udf")
    offline_configs: list[dict[str, Any]] = []
    if udf and isinstance(udf, dict):
        table_name = f"{name.upper()}${version.upper()}$UDF_TRANSFORMED"
        offline_configs.append(
            {
                "store_type": "snowflake",
                "table_type": "UDFTransformed",
                "database": database,
                "schema": schema,
                "table": table_name,
                "columns": [dict(col) for col in udf.get("output_columns", [])],
            }
        )

    # 3. spec -----------------------------------------------------------
    raw_features: list[dict[str, Any]] = spec_dict.get("features", [])
    compiled_features = _compile_features(raw_features)

    feature_granularity_sec = _resolve_duration(spec_dict, "feature_granularity")

    spec: dict[str, Any] = {
        "ordered_entity_column_names": list(spec_dict.get("ordered_entity_column_names", [])),
        "sources": [dict(s) for s in spec_dict.get("sources", [])],
        "features": compiled_features,
    }

    if spec_dict.get("timestamp_field"):
        spec["timestamp_field"] = spec_dict["timestamp_field"]

    if feature_granularity_sec is not None:
        spec["feature_granularity_sec"] = feature_granularity_sec

    # ``target_lag_sec`` survives the round-trip for *every* FV kind that
    # carries it — Batch FVs in particular set ``spec.target_lag_sec`` in
    # the SPECIFICATION JSON even when they have no aggregation windows,
    # so we cannot gate this on ``has_windows``.  When present in the
    # authoring spec (either as the canonical integer field or as a
    # human-friendly string parsed by :func:`_resolve_duration`), copy it
    # through unchanged so :func:`_full_spec_hash` matches the deployed
    # payload.
    target_lag_sec = _resolve_duration(spec_dict, "target_lag")
    if target_lag_sec is not None:
        spec["target_lag_sec"] = target_lag_sec

    has_windows = any("window_sec" in f for f in compiled_features)
    if has_windows:
        method = spec_dict.get("feature_aggregation_method", "tiles")
        spec["feature_aggregation_method"] = method

    if udf and isinstance(udf, dict):
        spec["udf"] = _compile_udf(udf)

    # Enrich Stream sources with column schema if missing.
    # Only use columns that were already resolved (e.g. from datasource YAML
    # loaded by the pipeline). Do NOT fall back to UDF output_columns here —
    # those are the transformed output schema, not the raw input schema.
    enriched_sources = []
    for src in spec["sources"]:
        enriched_sources.append(dict(src))
    spec["sources"] = enriched_sources

    # 4. Assemble root --------------------------------------------------
    return {
        "kind": kind,
        "metadata": metadata,
        "offline_configs": offline_configs,
        "spec": spec,
        "online_store_type": "postgres",
    }


def to_json(spec_result: dict[str, Any]) -> str:
    """Serialize a compiled spec dict to JSON safe for SQL ``$$`` quoting.

    Args:
        spec_result: Output of :func:`compile_to_spec`.

    Returns:
        JSON string with ``$$`` sequences replaced by ``$\\u0024``.
    """
    return sanitize_json_for_dollar_quoting(json.dumps(spec_result))
