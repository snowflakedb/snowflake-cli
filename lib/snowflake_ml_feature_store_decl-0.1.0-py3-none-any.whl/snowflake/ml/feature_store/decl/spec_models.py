"""Pydantic v2 authoring-format models for the declarative feature store.

These models represent the human-facing spec format: string-based type
identifiers, human-friendly duration strings, and rich references.
They are fully standalone — no imports from ``snowflake.ml.feature_store.spec``,
``snowflake.snowpark``, or ``snowflake.connector``.

A compilation step (``decl/compiler.py``) transforms these into the JSON
payload format expected by ``CREATE ONLINE FEATURE TABLE ... FROM SPECIFICATION``.
"""

from typing import Any, Optional, Union

from pydantic import BaseModel


class FSColumn(BaseModel):
    """A single column with name and string-based type information.

    The ``default`` field is required when adding a new output column to
    a feature view that has already been deployed — it tells downstream
    consumers what value to use for historical rows that predate the column.
    """

    name: str
    type: str  # FSBaseType value or alias — normalized during compilation
    length: Optional[int] = None  # For StringType
    precision: Optional[int] = None  # For DecimalType
    scale: Optional[int] = None  # For DecimalType
    tz: Optional[str] = None  # For TimestampType
    default: Optional[Any] = None  # Backfill value for new columns on deployed views


class SpecBase(BaseModel):
    """Common fields shared by all top-level spec kinds."""

    kind: str = ""
    name: str = ""
    version: Optional[str] = None
    database: Optional[str] = None
    schema_: Optional[str] = None
    description: Optional[str] = None


class Entity(SpecBase):
    """Top-level Entity definition."""

    kind: str = "Entity"
    join_keys: list[FSColumn] = []


class StreamingSource(SpecBase):
    """Top-level StreamingSource definition (real-time REST push source)."""

    kind: str = "StreamingSource"
    type: str = "REST"
    columns: list[FSColumn] = []


class BatchSource(SpecBase):
    """Top-level BatchSource definition (offline table source).

    ``source_database`` and ``source_schema`` identify where the backing
    table lives and may differ from the deployment ``database``/``schema_``
    inherited from SpecBase.
    """

    kind: str = "BatchSource"
    source_database: Optional[str] = None
    source_schema: Optional[str] = None
    table: Optional[str] = None
    columns: list[FSColumn] = []


class SQLDataSource(BatchSource):
    """Batch source backed by a raw SQL query instead of a table reference."""

    kind: str = "SQLDataSource"
    query: Optional[str] = None


class SourceRef(BaseModel):
    """A reference to a named source within a feature view."""

    name: str
    source_type: str  # SourceType value


class UDF(BaseModel):
    """User-defined function configuration.

    In the authoring format, ``file`` points to a co-located Python file
    and ``name`` identifies the function within it. During compilation
    the CLI reads the file and inlines the source as ``function_definition``.
    """

    name: str
    engine: str = "pandas"
    file: Optional[str] = None  # Path to .py file (YAML authoring)
    function_definition: Optional[Union[str, Any]] = None  # String source or callable
    output_columns: list[FSColumn] = []


class Feature(BaseModel):
    """A feature mapping from source column to output column.

    Optionally includes an aggregation function and time window.
    Durations use human-friendly strings in the authoring format
    (e.g. ``"5m"``, ``"1h"``) and are normalized to ``_sec`` integers
    during compilation.

    The ``_sec`` integer variants (``window_sec`` / ``offset_sec``) are
    accepted directly so a freshly-exported YAML — which carries the
    seconds form returned by ``DESCRIBE ... TYPE = SPECIFICATION`` —
    survives the round-trip through ``model_validate`` / ``model_dump``
    without losing the duration information.
    """

    source_column: FSColumn = FSColumn(name="", type="")
    output_column: FSColumn = FSColumn(name="", type="")
    function: Optional[str] = None
    window: Optional[Union[str, int]] = None  # Authoring: "5m", "1h"
    offset: Optional[Union[str, int]] = None  # Authoring: "1m"
    window_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    offset_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    function_params: Optional[dict[str, Any]] = None


class FeatureView(SpecBase):
    """Top-level FeatureView definition.

    The ``sources`` list accepts ``SourceRef`` name-reference dicts or
    direct source-object dicts. Source objects are resolved to ``SourceRef``
    dicts during compilation.

    ``ordered_entity_column_names`` accepts plain column-name strings.
    """

    kind: str = "StreamingFeatureView"
    online: bool = False
    offline: bool = False
    timestamp_field: Optional[str] = None
    feature_granularity: Optional[Union[str, int]] = None
    feature_granularity_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    feature_aggregation_method: Optional[str] = None
    target_lag: Optional[Union[str, int]] = None
    target_lag_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    batch_schedule: Optional[str] = None
    ordered_entity_column_names: list[Any] = []  # str or Entity
    sources: list[Any] = []  # SourceRef or StreamingSource/BatchSource
    udf: Optional[UDF] = None
    features: list[Feature] = []


class FeatureViewRef(BaseModel):
    """A name-based reference to a feature view within a feature group."""

    name: str


class FeatureGroup(SpecBase):
    """Top-level FeatureGroup definition.

    A logical grouping of feature views sharing the same schema and
    versioned together. The ``feature_views`` list accepts ``FeatureView``
    instances (resolved to name refs during compilation) or ``FeatureViewRef``
    name references.
    """

    kind: str = "FeatureGroup"
    feature_views: list[Any] = []  # FeatureView or FeatureViewRef
