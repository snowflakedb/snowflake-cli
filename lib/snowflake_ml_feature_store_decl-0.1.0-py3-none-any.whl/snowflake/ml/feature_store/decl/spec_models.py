"""Pydantic v2 authoring-format models for the declarative feature store.

These models represent the human-facing spec format: string-based type
identifiers, human-friendly duration strings, and rich references.
They are fully standalone — no imports from ``snowflake.ml.feature_store.spec``,
``snowflake.snowpark``, or ``snowflake.connector``.

A compilation step (``decl/compiler.py``) transforms these into the JSON
payload format expected by ``CREATE ONLINE FEATURE TABLE ... FROM SPECIFICATION``.
"""

import datetime
from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator


class FSColumn(BaseModel):
    """A single column with name and string-based type information.

    The ``default`` field is required when adding a new output column to
    a feature view that has already been deployed — it tells downstream
    consumers what value to use for historical rows that predate the column.
    """

    name: str
    type: str  # FSBaseType value or alias — normalized during compilation
    length: Optional[int] = None  # For StringType
    precision: Optional[int] = None  # For DecimalType
    scale: Optional[int] = None  # For DecimalType
    tz: Optional[str] = None  # For TimestampType
    default: Optional[Any] = None  # Backfill value for new columns on deployed views


class SpecBase(BaseModel):
    """Common fields shared by all top-level spec kinds."""

    kind: str = ""
    name: str = ""
    version: Optional[str] = None
    database: Optional[str] = None
    schema_: Optional[str] = None
    description: Optional[str] = None


class Entity(SpecBase):
    """Top-level Entity definition."""

    kind: str = "Entity"
    join_keys: list[FSColumn] = []


class StreamingSource(SpecBase):
    """Top-level StreamingSource definition (real-time REST push source).

    Backfill is no longer attached to the source.  Use the FV-level
    :class:`Backfill` block on :class:`FeatureView` to wire
    ``StreamConfig.backfill_df`` and ``StreamConfig.backfill_start_time``.

    A YAML or dict carrying the legacy ``backfill_table`` key raises a
    ``ValidationError`` with an actionable migration message.
    """

    kind: str = "StreamingSource"
    type: str = "REST"
    columns: list[FSColumn] = []

    @model_validator(mode="before")
    @classmethod
    def _reject_legacy_backfill_table(cls, data: Any) -> Any:
        if isinstance(data, dict) and "backfill_table" in data:
            raise ValueError(
                "StreamingSource.backfill_table has been removed; backfill is "
                "now an FV-level concern that mirrors the imperative API. "
                "Move this value onto the dependent FeatureView as "
                "`backfill: { table: <FQN> }` (and add `start_time:` if you "
                "need StreamConfig.backfill_start_time)."
            )
        return data


class BatchSource(SpecBase):
    """Top-level BatchSource definition (offline batch source).

    A ``BatchSource`` describes the data the ``BatchFeatureView`` reads from.
    Exactly one of these three fields must be set:

    * ``table`` — fully qualified or bare table name; resolved via
      ``session.table(...)`` at apply time.
    * ``query`` — inline SQL string; resolved via ``session.sql(query)``.
      Whitespace is normalized at compile time so the recovered DT body
      compares equal across re-applies.
    * ``query_file`` — path (relative to the spec file) to a sibling
      ``.sql`` file; the compiler reads it and inlines the contents into
      ``query``. Mirrors the ``udf.file`` sidecar convention.

    ``source_database`` and ``source_schema`` identify where ``table``
    lives and may differ from the deployment ``database``/``schema_``
    inherited from SpecBase. They are unused for ``query`` / ``query_file``
    sources, where any qualification is part of the SQL itself.
    """

    kind: str = "BatchSource"
    source_database: Optional[str] = None
    source_schema: Optional[str] = None
    table: Optional[str] = None
    query: Optional[str] = None
    query_file: Optional[str] = None
    columns: list[FSColumn] = []

    @model_validator(mode="after")
    def _validate_exactly_one_source(self) -> "BatchSource":
        present = [field for field in ("table", "query", "query_file") if getattr(self, field)]
        if len(present) == 0:
            raise ValueError(
                f"BatchSource '{self.name}' must set exactly one of " "{table, query, query_file}; none were provided."
            )
        if len(present) > 1:
            raise ValueError(
                f"BatchSource '{self.name}' must set exactly one of "
                "{table, query, query_file}; got "
                f"{', '.join(sorted(present))}."
            )
        return self


class SourceRef(BaseModel):
    """A reference to a named source within a feature view.

    Authoring YAML usually lists only ``name`` and ``source_type``; the
    declarative ``resolve_datasource_columns`` pass copies ``columns`` plus
    ``table`` / ``query`` / ``source_database`` / ``source_schema`` from the
    matching top-level datasource spec so :func:`decl.imperative_executor._build_feature_df`
    can resolve ``session.table(...)`` without duplicating location fields on
    every feature view.
    """

    name: str
    source_type: str  # SourceType value
    columns: list[FSColumn] = Field(default_factory=list)
    table: Optional[str] = None
    query: Optional[str] = None
    source_database: Optional[str] = None
    source_schema: Optional[str] = None


class UDF(BaseModel):
    """User-defined function configuration.

    In the authoring format, ``file`` points to a co-located Python file
    and ``name`` identifies the function within it. During compilation
    the CLI reads the file and inlines the source as ``function_definition``.
    """

    name: str
    engine: str = "pandas"
    file: Optional[str] = None  # Path to .py file (YAML authoring)
    function_definition: Optional[Union[str, Any]] = None  # String source or callable
    output_columns: list[FSColumn] = []


class Feature(BaseModel):
    """A feature mapping from source column to output column.

    Optionally includes an aggregation function and time window.
    Durations use human-friendly strings in the authoring format
    (e.g. ``"5m"``, ``"1h"``) and are normalized to ``_sec`` integers
    during compilation.

    The ``_sec`` integer variants (``window_sec`` / ``offset_sec``) are
    accepted directly so a freshly-exported YAML — which carries the
    seconds form returned by ``DESCRIBE ... TYPE = SPECIFICATION`` —
    survives the round-trip through ``model_validate`` / ``model_dump``
    without losing the duration information.
    """

    source_column: FSColumn = FSColumn(name="", type="")
    output_column: FSColumn = FSColumn(name="", type="")
    function: Optional[str] = None
    window: Optional[Union[str, int]] = None  # Authoring: "5m", "1h"
    offset: Optional[Union[str, int]] = None  # Authoring: "1m"
    window_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    offset_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    function_params: Optional[dict[str, Any]] = None


class Backfill(BaseModel):
    """FeatureView-level backfill configuration.

    Mirrors the imperative API's two backfill surfaces in a single
    declarative block:

    * **Streaming** (``kind: StreamingFeatureView``) — ``table`` resolves to
      ``StreamConfig.backfill_df`` (via ``session.table(<table>)``) and
      ``start_time`` is forwarded as ``StreamConfig.backfill_start_time``.
      When ``table`` is omitted the imperative executor still synthesises a
      single typed-sentinel row from the source's declared ``columns`` so
      streaming registration works for REST sources without history.
    * **Batch** (``kind: BatchFeatureView``) — ``overwrite`` is forwarded to
      ``FeatureStore.register_feature_view(overwrite=...)`` and
      ``initialize`` to ``FeatureView(initialize=...)`` so authors can opt
      into the imperative ``ON_CREATE`` / ``ON_SCHEDULE`` semantics.

    Cross-field-kind validation lives on :class:`FeatureView` so the
    error message can name the FV kind that produced the misuse.
    """

    table: Optional[str] = None
    start_time: Optional[Union[datetime.datetime, str]] = None
    overwrite: Optional[bool] = None
    initialize: Optional[Literal["ON_CREATE", "ON_SCHEDULE"]] = None


class FeatureView(SpecBase):
    """Top-level FeatureView definition.

    The ``sources`` list accepts ``SourceRef`` name-reference dicts or
    direct source-object dicts. Source objects are resolved to ``SourceRef``
    dicts during compilation.

    ``ordered_entity_column_names`` accepts plain column-name strings.

    ``backfill`` is an FV-level :class:`Backfill` block; see that class for
    the streaming / batch field map.
    """

    kind: str = "StreamingFeatureView"
    online: bool = False
    offline: bool = False
    timestamp_field: Optional[str] = None
    feature_granularity: Optional[Union[str, int]] = None
    feature_granularity_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    feature_aggregation_method: Optional[str] = None
    target_lag: Optional[Union[str, int]] = None
    target_lag_sec: Optional[int] = None  # Imperative-shape (DESCRIBE / exporter)
    batch_schedule: Optional[str] = None
    ordered_entity_column_names: list[Any] = []  # str or Entity
    sources: list[Any] = []  # SourceRef or StreamingSource/BatchSource
    udf: Optional[UDF] = None
    features: list[Feature] = []
    backfill: Optional[Backfill] = None

    @model_validator(mode="after")
    def _validate_backfill_against_kind(self) -> "FeatureView":
        b = self.backfill
        if b is None:
            return self
        kind = self.kind or ""
        is_streaming = "Streaming" in kind or "Realtime" in kind
        is_batch = kind == "BatchFeatureView"
        # Streaming: reject the batch-only fields.
        if is_streaming:
            if b.overwrite is not None and b.overwrite is not False:
                raise ValueError(
                    f"FeatureView '{self.name}' (kind={kind}): "
                    "backfill.overwrite is only valid on a BatchFeatureView "
                    "(it maps to FeatureStore.register_feature_view(overwrite=...)). "
                    "Streaming feature views use StreamConfig lifecycle instead."
                )
            if b.initialize is not None:
                raise ValueError(
                    f"FeatureView '{self.name}' (kind={kind}): "
                    "backfill.initialize is only valid on a BatchFeatureView "
                    "(it maps to FeatureView(initialize=...)). "
                    "Streaming feature views use StreamConfig lifecycle instead."
                )
        # Batch: reject the streaming-only fields.
        if is_batch:
            if b.table is not None:
                raise ValueError(
                    f"FeatureView '{self.name}' (kind={kind}): "
                    "backfill.table is only valid on a StreamingFeatureView "
                    "(it maps to StreamConfig.backfill_df via session.table(...)). "
                    "Batch feature views read history from their declared sources."
                )
            if b.start_time is not None:
                raise ValueError(
                    f"FeatureView '{self.name}' (kind={kind}): "
                    "backfill.start_time is only valid on a StreamingFeatureView "
                    "(it maps to StreamConfig.backfill_start_time). "
                    "Batch feature views derive freshness from their refresh cadence."
                )
        return self


class FeatureViewRef(BaseModel):
    """A name-based reference to a feature view within a feature group."""

    name: str


class FeatureGroup(SpecBase):
    """Top-level FeatureGroup definition.

    A logical grouping of feature views sharing the same schema and
    versioned together. The ``feature_views`` list accepts ``FeatureView``
    instances (resolved to name refs during compilation) or ``FeatureViewRef``
    name references.
    """

    kind: str = "FeatureGroup"
    feature_views: list[Any] = []  # FeatureView or FeatureViewRef
