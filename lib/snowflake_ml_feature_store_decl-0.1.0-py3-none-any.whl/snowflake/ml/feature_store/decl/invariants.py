"""Invariant engine for the declarative feature store library.

Pure functions only — no database connections, no file I/O.
Entry point: ``validate_specs(batch, applied_state) -> list[ValidationResult]``.
"""

from __future__ import annotations

import copy
import hashlib
import json
from typing import Any, Optional

from snowflake.ml.feature_store.decl.spec_models import SpecBase
from snowflake.ml.feature_store.decl.types import (
    AppliedObject,
    AppliedState,
    SpecBatch,
    ValidationResult,
)

# Kinds that must carry an explicit version string.
_VERSIONED_KINDS: frozenset[str] = frozenset(
    {"StreamingFeatureView", "RealtimeFeatureView", "BatchFeatureView", "FeatureGroup"}
)

# FeatureView kinds that, when ``applied.from_specification`` is True, must
# diff against the deployed spec via the full-spec hash path (compile then
# :func:`_full_spec_hash`).  Mirrors :data:`planner._RECREATE_OP` keys so the
# validator's idempotency check stays consistent with
# :func:`planner.generate_plan` — otherwise the validator always disagrees
# with the planner on FVs recovered from ``DESCRIBE ... TYPE = SPECIFICATION``
# (different hash strategy → spurious ``VERSION_CONFLICT`` on round-trip).
_FV_RECREATE_KINDS: frozenset[str] = frozenset({"StreamingFeatureView", "RealtimeFeatureView", "BatchFeatureView"})

# Keys excluded from all hash computations so that storing a hash in the spec
# itself does not change the hash on the next read.
_INTERNAL_KEYS: frozenset[str] = frozenset({"_hash", "_content_hash"})

# FSBaseType → Snowflake SQL type mapping used for structural fingerprinting.
# Mirrors sql_generator._SF_TYPE_MAP so that DESCRIBE-side types (SQL format)
# and spec-side types (FSBaseType format) normalise to the same string.
_FINGERPRINT_TYPE_MAP: dict[str, str] = {
    "StringType": "VARCHAR",
    "IntegerType": "INTEGER",
    "LongType": "INTEGER",
    "FloatType": "FLOAT",
    "DoubleType": "FLOAT",
    "DecimalType": "NUMBER",
    "BooleanType": "BOOLEAN",
    "TimestampType": "TIMESTAMP_NTZ",
}


# ---------------------------------------------------------------------------
# Hash helpers
# ---------------------------------------------------------------------------


_SOURCE_KIND_ALIASES: frozenset[str] = frozenset({"StreamingSource", "BatchSource"})


def _spec_key(data: dict, *, database: str = "", schema: str = "") -> str:
    """Build a unique key: ``kind:database.schema:NAME`` (uppercased name).

    The two concrete source kinds (``StreamingSource``, ``BatchSource``)
    collapse to the canonical ``Datasource`` kind in
    the key so a freshly-loaded YAML matches the
    :func:`state._datasource_objects_from_specs` AppliedObject (which
    uses the generic :data:`ObjectKind.DATASOURCE` for display
    consistency in ``snow feature list``).

    The ``database`` / ``schema`` kwargs are *fallback only* — they are
    consulted only when the spec dict itself omits the corresponding
    field.  This keeps the multi-store contract intact (a spec that
    explicitly names ``OTHER_DB.OTHER_SCHEMA`` always wins over the
    connection context) while letting the planner qualify keys for
    bare YAMLs (single-file ``apply`` / ``plan`` invocations or
    declarative entities written without ``database:``/``schema:``)
    against the active ``snow`` connection so the lookup key collides
    with the applied-state key (which is *always* fully qualified by
    :func:`state._build_spec_key`).

    Args:
        data: Spec dict carrying ``kind``, ``name``, ``database``, and
            either ``schema`` or ``schema_``.
        database: Connection-context database used as a fallback when
            ``data`` does not carry a ``database`` field.  Defaults to
            ``""`` for backwards compatibility with callers that don't
            yet thread connection context through (e.g. ad-hoc spec
            inspection in tests).
        schema: Connection-context schema used as a fallback when
            ``data`` does not carry a ``schema`` / ``schema_`` field.
            Defaults to ``""``.

    Returns:
        Canonical key string.
    """
    kind = data.get("kind", "Unknown")
    if kind in _SOURCE_KIND_ALIASES:
        kind = "Datasource"
    name = data.get("name", "unnamed").upper()
    db = (data.get("database", "") or database or "").upper()
    schema = (data.get("schema", "") or data.get("schema_", "") or schema or "").upper()
    qualifier = f"{db}.{schema}" if (db or schema) else ""
    return f"{kind}:{qualifier}:{name}"


def _spec_hash(data: dict) -> str:
    """SHA-256 over the full spec dict (excluding ``_hash`` / ``_content_hash``)."""
    clean = {k: v for k, v in data.items() if k not in _INTERNAL_KEYS}
    canonical = json.dumps(clean, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(canonical.encode()).hexdigest()


def _content_hash(data: dict) -> str:
    """SHA-256 excluding the ``version`` field (for dev-mode idempotency)."""
    d = {k: v for k, v in data.items() if k not in _INTERNAL_KEYS}
    d = copy.deepcopy(d)
    d.pop("version", None)
    canonical = json.dumps(d, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(canonical.encode()).hexdigest()


def _sf_type_for_fp(type_str: str) -> str:
    """Normalise a type string for structural fingerprinting.

    Converts FSBaseType names (e.g. ``"StringType"``) to their Snowflake SQL
    equivalents (e.g. ``"VARCHAR"``), then uppercases the result.  SQL type
    strings that come directly from ``DESCRIBE ONLINE FEATURE TABLE`` are
    already in SQL format and are just uppercased.

    Args:
        type_str: A raw type string from either an authoring spec or DESCRIBE.

    Returns:
        Normalised uppercase SQL type string.
    """
    return _FINGERPRINT_TYPE_MAP.get(type_str, type_str).upper()


def _structural_fingerprint(data: dict, include_version: bool = True) -> dict:
    """Build a structural fingerprint from a spec or DESCRIBE-derived dict.

    Extracts ``name``, ``version`` (optional), and sorted output column
    ``name``/``type`` pairs.  Both the authoring-spec path (via
    ``planner.generate_plan``) and the DESCRIBE-reconstruction path (via
    ``state.fetch_applied_state``) call this function, so they always produce
    identical fingerprints for the same deployed feature view.

    For specs: output columns come from ``features[].output_column`` or from
    ``udf.output_columns`` when a UDF is present.

    For DESCRIBE-derived dicts: ``features[].output_column`` is pre-populated
    with the non-primary-key column rows from ``DESCRIBE ONLINE FEATURE TABLE``.

    For ``Entity`` specs the fingerprint additionally folds in
    ``description`` and the sorted ``join_keys`` schema so a non-destructive
    ``UPDATE_ENTITY`` op fires for any of the three editable surfaces of an
    entity tag (``ALLOWED_VALUES`` → join keys, ``COMMENT`` → description,
    name).  Without this widen a ``description``-only edit hashes
    identically and the planner reports ``NO_CHANGE`` (BUG_BASH §11 cascade
    — see ``plans/step11_update_entity_bug_*.plan.md``).

    Args:
        data: Spec dict or DESCRIBE-derived dict.
        include_version: When ``False``, the version field is omitted from the
            fingerprint.  Used for dev-mode idempotency where auto-generated
            timestamp versions should be ignored.

    Returns:
        Dict with keys ``name``, ``version``, ``columns``, and (for
        ``Entity`` kinds only) ``description`` and ``join_keys``.
    """
    name = (data.get("name") or "").upper()
    version = (data.get("version") or "").upper() if include_version else ""

    udf = data.get("udf") or {}
    if udf and "output_columns" in udf:
        raw_cols = list(udf["output_columns"])
    else:
        raw_cols = [f.get("output_column") or {} for f in data.get("features", [])]

    cols = sorted(
        (
            {
                "name": (c.get("name") or "").upper(),
                "type": _sf_type_for_fp(c.get("type") or ""),
            }
            for c in raw_cols
            if c.get("name")
        ),
        key=lambda x: x["name"],
    )
    fingerprint: dict[str, Any] = {"name": name, "version": version, "columns": cols}

    # Entity-specific fields.  An empty / missing ``description`` collapses
    # to "" so ``_build_entity_object`` (no comment) and a YAML lacking a
    # ``description:`` key hash identically — the round-trip after a clean
    # export must still emit ``NO_CHANGE``.
    if data.get("kind") == "Entity":
        fingerprint["description"] = data.get("description") or ""
        fingerprint["join_keys"] = sorted(
            (
                {
                    "name": (jk.get("name") or "").upper(),
                    "type": _sf_type_for_fp(jk.get("type") or ""),
                }
                for jk in (data.get("join_keys") or [])
                if isinstance(jk, dict) and jk.get("name")
            ),
            key=lambda x: x["name"],
        )
    return fingerprint


def _structural_fingerprint_hash(data: dict, include_version: bool = True) -> str:
    """SHA-256 of the structural fingerprint (name + version + output columns).

    This is the canonical hash used for idempotency checks throughout the
    pipeline.  It replaces ``_spec_hash`` so that applied state reconstructed
    from ``DESCRIBE ONLINE FEATURE TABLE`` produces the same hash as the
    authoring spec, enabling ``NO_CHANGE`` detection without a specification
    column in SHOW results.

    Args:
        data: Spec dict or DESCRIBE-derived dict.
        include_version: Passed through to :func:`_structural_fingerprint`.

    Returns:
        64-character lowercase hex SHA-256 digest.
    """
    fp = _structural_fingerprint(data, include_version=include_version)
    canonical = json.dumps(fp, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(canonical.encode()).hexdigest()


# Volatile metadata fields that change with tool versions / build numbers
# but do not represent a change in feature-store semantics.  Stripped before
# computing :func:`_full_spec_hash` so that a client-version bump does not
# falsely flag a deployed spec as changed.
#
# ``oft_id`` is the per-deploy internal ID Snowflake stamps into
# ``DESCRIBE ... TYPE = SPECIFICATION`` output; it changes on every
# ``CREATE`` and is meaningless to the authoring spec, so we treat it the
# same as the other client-version-style stamps.
_VOLATILE_METADATA_KEYS: frozenset[str] = frozenset(
    {
        "client_version",
        "spec_format_version",
        "internal_data_version",
        "oft_id",
    }
)

# Top-level keys that Snowflake adds to the ``DESCRIBE ... TYPE =
# SPECIFICATION`` payload but that the authoring layer never produces.
# These are derived runtime metadata (offline-table descriptors,
# online-store routing flags) and are stripped before hashing so a clean
# round-trip does not flag them as drift.
_DERIVED_TOP_LEVEL_KEYS: frozenset[str] = frozenset(
    {
        "offline_configs",
        "online_store_type",
    }
)

# Spec-level keys that Snowflake stamps onto the ``DESCRIBE ... TYPE =
# SPECIFICATION`` payload at deploy time but that the authoring layer
# does not produce when the operator omits them from the YAML.  Stripped
# before hashing so a runtime-side default (e.g. ``target_lag_sec: 0``
# stamped after a streaming-FV CREATE) does not falsely flag the
# deployed spec as changed on the next ``snow feature plan``.
#
# Add a key here when:
#   * the live runtime emits it on DESCRIBE TYPE = SPECIFICATION,
#   * the local-compile path (``spec_compiler.compile_to_spec``) does
#     not emit it for the equivalent local YAML,
#   * its value is a deploy-time default (zero, infinity, or otherwise
#     boilerplate), AND
#   * dropping it from the hash does not lose semantic information
#     (i.e. the local YAML really has no equivalent).
_RUNTIME_STAMPED_SPEC_KEYS: frozenset[str] = frozenset(
    {
        # Snowflake stamps target_lag_sec=0 onto every streaming FV
        # SPECIFICATION post-CREATE; the authoring YAML never sets it
        # because the bug-bash pattern is "use the default lag".
        "target_lag_sec",
    }
)

# Default ``length`` values Snowflake stamps onto STRING-family columns
# in the SPECIFICATION payload that the local-compile path leaves out.
# Stripped from each ``columns[]`` / ``output_columns[]`` entry before
# hashing.  ``16777216`` is the VARCHAR maximum (2^24) and is the value
# the runtime defaults to for un-sized StringType columns, so its
# presence on the deployed side is not a semantic difference.
_RUNTIME_STAMPED_COLUMN_DEFAULTS: dict[str, object] = {
    "length": 16777216,
}


def _strip_runtime_stamped_columns(columns: object) -> None:
    """Remove runtime-default keys from a ``columns``/``output_columns`` list.

    Walks the list in place; entries that are not dicts are left
    untouched.  A key is stripped only when its value matches the
    documented runtime default — non-default values (e.g. an explicit
    ``length: 100`` set in the local YAML) survive so they continue to
    contribute to the hash.

    Args:
        columns: The list value of a ``columns`` / ``output_columns``
            spec key (or any non-list, in which case this is a no-op).
    """
    if not isinstance(columns, list):
        return
    for entry in columns:
        if not isinstance(entry, dict):
            continue
        for key, default in _RUNTIME_STAMPED_COLUMN_DEFAULTS.items():
            if entry.get(key) == default:
                entry.pop(key, None)


def _full_spec_hash(spec: dict) -> str:
    """SHA-256 over the full spec JSON, with stable key ordering.

    Used by the planner for full-spec diffs when an ``AppliedObject`` was
    populated from ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE =
    SPECIFICATION`` (i.e. ``from_specification=True``).  Volatile metadata
    fields (see :data:`_VOLATILE_METADATA_KEYS`) are removed before
    hashing so that a tool-version bump does not falsely flag a deployed
    spec as changed.  Spec-level runtime-stamped keys (see
    :data:`_RUNTIME_STAMPED_SPEC_KEYS`) and per-column runtime defaults
    (see :data:`_RUNTIME_STAMPED_COLUMN_DEFAULTS`) are likewise stripped
    so a deploy-time ``target_lag_sec: 0`` or ``length: 16777216``
    stamping does not bump the hash on the next ``snow feature plan``.

    Args:
        spec: A compiled-spec dict (e.g. the output of
            :func:`spec_compiler.compile_to_spec` or the JSON returned by
            ``DESCRIBE ... TYPE = SPECIFICATION``).

    Returns:
        64-character lowercase hex SHA-256 digest.
    """
    cleaned = json.loads(json.dumps(spec))  # deep copy via JSON round-trip
    metadata = cleaned.get("metadata") if isinstance(cleaned, dict) else None
    if isinstance(metadata, dict):
        for key in _VOLATILE_METADATA_KEYS:
            metadata.pop(key, None)
    if isinstance(cleaned, dict):
        for key in _DERIVED_TOP_LEVEL_KEYS:
            cleaned.pop(key, None)
    inner = cleaned.get("spec") if isinstance(cleaned, dict) else None
    if isinstance(inner, dict):
        for key in _RUNTIME_STAMPED_SPEC_KEYS:
            inner.pop(key, None)
        # Strip runtime-default ``length`` (and any future
        # ``_RUNTIME_STAMPED_COLUMN_DEFAULTS`` keys) from every
        # ``columns`` / ``output_columns`` list reachable from
        # ``spec``.  Walk one level deep — sources[].columns and
        # udf.output_columns are the two known carriers; the
        # ``_strip_runtime_stamped_columns`` helper is a no-op on
        # non-list values so the walk stays defensive.
        _strip_runtime_stamped_columns(inner.get("output_columns"))
        sources = inner.get("sources")
        if isinstance(sources, list):
            for source in sources:
                if isinstance(source, dict):
                    _strip_runtime_stamped_columns(source.get("columns"))
        udf = inner.get("udf")
        if isinstance(udf, dict):
            _strip_runtime_stamped_columns(udf.get("output_columns"))
    canonical = json.dumps(cleaned, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(canonical.encode()).hexdigest()


def _compute_local_spec_hash(model_dict: dict, database: str, schema: str) -> str:
    """Compile a local FV spec dict and return its full-spec hash.

    The local model dict (produced by :func:`_model_to_dict`) is run
    through :func:`spec_compiler.compile_to_spec` so the result has the
    same shape as the JSON returned by ``DESCRIBE ... TYPE =
    SPECIFICATION``.  The hash is then computed via
    :func:`_full_spec_hash` so a deployed spec and a local spec produce
    identical digests when their semantics match.

    This helper is only meaningful for FeatureView kinds.  Entity and
    Source kinds should keep using :func:`_structural_fingerprint_hash`.

    Args:
        model_dict: Spec dict from :func:`_model_to_dict`.
        database: Snowflake database name (used as ``metadata.database``).
        schema: Snowflake schema name (used as ``metadata.schema``).

    Returns:
        64-character lowercase hex SHA-256 digest of the compiled spec.
    """
    # Imported locally to avoid widening the import surface of this module
    # at package-load time.
    from snowflake.ml.feature_store.decl.spec_compiler import compile_to_spec

    compiled = compile_to_spec(model_dict, database, schema)
    return _full_spec_hash(compiled)


def _model_to_dict(spec_obj: SpecBase) -> dict:
    """Serialize a SpecBase model to a canonical dict for hashing/comparison.

    Renames ``schema_`` to ``schema`` so the key is consistent with raw dict
    representations produced by ``fetch_applied_state``.

    Args:
        spec_obj: A SpecBase (or subclass) model instance.

    Returns:
        Canonical dict with ``schema_`` renamed to ``schema``.
    """
    d = spec_obj.model_dump(exclude_none=True)
    if "schema_" in d:
        d["schema"] = d.pop("schema_")
    return d


def _result(
    severity: str,
    code: str,
    message: str,
    object_name: str = "",
) -> ValidationResult:
    return ValidationResult(
        severity=severity,  # type: ignore[arg-type]
        code=code,
        message=message,
        object_name=object_name,
    )


# ---------------------------------------------------------------------------
# Individual invariant checkers
# ---------------------------------------------------------------------------


def _check_versions(
    spec: dict,
    applied: Optional[AppliedObject],
    dev_mode: bool,
) -> list[ValidationResult]:
    """Version management invariants.

    Only ``FeatureView`` and ``FeatureGroup`` kinds are required to carry an
    explicit version string. ``Entity`` and ``Source`` specs are schema-level
    objects without semantic versioning.

    ``VERSION_CONFLICT`` fires only when the local version is *strictly*
    less than the deployed version (i.e. an attempt to "go backwards").
    Equal versions are not a conflict — they're the canonical re-plan
    case and are short-circuited upstream by ``_check_idempotency``
    when the content matches.  When the content has actually changed at
    the same version, the planner emits a destructive ``RECREATE_FV``
    op (gated behind ``--allow-recreate``), which provides natural
    friction without forcing an explicit version bump.  See
    ``plans/planner_revalidate_identical_spec.plan.md`` for the
    BUG_BASH §9 cascade where the prior ``<=`` semantics caused
    spurious ``VERSION_CONFLICT`` errors when the idempotency hash
    diverged on a re-plan of an unchanged FV.

    Args:
        spec: The normalized spec dict to validate.
        applied: The currently-deployed object, or ``None`` for new objects.
        dev_mode: When True, bypass version-conflict checks.

    Returns:
        List of ``ValidationResult`` objects (may be empty).
    """
    results: list[ValidationResult] = []
    name = spec.get("name", "")
    kind = spec.get("kind", "")
    version = spec.get("version")

    # Version is only mandatory for versioned kinds.
    if kind not in _VERSIONED_KINDS:
        return results

    if not version:
        if not dev_mode:
            results.append(
                _result(
                    "ERROR",
                    "MISSING_VERSION",
                    f"{name} has no version. Add a version or use dev_mode for automatic "
                    "timestamp-based versioning.",
                    name,
                )
            )
        # In dev_mode a version will be auto-generated later; no error.
        return results

    if applied is None:
        # New object — no conflict possible.
        return results

    # Object already exists: only flag a *strictly lower* local version.
    # Equal versions on identical content are NO_CHANGE (handled by
    # ``_check_idempotency``); equal versions on changed content surface
    # as a destructive ``RECREATE_FV`` plan op rather than a validator
    # error.
    applied_version = applied.version or ""
    if applied_version and version < applied_version:
        results.append(
            _result(
                "ERROR",
                "VERSION_CONFLICT",
                f"{name}: version '{version}' is lower than the currently deployed "
                f"'{applied_version}'. Bump the version or use overwrite to force.",
                name,
            )
        )
    return results


def _check_idempotency(
    spec: dict,
    applied: Optional[AppliedObject],
    dev_mode: bool,
    target_database: str = "",
    target_schema: str = "",
) -> tuple[bool, list[ValidationResult]]:
    """Content-hash idempotency check.

    For FeatureView kinds whose ``applied`` object came from
    ``DESCRIBE ... TYPE = SPECIFICATION`` (``applied.from_specification ==
    True``), the desired-side hash is computed via
    :func:`_compute_local_spec_hash` (compile + :func:`_full_spec_hash`) so it
    matches the strategy used by :func:`planner.generate_plan` and the
    state-side ``content_hash`` set by
    :func:`state.fetch_applied_state`.  Otherwise the legacy
    structural-fingerprint comparison is used.

    Args:
        spec: The normalized spec dict to check.
        applied: The currently-deployed object, or ``None`` for new objects.
        dev_mode: When True, compare structural fingerprints excluding version
            so that auto-generated timestamp versions are ignored.
        target_database: Connection target database used when compiling the
            local spec for the full-spec hash path.  Falls back to
            ``spec["database"]`` if empty.
        target_schema: Connection target schema used when compiling the local
            spec for the full-spec hash path.  Falls back to
            ``spec["schema"]`` / ``spec["schema_"]`` if empty.

    Returns:
        Tuple of ``(is_up_to_date, results)``.
    """
    if applied is None:
        return False, []

    name = spec.get("name", "")

    if dev_mode:
        # Compare structural fingerprints without version so auto-generated
        # timestamps do not cause spurious re-deploys.
        current_hash = _structural_fingerprint_hash(spec, include_version=False)
        applied_hash = _structural_fingerprint_hash(applied.spec_payload, include_version=False)
        if current_hash == applied_hash:
            return True, [_result("WARNING", "NO_CHANGE", f"{name}: content unchanged (dev-mode).", name)]
    else:
        kind = spec.get("kind", "")
        if applied.from_specification and kind in _FV_RECREATE_KINDS:
            db_for_compile = target_database or spec.get("database", "") or ""
            sch_for_compile = target_schema or spec.get("schema", "") or spec.get("schema_", "") or ""
            try:
                current_hash = _compute_local_spec_hash(spec, db_for_compile, sch_for_compile)
            except Exception:  # noqa: BLE001 — defensive fallback (mirrors planner)
                current_hash = _structural_fingerprint_hash(spec)
        else:
            current_hash = _structural_fingerprint_hash(spec)
        if current_hash == applied.content_hash:
            return True, [
                _result("WARNING", "NO_CHANGE", f"{name}: spec is identical to deployed version; skipping.", name)
            ]

    return False, []


def _check_column_evolution(
    spec: dict,
    applied: Optional[AppliedObject],
) -> list[ValidationResult]:
    """Column-evolution invariants for feature views and sources."""
    if applied is None:
        return []

    results: list[ValidationResult] = []
    name = spec.get("name", "")
    kind = spec.get("kind", "")

    if "FeatureView" in kind:
        _check_fv_column_evolution(spec, applied, name, results)
    elif kind in ("StreamingSource", "BatchSource"):
        _check_source_column_evolution(spec, applied, name, results)

    return results


def _check_fv_column_evolution(
    spec: dict,
    applied: AppliedObject,
    name: str,
    results: list[ValidationResult],
) -> None:
    """Column evolution checks for feature-view output columns.

    The ``features`` list lives at different nesting levels depending on
    where ``applied.spec_payload`` came from:

    - ``from_specification=True`` — the payload is the full
      ``DESCRIBE ... TYPE = SPECIFICATION`` JSON, so ``features`` is at
      ``spec_payload['spec']['features']`` (one level deeper).
    - ``from_specification=False`` — the payload is the legacy
      structural-fingerprint shape with ``features`` at the top level.

    Without this kind-aware lookup the ``from_specification=True`` path
    silently sees zero deployed features, so every current feature
    looks "added" and the validator emits a spurious ``COLUMN_ADDED``
    warning per output column on every re-plan against a SPECIFICATION-
    backed AppliedObject.  See ``plans/planner_revalidate_identical_spec.plan.md``.

    Args:
        spec: The local spec dict being validated.
        applied: The deployed applied object (any ``from_specification``).
        name: The feature view's name (used in result messages).
        results: Mutable list accumulating any ``ValidationResult`` rows.
    """
    if applied.from_specification:
        applied_features = applied.spec_payload.get("spec", {}).get("features", [])
    else:
        applied_features = applied.spec_payload.get("features", [])

    prev_features: dict[str, dict] = {
        f.get("output_column", {}).get("name"): f.get("output_column", {})
        for f in applied_features
        if f.get("output_column", {}).get("name")
    }
    curr_features: dict[str, dict] = {
        f.get("output_column", {}).get("name"): f.get("output_column", {})
        for f in spec.get("features", [])
        if f.get("output_column", {}).get("name")
    }

    prev_names = set(prev_features.keys())
    curr_names = set(curr_features.keys())

    # New columns: warning only (OFTs always recreate, no in-place update)
    added = curr_names - prev_names
    for col in sorted(added):
        results.append(
            _result(
                "WARNING",
                "COLUMN_ADDED",
                f"{name}.{col}: new output column (will be included in recreated OFT).",
                name,
            )
        )

    # Removed columns: warning for downstream consumers
    removed = prev_names - curr_names
    for col in sorted(removed):
        results.append(
            _result(
                "WARNING",
                "COLUMN_REMOVED",
                f"{name}.{col}: output column removed; downstream consumers may break.",
                name,
            )
        )

    # Type changes: warning
    for col in sorted(prev_names & curr_names):
        old_type = prev_features[col].get("type")
        new_type = curr_features[col].get("type")
        if old_type and new_type and old_type != new_type:
            results.append(
                _result(
                    "WARNING",
                    "COLUMN_TYPE_CHANGED",
                    f"{name}.{col}: output column type changed from '{old_type}' to '{new_type}'.",
                    name,
                )
            )


def _check_source_column_evolution(
    spec: dict,
    applied: AppliedObject,
    name: str,
    results: list[ValidationResult],
) -> None:
    """Column evolution checks for source columns."""
    prev_cols: dict[str, dict] = {c.get("name"): c for c in applied.spec_payload.get("columns", []) if c.get("name")}
    curr_cols: dict[str, dict] = {c.get("name"): c for c in spec.get("columns", []) if c.get("name")}

    prev_names = set(prev_cols.keys())
    curr_names = set(curr_cols.keys())

    added = curr_names - prev_names
    for col in sorted(added):
        results.append(
            _result(
                "WARNING",
                "COLUMN_ADDED",
                f"{name}.{col}: new source column (will be included in recreated object).",
                name,
            )
        )

    removed = prev_names - curr_names
    for col in sorted(removed):
        results.append(
            _result(
                "WARNING",
                "COLUMN_REMOVED",
                f"{name}.{col}: source column removed; downstream feature views may break.",
                name,
            )
        )

    for col in sorted(prev_names & curr_names):
        old_type = prev_cols[col].get("type")
        new_type = curr_cols[col].get("type")
        if old_type and new_type and old_type != new_type:
            results.append(
                _result(
                    "WARNING",
                    "COLUMN_TYPE_CHANGED",
                    f"{name}.{col}: source column type changed from '{old_type}' to '{new_type}'.",
                    name,
                )
            )


def _check_dependencies(
    spec: dict,
    batch_names: set[str],
    applied_state: AppliedState,
) -> list[ValidationResult]:
    """Dependency-resolution invariants."""
    results: list[ValidationResult] = []
    name = spec.get("name", "")
    kind = spec.get("kind", "")

    # Collect all entity join-keys from applied state
    applied_entity_join_keys: set[str] = set()
    applied_source_names: set[str] = set()
    applied_fv_names: set[str] = set()
    for obj in applied_state.objects.values():
        payload = obj.spec_payload
        obj_kind = payload.get("kind", "")
        if obj_kind == "Entity":
            for jk in payload.get("join_keys", []):
                jk_name = jk.get("name", "")
                if jk_name:
                    applied_entity_join_keys.add(jk_name)
        elif obj_kind in ("StreamingSource", "BatchSource"):
            src_name = payload.get("name", "")
            if src_name:
                applied_source_names.add(src_name)
        elif "FeatureView" in obj_kind:
            fv_name = payload.get("name", "")
            if fv_name:
                applied_fv_names.add(fv_name)

    if "FeatureView" in kind:
        # Entity column validation
        entity_cols = spec.get("ordered_entity_column_names", [])
        # Collect entity join-keys from the batch as well (by scanning applied state entities)
        # batch_names contains object names — but we need to check via applied state for join keys
        # We pass batch entity join keys via applied_state for simplicity; callers should merge.
        for ecol in entity_cols:
            if ecol not in applied_entity_join_keys:
                results.append(
                    _result(
                        "ERROR",
                        "MISSING_ENTITY",
                        f"{name}: references entity column '{ecol}' but no entity with that "
                        "join key exists in the current batch or applied state.",
                        name,
                    )
                )

        # Source reference validation
        all_source_names = applied_source_names | batch_names
        for src_ref in spec.get("sources", []):
            src_name = src_ref.get("name", "")
            if src_name and src_name not in all_source_names:
                results.append(
                    _result(
                        "ERROR",
                        "MISSING_SOURCE",
                        f"{name}: references source '{src_name}' but no source with that name "
                        "exists in the current batch or applied state.",
                        name,
                    )
                )

    elif kind == "FeatureGroup":
        all_fv_names = applied_fv_names | batch_names
        for fv_ref in spec.get("feature_views", []):
            fv_name = fv_ref.get("name", "")
            if fv_name and fv_name not in all_fv_names:
                results.append(
                    _result(
                        "ERROR",
                        "MISSING_FEATURE_VIEW",
                        f"{name}: references feature view '{fv_name}' which does not exist "
                        "in the current batch or applied state.",
                        name,
                    )
                )

    return results


def _check_destructive(
    spec: dict,
    applied: Optional[AppliedObject],
) -> list[ValidationResult]:
    """Detect changes that require re-materialization.

    The deployed features list lives at different nesting levels
    depending on where ``applied.spec_payload`` came from — see
    :func:`_check_fv_column_evolution` for the same nesting contract.
    Without this kind-aware lookup, ``_check_destructive`` silently
    sees zero deployed features for ``from_specification=True``
    AppliedObjects and never fires the ``DESTRUCTIVE_CHANGE`` error
    that gates plain ``snow feature apply`` against destructive
    aggregation/function edits.

    Args:
        spec: The local spec dict being validated.
        applied: The deployed applied object, or ``None`` for new objects.

    Returns:
        List of ``ValidationResult`` objects (may be empty).
    """
    if applied is None:
        return []

    results: list[ValidationResult] = []
    name = spec.get("name", "")
    kind = spec.get("kind", "")

    if "FeatureView" not in kind:
        return results

    if applied.from_specification:
        applied_features = applied.spec_payload.get("spec", {}).get("features", [])
    else:
        applied_features = applied.spec_payload.get("features", [])

    prev_features: dict[str, dict] = {
        f.get("output_column", {}).get("name"): f for f in applied_features if f.get("output_column", {}).get("name")
    }
    for feat in spec.get("features", []):
        col_name = feat.get("output_column", {}).get("name")
        if not col_name or col_name not in prev_features:
            continue
        prev_feat = prev_features[col_name]
        # Compare functions (expression change)
        old_fn = prev_feat.get("function")
        new_fn = feat.get("function")
        if old_fn != new_fn:
            results.append(
                _result(
                    "ERROR",
                    "DESTRUCTIVE_CHANGE",
                    f"{name}.{col_name}: expression/function changed from '{old_fn}' to "
                    f"'{new_fn}'. This requires re-materialization. Use allow_recreate=True.",
                    name,
                )
            )

    return results


def _check_state_sync(
    spec: dict,
    applied: Optional[AppliedObject],
) -> list[ValidationResult]:
    """State-synchronization invariants (concurrent modification / state drift)."""
    if applied is None:
        return []

    results: list[ValidationResult] = []
    name = spec.get("name", "")
    spec_version = spec.get("version") or ""
    applied_version = applied.version or ""

    # State drift: applied has a strictly newer version than what the plan expects.
    # This indicates a concurrent modification between fetch_applied_state and now.
    if applied_version and spec_version and applied_version > spec_version:
        results.append(
            _result(
                "ERROR",
                "STATE_DRIFT",
                f"{name}: state drift detected. Expected version '{spec_version}', found "
                f"'{applied_version}'. Re-run plan to refresh state.",
                name,
            )
        )

    return results


def _check_database_schema_mismatch(
    specs: list[dict],
    target_database: str,
    target_schema: str,
) -> list[ValidationResult]:
    """Warn when spec database/schema fields differ from the connection target.

    When a spec explicitly sets ``database`` or ``schema`` / ``schema_`` to a
    value that differs from the connection target, the connection target will
    always be used — the spec field is ignored.  This check surfaces that
    discrepancy so users are aware.

    Only checks are emitted when both the spec field and the target are
    non-empty (and differ).

    Args:
        specs: List of normalised spec dicts to check.
        target_database: The connection's target database (uppercased for
            comparison).
        target_schema: The connection's target schema (uppercased for
            comparison).

    Returns:
        List of ``ValidationResult`` objects with severity ``WARNING``.
    """
    results: list[ValidationResult] = []
    target_db_upper = (target_database or "").upper()
    target_sch_upper = (target_schema or "").upper()

    for spec in specs:
        name = spec.get("name", "")

        # Database mismatch
        if target_db_upper:
            spec_db = (spec.get("database") or "").upper()
            if spec_db and spec_db != target_db_upper:
                results.append(
                    _result(
                        "WARNING",
                        "DB_MISMATCH",
                        f"{name}: spec has database='{spec.get('database')}' but target is "
                        f"'{target_database}'. The connection database ('{target_database}') "
                        "will be used.",
                        name,
                    )
                )

        # Schema mismatch — spec may use 'schema' or 'schema_' (Pydantic alias)
        if target_sch_upper:
            spec_sch_raw = spec.get("schema") or spec.get("schema_") or ""
            spec_sch = spec_sch_raw.upper()
            if spec_sch and spec_sch != target_sch_upper:
                results.append(
                    _result(
                        "WARNING",
                        "SCHEMA_MISMATCH",
                        f"{name}: spec has schema='{spec_sch_raw}' but target is "
                        f"'{target_schema}'. The connection schema ('{target_schema}') "
                        "will be used.",
                        name,
                    )
                )

    return results


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Source compatibility checker
# ---------------------------------------------------------------------------


_SOURCE_KINDS: frozenset[str] = frozenset({"StreamingSource", "BatchSource"})


def _check_source_compatibility(
    batch_specs: list[dict],
    applied_state: AppliedState,
) -> list[ValidationResult]:
    """Check that source spec changes are compatible with dependent feature views.

    For each source spec in the batch, compares it against the applied version and
    checks whether any feature views in the batch reference affected columns.

    Rules:
    - Column removed and used by a batch FV: ERROR (SOURCE_COLUMN_REMOVED)
    - Column type changed and used by a batch FV: ERROR (SOURCE_COLUMN_TYPE_CHANGED)
    - Column added: WARNING (SOURCE_COLUMN_ADDED)
    - Source absent from batch but referenced by a batch FV: ERROR (SOURCE_DELETED_WITH_DEPENDENTS)

    Args:
        batch_specs: List of normalised spec dicts in the current batch.
        applied_state: Current applied-state snapshot.

    Returns:
        List of ``ValidationResult`` objects.
    """
    results: list[ValidationResult] = []

    # Map source name -> new spec dict (from batch)
    batch_sources: dict[str, dict] = {}
    for spec in batch_specs:
        if spec.get("kind") in _SOURCE_KINDS:
            name = spec.get("name", "")
            if name:
                batch_sources[name] = spec

    # Map source name -> list of FV dicts that reference it (from batch)
    batch_fv_by_source: dict[str, list[dict]] = {}
    for spec in batch_specs:
        if "FeatureView" in spec.get("kind", ""):
            for src_ref in spec.get("sources", []):
                src_name = src_ref.get("name", "")
                if src_name:
                    batch_fv_by_source.setdefault(src_name, []).append(spec)

    # -------------------------------------------------------------------------
    # Check 1: column-level changes for sources present in both batch and applied
    # -------------------------------------------------------------------------
    for src_name, new_src in batch_sources.items():
        applied_src_obj: Optional[AppliedObject] = None
        for obj in applied_state.objects.values():
            if obj.kind in _SOURCE_KINDS and obj.name == src_name:
                applied_src_obj = obj
                break

        if applied_src_obj is None:
            # Brand-new source -- no compatibility issue possible
            continue

        prev_cols: dict[str, dict] = {
            c.get("name"): c for c in applied_src_obj.spec_payload.get("columns", []) if c.get("name")
        }
        curr_cols: dict[str, dict] = {c.get("name"): c for c in new_src.get("columns", []) if c.get("name")}

        # Collect source columns actually used by dependent batch FVs
        used_columns: set[str] = set()
        for fv in batch_fv_by_source.get(src_name, []):
            for feat in fv.get("features", []):
                col = (feat.get("source_column") or {}).get("name", "")
                if col:
                    used_columns.add(col)

        # Columns removed -- error only when a batch FV depends on that column
        removed = set(prev_cols.keys()) - set(curr_cols.keys())
        for col in sorted(removed):
            if col in used_columns:
                results.append(
                    _result(
                        "ERROR",
                        "SOURCE_COLUMN_REMOVED",
                        f"{src_name}.{col}: source column removed but referenced by feature view(s). "
                        "Remove the column from dependent feature views first.",
                        src_name,
                    )
                )

        # Columns added -- always a backward-compatible warning
        added = set(curr_cols.keys()) - set(prev_cols.keys())
        for col in sorted(added):
            results.append(
                _result(
                    "WARNING",
                    "SOURCE_COLUMN_ADDED",
                    f"{src_name}.{col}: new source column (backward compatible).",
                    src_name,
                )
            )

        # Column type changes -- error only when a batch FV depends on that column
        for col in sorted(set(prev_cols.keys()) & set(curr_cols.keys())):
            old_type = prev_cols[col].get("type")
            new_type = curr_cols[col].get("type")
            if old_type and new_type and old_type != new_type and col in used_columns:
                results.append(
                    _result(
                        "ERROR",
                        "SOURCE_COLUMN_TYPE_CHANGED",
                        f"{src_name}.{col}: source column type changed from '{old_type}' to "
                        f"'{new_type}'; referenced by feature view(s). "
                        "Update dependent feature views first.",
                        src_name,
                    )
                )

    # -------------------------------------------------------------------------
    # Check 2: applied sources absent from the batch but still referenced by
    # FVs in the batch (implicit deletion)
    # -------------------------------------------------------------------------
    for obj in applied_state.objects.values():
        if obj.kind not in _SOURCE_KINDS:
            continue
        src_name = obj.name
        if src_name in batch_sources:
            continue  # Source is present in the batch -- not being deleted

        dependent_fvs = batch_fv_by_source.get(src_name, [])
        if dependent_fvs:
            fv_names = ", ".join(sorted(fv.get("name", "?") for fv in dependent_fvs))
            results.append(
                _result(
                    "ERROR",
                    "SOURCE_DELETED_WITH_DEPENDENTS",
                    f"{src_name}: source is being removed but still referenced by feature view(s): "
                    f"{fv_names}. Remove or update the dependent feature views first.",
                    src_name,
                )
            )

    return results


def validate_specs(
    batch: SpecBatch,
    applied_state: AppliedState,
    dev_mode: bool = False,
    target_database: str = "",
    target_schema: str = "",
) -> list[ValidationResult]:
    """Validate a spec batch against all invariant rules.

    This is a pure function — no side effects, no database access.

    Args:
        batch: The parsed spec batch to validate.
        applied_state: Current applied-state snapshot (from ``fetch_applied_state``).
        dev_mode: When True, skip version checks and use content-hash idempotency.
        target_database: Connection target database; when non-empty, specs with a
            differing ``database`` field produce a ``DB_MISMATCH`` warning.
        target_schema: Connection target schema; when non-empty, specs with a
            differing ``schema`` / ``schema_`` field produce a ``SCHEMA_MISMATCH``
            warning.

    Returns:
        Combined list of ``ValidationResult`` objects (ERRORRs and WARNINGGs).
    """
    results: list[ValidationResult] = []

    # Build lookup data from the batch for cross-spec dependency checks.
    # We need entity join-keys and source names from ALL specs in this batch.
    batch_entity_join_keys: set[str] = set()
    batch_source_names: set[str] = set()
    batch_fv_names: set[str] = set()
    batch_names: set[str] = set()

    for spec_obj in batch.specs:
        data = _model_to_dict(spec_obj)
        kind = data.get("kind", "")
        name = data.get("name", "")
        if name:
            batch_names.add(name)
        if kind == "Entity":
            for jk in data.get("join_keys", []):
                jk_name = jk.get("name", "")
                if jk_name:
                    batch_entity_join_keys.add(jk_name)
        elif kind in ("StreamingSource", "BatchSource"):
            if name:
                batch_source_names.add(name)
        elif "FeatureView" in kind:
            if name:
                batch_fv_names.add(name)

    # Merge batch entity join keys into a temporary applied_state for dependency checks.
    # We synthesise ephemeral AppliedObject entries for batch entities so that
    # _check_dependencies can find them via applied_state.objects.
    merged_objects = dict(applied_state.objects)
    for spec_obj in batch.specs:
        data = _model_to_dict(spec_obj)
        kind = data.get("kind", "")
        if kind == "Entity":
            # Forward connection context so unqualified spec keys collide
            # with the (always fully-qualified) applied-state keys — same
            # rationale as the planner's diff loop.
            key = _spec_key(data, database=target_database, schema=target_schema)
            if key not in merged_objects:
                merged_objects[key] = AppliedObject(
                    key=key,
                    kind=kind,
                    name=data.get("name", ""),
                    spec_payload=data,
                )
    from snowflake.ml.feature_store.decl.types import AppliedState as _AS

    merged_applied = _AS(objects=merged_objects)
    all_source_batch_names = batch_source_names | batch_fv_names | batch_names

    for spec_obj in batch.specs:
        data = _model_to_dict(spec_obj)
        # See ``planner.generate_plan`` for the rationale: connection
        # context is a fallback so bare YAMLs match fully-qualified
        # applied-state keys instead of silently producing phantom
        # diffs.  ``target_database`` / ``target_schema`` flow in via
        # the public ``validate_specs`` signature.
        key = _spec_key(data, database=target_database, schema=target_schema)
        applied = applied_state.objects.get(key)

        # 1. Idempotency — check first; if up-to-date, skip remaining checks.
        is_up_to_date, idem_results = _check_idempotency(
            data,
            applied,
            dev_mode,
            target_database=target_database,
            target_schema=target_schema,
        )
        results.extend(idem_results)
        if is_up_to_date:
            continue

        # 2. Version checks
        results.extend(_check_versions(data, applied, dev_mode))

        # 3. Column evolution
        results.extend(_check_column_evolution(data, applied))

        # 4. Dependency validation
        results.extend(_check_dependencies(data, all_source_batch_names, merged_applied))

        # 5. Destructive changes
        results.extend(_check_destructive(data, applied))

        # 6. State sync / drift detection
        results.extend(_check_state_sync(data, applied))

    # 7. Database/schema mismatch warnings (batch-level, after per-spec loop)
    if target_database or target_schema:
        all_dicts = [_model_to_dict(s) for s in batch.specs]
        results.extend(_check_database_schema_mismatch(all_dicts, target_database, target_schema))

    # 8. Source compatibility checks (batch-level)
    all_dicts = [_model_to_dict(s) for s in batch.specs]
    results.extend(_check_source_compatibility(all_dicts, applied_state))

    return results
