"""Compilation passes for declarative feature store spec dicts.

Transforms authoring-format spec dicts (human-friendly types and durations)
into normalized output ready for validation and planning.

All functions are self-contained — no imports from snowflake.ml.feature_store.spec,
snowflake.snowpark, or snowflake.connector.  String duration parsing is
delegated to the shared, stdlib-only
:mod:`snowflake.ml.feature_store.interval_utils` module so the imperative
and declarative paths agree on accepted units and the ``"lifetime"``
sentinel.
"""

from __future__ import annotations

from typing import Any

from snowflake.ml.feature_store.decl.enums import normalize_type
from snowflake.ml.feature_store.interval_utils import interval_to_seconds

# Duration keys that should be renamed to their _sec counterparts.
_DURATION_KEYS = frozenset({"feature_granularity", "target_lag", "window", "offset"})


def parse_duration_to_seconds(duration: str | int | float | None) -> int | None:
    """Parse a human-friendly duration value to integer seconds.

    The declarative authoring layer accepts ``None`` and pre-converted
    ``int`` / ``float`` values directly; every string is delegated to
    :func:`snowflake.ml.feature_store.interval_utils.interval_to_seconds`,
    which is the canonical duration parser shared with the imperative
    aggregation layer.

    Accepted shapes:

    - ``None`` → ``None``
    - ``int`` / ``float`` → ``int(value)`` (assumed already in seconds)
    - ``"5m"``, ``"30 minutes"``, ``"1h"``, ``"7d"``, ``"1w"``,
      ``"2 weeks"``, ``"1.5m"`` (fractional values truncated)
    - ``"lifetime"`` → ``-1`` (sentinel matching the imperative layer)

    Bare numeric strings (``"300"``) are intentionally rejected; the
    imperative ``parse_interval`` rejects them as well.  Authoring code
    should pass an ``int`` if the value is already in seconds.

    Args:
        duration: A duration value to parse.

    Returns:
        Integer seconds, or ``None`` if input is ``None``.
    """
    if duration is None:
        return None
    if isinstance(duration, (int, float)):
        return int(duration)
    return interval_to_seconds(str(duration))


def normalize_types(obj: Any) -> Any:
    """Recursively resolve type aliases to FSBaseType values.

    Walks all ``type`` fields in a dict/list tree and normalises the values
    via :func:`~snowflake.ml.feature_store.decl.enums.normalize_type`.

    Args:
        obj: A dict, list, or scalar to normalise.

    Returns:
        The same structure with all ``type`` field values resolved.
    """
    if isinstance(obj, dict):
        result = {}
        for k, v in obj.items():
            if k == "type" and isinstance(v, str):
                result[k] = normalize_type(v)
            else:
                result[k] = normalize_types(v)
        return result
    elif isinstance(obj, list):
        return [normalize_types(item) for item in obj]
    return obj


def normalize_durations(obj: Any) -> Any:
    """Recursively normalize human-friendly duration fields to integer seconds.

    Renames the following keys to their ``_sec`` equivalents and converts
    the value using :func:`parse_duration_to_seconds`:

    - ``feature_granularity`` → ``feature_granularity_sec``
    - ``target_lag`` → ``target_lag_sec``
    - ``window`` → ``window_sec``
    - ``offset`` → ``offset_sec``

    If the value is ``None`` the key is kept unchanged (no ``_sec`` variant).
    If the value cannot be parsed (e.g. ``"invalid"``) the key is kept unchanged.

    Args:
        obj: A dict, list, or scalar to normalise.

    Returns:
        The same structure with duration fields renamed and converted.
    """
    if isinstance(obj, dict):
        result: dict[str, Any] = {}
        for k, v in obj.items():
            if k in _DURATION_KEYS:
                if v is None:
                    result[k] = v
                else:
                    try:
                        result[f"{k}_sec"] = parse_duration_to_seconds(v)
                    except ValueError:
                        result[k] = v
            else:
                result[k] = normalize_durations(v)
        return result
    elif isinstance(obj, list):
        return [normalize_durations(item) for item in obj]
    return obj


def inline_udf_source(data: dict[str, Any], spec_file_dir: str | None) -> dict[str, Any]:
    """Read an external UDF file and inline its source as ``function_definition``.

    If ``data["udf"]["file"]`` is set, reads the file relative to
    ``spec_file_dir`` and stores the source in ``data["udf"]["function_definition"]``.
    The ``file`` key is removed from the compiled output.

    If the file is not found, a warning is printed and the spec is returned
    unchanged.

    Args:
        data: A spec dict that may contain a ``udf`` sub-dict.
        spec_file_dir: Directory to resolve relative ``udf.file`` paths against.

    Returns:
        The spec dict with UDF source inlined (mutated in place and returned).
    """
    import os

    udf = data.get("udf")
    if not udf or not isinstance(udf, dict):
        return data

    udf_file = udf.get("file")
    if not udf_file:
        return data

    if spec_file_dir is None:
        return data

    udf_path = os.path.join(spec_file_dir, udf_file)
    if not os.path.exists(udf_path):
        import warnings

        warnings.warn(f"UDF file not found: {udf_path}", stacklevel=2)
        return data

    with open(udf_path) as f:
        source = f.read()

    udf["function_definition"] = source
    del udf["file"]
    return data


def compile_spec(data: dict[str, Any], spec_file_dir: str | None = None) -> dict[str, Any]:
    """Compile an authoring-format spec dict into normalized output.

    Runs three normalization passes in order:

    1. :func:`normalize_types` — resolve type aliases to ``FSBaseType`` values.
    2. :func:`inline_udf_source` — inline external UDF ``.py`` files.
    3. :func:`normalize_durations` — convert human-friendly duration strings to
       integer seconds and rename keys to ``_sec`` variants.

    Args:
        data: The raw authoring-format spec dict.
        spec_file_dir: Directory for resolving relative ``udf.file`` paths.
            May be ``None`` when no UDF inlining is needed.

    Returns:
        The compiled, normalized spec dict.
    """
    data = normalize_types(data)
    data = inline_udf_source(data, spec_file_dir)
    data = normalize_durations(data)
    return data
