"""Public API for the declarative feature store library.

Import the key functions and types from this package:

    from snowflake.ml.feature_store.decl import (
        load_specs,
        validate_specs,
        generate_plan,
        fetch_applied_state,
        SpecBatch,
        AppliedState,
        Plan,
        PlanOptions,
        ValidationResult,
        PlanOp,
        AppliedObject,
        SpecLoadError,
        ValidationError,
        DependencyError,
        StateDriftError,
        FSBaseType,
        FeatureViewKind,
        SourceType,
        FeatureAggregationMethod,
        OpKind,
        TYPE_ALIASES,
        normalize_type,
        FSColumn,
        SpecBase,
        Entity,
        StreamingSource,
        BatchSource,
        SQLDataSource,
        SourceRef,
        UDF,
        Feature,
        FeatureView,
        FeatureViewRef,
        FeatureGroup,
    )
"""

from snowflake.ml.feature_store.decl.api import (
    fetch_applied_state,
    generate_plan,
    load_specs,
    resolve_datasource_columns,
    validate_specs,
)
from snowflake.ml.feature_store.decl.enums import (
    TYPE_ALIASES,
    FeatureAggregationMethod,
    FeatureViewKind,
    FSBaseType,
    OpKind,
    SourceType,
    normalize_type,
)
from snowflake.ml.feature_store.decl.errors import (
    DependencyError,
    SpecLoadError,
    StateDriftError,
    ValidationError,
)
from snowflake.ml.feature_store.decl.spec_models import (
    UDF,
    BatchSource,
    Entity,
    Feature,
    FeatureGroup,
    FeatureView,
    FeatureViewRef,
    FSColumn,
    SourceRef,
    SpecBase,
    SQLDataSource,
    StreamingSource,
)
from snowflake.ml.feature_store.decl.types import (
    AppliedObject,
    AppliedState,
    Plan,
    PlanOp,
    PlanOptions,
    SpecBatch,
    ValidationResult,
)

__all__ = [
    # api.py
    "load_specs",
    "validate_specs",
    "generate_plan",
    "fetch_applied_state",
    "resolve_datasource_columns",
    # enums.py
    "FSBaseType",
    "FeatureViewKind",
    "SourceType",
    "FeatureAggregationMethod",
    "OpKind",
    "TYPE_ALIASES",
    "normalize_type",
    # errors.py
    "SpecLoadError",
    "ValidationError",
    "DependencyError",
    "StateDriftError",
    # spec_models.py
    "FSColumn",
    "SpecBase",
    "Entity",
    "StreamingSource",
    "BatchSource",
    "SQLDataSource",
    "SourceRef",
    "UDF",
    "Feature",
    "FeatureView",
    "FeatureViewRef",
    "FeatureGroup",
    # types.py
    "AppliedObject",
    "AppliedState",
    "PlanOp",
    "Plan",
    "ValidationResult",
    "PlanOptions",
    "SpecBatch",
]
