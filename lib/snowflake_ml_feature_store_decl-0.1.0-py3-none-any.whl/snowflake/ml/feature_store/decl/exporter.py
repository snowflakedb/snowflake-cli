"""Export spec reconstruction for the declarative feature store library.

Reconstructs YAML spec files from pre-fetched SHOW results plus the full
original spec JSON returned by ``DESCRIBE ONLINE FEATURE TABLE <name>
TYPE = SPECIFICATION``.  No Snowflake connection access — accepts data
that the caller has already fetched and converted to plain dicts.

Export is strict: every OFT row in *show_rows* must have a corresponding
non-empty entry in *specification_map*.  Missing entries abort the export
with a :class:`ValueError`.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

import yaml

from snowflake.ml.feature_store.decl.state import _parse_oft_name

logger = logging.getLogger(__name__)


# YAML keys that should appear at the top of a feature view document, in this
# order, when present.  Any keys not listed here are appended after these.
_FV_TOP_LEVEL_ORDER: tuple[str, ...] = (
    "kind",
    "name",
    "version",
    "database",
    "schema",
    "online",
    "scheduling_state",
    "ordered_entity_column_names",
    "timestamp_field",
    "feature_granularity_sec",
    "feature_aggregation_method",
    "sources",
    "features",
    "udf",
)


def _ordered_fv_doc(fv_spec: dict[str, Any]) -> dict[str, Any]:
    """Return *fv_spec* re-ordered with well-known keys first.

    Python ``dict`` preserves insertion order, and PyYAML respects it when
    serializing — so this gives the emitted YAML a predictable layout while
    leaving any unknown keys to trail at the end.

    Args:
        fv_spec: Feature view dict to re-order.

    Returns:
        New dict with the same keys, ordered with well-known keys first.
    """
    ordered: dict[str, Any] = {}
    for key in _FV_TOP_LEVEL_ORDER:
        if key in fv_spec:
            ordered[key] = fv_spec[key]
    for key, value in fv_spec.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def _build_full_fidelity_fv(
    full_spec: dict[str, Any],
    *,
    fallback_name: str,
    fallback_version: str,
    fallback_database: str,
    fallback_schema: str,
    scheduling_state: str,
) -> dict[str, Any]:
    """Build a YAML-ready feature view dict from a parsed spec JSON document.

    Args:
        full_spec: The spec JSON returned by ``DESCRIBE ... TYPE = SPECIFICATION``.
            Expected shape: ``{kind, metadata, offline_configs, spec, ...}``.
        fallback_name: Name to use if ``metadata.name`` is absent.
        fallback_version: Version to use if ``metadata.version`` is absent.
        fallback_database: Database to use if ``metadata.database`` is absent.
        fallback_schema: Schema to use if ``metadata.schema`` is absent.
        scheduling_state: Scheduling state from the SHOW row (may be ``""``).

    Returns:
        Dict ready to be passed through :func:`_ordered_fv_doc` and serialized.
    """
    kind = full_spec.get("kind", "StreamingFeatureView")
    metadata = full_spec.get("metadata", {}) if isinstance(full_spec.get("metadata"), dict) else {}
    inner = full_spec.get("spec", {}) if isinstance(full_spec.get("spec"), dict) else {}

    fv_doc: dict[str, Any] = {
        "kind": kind,
        "name": metadata.get("name", fallback_name),
        "version": metadata.get("version", fallback_version),
        "database": metadata.get("database", fallback_database),
        "schema": metadata.get("schema", fallback_schema),
        "online": True,
    }
    if scheduling_state:
        fv_doc["scheduling_state"] = scheduling_state

    if "ordered_entity_column_names" in inner:
        fv_doc["ordered_entity_column_names"] = list(inner["ordered_entity_column_names"])

    if "timestamp_field" in inner and inner["timestamp_field"] is not None:
        fv_doc["timestamp_field"] = inner["timestamp_field"]
    if "feature_granularity_sec" in inner and inner["feature_granularity_sec"] is not None:
        fv_doc["feature_granularity_sec"] = inner["feature_granularity_sec"]
    if "feature_aggregation_method" in inner and inner["feature_aggregation_method"] is not None:
        fv_doc["feature_aggregation_method"] = inner["feature_aggregation_method"]

    sources = inner.get("sources")
    if isinstance(sources, list):
        fv_doc["sources"] = [dict(s) if isinstance(s, dict) else s for s in sources]

    features = inner.get("features")
    if isinstance(features, list):
        fv_doc["features"] = [dict(f) if isinstance(f, dict) else f for f in features]

    udf = inner.get("udf")
    if isinstance(udf, dict) and udf:
        fv_doc["udf"] = dict(udf)

    return fv_doc


def _extract_udf_to_py_file(
    fv_doc: dict[str, Any],
    fv_dir: Path,
    file_stem: str,
) -> Optional[str]:
    """Externalize ``fv_doc['udf']['function_definition']`` to a sibling ``.py`` file.

    Mutates *fv_doc* in place: when a non-empty ``function_definition`` string
    is present, it is removed from the ``udf`` block and replaced with a
    ``file`` key holding the bare filename (relative to *fv_dir*).  The source
    is written to ``<fv_dir>/<file_stem>.py``.  When ``function_definition``
    is missing, empty, or non-string, no file is written and the ``udf`` block
    is left untouched.

    The bare-filename convention matches what
    :func:`compiler.inline_udf_source` resolves (it joins ``udf.file`` with
    the spec file's directory) — so the exported YAML round-trips through
    ``snow feature apply`` without manual edits.

    Args:
        fv_doc: Feature view dict being assembled for YAML serialization.
        fv_dir: Directory in which the FV YAML will be written.
        file_stem: Base filename (typically the FV name) used for the ``.py``
            sidecar.

    Returns:
        Absolute path to the written ``.py`` file as a string, or ``None`` if
        no extraction occurred.
    """
    udf = fv_doc.get("udf")
    if not isinstance(udf, dict):
        return None
    source = udf.get("function_definition")
    if not isinstance(source, str) or not source:
        return None

    udf_filename = f"{file_stem}.py"
    udf_path = fv_dir / udf_filename
    udf_path.write_text(source)
    udf.pop("function_definition", None)
    udf["file"] = udf_filename
    return str(udf_path)


def _entity_cols_from_full_spec(full_spec: dict[str, Any]) -> list[str]:
    """Return the join-key column names from a full spec JSON document.

    Args:
        full_spec: Spec JSON returned by ``DESCRIBE ... TYPE = SPECIFICATION``.

    Returns:
        List of entity column names, or an empty list if absent.
    """
    inner = full_spec.get("spec", {}) if isinstance(full_spec.get("spec"), dict) else {}
    cols = inner.get("ordered_entity_column_names")
    if isinstance(cols, list):
        return [str(c) for c in cols]
    return []


def export_specs(
    show_rows: list[dict[str, Any]],
    describe_rows_by_oft: dict[str, list[dict[str, Any]]],
    output_dir: str,
    database: str,
    schema: str,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
) -> dict[str, Any]:
    """Reconstruct YAML specs from raw Snowflake query results and write to disk.

    Strict mode: every row in ``SHOW ONLINE FEATURE TABLES`` must have a
    matching non-empty entry in *specification_map* (the parsed JSON
    returned by ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE =
    SPECIFICATION``).  When that requirement is met, each YAML preserves
    UDF source, source column schemas, feature aggregations
    (function/window/offset), granularity, and target lag — enabling a
    round-trip ``snow feature apply`` without manual edits.

    Entity YAML files are written for each unique join-key column across
    all OFTs (deduplicated).

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES`` (list of dicts).
        describe_rows_by_oft: Map of OFT name → ``DESCRIBE`` rows (list of
            dicts).  Retained for forward compatibility; not consumed in
            strict mode.
        output_dir: Base output directory.  A ``<database>.<schema>``
            subdirectory is created inside it.
        database: Connection database name, used as the directory prefix and
            as a fallback when a row lacks one.
        schema: Connection schema name, used as the directory prefix and as
            a fallback when a row lacks one.
        specification_map: Map of OFT name → parsed spec JSON returned by
            ``DESCRIBE ... TYPE = SPECIFICATION``.  Required for every OFT
            in *show_rows*; missing or empty entries abort the export.

    Returns:
        Dict with keys:

        - ``status``: ``"exported"``
        - ``directory``: Absolute path to the ``<database>.<schema>`` base dir,
          or ``""`` if *show_rows* was empty.
        - ``files``: List of absolute paths to the written YAML files.

    Raises:
        ValueError: If any OFT in *show_rows* has no corresponding entry in
            *specification_map* (or maps to an empty/non-dict value).
    """
    del describe_rows_by_oft  # retained in signature for forward compatibility

    if not show_rows:
        return {"status": "exported", "directory": "", "files": []}

    spec_map = specification_map or {}

    base = Path(output_dir) / f"{database}.{schema}"
    entities_dir = base / "entities"
    fv_dir = base / "feature_views"
    for d in (entities_dir, fv_dir):
        d.mkdir(parents=True, exist_ok=True)

    seen_entities: set[str] = set()
    created: list[str] = []

    for row in show_rows:
        raw_name = row.get("name", "")
        db = row.get("database_name", database)
        sch = row.get("schema_name", schema)
        scheduling_state = row.get("scheduling_state", "")

        full_spec = spec_map.get(raw_name)
        if not isinstance(full_spec, dict) or not full_spec:
            raise ValueError(
                f"DESCRIBE … TYPE = SPECIFICATION returned no spec for OFT "
                f"'{raw_name}'. Cannot export without authoritative specification."
            )

        fallback_name, fallback_version = _parse_oft_name(raw_name)
        fv_doc = _build_full_fidelity_fv(
            full_spec,
            fallback_name=fallback_name,
            fallback_version=fallback_version,
            fallback_database=db,
            fallback_schema=sch,
            scheduling_state=scheduling_state,
        )
        entity_cols = _entity_cols_from_full_spec(full_spec)
        file_stem = str(fv_doc.get("name") or fallback_name)

        # Extract UDF source into a sibling ``.py`` file before serializing the
        # YAML, so the YAML carries a ``file:`` reference instead of inlining
        # the source.  This mirrors the authoring format (``UDF.file`` in
        # ``spec_models.py``) and is reversed by ``compiler.inline_udf_source``
        # when the YAML is later loaded for ``snow feature apply``.
        udf_py_path = _extract_udf_to_py_file(fv_doc, fv_dir, file_stem)

        fv_path = fv_dir / f"{file_stem}.yaml"
        fv_path.write_text(yaml.dump(_ordered_fv_doc(fv_doc), default_flow_style=False, sort_keys=False))
        created.append(str(fv_path))
        if udf_py_path is not None:
            created.append(udf_py_path)

        for col_name in entity_cols:
            if col_name in seen_entities:
                continue
            seen_entities.add(col_name)
            entity_spec: dict[str, Any] = {
                "kind": "Entity",
                "name": col_name,
                "join_keys": [{"name": col_name, "type": "StringType"}],
            }
            entity_path = entities_dir / f"{col_name}.yaml"
            entity_path.write_text(yaml.dump(entity_spec, default_flow_style=False))
            created.append(str(entity_path))

    return {"status": "exported", "directory": str(base), "files": created}
