"""Export spec reconstruction for the declarative feature store library.

Reconstructs YAML spec files from pre-fetched SHOW/DESCRIBE results.
No Snowflake connection access — accepts data that the caller has already
fetched and converted to plain dicts.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from snowflake.ml.feature_store.decl.state import _parse_oft_name

logger = logging.getLogger(__name__)


def export_specs(
    show_rows: list[dict[str, Any]],
    describe_rows_by_oft: dict[str, list[dict[str, Any]]],
    output_dir: str,
    database: str,
    schema: str,
) -> dict[str, Any]:
    """Reconstruct YAML specs from raw SHOW/DESCRIBE results and write to disk.

    Parses each row from ``SHOW ONLINE FEATURE TABLES``, looks up the
    corresponding ``DESCRIBE`` rows to determine the column schema and
    primary key columns, then writes one ``StreamingFeatureView`` YAML file
    per feature view and one ``Entity`` YAML file per unique primary-key
    column (deduplicated across all feature views).

    Note:
        Exported specs are *partial*. UDFs, source definitions, feature
        aggregations, and window configurations are not recoverable from
        Snowflake and must be added manually from original source files.

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES`` (list of dicts).
        describe_rows_by_oft: Map of OFT name → ``DESCRIBE`` rows (list of
            dicts). Keys must match the ``name`` field in *show_rows*.
        output_dir: Base output directory. A ``<database>.<schema>``
            subdirectory is created inside it.
        database: Connection database name, used as the directory prefix and
            embedded in feature view specs.
        schema: Connection schema name, used as the directory prefix and
            embedded in feature view specs.

    Returns:
        Dict with keys:

        - ``status``: ``"exported"``
        - ``directory``: Absolute path to the ``<database>.<schema>`` base dir,
          or ``""`` if *show_rows* was empty.
        - ``files``: List of absolute paths to the written YAML files.
    """
    if not show_rows:
        return {"status": "exported", "directory": "", "files": []}

    base = Path(output_dir) / f"{database}.{schema}"
    entities_dir = base / "entities"
    fv_dir = base / "feature_views"
    for d in (entities_dir, fv_dir):
        d.mkdir(parents=True, exist_ok=True)

    seen_entities: set[str] = set()
    created: list[str] = []

    for row in show_rows:
        raw_name = row.get("name", "")
        db = row.get("database_name", database)
        sch = row.get("schema_name", schema)
        scheduling_state = row.get("scheduling_state", "")

        fv_name, version = _parse_oft_name(raw_name)

        desc_rows = describe_rows_by_oft.get(raw_name, [])
        columns: list[dict[str, str]] = []
        entity_cols: list[str] = []

        for dr in desc_rows:
            col_name = dr.get("name", "")
            col_type = dr.get("type", "VARCHAR")

            is_pk = False
            for pk_key in ("primary key", "primary_key", "PRIMARY KEY", "PRIMARY_KEY"):
                if dr.get(pk_key, "") == "Y":
                    is_pk = True
                    break
            # Positional fallback: 5th value in the row (index 4) == "Y"
            if not is_pk:
                raw_vals = list(dr.values())
                if len(raw_vals) >= 5 and raw_vals[4] == "Y":
                    is_pk = True

            columns.append({"name": col_name, "type": col_type})
            if is_pk:
                entity_cols.append(col_name)

        fv_spec: dict[str, Any] = {
            "kind": "StreamingFeatureView",
            "name": fv_name,
            "version": version,
            "database": db,
            "schema": sch,
            "scheduling_state": scheduling_state,
            "online": True,
            "ordered_entity_column_names": entity_cols,
            "columns": columns,
            "_note": (
                "Partial export — UDFs, sources, feature aggregations, and "
                "window configurations are not recoverable from Snowflake. "
                "Add these manually from original source files."
            ),
        }
        fv_path = fv_dir / f"{fv_name}.yaml"
        fv_path.write_text(yaml.dump(fv_spec, default_flow_style=False))
        created.append(str(fv_path))

        for col_name in entity_cols:
            if col_name not in seen_entities:
                seen_entities.add(col_name)
                entity_spec: dict[str, Any] = {
                    "kind": "Entity",
                    "name": col_name,
                    "join_keys": [{"name": col_name, "type": "StringType"}],
                }
                entity_path = entities_dir / f"{col_name}.yaml"
                entity_path.write_text(yaml.dump(entity_spec, default_flow_style=False))
                created.append(str(entity_path))

    return {"status": "exported", "directory": str(base), "files": created}
