"""Export spec reconstruction for the declarative feature store library.

Reconstructs YAML spec files from pre-fetched SHOW results plus the full
original spec JSON returned by ``DESCRIBE ONLINE FEATURE TABLE <name>
TYPE = SPECIFICATION``.  No Snowflake connection access — accepts data
that the caller has already fetched and converted to plain dicts.

Export is strict: every OFT row in *show_rows* must have a corresponding
non-empty entry in *specification_map*.  Missing entries abort the export
with a :class:`ValueError`.

Entity emission is driven by *entity_rows* — the legacy ``SHOW TAGS``-shape
rows returned by :func:`decl_api.fetch_entity_rows` (which delegates to
``FeatureStore.list_entities()``).  This is the only way orphan entities
(registered tags not referenced by any FV) make it into the exported
YAML.  Passing ``entity_rows=None`` or ``entity_rows=[]`` means "no
entities registered" — no entity YAMLs are written and the
``FV.entities`` subset check is skipped (callers that want
authoritative entity emission must forward the output of
:func:`decl_api.fetch_entity_rows`).

When *entity_rows* is non-empty, an OFT whose entity column has no
matching registered entity tag is a stale artifact (typically an
imperative-API registration predating the 2026-07-31 join-key
immutability decision).  Such an OFT is a real deployed object whose
FV definition (sources, features, schema) is fully recoverable, so it
is exported with a WARNING surfaced in the returned ``warnings`` list
— NOT skipped.  Skipping its YAML would leave the planner seeing the
deployed FV with no local spec and emitting a spurious ``DROP_FV`` on
every re-plan; exporting it means an unmodified ``init`` -> ``plan``
cycle reports ``NO_CHANGE`` (the validator's content-hash idempotency
check short-circuits before the ``MISSING_ENTITY`` dependency check
for an unchanged FV).  A *modified* orphaned FV would still fail to
re-apply because its entity is not registered — hence the warning.
"""

from __future__ import annotations

import ast
import copy
import json
import logging
import re
from pathlib import Path
from typing import Any, Optional

import yaml

from snowflake.ml.feature_store.decl.state import (
    _ENTITY_TAG_PREFIX,
    _parse_oft_name,
    orphaned_oft_warnings,
)

logger = logging.getLogger(__name__)


# Spec constructors emitted by ``python_codegen.spec_dict_to_python_source`` as
# the module-level ``NAME = <Constructor>(...)`` assignment.  Their presence is
# the deterministic signal that a ``.py`` file is exporter-generated (and thus
# safe to overwrite on re-export); a UDF body — referenced via a sibling YAML's
# ``udf.file:`` — carries only ``def`` blocks and never such an assignment.
_SPEC_CONSTRUCTORS = frozenset(
    {
        "Entity",
        "BatchSource",
        "StreamingSource",
        "BatchFeatureView",
        "StreamingFeatureView",
        "RealtimeFeatureView",
        "FeatureGroup",
    }
)


def _py_is_exported_spec_module(text: str) -> bool:
    """Return True when *text* looks like an exporter-generated spec stub.

    A Python-form export file always contains a module-level assignment
    ``NAME = <Constructor>(...)`` where ``<Constructor>`` is one of the
    decl spec classes in :data:`_SPEC_CONSTRUCTORS`.  A UDF companion
    body (the ``udf.file:`` sidecar) contains only ``def`` blocks and no
    such assignment, so it classifies as *not* a spec module and is
    protected from being clobbered on re-export.

    Args:
        text: The current on-disk contents of a ``.py`` file.

    Returns:
        ``True`` if the source parses and defines a top-level spec-class
        assignment; ``False`` for a UDF body, arbitrary user content, or
        unparsable source.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return False
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            func = node.value.func
            name = func.id if isinstance(func, ast.Name) else getattr(func, "attr", None)
            if name in _SPEC_CONSTRUCTORS:
                return True
    return False


def _guarded_write_py(path: Path, content: str, warnings: list[str]) -> bool:
    """Write a Python-form spec file unless it would clobber non-spec content.

    ``snow feature init`` (python form) derives an FV file name from the
    object name, which collides with a UDF body named after the same FV
    (e.g. ``USER_CLICK_BACKFILL_DECL.py`` referenced by the sibling
    YAML's ``udf.file:``).  A blind write would replace the UDF function
    with the FV stub and break the next apply.  When the destination
    already exists and is not an exporter-generated spec module, the file
    is left untouched and a warning is recorded instead.

    Args:
        path: Destination ``.py`` path.
        content: Python-form source to write.
        warnings: Mutable list the skip warning is appended to.

    Returns:
        ``True`` if the file was written; ``False`` if the existing
        on-disk file was preserved (skipped).
    """
    if path.exists() and not _py_is_exported_spec_module(path.read_text()):
        warnings.append(
            f"Skipped exporting to '{path}': the file already exists and does not "
            "appear to be an exported spec module (e.g. a UDF function body); "
            "the on-disk file was left unchanged."
        )
        return False
    path.write_text(content)
    return True


# YAML keys that should appear at the top of a feature view document, in this
# order, when present.  Any keys not listed here are appended after these.
#
# Order policy: identity → routing → schema → semantics → advanced runtime
# knobs → operational metadata.  The "advanced runtime knobs" cluster
# (``warehouse`` / ``cluster_by`` / ``refresh_mode`` / ``initialize`` /
# ``storage_config`` / ``aggregation_secondary_keys``) is a stable
# placement contract; each per-field TDD phase fills the corresponding
# slot in ``_build_full_fidelity_fv`` without re-ordering this tuple.
_FV_TOP_LEVEL_ORDER: tuple[str, ...] = (
    "kind",
    "name",
    "version",
    "database",
    "schema",
    "online",
    # ``description`` is an operational knob (stripped from the structural
    # hash via ``invariants._OPERATIONAL_FV_KEYS``) but must round-trip so a
    # deployed FV's comment does not surface as a spurious ``UPDATE_FV`` on
    # every ``snow feature init`` + ``snow feature plan``.  Re-emitted from the
    # recovered top-level ``desc`` in ``_build_full_fidelity_fv``.
    "description",
    # Authoring-side keys (match the imperative FeatureView constructor).
    # The exporter translates the wire-form ``ordered_entity_column_names``
    # / ``timestamp_field`` keys recovered from DESCRIBE into these
    # authoring names in ``_build_full_fidelity_fv``.
    "entities",
    "timestamp_col",
    "feature_granularity_sec",
    "feature_aggregation_method",
    # ``refresh_freq`` is the authoring-form Dynamic Table refresh
    # cadence — it sits next to the tile-aggregation knobs because they
    # always co-author together for tiled feature views.  Same name on
    # both sides: the imperative ``FeatureView(refresh_freq=...)``
    # constructor kwarg and the declarative authoring key match.
    "refresh_freq",
    # ``target_lag`` is the authoring-form OFT staleness — online-only
    # by validator contract; rare in practice (most online BFVs accept
    # the imperative default ``"10 seconds"``) but exported when present.
    "target_lag",
    "sources",
    "features",
    "udf",
    # Advanced BFV authoring knobs (one slot per Phase 1–6 field, in plan
    # order).  Slots are reserved up front so a recovered FV YAML keeps
    # the same stable layout across phases — implementations only fill
    # values, never re-order the schema.
    "warehouse",
    "cluster_by",
    "refresh_mode",
    "initialize",
    "storage_config",
    "aggregation_secondary_keys",
    "append_only",
    # ``backfill`` is operational metadata authored by the user — it never
    # appears in DESCRIBE … TYPE = SPECIFICATION output, so the exporter
    # cannot emit it from a recovered spec.  Listed here so any future code
    # path (or test) that hand-attaches a backfill block to the export dict
    # ends up with a stable, last-position placement under the FV doc.
    "backfill",
)


def _ordered_fv_doc(fv_spec: dict[str, Any]) -> dict[str, Any]:
    """Return *fv_spec* re-ordered with well-known keys first.

    Python ``dict`` preserves insertion order, and PyYAML respects it when
    serializing — so this gives the emitted YAML a predictable layout while
    leaving any unknown keys to trail at the end.

    Args:
        fv_spec: Feature view dict to re-order.

    Returns:
        New dict with the same keys, ordered with well-known keys first.
    """
    ordered: dict[str, Any] = {}
    for key in _FV_TOP_LEVEL_ORDER:
        if key in fv_spec:
            ordered[key] = fv_spec[key]
    for key, value in fv_spec.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


# FV kinds whose deployed SPECIFICATION carries content that snowml-core
# derived from ``aggregation_secondary_keys`` rather than from anything the
# operator authored.  RealtimeFeatureView has no aggregation surface and so
# never picks up the derivations.  Matches the kinds
# :func:`invariants._strip_secondary_key_derivations` is invoked for.
_SK_DERIVING_FV_KINDS: frozenset[str] = frozenset({"BatchFeatureView", "StreamingFeatureView"})


def _secondary_key_columns(inner: dict[str, Any]) -> set[str]:
    """Return the upper-cased secondary-key columns declared by an inner spec.

    Args:
        inner: The ``spec`` sub-dict of a ``DESCRIBE ... TYPE =
            SPECIFICATION`` document.  The wire form surfaces the keys as
            ``ordered_secondary_key_column_names``; a payload that already
            went through state recovery may carry the authoring-form
            ``aggregation_secondary_keys`` instead.

    Returns:
        Upper-cased secondary-key column names; empty when the spec
        declares none.
    """
    raw = inner.get("aggregation_secondary_keys") or inner.get("ordered_secondary_key_column_names")
    if not isinstance(raw, list):
        return set()
    return {str(col).upper() for col in raw if col}


def _authoring_features(features: list[Any], sk_columns: set[str]) -> list[Any]:
    """Return *features* with core's synthesised SK-array entries removed.

    When a feature view declares ``aggregation_secondary_keys``, snowml-core's
    spec builders add one synthesised SK-array feature per distinct window
    (``<SK>_KEYS_<window>S``: sourced from the SK column, ``ArrayType``
    output, no aggregation ``function``).  It is a pure derivation from the SK
    — the same one :func:`invariants._strip_secondary_key_derivations` drops
    before hashing and :func:`imperative_executor._emulate_quake_postprocess`
    drops when emulating the server transform client-side.

    Re-emitting it into the exported YAML produces a spec the operator cannot
    re-apply: the entry looks like an aggregation (it carries ``window_sec``)
    but has no ``function``, so ``snow feature plan`` rejects the freshly
    exported tree with ``FEATURE_INCOMPLETE``.  Core re-synthesises the entry
    from ``aggregation_secondary_keys`` on the next apply, so dropping it here
    loses nothing.

    The ``ArrayType`` wrapper core puts on the *real* aggregation outputs is
    deliberately left alone: an array output column can equally be operator-
    authored (``last_n`` / ``last_distinct_n``), its ``element_type`` is
    hash-significant in its own right, and the SK-gated hash normalisation
    already reconciles the two sides.

    Args:
        features: The ``features`` list from the deployed inner spec.  Never
            mutated — entries are deep-copied so the caller's
            ``specification_map`` (which doubles as the applied-state payload)
            is left untouched.
        sk_columns: Upper-cased secondary-key columns from
            :func:`_secondary_key_columns`.  Empty means nothing is dropped.

    Returns:
        A new list holding the authoring-shape features.
    """
    authored: list[Any] = []
    for entry in features:
        if not isinstance(entry, dict):
            authored.append(entry)
            continue
        if sk_columns and not entry.get("function"):
            source_column = entry.get("source_column")
            source_name = str(source_column.get("name") or "").upper() if isinstance(source_column, dict) else ""
            if source_name in sk_columns:
                continue
        authored.append(copy.deepcopy(entry))
    return authored


def _build_full_fidelity_fv(
    full_spec: dict[str, Any],
    *,
    fallback_name: str,
    fallback_version: str,
    fallback_database: str,
    fallback_schema: str,
) -> dict[str, Any]:
    """Build a YAML-ready feature view dict from a parsed spec JSON document.

    Args:
        full_spec: The spec JSON returned by ``DESCRIBE ... TYPE = SPECIFICATION``.
            Expected shape: ``{kind, metadata, offline_configs, spec, ...}``.
        fallback_name: Name to use if ``metadata.name`` is absent.
        fallback_version: Version to use if ``metadata.version`` is absent.
        fallback_database: Database to use if ``metadata.database`` is absent.
        fallback_schema: Schema to use if ``metadata.schema`` is absent.

    Returns:
        Dict ready to be passed through :func:`_ordered_fv_doc` and serialized.
    """
    kind = full_spec.get("kind", "StreamingFeatureView")
    metadata = full_spec.get("metadata", {}) if isinstance(full_spec.get("metadata"), dict) else {}
    inner = full_spec.get("spec", {}) if isinstance(full_spec.get("spec"), dict) else {}

    # Secondary keys drive core-side derivations that must be undone to
    # recover the authoring shape (see :func:`_authoring_features` and the
    # entity-list strip below).  The SK identity itself survives on the
    # ``aggregation_secondary_keys`` key emitted further down.
    sk_columns = _secondary_key_columns(inner) if kind in _SK_DERIVING_FV_KINDS else set()

    fv_doc: dict[str, Any] = {
        "kind": kind,
        "name": metadata.get("name", fallback_name),
        "version": metadata.get("version", fallback_version),
        "database": metadata.get("database", fallback_database),
        "schema": metadata.get("schema", fallback_schema),
    }

    # ``StreamingFeatureView`` and ``RealtimeFeatureView`` are always
    # online by design — the implicit-online contract on
    # ``spec_models.FeatureView`` defaults ``online=True`` and rejects
    # an explicit ``online=False`` for those kinds — so emitting the
    # field here would be redundant noise in the exported YAML.
    # ``BatchFeatureView`` keeps the field first-class because batch
    # FVs can legitimately be offline-only; infer ``online: true |
    # false`` from whether the recovered SPECIFICATION carries an
    # ``online_store_type`` (stripped from hashes but present on
    # DESCRIBE).
    if kind == "BatchFeatureView":
        fv_doc["online"] = bool(full_spec.get("online_store_type"))

    # ``description`` (operational) is recovered onto the top level of the
    # applied ``spec_payload`` as ``desc`` (from ``list_feature_views().desc``
    # / the deployed DT COMMENT) by ``state._inject_fv_desc_from_list_row``.
    # Re-emit it in the authoring-shape key so ``compile_to_spec`` produces the
    # same value ``planner._resolve_applied_desc`` reads on the applied side —
    # otherwise a described FV drifts to ``UPDATE_FV`` on every clean re-plan.
    # Empty / absent descriptions stay off the doc (a plain FV never gains a
    # spurious ``description: ''``).
    desc_val = full_spec.get("desc")
    if isinstance(desc_val, str) and desc_val.strip():
        fv_doc["description"] = desc_val.strip()

    # Translate the wire-form keys recovered from DESCRIBE ... TYPE =
    # SPECIFICATION into the authoring keys the Pydantic models accept.
    # ``snow feature plan`` re-validates this YAML through the renamed
    # FeatureView model, so emitting the legacy keys would surface the
    # migration error in ``spec_models.FeatureView._reject_legacy_authoring_keys``
    # for every exported FV — defeating the round-trip.
    # Core appends the SK to the deployed entity list; the operator authored it
    # only under ``aggregation_secondary_keys``.  Re-emitting it as an entity
    # would make the next apply register the SK as a second join key.
    if "ordered_entity_column_names" in inner:
        fv_doc["entities"] = [col for col in inner["ordered_entity_column_names"] if str(col).upper() not in sk_columns]

    if "timestamp_field" in inner and inner["timestamp_field"] is not None:
        fv_doc["timestamp_col"] = inner["timestamp_field"]
    if "feature_granularity_sec" in inner and inner["feature_granularity_sec"] is not None:
        fv_doc["feature_granularity_sec"] = inner["feature_granularity_sec"]
    if "feature_aggregation_method" in inner and inner["feature_aggregation_method"] is not None:
        fv_doc["feature_aggregation_method"] = inner["feature_aggregation_method"]
    # ``refresh_freq`` (authoring-form DT refresh) is the canonical
    # YAML-side surface for the offline Dynamic Table cadence — same
    # name as the imperative ``FeatureView(refresh_freq=...)``
    # constructor kwarg.  Prefer the explicit ``refresh_freq`` value on
    # the applied inner spec (``state._inject_fv_refresh_freq_from_list_row``
    # populates it from the deployed DT's ``REFRESH_FREQ``) and fall
    # back to deriving ``"<n> seconds"`` from the wire-form
    # ``target_lag_sec`` when only that key is present.  A **tiled**
    # streaming FV also emits ``refresh_freq`` — it schedules an offline
    # tile Dynamic Table whose ``REFRESH_FREQ`` state recovery plumbs onto
    # ``spec.refresh_freq`` — but ONLY from the recovered ``refresh_freq``
    # key, never derived from ``target_lag_sec`` (the OFT ingest lag the
    # runtime stamps to ``0``).  Non-tiled streaming and realtime kinds
    # are excluded entirely: they have no offline DT and the spec
    # validator ``FeatureView._reject_refresh_freq_on_stream_or_realtime``
    # rejects authoring ``refresh_freq`` there, so emitting it would break
    # the ``snow feature init`` -> ``snow feature plan`` round-trip.  The
    # wire-form ``target_lag_sec`` is never emitted at the top level —
    # ``refresh_freq`` is the single authoring surface for the DT refresh
    # cadence after the ``feature_granularity`` / ``refresh_freq`` /
    # ``target_lag`` decoupling.
    _inner_features = inner.get("features") or []
    _inner_is_tiled = any(
        isinstance(f, dict) and (f.get("window_sec") is not None or f.get("window") is not None)
        for f in _inner_features
    )
    if kind == "BatchFeatureView":
        rf = inner.get("refresh_freq")
        if isinstance(rf, str) and rf:
            fv_doc["refresh_freq"] = rf
        elif "target_lag_sec" in inner and inner["target_lag_sec"] is not None:
            fv_doc["refresh_freq"] = f"{int(inner['target_lag_sec'])} seconds"
    elif kind == "StreamingFeatureView" and _inner_is_tiled:
        rf = inner.get("refresh_freq")
        if isinstance(rf, str) and rf:
            fv_doc["refresh_freq"] = rf

    sources = inner.get("sources")
    if isinstance(sources, list):
        fv_doc["sources"] = [dict(s) if isinstance(s, dict) else s for s in sources]

    features = inner.get("features")
    if isinstance(features, list):
        fv_doc["features"] = _authoring_features(features, sk_columns)

    udf = inner.get("udf")
    if isinstance(udf, dict) and udf:
        # The live SPECIFICATION JSON already uses the authoring-shape
        # keys ``name`` / ``engine``; only ``function_definition`` needs to
        # become the authoring alias ``source`` for the YAML to round-trip
        # cleanly through :func:`spec_compiler._compile_udf`.  Note: the
        # source body is later extracted to a sibling ``.py`` file by
        # :func:`_extract_udf_to_py_file`, so the YAML actually carries
        # ``udf.file`` rather than an inline ``udf.source``.
        fv_doc["udf"] = dict(udf)

    # Advanced BFV authoring knobs recovered into ``inner.*`` by
    # ``state._inject_advanced_bfv_fields_from_dt_text``.  Each is copied
    # through verbatim into the YAML doc so ``snow feature init`` against
    # a deployed BFV produces a re-applicable spec.  Phase 2 wires
    # ``cluster_by``; later phases will add ``refresh_mode`` /
    # ``initialize`` / ``storage_config`` / ``aggregation_secondary_keys``
    # at this same block.
    cluster_by = inner.get("cluster_by")
    if isinstance(cluster_by, list) and cluster_by:
        fv_doc["cluster_by"] = list(cluster_by)

    refresh_mode = inner.get("refresh_mode")
    if isinstance(refresh_mode, str) and refresh_mode:
        # ``AUTO`` is Snowflake's runtime default (stamped by DESCRIBE …
        # TYPE = SPECIFICATION when no mode was pinned) — semantically
        # equivalent to an unset field.  The spec models reject it, so
        # omit it here rather than emit a YAML the next plan cannot load.
        rm = refresh_mode.upper()
        if rm != "AUTO":
            fv_doc["refresh_mode"] = rm

    initialize = inner.get("initialize")
    if isinstance(initialize, str) and initialize:
        fv_doc["initialize"] = initialize.upper()

    storage_config = inner.get("storage_config")
    if isinstance(storage_config, dict) and storage_config:
        fv_doc["storage_config"] = {k: v for k, v in storage_config.items() if v is not None}

    # The applied wire spec surfaces secondary keys under
    # ``ordered_secondary_key_column_names``; fall back to it so a
    # StreamingFeatureView export declares the authoring-form
    # ``aggregation_secondary_keys`` (otherwise the field is silently dropped
    # and the re-plan lands as a spurious ``RECREATE_FV``).
    secondary_keys = inner.get("aggregation_secondary_keys") or inner.get("ordered_secondary_key_column_names")
    if isinstance(secondary_keys, list) and secondary_keys:
        fv_doc["aggregation_secondary_keys"] = list(secondary_keys)

    # ``append_only`` is emitted only when the recovered inner spec carries the
    # truthy flag (the injector / hash-normaliser strip the default ``False``),
    # so a plain BFV never gains a spurious ``append_only: false`` in its YAML.
    if inner.get("append_only"):
        fv_doc["append_only"] = True

    # ``backfill:`` block re-emission (Plan B8 — closes LIMITATIONS L2
    # export half).  Phase A's metadata-roundtrip extensions persist the
    # operator's authored streaming-backfill table
    # (:attr:`StreamingMetadata.backfill_table` from A3) and carry the
    # existing ``backfill_start_time`` (already in ``STREAM_CONFIG``)
    # into the recovered ``spec_payload``.  Surface them back into the
    # YAML so ``snow feature init`` produces a re-applicable spec.
    #
    # ``initialize`` is intentionally NOT folded into the backfill block:
    # it has been promoted to a first-class top-level FV field
    # (:class:`FeatureView.initialize` per ``spec_models.py`` Phase 4)
    # and is already emitted above as ``fv_doc["initialize"]``.  Per the
    # plan note that field is "already in DT tag metadata" — listed
    # alongside the new backfill keys for completeness, not because it
    # needs to be re-folded.
    #
    # ``backfill.overwrite`` is intentionally NOT re-emitted.  This is
    # the authoring-only contract pinned by Plan B8 / LIMITATIONS L2:
    # round-tripping the operational one-shot flag would silently force
    # re-overwrites on every ``snow feature plan``.  A3 deliberately
    # does NOT persist it; the exporter's matching contract is to
    # never surface it even if some upstream payload happens to carry
    # the key.
    backfill_block: dict[str, Any] = {}
    backfill_table = inner.get("backfill_table")
    if isinstance(backfill_table, str) and backfill_table:
        backfill_block["table"] = backfill_table
    backfill_start_time = inner.get("backfill_start_time")
    if isinstance(backfill_start_time, str) and backfill_start_time:
        backfill_block["start_time"] = backfill_start_time
    if backfill_block:
        fv_doc["backfill"] = backfill_block

    return fv_doc


# ``file_stem`` comes from attacker-influenceable metadata; restrict it to a
# strict allowlist so a crafted name cannot escape the export dir (CWE-22).
_SAFE_FILE_STEM_RE = re.compile(r"[A-Za-z0-9_\-]+")


def _safe_sidecar_path(base_dir: Path, file_stem: str, suffix: str) -> Path:
    """Build a sidecar path under *base_dir*, rejecting path traversal.

    Args:
        base_dir: Directory the sidecar must be written inside.
        file_stem: Bare filename stem derived from object metadata.
        suffix: File extension including the dot (e.g. ``".py"``).

    Returns:
        The resolved absolute path to the sidecar file.

    Raises:
        ValueError: If *file_stem* is not allowlist-clean or the resolved
            path escapes *base_dir*.
    """
    if not isinstance(file_stem, str) or not _SAFE_FILE_STEM_RE.fullmatch(file_stem):
        raise ValueError(f"unsafe sidecar file stem {file_stem!r}: only [A-Za-z0-9_-] permitted")
    resolved_base = base_dir.resolve()
    candidate = (resolved_base / f"{file_stem}{suffix}").resolve()
    if candidate.parent != resolved_base:
        raise ValueError(f"sidecar path {candidate} escapes export directory {resolved_base}")
    return candidate


def _extract_udf_to_py_file(
    fv_doc: dict[str, Any],
    fv_dir: Path,
    file_stem: str,
) -> Optional[str]:
    """Externalize ``fv_doc['udf']['function_definition']`` to a sibling ``.py`` file.

    Mutates *fv_doc* in place: when a non-empty ``function_definition`` string
    is present, it is removed from the ``udf`` block and replaced with a
    ``file`` key holding the bare filename (relative to *fv_dir*).  The source
    is written to ``<fv_dir>/<file_stem>.py``.  When ``function_definition``
    is missing, empty, or non-string, no file is written and the ``udf`` block
    is left untouched.

    The bare-filename convention matches what
    :func:`compiler.inline_udf_source` resolves (it joins ``udf.file`` with
    the spec file's directory) — so the exported YAML round-trips through
    ``snow feature apply`` without manual edits.

    Args:
        fv_doc: Feature view dict being assembled for YAML serialization.
        fv_dir: Directory in which the FV YAML will be written.
        file_stem: Base filename (typically the FV name) used for the ``.py``
            sidecar.

    Returns:
        Absolute path to the written ``.py`` file as a string, or ``None`` if
        no extraction occurred.
    """
    udf = fv_doc.get("udf")
    if not isinstance(udf, dict):
        return None
    source = udf.get("function_definition")
    if not isinstance(source, str) or not source:
        return None

    udf_path = _safe_sidecar_path(fv_dir, file_stem, ".py")
    udf_path.write_text(source)
    udf.pop("function_definition", None)
    udf["file"] = udf_path.name
    return str(udf_path)


def _extract_query_to_sql_file(
    ds_doc: dict[str, Any],
    ds_dir: Path,
    file_stem: str,
) -> Optional[str]:
    """Externalize ``ds_doc['query']`` to a sibling ``.sql`` file.

    Mirrors :func:`_extract_udf_to_py_file` for the BatchSource ``query`` /
    ``query_file`` sidecar pair.  Mutates *ds_doc* in place: when a
    non-empty ``query`` string is present it is removed from the
    datasource doc and replaced with a ``query_file`` key holding the
    bare filename (relative to *ds_dir*).  The SQL body is written to
    ``<ds_dir>/<file_stem>.sql``.

    No length threshold — every recovered query goes to a sidecar so
    the YAML stays thin and the on-disk shape matches what
    ``snow feature init`` scaffolds (Plan §7 OS2 default).  Empty,
    missing, or non-string ``query`` values are no-ops; ``query_file``
    is left untouched in those cases (the helper is idempotent against
    a doc that already carries ``query_file``).

    The bare-filename convention matches what
    :func:`compiler.inline_query_source` resolves on load (it joins
    ``query_file`` with the spec file's directory) — so the exported
    YAML round-trips through ``snow feature apply`` without manual
    edits.

    Args:
        ds_doc: BatchSource datasource dict being assembled for YAML
            serialization.
        ds_dir: Directory in which the datasource YAML will be written
            (the ``.sql`` sidecar lands beside it).
        file_stem: Base filename (typically the source name) used for
            the ``.sql`` sidecar.

    Returns:
        Absolute path to the written ``.sql`` file as a string, or
        ``None`` if no extraction occurred.
    """
    query = ds_doc.get("query")
    if not isinstance(query, str) or not query:
        return None

    sql_path = _safe_sidecar_path(ds_dir, file_stem, ".sql")
    sql_path.write_text(query)
    ds_doc.pop("query", None)
    ds_doc["query_file"] = sql_path.name
    return str(sql_path)


# Mapping from SPECIFICATION JSON ``source_type`` (as emitted by Snowflake)
# to the authoring-format top-level ``kind`` for the datasource YAML.  The
# ``Request`` and ``Features`` source kinds are intentionally excluded —
# they describe synthetic realtime-FV inputs that have no external system
# to materialize as a top-level datasource.
# ``Batch`` is the canonical ``source_type`` value emitted by the
# imperative side (:data:`snowflake.ml.feature_store.spec.enums.SourceType.BATCH`)
# and by the consolidated decl serializer.  ``BatchSource`` is the
# pre-consolidation decl-side value retained for plan-file backward
# compatibility, and ``OfflineTable`` is a Go-backend value carried over
# from earlier spec emissions.  The ``SQLDataSource`` entry was removed
# during the decl/spec enum consolidation.
_SOURCE_TYPE_TO_KIND: dict[str, str] = {
    "Stream": "StreamingSource",
    "Batch": "BatchSource",
    "BatchSource": "BatchSource",
    "OfflineTable": "BatchSource",
}

_REALTIME_SYNTHETIC_SOURCE_TYPES: frozenset[str] = frozenset({"Request", "Features"})

_DS_TOP_LEVEL_ORDER: tuple[str, ...] = (
    "kind",
    "name",
    "version",
    "type",
    "source_database",
    "source_schema",
    "table",
    "query",
    "query_file",
    "columns",
)

# Fields copied verbatim from the FV inline source dict to the emitted
# datasource YAML, when present on the source.  ``type`` is only honoured for
# StreamingSource (see :func:`_collect_datasources`); for non-streaming kinds
# any stray ``type`` key on the FV source dict is ignored.
_DS_PASSTHROUGH_FIELDS: tuple[str, ...] = (
    "source_database",
    "source_schema",
    "table",
    "query",
    "version",
)


def _ordered_ds_doc(ds_spec: dict[str, Any]) -> dict[str, Any]:
    """Return *ds_spec* re-keyed in the canonical authoring order.

    Mirrors :func:`_ordered_fv_doc`: well-known keys come first in a fixed
    order; any unknown keys retain their insertion order at the end.

    Args:
        ds_spec: Datasource dict to re-order.

    Returns:
        New dict with the same keys, ordered with well-known keys first.
    """
    ordered: dict[str, Any] = {}
    for key in _DS_TOP_LEVEL_ORDER:
        if key in ds_spec:
            ordered[key] = ds_spec[key]
    for key, value in ds_spec.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def _collect_datasources(
    specification_map: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Build datasource dicts from the union of every FV's ``spec.sources[]``.

    Groups by lowercase source name (so case differences across FVs collapse
    to one entry) and merges columns into a superset (deduped by lowercase
    column name).  The first occurrence's case is preserved for the emitted
    name and column names; the returned dict is keyed by that case-preserved
    emit name so callers can use it directly as the YAML filename.

    Strict-fail on conflict: if two FVs reference the same source with the
    same column but disagree on its ``type``, raises :class:`ValueError`
    naming the datasource, the column, and both contributing FVs.  The same
    rule applies to top-level passthrough fields (``source_database``,
    ``source_schema``, ``table``, ``query``, ``version``) and to the
    StreamingSource ``type`` field — any disagreement is a hard error.

    Realtime synthetic source types (``Request``, ``Features``) are silently
    skipped — they have no external system to materialize as a top-level
    datasource.  Any other unrecognised ``source_type`` value raises
    :class:`ValueError` naming the offending value.

    Args:
        specification_map: Map of OFT name → parsed spec JSON, as returned by
            ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE = SPECIFICATION``.

    Returns:
        Dict keyed by case-preserved emit name → datasource spec dict, each
        ready for :func:`_ordered_ds_doc` and YAML serialization.

    Raises:
        ValueError: On any conflict between two FVs (column type, passthrough
            field, or kind), or on an unrecognised ``source_type`` value.
    """
    by_name: dict[str, dict[str, Any]] = {}
    name_case: dict[str, str] = {}
    col_index: dict[str, dict[str, tuple[str, Optional[str], str]]] = {}
    meta_index: dict[str, dict[str, tuple[Any, str]]] = {}

    for oft_name, full_spec in specification_map.items():
        if not isinstance(full_spec, dict):
            continue
        _md = full_spec.get("metadata")
        metadata = _md if isinstance(_md, dict) else {}
        fv_name = metadata.get("name") or oft_name or "<unknown>"
        inner = full_spec.get("spec") if isinstance(full_spec.get("spec"), dict) else {}
        sources = inner.get("sources") if isinstance(inner, dict) else None
        if not isinstance(sources, list):
            continue

        for src in sources:
            if not isinstance(src, dict):
                continue
            source_type = src.get("source_type", "")
            if source_type in _REALTIME_SYNTHETIC_SOURCE_TYPES:
                continue
            kind = _SOURCE_TYPE_TO_KIND.get(source_type)
            if kind is None:
                raise ValueError(
                    f"datasource export: source '{src.get('name', '<unknown>')}' in feature view "
                    f"'{fv_name}' has unrecognised source_type '{source_type}'."
                )
            raw_name = src.get("name")
            if not raw_name:
                continue
            lower_name = str(raw_name).lower()

            if lower_name not in by_name:
                emit_name = str(raw_name)
                ds: dict[str, Any] = {"kind": kind, "name": emit_name}
                if kind == "StreamingSource":
                    ds["type"] = src.get("type") or "REST"
                for fld in _DS_PASSTHROUGH_FIELDS:
                    if src.get(fld) is not None:
                        ds[fld] = src[fld]
                ds["columns"] = []
                by_name[lower_name] = ds
                name_case[lower_name] = emit_name
                col_index[lower_name] = {}
                meta_index[lower_name] = {}
                if kind == "StreamingSource":
                    meta_index[lower_name]["type"] = (ds["type"], fv_name)
                for fld in _DS_PASSTHROUGH_FIELDS:
                    if fld in ds:
                        meta_index[lower_name][fld] = (ds[fld], fv_name)
            else:
                ds = by_name[lower_name]
                if ds["kind"] != kind:
                    prev_fv = next(iter(meta_index[lower_name].values()))[1] if meta_index[lower_name] else "<unknown>"
                    raise ValueError(
                        f"datasource export: source '{name_case[lower_name]}' has conflicting "
                        f"kinds: '{ds['kind']}' (from feature view '{prev_fv}') vs "
                        f"'{kind}' (from feature view '{fv_name}')."
                    )
                check_fields: tuple[str, ...] = _DS_PASSTHROUGH_FIELDS
                if kind == "StreamingSource":
                    check_fields = ("type",) + _DS_PASSTHROUGH_FIELDS
                for fld in check_fields:
                    src_val = src.get(fld)
                    if src_val is None:
                        continue
                    current = meta_index[lower_name]
                    if fld in current:
                        prev_val, prev_fv = current[fld]
                        if prev_val != src_val:
                            raise ValueError(
                                f"datasource export: source '{name_case[lower_name]}' field "
                                f"'{fld}' conflicts: '{prev_val}' (from feature view "
                                f"'{prev_fv}') vs '{src_val}' (from feature view '{fv_name}')."
                            )
                    else:
                        current[fld] = (src_val, fv_name)
                        ds[fld] = src_val

            cols = src.get("columns")
            if not isinstance(cols, list):
                continue
            for col in cols:
                if not isinstance(col, dict):
                    continue
                col_name = col.get("name")
                if not col_name:
                    continue
                lower_col = str(col_name).lower()
                col_type = col.get("type")
                if lower_col in col_index[lower_name]:
                    prev_col_name, prev_type, prev_fv = col_index[lower_name][lower_col]
                    if col_type != prev_type:
                        raise ValueError(
                            f"datasource export: source '{name_case[lower_name]}' column "
                            f"'{prev_col_name}' type conflicts: '{prev_type}' (from feature "
                            f"view '{prev_fv}') vs '{col_type}' (from feature view "
                            f"'{fv_name}')."
                        )
                else:
                    col_index[lower_name][lower_col] = (str(col_name), col_type, fv_name)
                    by_name[lower_name]["columns"].append(dict(col))

    return {name_case[lower_name]: ds for lower_name, ds in by_name.items()}


def _entity_cols_from_full_spec(full_spec: dict[str, Any]) -> list[str]:
    """Return the join-key column names from a full spec JSON document.

    Args:
        full_spec: Spec JSON returned by ``DESCRIBE ... TYPE = SPECIFICATION``.

    Returns:
        List of entity column names, or an empty list if absent.
    """
    inner = full_spec.get("spec", {}) if isinstance(full_spec.get("spec"), dict) else {}
    cols = inner.get("ordered_entity_column_names")
    if isinstance(cols, list):
        return [str(c) for c in cols]
    return []


def _entity_name_from_row(row: dict[str, Any]) -> Optional[str]:
    """Return the prefix-stripped entity name from a SHOW TAGS row.

    Mirrors :func:`state._build_entity_object` so the exporter and the
    applied-state parser produce identical canonical names.  Rows whose
    ``name`` does not carry the ``SNOWML_FEATURE_STORE_ENTITY_`` prefix
    are skipped (defensive — a non-entity tag should not appear in the
    list returned by :func:`decl_api.fetch_entity_rows`).

    Args:
        row: One row dict from
            :func:`decl_api.fetch_entity_rows`.

    Returns:
        The uppercase entity name, or ``None`` if the row is malformed.
    """
    raw_name = row.get("name") or row.get("NAME") or ""
    if not isinstance(raw_name, str) or not raw_name:
        return None
    if not raw_name.startswith(_ENTITY_TAG_PREFIX):
        return None
    return raw_name[len(_ENTITY_TAG_PREFIX) :].upper()


def _join_keys_from_row(row: dict[str, Any]) -> list[str]:
    """Decode the join-key list from a SHOW TAGS row's ``allowed_values``.

    Mirrors the parsing in :func:`state._build_entity_object`: prefer a
    list value verbatim, otherwise treat ``allowed_values`` as JSON, with
    a final fallback to a comma-split form for legacy SHOW TAGS output.

    Args:
        row: One row dict from
            :func:`decl_api.fetch_entity_rows`.

    Returns:
        List of join-key column names (preserving case).  Empty when
        ``allowed_values`` is absent or unparsable.
    """
    raw = row.get("allowed_values") or row.get("ALLOWED_VALUES") or row.get("allowed_values_list")
    if not raw:
        return []
    if isinstance(raw, list):
        return [str(v) for v in raw]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(v) for v in parsed]
        except (json.JSONDecodeError, TypeError):
            pass
        return [v.strip() for v in raw.strip("[]").split(",") if v.strip()]
    return []


def _entity_yaml_from_row(row: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Build a full-fidelity entity authoring dict from a SHOW TAGS row.

    The shape mirrors what :func:`state._build_entity_object` emits as
    ``spec_payload`` (minus the ``database`` / ``schema`` fields, which
    the loader fills in from the directory layout).  Per-join-key types
    are not carried by tag rows, so every join key is normalised to
    ``StringType`` — matching the applied-state path so the structural
    fingerprints align (see :func:`invariants._structural_fingerprint`).

    The ``description`` field carries the tag's ``comment`` so the
    user-authored description round-trips back into authoring YAML.

    Args:
        row: One row dict from
            :func:`decl_api.fetch_entity_rows`.

    Returns:
        Authoring-format entity dict ready for YAML serialization, or
        ``None`` if the row is missing a recognisable entity name.
    """
    entity_name = _entity_name_from_row(row)
    if not entity_name:
        return None

    join_keys = _join_keys_from_row(row)
    if not join_keys:
        # Defensive: an entity tag with no allowed_values is a degenerate
        # state, but we still want to emit a YAML so the planner sees it
        # (and produces NO_CHANGE on round-trip).  Use the entity name
        # itself as the implicit join-key column.
        join_keys = [entity_name]

    spec: dict[str, Any] = {
        "kind": "Entity",
        "name": entity_name,
        "join_keys": [{"name": jk.upper(), "type": "StringType"} for jk in join_keys],
    }
    comment = row.get("comment") or row.get("COMMENT")
    if isinstance(comment, str) and comment:
        spec["description"] = comment
    return spec


_VALID_LAYOUTS = ("db_schema", "sources")


# Canonical authoring-format key order for FeatureGroup YAML.  Mirrors
# the ``_FV_TOP_LEVEL_ORDER`` policy: identity first, then schema-shaping
# fields, then sources.  Any keys not listed here are appended in their
# natural (insertion) order so future fields land predictably without
# requiring a re-order of this tuple.
_FG_TOP_LEVEL_ORDER: tuple[str, ...] = (
    "kind",
    "name",
    "version",
    "database",
    "schema",
    "desc",
    "auto_prefix",
    "feature_views",
)


def _fg_source_to_authoring_dict(source: dict[str, Any]) -> dict[str, Any]:
    """Translate one imperative FG source row into authoring-shape dict.

    The imperative row carries ``fv_name`` / ``fv_version`` (the keys
    used by :class:`FeatureGroupMetadata.FvSourceRef` on the imperative
    side); the authoring YAML uses ``name`` / ``version`` (matching
    :class:`spec_models.FeatureViewRef`).  ``slice_columns`` is
    omitted when ``None`` or empty (matching the validator's "absent
    means no slice"); ``alias`` is preserved as an explicit key
    whenever present in the row (including ``alias=""``, which is
    distinct from "absent").

    Strict-fail on missing/empty ``fv_name`` / ``fv_version``: emitting
    a YAML with ``name: null`` / ``version: null`` (or omitted keys)
    would re-load as ``FeatureViewRef(version="")``, which the loader
    validator rejects with a less-actionable message.  Raising here
    points the operator at the upstream metadata problem in the row
    instead of the downstream loader symptom.

    Args:
        source: One element of the row's ``sources`` list.

    Returns:
        Dict in canonical authoring shape ready for YAML serialisation.

    Raises:
        ValueError: If ``fv_name`` or ``fv_version`` is missing or empty.
    """
    fv_name = source.get("fv_name") or ""
    fv_version = source.get("fv_version") or ""
    if not fv_name:
        raise ValueError(
            f"FeatureGroup source ref is missing 'fv_name' "
            f"(row: {source!r}) — refusing to emit a YAML feature_views[] "
            f"entry that would re-validate as missing-name"
        )
    if not fv_version:
        raise ValueError(
            f"FeatureGroup source ref '{fv_name}' is missing 'fv_version' "
            f"(row: {source!r}) — refusing to emit a YAML feature_views[] "
            f"entry that would re-validate as MISSING_VERSION"
        )
    out: dict[str, Any] = {
        "name": fv_name,
        "version": fv_version,
    }
    slice_cols = source.get("slice_columns")
    if slice_cols:
        out["slice_columns"] = list(slice_cols)
    if "alias" in source:
        out["alias"] = source["alias"]
    return out


def _ordered_fg_doc(doc: dict[str, Any]) -> dict[str, Any]:
    """Reorder an FG authoring dict by ``_FG_TOP_LEVEL_ORDER``.

    Args:
        doc: Authoring-format FG dict (kind/name/version/...).

    Returns:
        New dict with stable key order suitable for ``yaml.dump``.
    """
    ordered: dict[str, Any] = {}
    for key in _FG_TOP_LEVEL_ORDER:
        if key in doc:
            ordered[key] = doc[key]
    for key, val in doc.items():
        if key not in ordered:
            ordered[key] = val
    return ordered


def _build_fg_yaml_doc(row: dict[str, Any]) -> dict[str, Any]:
    """Build a canonical authoring-format FG dict from an imperative row.

    The row shape mirrors :func:`imperative_executor.fetch_feature_group_rows`
    output: ``{name, version, desc, owner, auto_prefix, sources,
    output_columns, database_name, schema_name}``.  ``output_columns``
    is intentionally NOT emitted into the YAML — it is a derived field
    on the imperative side and is excluded from the FG content hash for
    exactly the same reason; round-tripping it would create a spurious
    diff under different declarative orderings of the same FV refs.

    Strict-fail on missing/empty ``name`` / ``version``: ``yaml.dump``
    would otherwise emit ``version: null`` (or omit the key entirely),
    and the next ``snow feature plan`` would re-validate the file as
    ``MISSING_VERSION`` — a confusing downstream symptom of the real
    upstream metadata problem.  Raising here surfaces the row that's
    actually broken so the operator can fix the source instead of
    debugging the loader.  Mirrors the OFT strict-fail pattern further
    down in this module (DESCRIBE … TYPE = SPECIFICATION).

    Args:
        row: One row dict from
            :func:`imperative_executor.fetch_feature_group_rows`.

    Returns:
        Authoring-format FG dict ready for YAML serialisation.

    Raises:
        ValueError: If ``name`` or ``version`` is missing or empty.
    """
    name = row.get("name") or ""
    version = row.get("version") or ""
    if not name:
        raise ValueError(
            f"FeatureGroup export row is missing 'name' (row: {row!r}) — " f"refusing to write a YAML with no identity"
        )
    if not version:
        raise ValueError(
            f"FeatureGroup '{name}' export row is missing 'version' "
            f"(row: {row!r}) — refusing to write a YAML that would "
            f"re-validate as MISSING_VERSION on the next snow feature plan"
        )
    sources = row.get("sources") or []
    feature_views = [_fg_source_to_authoring_dict(s) for s in sources]
    doc: dict[str, Any] = {
        "kind": "FeatureGroup",
        "name": name,
        "version": version,
        "desc": row.get("desc", "") or "",
        "auto_prefix": bool(row.get("auto_prefix", True)),
        "feature_views": feature_views,
    }
    return doc


# Canonical FV-kind discriminator values used to filter ``AppliedState``
# down to the subset the exporter knows how to render.  Keep in sync
# with :data:`state._FV_KIND_MAP` — entities / datasources /
# feature-groups travel through their dedicated kwargs.
_FV_APPLIED_KINDS: frozenset[str] = frozenset({"BatchFeatureView", "StreamingFeatureView", "RealtimeFeatureView"})


def _fv_doc_sources_recovered(fv_doc: dict[str, Any], full_spec: dict[str, Any]) -> bool:
    """Return True when a BatchFV's source is recoverable from the export inputs.

    A legacy ``BatchFeatureView`` registered by an older client can lack both
    ``FV_SOURCE_REFS`` metadata and any ``spec.sources`` in its recovered
    SPECIFICATION, in which case :func:`_build_full_fidelity_fv` produces a
    ``fv_doc`` with an empty (or absent) ``sources`` list.  Such a feature view
    cannot round-trip through ``snow feature apply`` and is warned + skipped
    rather than written source-less.

    A source counts as recovered when either:

    - ``fv_doc`` already carries a non-empty ``sources`` list (state recovery
      injected it from ``FV_SOURCE_REFS`` or the SPECIFICATION carried it), or
    - the SPECIFICATION's ``offline_configs`` carries a ``BatchSource`` table
      binding — a passthrough-style BatchFV whose offline store *is* the source
      table (see the ``USER_PROFILE_INFO_BATCH`` golden).  Its ``spec.sources``
      is legitimately empty yet the FV round-trips, so it must not be skipped.

    Args:
        fv_doc: The authoring-shape feature-view dict produced by
            :func:`_build_full_fidelity_fv`.
        full_spec: The raw ``DESCRIBE ... TYPE = SPECIFICATION`` document for
            the OFT (carries ``offline_configs``).

    Returns:
        ``True`` when the BatchFeatureView's source is recoverable, else
        ``False``.
    """
    srcs = fv_doc.get("sources")
    if isinstance(srcs, list) and len(srcs) > 0:
        return True
    offline_configs = full_spec.get("offline_configs")
    if isinstance(offline_configs, list):
        for cfg in offline_configs:
            if isinstance(cfg, dict) and str(cfg.get("table_type")) == "BatchSource":
                return True
    return False


def _overlay_applied_state_on_export_inputs(
    show_rows: list[dict[str, Any]],
    specification_map: Optional[dict[str, dict[str, Any]]],
    applied_state: Optional[Any],
    *,
    default_database: str,
    default_schema: str,
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    """Overlay an :class:`AppliedState` snapshot onto raw exporter inputs.

    Returns the ``(show_rows, spec_map)`` pair the rest of
    :func:`export_specs` consumes, with two transformations applied
    when *applied_state* is provided:

    1. **Recovered-payload precedence.**  For every FV-kind
       ``AppliedObject`` whose synthesised OFT name matches an entry
       in *show_rows* / *specification_map*, the object's
       ``spec_payload`` overwrites the raw ``specification_map`` entry
       — this is how recovered BatchFV ``sources`` (injected from DT
       text by :func:`state._inject_batch_fv_source_from_dt_text`,
       transitioning under Plan B-state to the
       ``FV_SOURCE_REFS``-driven
       :func:`state._inject_batch_fv_source_from_metadata`) and
       advanced BFV fields (``cluster_by``, ``refresh_mode``,
       ``initialize`` — injected by
       :func:`state._inject_advanced_bfv_fields_from_dt_text`) make
       their way into the exported YAML.  Without this rule, the
       lossy raw SPECIFICATION JSON would always win.

       FVs absent from *applied_state* (legacy / fresh-init case) keep
       their raw ``specification_map`` entry untouched so the export
       still produces a YAML for them — soft-fallback per Plan B8.
    2. **Offline-only synthesis.**  When an ``AppliedObject`` has no
       matching *show_rows* entry (because it was surfaced by
       :func:`state._build_offline_fv_object` from
       ``feature_view_rows`` rather than ``SHOW ONLINE FEATURE
       TABLES``), a synthetic *show_row* is appended so the FV
       reaches the YAML-emission loop.  Only the keys the exporter
       actually consumes (``name`` / ``database_name`` /
       ``schema_name``) are populated — runtime metadata such as
       ``scheduling_state`` is never authoring surface and is no
       longer round-tripped into the YAML.

    Args:
        show_rows: Caller-provided rows from ``SHOW ONLINE FEATURE
            TABLES``.  Returned as a new list (the original is never
            mutated) extended with offline-only synthesised rows.
        specification_map: Caller-provided OFT → spec_payload map.
            Returned as a new dict (never mutated) with recovered
            payloads from *applied_state* overlaid.
        applied_state: Optional :class:`AppliedState` snapshot.
            ``None`` short-circuits — the function returns
            ``(show_rows, specification_map or {})`` unchanged so
            legacy callers keep working byte-stably.
        default_database: Fallback database for synthesised
            show-rows when an ``AppliedObject``'s ``spec_payload.
            metadata.database`` is empty.
        default_schema: Fallback schema for synthesised show-rows
            when an ``AppliedObject``'s
            ``spec_payload.metadata.schema`` is empty.

    Returns:
        Tuple ``(show_rows, spec_map)`` ready for the rest of
        :func:`export_specs`.  Both are fresh objects when overlay
        was performed; otherwise ``spec_map`` is ``specification_map
        or {}`` and ``show_rows`` is the input reference.
    """
    if applied_state is None:
        return show_rows, specification_map or {}

    objects = getattr(applied_state, "objects", None)
    if not objects:
        return show_rows, specification_map or {}

    overlaid_spec_map: dict[str, dict[str, Any]] = dict(specification_map or {})
    existing_oft_names: set[str] = {str(r.get("name", "")) for r in show_rows if r.get("name")}
    synthesised_rows: list[dict[str, Any]] = []

    # TODO(gate-b cross-stream): the BatchFV ``Source`` bindings inside
    # ``spec_payload["spec"]["sources"]`` are produced today by
    # :func:`state._inject_batch_fv_source_from_dt_text`.  Plan B-state
    # is rewriting that helper as
    # :func:`state._inject_batch_fv_source_from_metadata` driven by the
    # ``FV_SOURCE_REFS`` row introduced in Plan A1.  The exporter reads
    # the *result* (``spec_payload["spec"]["sources"]``) regardless of
    # which injector produced it — but Gate B's full-test cross-check
    # must confirm B-state still surfaces the recovered list under the
    # same key path.  If B-state moves the bindings (e.g. to a
    # top-level ``spec_payload["sources_metadata"]``), this overlay
    # function and ``_build_full_fidelity_fv`` need a parallel update.
    for obj in objects.values():
        kind = getattr(obj, "kind", "")
        if kind not in _FV_APPLIED_KINDS:
            continue
        spec_payload = getattr(obj, "spec_payload", None)
        if not isinstance(spec_payload, dict) or not spec_payload:
            continue
        name = getattr(obj, "name", "") or ""
        version = getattr(obj, "version", "") or ""
        if not name or not version:
            continue
        # OFT-naming contract: ``<base>$<version>$ONLINE`` — must match
        # what :func:`state._parse_oft_name` expects on the inverse
        # parse so synthesised show-rows are indistinguishable from
        # the real SHOW output.
        oft_name = f"{name}${version}$ONLINE"

        # Precedence rule: applied_state's recovered payload always
        # wins for collisions — that is the entire point of the
        # overlay.  Raw specification_map entries survive only for
        # FVs that applied_state does not know about (defensive: the
        # plan path normally populates every OFT).
        overlaid_spec_map[oft_name] = spec_payload

        if oft_name in existing_oft_names:
            continue
        _md = spec_payload.get("metadata")
        metadata = _md if isinstance(_md, dict) else {}
        synth_db = metadata.get("database") or default_database
        synth_schema = metadata.get("schema") or default_schema
        synthesised_rows.append(
            {
                "name": oft_name,
                "database_name": synth_db,
                "schema_name": synth_schema,
            }
        )
        existing_oft_names.add(oft_name)

    if not synthesised_rows:
        return list(show_rows), overlaid_spec_map
    return list(show_rows) + synthesised_rows, overlaid_spec_map


def _orphaned_entity_column_warnings(
    show_rows: list[dict[str, Any]],
    spec_map: dict[str, Any],
    entity_rows: Optional[list[dict[str, Any]]],
    name_filter: Optional[str],
) -> list[str]:
    """Pre-validate FV entity columns against the registered join-key columns.

    When ``entity_rows`` is non-empty it is authoritative.  An OFT whose
    ``ordered_entity_column_names`` references a column with no matching
    registered join-key column (decoded from each entity tag's
    ``allowed_values`` via :func:`_join_keys_from_row`) is a stale artifact
    (typically registered via the older imperative API before the 2026-07-31
    join-key-immutability decision): such an OFT can never round-trip through
    ``snow feature apply`` because its entity is not registered.

    The comparison set is built from join-key **columns**, never entity
    **names** (:func:`_entity_name_from_row`): an entity's name and its
    join-key column are frequently and validly different strings (e.g. entity
    ``NOTEBOOK_SYNC_USER`` with join-key column ``USER_ID``), so comparing
    across the two namespaces would flag every such normal pairing as
    orphaned.

    The caller surfaces a WARNING for each such OFT but still exports its FV
    (the FV is a real deployed object whose definition is fully recoverable;
    skipping the YAML would leave the planner seeing the deployed FV with no
    local spec — a spurious ``DROP_FV`` on every re-plan).  An empty / ``None``
    ``entity_rows`` means the caller opted out of entity emission; the subset
    check is vacuous and yields no warnings.

    Args:
        show_rows: OFT ``SHOW`` rows (or synthesised equivalents) being exported.
        spec_map: OFT name → full SPECIFICATION spec JSON.
        entity_rows: Registered entity tag rows in the legacy SHOW TAGS shape;
            ``None`` / empty skips the check.
        name_filter: Optional case-insensitive object-name filter mirroring the
            export write loop, so a filtered export only warns about OFTs it
            actually emits.

    Returns:
        One warning string per orphaned OFT (its first unregistered entity
        column), in ``show_rows`` order.  Empty when the check is skipped or
        every entity column resolves to a registered join key.
    """
    if not entity_rows:
        return []

    known_join_cols: set[str] = set()
    for row in entity_rows:
        for col in _join_keys_from_row(row):
            known_join_cols.add(col.upper())

    warnings: list[str] = []
    for row in show_rows:
        raw_name = row.get("name", "")
        full_spec = spec_map.get(raw_name)
        if not isinstance(full_spec, dict) or not full_spec:
            continue
        if name_filter:
            _md = full_spec.get("metadata") or {}
            _fn, _ = _parse_oft_name(raw_name)
            _spec_name = _md.get("name") or _fn
            if str(_spec_name).upper() != name_filter.upper():
                continue
        for col_name in _entity_cols_from_full_spec(full_spec):
            if col_name.upper() not in known_join_cols:
                warnings.append(
                    f"OFT '{raw_name}' references entity column "
                    f"'{col_name}' which has no corresponding entity tag; "
                    "exporting the feature view anyway (its entity is not "
                    "registered, so a modified re-apply would fail)."
                )
                break
    return warnings


def export_specs(
    show_rows: list[dict[str, Any]],
    describe_rows_by_oft: dict[str, list[dict[str, Any]]],
    output_dir: str,
    database: str,
    schema: str,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
    entity_rows: Optional[list[dict[str, Any]]] = None,
    feature_group_rows: Optional[list[dict[str, Any]]] = None,
    feature_view_rows: Optional[list[dict[str, Any]]] = None,
    applied_state: Optional[Any] = None,
    layout: str = "db_schema",
    name_filter: Optional[str] = None,
) -> dict[str, Any]:
    """Reconstruct YAML specs from raw Snowflake query results and write to disk.

    Strict mode: every row in ``SHOW ONLINE FEATURE TABLES`` must have a
    matching non-empty entry in *specification_map* (the parsed JSON
    returned by ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE =
    SPECIFICATION``).  When that requirement is met, each YAML preserves
    UDF source, source column schemas, feature aggregations
    (function/window/offset), granularity, and target lag — enabling a
    round-trip ``snow feature apply`` without manual edits.

    Entity YAML emission is driven by *entity_rows* (the legacy SHOW
    TAGS-shape rows returned by :func:`decl_api.fetch_entity_rows`).
    Every entity tag is materialised to YAML — including orphan tags
    not referenced by any FV — and every FV's ``entities`` (the
    authoring-side name; recovered from the wire-form
    ``ordered_entity_column_names`` key in DESCRIBE output) is
    cross-checked against the provided rows.  A deployed OFT
    referencing an entity column with no matching entity tag is a
    stale artifact that cannot round-trip through ``snow feature
    apply``; it is warned and skipped (its name surfaced in the
    returned ``warnings`` list) rather than aborting the whole
    export, so the remaining consistent OFTs, entity tags, and FGs
    still export.  ``entity_rows=None`` and ``entity_rows=[]`` are
    treated identically: no entity YAMLs are emitted and the subset
    check is skipped (the caller has opted out of authoritative
    entity emission).  Callers that want entity YAMLs on disk must
    forward the output of :func:`decl_api.fetch_entity_rows`.

    Datasource YAML files are written for the deduped column-superset
    of every FV's ``spec.sources[]`` entry.

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES`` (list of dicts).
        describe_rows_by_oft: Map of OFT name → ``DESCRIBE`` rows (list of
            dicts).  Retained for forward compatibility; not consumed in
            strict mode.
        output_dir: Base output directory.  Under the default
            ``layout="db_schema"`` a ``<database>.<schema>`` subdirectory
            is created inside it; under ``layout="sources"`` the YAMLs
            land directly in ``<output_dir>/sources/`` (mirroring the
            manifest project tree scaffolded by ``snow feature init``).
        database: Connection database name, used as the directory prefix and
            as a fallback when a row lacks one.
        schema: Connection schema name, used as the directory prefix and as
            a fallback when a row lacks one.
        specification_map: Map of OFT name → parsed spec JSON returned by
            ``DESCRIBE ... TYPE = SPECIFICATION``.  Required for every OFT
            in *show_rows*; missing or empty entries abort the export.
        entity_rows: Rows from
            ``SHOW TAGS LIKE 'SNOWML_FEATURE_STORE_ENTITY_%'`` (or the
            equivalent imperative ``FeatureStore.list_entities()``
            output).  When non-empty, these rows are the authoritative
            source of truth for entity emission: every row produces a
            YAML stub, and every FV ``entities`` entry (recovered from
            the wire-form ``ordered_entity_column_names`` key) is
            validated against the row set.  ``None`` and ``[]`` are
            treated identically — no entity YAMLs are written and the
            subset check is skipped.
        feature_group_rows: Rows produced by
            :func:`decl_api.fetch_feature_group_rows` (the imperative
            ``FeatureStore.list_feature_groups()`` output, normalised
            into the executor's row shape).  When non-empty, every row
            materialises a YAML in
            ``<base>/feature_groups/<NAME>.yaml``, including FGs whose
            source FVs reference advanced batch fields (``cluster_by``,
            ``storage_config``, etc.) — those advanced fields live on
            the FV YAML, not the FG, so the FG export path is
            decoupled from the BFV authoring surface.  ``None`` and
            ``[]`` are treated identically — no FG YAMLs are written.
        feature_view_rows: Optional rows produced by
            :func:`decl_api.fetch_feature_view_rows` (the imperative
            ``FeatureStore.list_feature_views()`` output).  When
            provided, ``SHOW ONLINE FEATURE TABLES`` is cross-checked
            against this authoritative discovery set via
            :func:`state.orphaned_oft_warnings`; any OFT with no
            matching listed feature view (backing Dynamic Table
            dropped) surfaces a named diagnostic warning in the return
            envelope.  ``None`` (the default) disables the cross-check
            for back-compat with callers that do not thread the list
            rows — the diagnostic is strictly opt-in and never
            false-flags an OFT.
        applied_state: Optional :class:`AppliedState` snapshot produced
            by :func:`fetch_applied_state` (the same surface the plan
            path consumes).  When present, the exporter overlays its
            FV-kind ``AppliedObject.spec_payload`` entries on top of
            *specification_map* — the recovered payload wins for every
            OFT also present in *show_rows*, and any FV in
            ``applied_state.objects`` that does not have a matching
            *show_rows* entry (offline-only BatchFVs surfaced through
            :func:`state._build_offline_fv_object`) is synthesised
            into a show-row so it still gets a YAML.  This is the
            init-export unification surface: with it,
            ``snow feature init`` no longer drops the BatchFV
            ``sources[]`` / advanced fields / offline-only entries
            the SPECIFICATION JSON loses on round-trip.  When
            ``None``, the legacy ``specification_map``-only codepath
            runs unchanged (back-compat for downstream callers that
            haven't migrated to the applied-state surface).
        layout: ``"db_schema"`` (default, back-compat) writes to
            ``<output_dir>/<database>.<schema>/{entities,datasources,
            feature_views}/``.  ``"sources"`` writes to
            ``<output_dir>/sources/{entities,datasources,feature_views}/``
            so the result drops straight into the manifest project tree
            consumed by ``snow feature plan`` / ``apply``.
        name_filter: Optional exact-match, case-insensitive object name
            filter.  When provided, only the single object whose name
            compares equal (``name.upper() == name_filter.upper()``) is
            written for each object kind (FV, entity, datasource,
            feature group).  Objects that do not match are silently
            skipped; a filter that matches nothing produces an empty
            ``files`` list.  ``None`` (default) exports all objects.

    Returns:
        Dict with keys:

        - ``status``: ``"exported"``
        - ``directory``: Absolute path to the export base directory
          (``<output_dir>/<database>.<schema>`` for ``layout="db_schema"``
          or ``<output_dir>/sources`` for ``layout="sources"``), or
          ``""`` if both *show_rows* and *entity_rows* are empty.
        - ``files``: List of absolute paths to the written YAML files.
        - ``warnings``: List of human-readable warning strings, one per
          OFT skipped because it references an entity column with no
          registered entity tag.  Empty when every OFT is consistent.

    Raises:
        ValueError: If *layout* is not one of ``"db_schema"`` /
            ``"sources"``; if any OFT in *show_rows* (that is not
            skipped as orphaned) has no corresponding entry in
            *specification_map* (or maps to an empty/non-dict value);
            if two FVs disagree on a datasource column type, kind, or
            passthrough field; or if a FV source carries an
            unrecognised ``source_type`` value.  An OFT referencing an
            entity column absent from *entity_rows* is **not** an error
            — it is warned and skipped (see the ``warnings`` return
            key).
    """
    del describe_rows_by_oft  # retained in signature for forward compatibility

    if layout not in _VALID_LAYOUTS:
        raise ValueError(f"export_specs: unknown layout {layout!r}; expected one of " f"{_VALID_LAYOUTS!r}")

    # Normalise the caller-facing ``Optional[list]`` shape into a list so
    # the rest of the function can iterate without re-checking for None.
    # Empty (None or []) means "no entities registered" — no entity YAMLs
    # are written and the strict subset check below is skipped.
    entity_rows = entity_rows or []
    feature_group_rows = feature_group_rows or []

    # Diagnostic-only cross-check (FV-retrieval unification).  Run against
    # the caller's ORIGINAL ``show_rows`` — before the applied-state
    # overlay appends synthetic ``$ONLINE`` rows for offline-only FVs — so
    # only genuinely deployed OFTs are checked.  ``list_feature_views``
    # (``feature_view_rows``) is the authoritative discovery set; any OFT
    # with no matching listed FV is surfaced as a warning rather than
    # silently mishandled.  ``None`` disables the check (back-compat).
    oft_diagnostic_warnings = orphaned_oft_warnings(
        show_rows,
        feature_view_rows=feature_view_rows,
        feature_group_rows=feature_group_rows or None,
    )

    # When the caller hands us an ``AppliedState`` (the same surface the
    # plan path consumes), overlay its recovered FV payloads on top of
    # the raw ``specification_map`` and synthesise show-rows for any
    # offline-only FVs that the SHOW pipeline cannot enumerate.  This is
    # the init-export unification: without it, BatchFV YAMLs land with
    # ``sources: []`` because the raw SPECIFICATION JSON drops the
    # offline-DT source binding, and offline-only BFVs silently
    # disappear from the exported tree.  Keep the overlay scoped to FV
    # kinds — entities and feature-groups still flow through their
    # dedicated kwargs.
    show_rows, specification_map = _overlay_applied_state_on_export_inputs(
        show_rows,
        specification_map,
        applied_state,
        default_database=database,
        default_schema=schema,
    )

    # Empty input means there is genuinely nothing to export (no FVs,
    # no entity tags, no FGs).  Preserved so a fresh-schema export call
    # returns a noop envelope without creating empty subdirectories.
    if not show_rows and not entity_rows and not feature_group_rows:
        return {"status": "exported", "directory": "", "files": [], "warnings": []}

    spec_map = specification_map or {}

    if layout == "sources":
        base = Path(output_dir) / "sources"
    else:
        base = Path(output_dir) / f"{database}.{schema}"
    entities_dir = base / "entities"
    fv_dir = base / "feature_views"
    for d in (entities_dir, fv_dir):
        d.mkdir(parents=True, exist_ok=True)

    # Pre-validate FV ↔ entity_rows consistency before writing any files: an
    # OFT whose ``ordered_entity_column_names`` references a column with no
    # matching registered join-key column is warned but still exported.  The
    # membership set is join-key *columns*, not entity *names* — see
    # :func:`_orphaned_entity_column_warnings` for the full rationale.
    warnings: list[str] = list(oft_diagnostic_warnings)
    warnings.extend(_orphaned_entity_column_warnings(show_rows, spec_map, entity_rows, name_filter))

    seen_entities: set[str] = set()
    created: list[str] = []

    # FeatureGroups are authoritative from ``feature_group_rows``
    # (``list_feature_groups()`` metadata); their OFTs must be excluded
    # from the FV write loop below (Symptom 1).
    fg_names_from_rows: set[str] = {str(r.get("name", "")).upper() for r in feature_group_rows if r.get("name")}

    # Version-qualify the on-disk stem for versioned kinds so two versions of
    # one name land in distinct files.  Identity is derived from the YAML
    # body (``spec_key`` reads name+version), so the stem is cosmetic — but a
    # name-only stem makes the second FV ``write_text`` overwrite the first and
    # the FG loop skip the duplicate, so only one version survives on disk and
    # a following ``plan ./...`` proposes a destructive DROP for the missing
    # one.  ``version`` is regex-safe (``V1`` etc.), so the shared UDF ``.py``
    # sidecar stem (allowlist ``[A-Za-z0-9_-]+``) stays valid.
    def _versioned_stem(base: str, version: Any) -> str:
        v = str(version or "").strip()
        return f"{base}_{v}" if v else base

    # Track stems per directory and hard-fail on a residual collision rather
    # than silently overwriting / skipping a version — an error is recoverable,
    # a dropped version is not.
    seen_fv_stems: set[str] = set()

    for row in show_rows:
        raw_name = row.get("name", "")
        db = row.get("database_name", database)
        sch = row.get("schema_name", schema)

        full_spec = spec_map.get(raw_name)
        if not isinstance(full_spec, dict) or not full_spec:
            raise ValueError(
                f"DESCRIBE … TYPE = SPECIFICATION returned no spec for OFT "
                f"'{raw_name}'. Cannot export without authoritative specification."
            )

        fallback_name, fallback_version = _parse_oft_name(raw_name)
        fv_doc = _build_full_fidelity_fv(
            full_spec,
            fallback_name=fallback_name,
            fallback_version=fallback_version,
            fallback_database=db,
            fallback_schema=sch,
        )
        kind = str(fv_doc.get("kind") or "StreamingFeatureView")
        base_stem = str(fv_doc.get("name") or fallback_name)
        if name_filter and base_stem.upper() != name_filter.upper():
            continue

        # Symptom 1: FeatureGroup (and any non-FV-kind) OFTs must never be
        # rendered through the FV path — a FeatureGroup would emit a broken
        # ``feature_views=[]`` stub under ``feature_views/``.  FGs are emitted
        # from ``feature_group_rows`` below; an FG OFT absent from that
        # metadata is genuinely unrecoverable (its member refs cannot be
        # reconstructed from the SPECIFICATION), so it is warned and skipped.
        if kind not in _FV_APPLIED_KINDS:
            if kind == "FeatureGroup" and base_stem.upper() not in fg_names_from_rows:
                warnings.append(
                    f"FeatureGroup OFT '{raw_name}' is not present in "
                    f"list_feature_groups() metadata; cannot export it. "
                    f"Re-register the FeatureGroup so its members are recoverable."
                )
            continue

        # Symptom 2: a legacy BatchFeatureView with no recoverable source
        # (no FV_SOURCE_REFS metadata and an empty SPECIFICATION ``sources``)
        # cannot round-trip; warn and skip rather than write it source-less.
        if kind == "BatchFeatureView" and not _fv_doc_sources_recovered(fv_doc, full_spec):
            warnings.append(
                f"BatchFeatureView '{base_stem}' has no recoverable source "
                f"(no FV_SOURCE_REFS metadata and the SPECIFICATION carries no "
                f"sources); skipping export. This feature view was likely "
                f"registered by an older client; re-register it or add its "
                f"BatchSource manually before the next apply."
            )
            continue

        # Version-qualify the on-disk stem now that the row is confirmed
        # exportable, and hard-fail on a residual collision.
        file_stem = _versioned_stem(base_stem, fv_doc.get("version"))
        if file_stem in seen_fv_stems:
            raise ValueError(
                f"FeatureView export stem collision on '{file_stem}.yaml': two "
                f"feature views resolve to the same (name, version). Refusing to "
                f"overwrite a version's YAML — resolve the duplicate before export."
            )
        seen_fv_stems.add(file_stem)

        # Extract UDF source into a sibling ``.py`` file before serializing the
        # YAML, so the YAML carries a ``file:`` reference instead of inlining
        # the source.  This mirrors the authoring format (``UDF.file`` in
        # ``spec_models.py``) and is reversed by ``compiler.inline_udf_source``
        # when the YAML is later loaded for ``snow feature apply``.
        udf_py_path = _extract_udf_to_py_file(fv_doc, fv_dir, file_stem)

        fv_path = fv_dir / f"{file_stem}.yaml"
        fv_path.write_text(yaml.dump(_ordered_fv_doc(fv_doc), default_flow_style=False, sort_keys=False))
        created.append(str(fv_path))
        if udf_py_path is not None:
            created.append(udf_py_path)

    # Authoritative entity emission: drive directly from entity_rows.
    # Every tag (referenced or orphan) gets a YAML.  Naming + casing
    # match :func:`state._build_entity_object` so structural
    # fingerprints align and the planner reports NO_CHANGE on an
    # unmodified round-trip.  When ``entity_rows`` was normalised to
    # ``[]`` above (caller passed ``None`` or ``[]``), the loop is a
    # noop and no entity YAMLs are written.
    for row in entity_rows:
        entity_spec = _entity_yaml_from_row(row)
        if entity_spec is None:
            continue
        ent_name = entity_spec["name"]
        if name_filter and ent_name.upper() != name_filter.upper():
            continue
        if ent_name in seen_entities:
            continue
        seen_entities.add(ent_name)
        entity_path = entities_dir / f"{ent_name}.yaml"
        entity_path.write_text(yaml.dump(entity_spec, default_flow_style=False, sort_keys=False))
        created.append(str(entity_path))

    # FeatureGroup emission: drive directly from feature_group_rows.
    # Every row produces a ``feature_groups/<NAME>.yaml`` stub in the
    # canonical authoring shape.  When ``feature_group_rows`` was
    # normalised to ``[]`` (caller passed ``None`` or ``[]``), the
    # loop is a noop and no FG YAMLs (or directory) are created.
    if feature_group_rows:
        feature_groups_dir = base / "feature_groups"
        feature_groups_dir.mkdir(parents=True, exist_ok=True)
        seen_fg_files: set[str] = set()
        for row in feature_group_rows:
            fg_doc = _build_fg_yaml_doc(row)
            fg_name = str(fg_doc["name"])
            if name_filter and fg_name.upper() != name_filter.upper():
                continue
            file_stem = _versioned_stem(fg_name, fg_doc.get("version"))
            if file_stem in seen_fg_files:
                raise ValueError(
                    f"FeatureGroup export stem collision on '{file_stem}.yaml': "
                    f"two feature groups resolve to the same (name, version). "
                    f"Refusing to skip a version's YAML — resolve the duplicate "
                    f"before export."
                )
            seen_fg_files.add(file_stem)
            fg_path = feature_groups_dir / f"{file_stem}.yaml"
            fg_path.write_text(yaml.dump(_ordered_fg_doc(fg_doc), default_flow_style=False, sort_keys=False))
            created.append(str(fg_path))

    # Datasource emission must come AFTER all FV/entity files are written but
    # BEFORE the ``datasources/`` directory is created — a ValueError raised by
    # ``_collect_datasources`` (column-type or kind/passthrough conflict, or an
    # unrecognised ``source_type``) must propagate cleanly without leaving any
    # partially-written datasource files on disk.
    datasources = _collect_datasources(spec_map)
    if name_filter:
        datasources = {k: v for k, v in datasources.items() if k.upper() == name_filter.upper()}
    if datasources:
        datasources_dir = base / "datasources"
        datasources_dir.mkdir(parents=True, exist_ok=True)
        for emit_name, ds_spec in datasources.items():
            # Externalise any inline ``query:`` body into a sibling ``.sql``
            # sidecar before serialising — mirrors the UDF emission path
            # above so the YAML stays thin and the on-disk shape matches
            # what ``snow feature init`` scaffolds.  ``compiler.inline_
            # query_source`` reverses the move on load.
            sql_sidecar_path = _extract_query_to_sql_file(ds_spec, datasources_dir, emit_name)
            ds_path = datasources_dir / f"{emit_name}.yaml"
            ds_path.write_text(yaml.dump(_ordered_ds_doc(ds_spec), default_flow_style=False, sort_keys=False))
            created.append(str(ds_path))
            if sql_sidecar_path is not None:
                created.append(sql_sidecar_path)

    return {"status": "exported", "directory": str(base), "files": created, "warnings": warnings}


def export_specs_as_python(
    show_rows: list[dict[str, Any]],
    describe_rows_by_oft: dict[str, list[dict[str, Any]]],
    output_dir: str,
    database: str,
    schema: str,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
    entity_rows: Optional[list[dict[str, Any]]] = None,
    feature_group_rows: Optional[list[dict[str, Any]]] = None,
    feature_view_rows: Optional[list[dict[str, Any]]] = None,
    applied_state: Optional[Any] = None,
    layout: str = "db_schema",
    name_filter: Optional[str] = None,
) -> dict[str, Any]:
    """Reconstruct Python-form spec files from raw Snowflake query results.

    Identical calling convention to :func:`export_specs` but writes
    ``.py`` files instead of ``.yaml`` files.  Each file contains a
    module-level variable assignment instantiating the appropriate Pydantic
    spec class (``Entity``, ``BatchSource``, ``StreamingFeatureView``,
    etc.) and is directly loadable by
    :func:`loader.load_python_file`.

    Key differences from :func:`export_specs`:

    - UDF source code is emitted as an inline ``def`` block in the
      ``.py`` file — no sibling ``.py`` sidecar is written.
    - Batch query sources carry ``query=`` inline — no ``.sql`` sidecar.
    - All output files have a ``.py`` extension; no ``.yaml`` is written.

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES``.
        describe_rows_by_oft: Map of OFT name → ``DESCRIBE`` rows.
            Retained for API parity; not consumed in strict mode.
        output_dir: Base output directory (same layout rules as
            :func:`export_specs`).
        database: Connection database name.
        schema: Connection schema name.
        specification_map: Map of OFT name → parsed spec JSON.
        entity_rows: Rows from the entity-tag SHOW query.
        feature_group_rows: Rows from the feature-group list query.
        feature_view_rows: Optional ``list_feature_views()`` discovery
            rows; when provided, an OFT with no matching listed feature
            view surfaces a diagnostic warning (see
            :func:`state.orphaned_oft_warnings`).  ``None`` disables the
            opt-in cross-check.
        applied_state: Optional :class:`AppliedState` snapshot.
        layout: ``"db_schema"`` (default) or ``"sources"``.
        name_filter: Optional exact-match, case-insensitive object name
            filter.  Identical semantics to :func:`export_specs`'s
            ``name_filter`` parameter.

    Returns:
        ``{"status": "exported", "directory": str, "files": [...],
        "warnings": [...]}``.  ``warnings`` carries one entry per OFT
        skipped because it references an entity column with no
        registered entity tag.

    Raises:
        ValueError: If a non-skipped row in *show_rows* has no matching
            entry in *specification_map*, or if a FG row is missing
            required ``name`` / ``version`` fields.  An OFT referencing
            an entity column absent from *entity_rows* is warned and
            skipped, not raised.
    """
    from snowflake.ml.feature_store.decl import python_codegen

    entity_rows = entity_rows or []
    feature_group_rows = feature_group_rows or []

    # Diagnostic-only cross-check against the ORIGINAL show-rows (before
    # the applied-state overlay appends synthetic offline rows).  See
    # :func:`export_specs` for the rationale.
    oft_diagnostic_warnings = orphaned_oft_warnings(
        show_rows,
        feature_view_rows=feature_view_rows,
        feature_group_rows=feature_group_rows or None,
    )

    show_rows, specification_map = _overlay_applied_state_on_export_inputs(
        show_rows,
        specification_map,
        applied_state,
        default_database=database,
        default_schema=schema,
    )

    if not show_rows and not entity_rows and not feature_group_rows:
        return {"status": "exported", "directory": "", "files": [], "warnings": []}

    spec_map = specification_map or {}

    if layout == "sources":
        base = Path(output_dir) / "sources"
    else:
        base = Path(output_dir) / f"{database}.{schema}"
    entities_dir = base / "entities"
    fv_dir = base / "feature_views"
    for d in (entities_dir, fv_dir):
        d.mkdir(parents=True, exist_ok=True)

    # Orphaned-OFT handling mirrors :func:`export_specs`: an OFT whose entity
    # column has no registered join-key column is warned but still exported (the
    # FV is a real deployed object whose definition is fully recoverable).  The
    # list-driven orphan diagnostic (OFT with no matching listed FV) is seeded
    # first; the join-key pre-check is shared with the YAML path.
    warnings: list[str] = list(oft_diagnostic_warnings)
    warnings.extend(_orphaned_entity_column_warnings(show_rows, spec_map, entity_rows, name_filter))

    seen_entities: set[str] = set()
    created: list[str] = []

    # FeatureGroups are authoritative from ``feature_group_rows``
    # (``list_feature_groups()`` metadata); their OFTs must be excluded
    # from the FV write loop below (Symptom 1).
    fg_names_from_rows: set[str] = {str(r.get("name", "")).upper() for r in feature_group_rows if r.get("name")}

    for row in show_rows:
        raw_name = row.get("name", "")
        db = row.get("database_name", database)
        sch = row.get("schema_name", schema)

        full_spec = spec_map.get(raw_name)
        if not isinstance(full_spec, dict) or not full_spec:
            raise ValueError(
                f"DESCRIBE … TYPE = SPECIFICATION returned no spec for OFT "
                f"'{raw_name}'. Cannot export without authoritative specification."
            )

        fallback_name, fallback_version = _parse_oft_name(raw_name)
        fv_doc = _build_full_fidelity_fv(
            full_spec,
            fallback_name=fallback_name,
            fallback_version=fallback_version,
            fallback_database=db,
            fallback_schema=sch,
        )
        kind = str(fv_doc.get("kind") or "StreamingFeatureView")
        file_stem = str(fv_doc.get("name") or fallback_name)
        if name_filter and file_stem.upper() != name_filter.upper():
            continue

        # Symptom 1: FeatureGroup (and any non-FV-kind) OFTs must never be
        # rendered through the FV path — a FeatureGroup would emit a broken
        # ``feature_views=[]`` stub under ``feature_views/``.  FGs are emitted
        # from ``feature_group_rows`` below; an FG OFT absent from that
        # metadata is genuinely unrecoverable (its member refs cannot be
        # reconstructed from the SPECIFICATION), so it is warned and skipped.
        if kind not in _FV_APPLIED_KINDS:
            if kind == "FeatureGroup" and file_stem.upper() not in fg_names_from_rows:
                warnings.append(
                    f"FeatureGroup OFT '{raw_name}' is not present in "
                    f"list_feature_groups() metadata; cannot export it. "
                    f"Re-register the FeatureGroup so its members are recoverable."
                )
            continue

        # Symptom 2: a legacy BatchFeatureView with no recoverable source
        # (no FV_SOURCE_REFS metadata and an empty SPECIFICATION ``sources``)
        # cannot round-trip; warn and skip rather than write it source-less.
        if kind == "BatchFeatureView" and not _fv_doc_sources_recovered(fv_doc, full_spec):
            warnings.append(
                f"BatchFeatureView '{file_stem}' has no recoverable source "
                f"(no FV_SOURCE_REFS metadata and the SPECIFICATION carries no "
                f"sources); skipping export. This feature view was likely "
                f"registered by an older client; re-register it or add its "
                f"BatchSource manually before the next apply."
            )
            continue

        py_src = python_codegen.spec_dict_to_python_source(kind, file_stem, fv_doc)
        fv_path = fv_dir / f"{file_stem}.py"
        if _guarded_write_py(fv_path, py_src, warnings):
            created.append(str(fv_path))

    for row in entity_rows:
        entity_spec = _entity_yaml_from_row(row)
        if entity_spec is None:
            continue
        ent_name = entity_spec["name"]
        if name_filter and ent_name.upper() != name_filter.upper():
            continue
        if ent_name in seen_entities:
            continue
        seen_entities.add(ent_name)
        py_src = python_codegen.spec_dict_to_python_source("Entity", ent_name, entity_spec)
        entity_path = entities_dir / f"{ent_name}.py"
        if _guarded_write_py(entity_path, py_src, warnings):
            created.append(str(entity_path))

    if feature_group_rows:
        feature_groups_dir = base / "feature_groups"
        feature_groups_dir.mkdir(parents=True, exist_ok=True)
        seen_fg_files: set[str] = set()
        for row in feature_group_rows:
            fg_doc = _build_fg_yaml_doc(row)
            file_stem = str(fg_doc["name"])
            if name_filter and file_stem.upper() != name_filter.upper():
                continue
            if file_stem in seen_fg_files:
                continue
            seen_fg_files.add(file_stem)
            py_src = python_codegen.spec_dict_to_python_source("FeatureGroup", file_stem, fg_doc)
            fg_path = feature_groups_dir / f"{file_stem}.py"
            if _guarded_write_py(fg_path, py_src, warnings):
                created.append(str(fg_path))

    datasources = _collect_datasources(spec_map)
    if name_filter:
        datasources = {k: v for k, v in datasources.items() if k.upper() == name_filter.upper()}
    if datasources:
        datasources_dir = base / "datasources"
        datasources_dir.mkdir(parents=True, exist_ok=True)
        for emit_name, ds_spec in datasources.items():
            ds_kind = str(ds_spec.get("kind") or "BatchSource")
            py_src = python_codegen.spec_dict_to_python_source(ds_kind, emit_name, ds_spec)
            ds_path = datasources_dir / f"{emit_name}.py"
            if _guarded_write_py(ds_path, py_src, warnings):
                created.append(str(ds_path))

    return {"status": "exported", "directory": str(base), "files": created, "warnings": warnings}
