"""Export spec reconstruction for the declarative feature store library.

Reconstructs YAML spec files from pre-fetched SHOW results plus the full
original spec JSON returned by ``DESCRIBE ONLINE FEATURE TABLE <name>
TYPE = SPECIFICATION``.  No Snowflake connection access — accepts data
that the caller has already fetched and converted to plain dicts.

Export is strict: every OFT row in *show_rows* must have a corresponding
non-empty entry in *specification_map*.  Missing entries abort the export
with a :class:`ValueError`.

Entity emission is driven by *entity_rows* — the legacy ``SHOW TAGS``-shape
rows returned by :func:`decl_api.fetch_entity_rows` (which delegates to
``FeatureStore.list_entities()``).  This is the only way orphan entities
(registered tags not referenced by any FV) make it into the exported
YAML, restoring the round-trip invariant: an unmodified export must
plan as all-``NO_CHANGE`` in full-directory mode.
"""

from __future__ import annotations

import json
import logging
import warnings
from pathlib import Path
from typing import Any, Optional

import yaml

from snowflake.ml.feature_store.decl.state import _ENTITY_TAG_PREFIX, _parse_oft_name

logger = logging.getLogger(__name__)


# YAML keys that should appear at the top of a feature view document, in this
# order, when present.  Any keys not listed here are appended after these.
_FV_TOP_LEVEL_ORDER: tuple[str, ...] = (
    "kind",
    "name",
    "version",
    "database",
    "schema",
    "online",
    "scheduling_state",
    "ordered_entity_column_names",
    "timestamp_field",
    "feature_granularity_sec",
    "feature_aggregation_method",
    "sources",
    "features",
    "udf",
)


def _ordered_fv_doc(fv_spec: dict[str, Any]) -> dict[str, Any]:
    """Return *fv_spec* re-ordered with well-known keys first.

    Python ``dict`` preserves insertion order, and PyYAML respects it when
    serializing — so this gives the emitted YAML a predictable layout while
    leaving any unknown keys to trail at the end.

    Args:
        fv_spec: Feature view dict to re-order.

    Returns:
        New dict with the same keys, ordered with well-known keys first.
    """
    ordered: dict[str, Any] = {}
    for key in _FV_TOP_LEVEL_ORDER:
        if key in fv_spec:
            ordered[key] = fv_spec[key]
    for key, value in fv_spec.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def _build_full_fidelity_fv(
    full_spec: dict[str, Any],
    *,
    fallback_name: str,
    fallback_version: str,
    fallback_database: str,
    fallback_schema: str,
    scheduling_state: str,
) -> dict[str, Any]:
    """Build a YAML-ready feature view dict from a parsed spec JSON document.

    Args:
        full_spec: The spec JSON returned by ``DESCRIBE ... TYPE = SPECIFICATION``.
            Expected shape: ``{kind, metadata, offline_configs, spec, ...}``.
        fallback_name: Name to use if ``metadata.name`` is absent.
        fallback_version: Version to use if ``metadata.version`` is absent.
        fallback_database: Database to use if ``metadata.database`` is absent.
        fallback_schema: Schema to use if ``metadata.schema`` is absent.
        scheduling_state: Scheduling state from the SHOW row (may be ``""``).

    Returns:
        Dict ready to be passed through :func:`_ordered_fv_doc` and serialized.
    """
    kind = full_spec.get("kind", "StreamingFeatureView")
    metadata = full_spec.get("metadata", {}) if isinstance(full_spec.get("metadata"), dict) else {}
    inner = full_spec.get("spec", {}) if isinstance(full_spec.get("spec"), dict) else {}

    fv_doc: dict[str, Any] = {
        "kind": kind,
        "name": metadata.get("name", fallback_name),
        "version": metadata.get("version", fallback_version),
        "database": metadata.get("database", fallback_database),
        "schema": metadata.get("schema", fallback_schema),
        "online": True,
    }
    if scheduling_state:
        fv_doc["scheduling_state"] = scheduling_state

    if "ordered_entity_column_names" in inner:
        fv_doc["ordered_entity_column_names"] = list(inner["ordered_entity_column_names"])

    if "timestamp_field" in inner and inner["timestamp_field"] is not None:
        fv_doc["timestamp_field"] = inner["timestamp_field"]
    if "feature_granularity_sec" in inner and inner["feature_granularity_sec"] is not None:
        fv_doc["feature_granularity_sec"] = inner["feature_granularity_sec"]
    if "feature_aggregation_method" in inner and inner["feature_aggregation_method"] is not None:
        fv_doc["feature_aggregation_method"] = inner["feature_aggregation_method"]
    # Pass ``target_lag_sec`` through unchanged.  Batch FVs in particular
    # carry it at the top of ``spec`` (with no aggregation windows), and
    # without this passthrough the exported YAML drops the value, the
    # compiler omits it from the local spec, and the round-trip hash
    # diverges from the deployed payload.
    if "target_lag_sec" in inner and inner["target_lag_sec"] is not None:
        fv_doc["target_lag_sec"] = inner["target_lag_sec"]

    sources = inner.get("sources")
    if isinstance(sources, list):
        fv_doc["sources"] = [dict(s) if isinstance(s, dict) else s for s in sources]

    features = inner.get("features")
    if isinstance(features, list):
        fv_doc["features"] = [dict(f) if isinstance(f, dict) else f for f in features]

    udf = inner.get("udf")
    if isinstance(udf, dict) and udf:
        # The live SPECIFICATION JSON already uses the authoring-shape
        # keys ``name`` / ``engine``; only ``function_definition`` needs to
        # become the authoring alias ``source`` for the YAML to round-trip
        # cleanly through :func:`spec_compiler._compile_udf`.  Note: the
        # source body is later extracted to a sibling ``.py`` file by
        # :func:`_extract_udf_to_py_file`, so the YAML actually carries
        # ``udf.file`` rather than an inline ``udf.source``.
        fv_doc["udf"] = dict(udf)

    return fv_doc


def _extract_udf_to_py_file(
    fv_doc: dict[str, Any],
    fv_dir: Path,
    file_stem: str,
) -> Optional[str]:
    """Externalize ``fv_doc['udf']['function_definition']`` to a sibling ``.py`` file.

    Mutates *fv_doc* in place: when a non-empty ``function_definition`` string
    is present, it is removed from the ``udf`` block and replaced with a
    ``file`` key holding the bare filename (relative to *fv_dir*).  The source
    is written to ``<fv_dir>/<file_stem>.py``.  When ``function_definition``
    is missing, empty, or non-string, no file is written and the ``udf`` block
    is left untouched.

    The bare-filename convention matches what
    :func:`compiler.inline_udf_source` resolves (it joins ``udf.file`` with
    the spec file's directory) — so the exported YAML round-trips through
    ``snow feature apply`` without manual edits.

    Args:
        fv_doc: Feature view dict being assembled for YAML serialization.
        fv_dir: Directory in which the FV YAML will be written.
        file_stem: Base filename (typically the FV name) used for the ``.py``
            sidecar.

    Returns:
        Absolute path to the written ``.py`` file as a string, or ``None`` if
        no extraction occurred.
    """
    udf = fv_doc.get("udf")
    if not isinstance(udf, dict):
        return None
    source = udf.get("function_definition")
    if not isinstance(source, str) or not source:
        return None

    udf_filename = f"{file_stem}.py"
    udf_path = fv_dir / udf_filename
    udf_path.write_text(source)
    udf.pop("function_definition", None)
    udf["file"] = udf_filename
    return str(udf_path)


# Mapping from SPECIFICATION JSON ``source_type`` (as emitted by Snowflake)
# to the authoring-format top-level ``kind`` for the datasource YAML.  The
# ``Request`` and ``Features`` source kinds are intentionally excluded —
# they describe synthetic realtime-FV inputs that have no external system
# to materialize as a top-level datasource.
_SOURCE_TYPE_TO_KIND: dict[str, str] = {
    "Stream": "StreamingSource",
    "BatchSource": "BatchSource",
    "OfflineTable": "BatchSource",
    "SQLDataSource": "SQLDataSource",
}

_REALTIME_SYNTHETIC_SOURCE_TYPES: frozenset[str] = frozenset({"Request", "Features"})

_DS_TOP_LEVEL_ORDER: tuple[str, ...] = (
    "kind",
    "name",
    "version",
    "type",
    "source_database",
    "source_schema",
    "table",
    "query",
    "columns",
)

# Fields copied verbatim from the FV inline source dict to the emitted
# datasource YAML, when present on the source.  ``type`` is only honoured for
# StreamingSource (see :func:`_collect_datasources`); for non-streaming kinds
# any stray ``type`` key on the FV source dict is ignored.
_DS_PASSTHROUGH_FIELDS: tuple[str, ...] = (
    "source_database",
    "source_schema",
    "table",
    "query",
    "version",
)


def _ordered_ds_doc(ds_spec: dict[str, Any]) -> dict[str, Any]:
    """Return *ds_spec* re-keyed in the canonical authoring order.

    Mirrors :func:`_ordered_fv_doc`: well-known keys come first in a fixed
    order; any unknown keys retain their insertion order at the end.

    Args:
        ds_spec: Datasource dict to re-order.

    Returns:
        New dict with the same keys, ordered with well-known keys first.
    """
    ordered: dict[str, Any] = {}
    for key in _DS_TOP_LEVEL_ORDER:
        if key in ds_spec:
            ordered[key] = ds_spec[key]
    for key, value in ds_spec.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def _collect_datasources(
    specification_map: dict[str, dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Build datasource dicts from the union of every FV's ``spec.sources[]``.

    Groups by lowercase source name (so case differences across FVs collapse
    to one entry) and merges columns into a superset (deduped by lowercase
    column name).  The first occurrence's case is preserved for the emitted
    name and column names; the returned dict is keyed by that case-preserved
    emit name so callers can use it directly as the YAML filename.

    Strict-fail on conflict: if two FVs reference the same source with the
    same column but disagree on its ``type``, raises :class:`ValueError`
    naming the datasource, the column, and both contributing FVs.  The same
    rule applies to top-level passthrough fields (``source_database``,
    ``source_schema``, ``table``, ``query``, ``version``) and to the
    StreamingSource ``type`` field — any disagreement is a hard error.

    Realtime synthetic source types (``Request``, ``Features``) are silently
    skipped — they have no external system to materialize as a top-level
    datasource.  Any other unrecognised ``source_type`` value raises
    :class:`ValueError` naming the offending value.

    Args:
        specification_map: Map of OFT name → parsed spec JSON, as returned by
            ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE = SPECIFICATION``.

    Returns:
        Dict keyed by case-preserved emit name → datasource spec dict, each
        ready for :func:`_ordered_ds_doc` and YAML serialization.

    Raises:
        ValueError: On any conflict between two FVs (column type, passthrough
            field, or kind), or on an unrecognised ``source_type`` value.
    """
    by_name: dict[str, dict[str, Any]] = {}
    name_case: dict[str, str] = {}
    col_index: dict[str, dict[str, tuple[str, Optional[str], str]]] = {}
    meta_index: dict[str, dict[str, tuple[Any, str]]] = {}

    for oft_name, full_spec in specification_map.items():
        if not isinstance(full_spec, dict):
            continue
        metadata = full_spec.get("metadata") if isinstance(full_spec.get("metadata"), dict) else {}
        fv_name = metadata.get("name") or oft_name or "<unknown>"
        inner = full_spec.get("spec") if isinstance(full_spec.get("spec"), dict) else {}
        sources = inner.get("sources") if isinstance(inner, dict) else None
        if not isinstance(sources, list):
            continue

        for src in sources:
            if not isinstance(src, dict):
                continue
            source_type = src.get("source_type", "")
            if source_type in _REALTIME_SYNTHETIC_SOURCE_TYPES:
                continue
            kind = _SOURCE_TYPE_TO_KIND.get(source_type)
            if kind is None:
                raise ValueError(
                    f"datasource export: source '{src.get('name', '<unknown>')}' in feature view "
                    f"'{fv_name}' has unrecognised source_type '{source_type}'."
                )
            raw_name = src.get("name")
            if not raw_name:
                continue
            lower_name = str(raw_name).lower()

            if lower_name not in by_name:
                emit_name = str(raw_name)
                ds: dict[str, Any] = {"kind": kind, "name": emit_name}
                if kind == "StreamingSource":
                    ds["type"] = src.get("type") or "REST"
                for fld in _DS_PASSTHROUGH_FIELDS:
                    if src.get(fld) is not None:
                        ds[fld] = src[fld]
                ds["columns"] = []
                by_name[lower_name] = ds
                name_case[lower_name] = emit_name
                col_index[lower_name] = {}
                meta_index[lower_name] = {}
                if kind == "StreamingSource":
                    meta_index[lower_name]["type"] = (ds["type"], fv_name)
                for fld in _DS_PASSTHROUGH_FIELDS:
                    if fld in ds:
                        meta_index[lower_name][fld] = (ds[fld], fv_name)
            else:
                ds = by_name[lower_name]
                if ds["kind"] != kind:
                    prev_fv = next(iter(meta_index[lower_name].values()))[1] if meta_index[lower_name] else "<unknown>"
                    raise ValueError(
                        f"datasource export: source '{name_case[lower_name]}' has conflicting "
                        f"kinds: '{ds['kind']}' (from feature view '{prev_fv}') vs "
                        f"'{kind}' (from feature view '{fv_name}')."
                    )
                check_fields: tuple[str, ...] = _DS_PASSTHROUGH_FIELDS
                if kind == "StreamingSource":
                    check_fields = ("type",) + _DS_PASSTHROUGH_FIELDS
                for fld in check_fields:
                    src_val = src.get(fld)
                    if src_val is None:
                        continue
                    current = meta_index[lower_name]
                    if fld in current:
                        prev_val, prev_fv = current[fld]
                        if prev_val != src_val:
                            raise ValueError(
                                f"datasource export: source '{name_case[lower_name]}' field "
                                f"'{fld}' conflicts: '{prev_val}' (from feature view "
                                f"'{prev_fv}') vs '{src_val}' (from feature view '{fv_name}')."
                            )
                    else:
                        current[fld] = (src_val, fv_name)
                        ds[fld] = src_val

            cols = src.get("columns")
            if not isinstance(cols, list):
                continue
            for col in cols:
                if not isinstance(col, dict):
                    continue
                col_name = col.get("name")
                if not col_name:
                    continue
                lower_col = str(col_name).lower()
                col_type = col.get("type")
                if lower_col in col_index[lower_name]:
                    prev_col_name, prev_type, prev_fv = col_index[lower_name][lower_col]
                    if col_type != prev_type:
                        raise ValueError(
                            f"datasource export: source '{name_case[lower_name]}' column "
                            f"'{prev_col_name}' type conflicts: '{prev_type}' (from feature "
                            f"view '{prev_fv}') vs '{col_type}' (from feature view "
                            f"'{fv_name}')."
                        )
                else:
                    col_index[lower_name][lower_col] = (str(col_name), col_type, fv_name)
                    by_name[lower_name]["columns"].append(dict(col))

    return {name_case[lower_name]: ds for lower_name, ds in by_name.items()}


def _entity_cols_from_full_spec(full_spec: dict[str, Any]) -> list[str]:
    """Return the join-key column names from a full spec JSON document.

    Args:
        full_spec: Spec JSON returned by ``DESCRIBE ... TYPE = SPECIFICATION``.

    Returns:
        List of entity column names, or an empty list if absent.
    """
    inner = full_spec.get("spec", {}) if isinstance(full_spec.get("spec"), dict) else {}
    cols = inner.get("ordered_entity_column_names")
    if isinstance(cols, list):
        return [str(c) for c in cols]
    return []


def _entity_name_from_row(row: dict[str, Any]) -> Optional[str]:
    """Return the prefix-stripped entity name from a SHOW TAGS row.

    Mirrors :func:`state._build_entity_object` so the exporter and the
    applied-state parser produce identical canonical names.  Rows whose
    ``name`` does not carry the ``SNOWML_FEATURE_STORE_ENTITY_`` prefix
    are skipped (defensive — a non-entity tag should not appear in the
    list returned by :func:`decl_api.fetch_entity_rows`).

    Args:
        row: One row dict from
            :func:`decl_api.fetch_entity_rows`.

    Returns:
        The uppercase entity name, or ``None`` if the row is malformed.
    """
    raw_name = row.get("name") or row.get("NAME") or ""
    if not isinstance(raw_name, str) or not raw_name:
        return None
    if not raw_name.startswith(_ENTITY_TAG_PREFIX):
        return None
    return raw_name[len(_ENTITY_TAG_PREFIX) :].upper()


def _join_keys_from_row(row: dict[str, Any]) -> list[str]:
    """Decode the join-key list from a SHOW TAGS row's ``allowed_values``.

    Mirrors the parsing in :func:`state._build_entity_object`: prefer a
    list value verbatim, otherwise treat ``allowed_values`` as JSON, with
    a final fallback to a comma-split form for legacy SHOW TAGS output.

    Args:
        row: One row dict from
            :func:`decl_api.fetch_entity_rows`.

    Returns:
        List of join-key column names (preserving case).  Empty when
        ``allowed_values`` is absent or unparsable.
    """
    raw = row.get("allowed_values") or row.get("ALLOWED_VALUES") or row.get("allowed_values_list")
    if not raw:
        return []
    if isinstance(raw, list):
        return [str(v) for v in raw]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(v) for v in parsed]
        except (json.JSONDecodeError, TypeError):
            pass
        return [v.strip() for v in raw.strip("[]").split(",") if v.strip()]
    return []


def _entity_yaml_from_row(row: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Build a full-fidelity entity authoring dict from a SHOW TAGS row.

    The shape mirrors what :func:`state._build_entity_object` emits as
    ``spec_payload`` (minus the ``database`` / ``schema`` fields, which
    the loader fills in from the directory layout).  Per-join-key types
    are not carried by tag rows, so every join key is normalised to
    ``StringType`` — matching the applied-state path so the structural
    fingerprints align (see :func:`invariants._structural_fingerprint`).

    The ``description`` field carries the tag's ``comment`` so the
    user-authored description round-trips back into authoring YAML.

    Args:
        row: One row dict from
            :func:`decl_api.fetch_entity_rows`.

    Returns:
        Authoring-format entity dict ready for YAML serialization, or
        ``None`` if the row is missing a recognisable entity name.
    """
    entity_name = _entity_name_from_row(row)
    if not entity_name:
        return None

    join_keys = _join_keys_from_row(row)
    if not join_keys:
        # Defensive: an entity tag with no allowed_values is a degenerate
        # state, but we still want to emit a YAML so the planner sees it
        # (and produces NO_CHANGE on round-trip).  Use the entity name
        # itself as the implicit join-key column.
        join_keys = [entity_name]

    spec: dict[str, Any] = {
        "kind": "Entity",
        "name": entity_name,
        "join_keys": [{"name": jk.upper(), "type": "StringType"} for jk in join_keys],
    }
    comment = row.get("comment") or row.get("COMMENT")
    if isinstance(comment, str) and comment:
        spec["description"] = comment
    return spec


def _legacy_fv_derived_entity_yaml(col_name: str) -> dict[str, Any]:
    """Legacy stub used when *entity_rows* is unavailable.

    Preserves the pre-list_entities behaviour: a minimal entity YAML
    derived solely from an FV's ``ordered_entity_column_names`` entry.
    Lossy (no description, the join-key column is the entity name
    itself) but the structural fingerprint still matches because the
    Entity fingerprint is name-only — see
    :func:`invariants._structural_fingerprint`.

    Args:
        col_name: Entity column name from
            ``ordered_entity_column_names``.

    Returns:
        Authoring-format entity dict ready for YAML serialization.
    """
    return {
        "kind": "Entity",
        "name": col_name,
        "join_keys": [{"name": col_name, "type": "StringType"}],
    }


def export_specs(
    show_rows: list[dict[str, Any]],
    describe_rows_by_oft: dict[str, list[dict[str, Any]]],
    output_dir: str,
    database: str,
    schema: str,
    *,
    specification_map: Optional[dict[str, dict[str, Any]]] = None,
    entity_rows: Optional[list[dict[str, Any]]] = None,
) -> dict[str, Any]:
    """Reconstruct YAML specs from raw Snowflake query results and write to disk.

    Strict mode: every row in ``SHOW ONLINE FEATURE TABLES`` must have a
    matching non-empty entry in *specification_map* (the parsed JSON
    returned by ``DESCRIBE ONLINE FEATURE TABLE <name> TYPE =
    SPECIFICATION``).  When that requirement is met, each YAML preserves
    UDF source, source column schemas, feature aggregations
    (function/window/offset), granularity, and target lag — enabling a
    round-trip ``snow feature apply`` without manual edits.

    Entity YAML emission is driven by *entity_rows* (the legacy SHOW
    TAGS-shape rows returned by :func:`decl_api.fetch_entity_rows`).
    Every entity tag is materialised to YAML — including orphan tags
    not referenced by any FV — and every FV's
    ``ordered_entity_column_names`` is cross-checked against the
    provided rows so a deployed FV referencing an unknown entity is a
    hard error.  When *entity_rows* is ``None`` (or empty), the
    exporter falls back to the legacy FV-derived emission and emits
    a :class:`DeprecationWarning` to alert the caller — the legacy
    path leaks orphan entities and breaks the round-trip invariant.

    Datasource YAML files are written for the deduped column-superset
    of every FV's ``spec.sources[]`` entry.

    Args:
        show_rows: Rows from ``SHOW ONLINE FEATURE TABLES`` (list of dicts).
        describe_rows_by_oft: Map of OFT name → ``DESCRIBE`` rows (list of
            dicts).  Retained for forward compatibility; not consumed in
            strict mode.
        output_dir: Base output directory.  A ``<database>.<schema>``
            subdirectory is created inside it.
        database: Connection database name, used as the directory prefix and
            as a fallback when a row lacks one.
        schema: Connection schema name, used as the directory prefix and as
            a fallback when a row lacks one.
        specification_map: Map of OFT name → parsed spec JSON returned by
            ``DESCRIBE ... TYPE = SPECIFICATION``.  Required for every OFT
            in *show_rows*; missing or empty entries abort the export.
        entity_rows: Rows from
            ``SHOW TAGS LIKE 'SNOWML_FEATURE_STORE_ENTITY_%'`` (or the
            equivalent imperative ``FeatureStore.list_entities()``
            output).  When provided, these rows are the authoritative
            source of truth for entity emission: every row produces a
            YAML stub, and every FV ``ordered_entity_column_names``
            entry is validated against the row set.  When omitted or
            empty, the exporter falls back to the legacy FV-derived
            emission and emits a :class:`DeprecationWarning`.

    Returns:
        Dict with keys:

        - ``status``: ``"exported"``
        - ``directory``: Absolute path to the ``<database>.<schema>`` base dir,
          or ``""`` if both *show_rows* and *entity_rows* are empty.
        - ``files``: List of absolute paths to the written YAML files.

    Raises:
        ValueError: If any OFT in *show_rows* has no corresponding entry in
            *specification_map* (or maps to an empty/non-dict value);
            if a FV's ``ordered_entity_column_names`` references an
            entity name absent from *entity_rows*; if two FVs disagree
            on a datasource column type, kind, or passthrough field;
            or if a FV source carries an unrecognised ``source_type``
            value.
    """
    del describe_rows_by_oft  # retained in signature for forward compatibility

    use_entity_rows = entity_rows is not None and len(entity_rows) > 0
    if not use_entity_rows:
        # entity_rows=None means the caller didn't bother; entity_rows=[]
        # means either "no entities registered" or "the caller forgot to
        # fetch" — we cannot distinguish, so warn unconditionally.  The
        # legacy fallback below preserves pre-fix behaviour for callers
        # not yet updated.
        warnings.warn(
            "export_specs called without entity_rows: orphan entity tags will be "
            "missed and snow feature plan ./... may emit spurious DROP_ENTITY ops. "
            "Pass the output of decl_api.fetch_entity_rows(...) as entity_rows= to "
            "preserve the export ↔ plan round-trip invariant.",
            DeprecationWarning,
            stacklevel=2,
        )

    # Empty input means there is genuinely nothing to export (no FVs and
    # no entity tags).  This preserves the pre-fix early-return semantics
    # for the trivial "fresh schema" case.
    if not show_rows and not use_entity_rows:
        return {"status": "exported", "directory": "", "files": []}

    spec_map = specification_map or {}

    base = Path(output_dir) / f"{database}.{schema}"
    entities_dir = base / "entities"
    fv_dir = base / "feature_views"
    for d in (entities_dir, fv_dir):
        d.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Pre-validate FV ↔ entity_rows consistency before writing any files.
    # When entity_rows is authoritative, every FV-referenced entity must
    # appear in the row set; otherwise the deployed runtime is in an
    # inconsistent state and we abort cleanly to avoid emitting a
    # half-baked tree that won't re-apply.
    # ------------------------------------------------------------------
    known_entity_names: set[str] = set()
    if use_entity_rows:
        assert entity_rows is not None  # narrow for type-checkers
        for row in entity_rows:
            ent_name = _entity_name_from_row(row)
            if ent_name:
                known_entity_names.add(ent_name)

        for row in show_rows:
            raw_name = row.get("name", "")
            full_spec = spec_map.get(raw_name)
            if not isinstance(full_spec, dict) or not full_spec:
                continue  # downstream loop will raise the strict error
            for col_name in _entity_cols_from_full_spec(full_spec):
                if col_name.upper() not in known_entity_names:
                    raise ValueError(
                        f"OFT '{raw_name}' references entity column "
                        f"'{col_name}' which is not present in entity_rows. "
                        "The deployed runtime is inconsistent; aborting export "
                        "before any partial state is written.  Re-run after "
                        "verifying the entity tag exists, or relax to legacy "
                        "FV-derived emission by passing entity_rows=None."
                    )

    seen_entities: set[str] = set()
    created: list[str] = []

    for row in show_rows:
        raw_name = row.get("name", "")
        db = row.get("database_name", database)
        sch = row.get("schema_name", schema)
        scheduling_state = row.get("scheduling_state", "")

        full_spec = spec_map.get(raw_name)
        if not isinstance(full_spec, dict) or not full_spec:
            raise ValueError(
                f"DESCRIBE … TYPE = SPECIFICATION returned no spec for OFT "
                f"'{raw_name}'. Cannot export without authoritative specification."
            )

        fallback_name, fallback_version = _parse_oft_name(raw_name)
        fv_doc = _build_full_fidelity_fv(
            full_spec,
            fallback_name=fallback_name,
            fallback_version=fallback_version,
            fallback_database=db,
            fallback_schema=sch,
            scheduling_state=scheduling_state,
        )
        entity_cols = _entity_cols_from_full_spec(full_spec)
        file_stem = str(fv_doc.get("name") or fallback_name)

        # Extract UDF source into a sibling ``.py`` file before serializing the
        # YAML, so the YAML carries a ``file:`` reference instead of inlining
        # the source.  This mirrors the authoring format (``UDF.file`` in
        # ``spec_models.py``) and is reversed by ``compiler.inline_udf_source``
        # when the YAML is later loaded for ``snow feature apply``.
        udf_py_path = _extract_udf_to_py_file(fv_doc, fv_dir, file_stem)

        fv_path = fv_dir / f"{file_stem}.yaml"
        fv_path.write_text(yaml.dump(_ordered_fv_doc(fv_doc), default_flow_style=False, sort_keys=False))
        created.append(str(fv_path))
        if udf_py_path is not None:
            created.append(udf_py_path)

        # Legacy FV-derived path: only used when entity_rows is not
        # authoritative.  Kept as a backwards-compatibility fallback so
        # callers not yet updated to pass entity_rows still produce
        # something usable (with the DeprecationWarning above).
        if not use_entity_rows:
            for col_name in entity_cols:
                if col_name in seen_entities:
                    continue
                seen_entities.add(col_name)
                entity_spec = _legacy_fv_derived_entity_yaml(col_name)
                entity_path = entities_dir / f"{col_name}.yaml"
                entity_path.write_text(yaml.dump(entity_spec, default_flow_style=False))
                created.append(str(entity_path))

    # Authoritative entity emission: drive directly from entity_rows.
    # Every tag (referenced or orphan) gets a YAML.  Naming + casing
    # match :func:`state._build_entity_object` so structural
    # fingerprints align and the planner reports NO_CHANGE on an
    # unmodified round-trip.
    if use_entity_rows:
        assert entity_rows is not None  # narrow for type-checkers
        for row in entity_rows:
            entity_spec = _entity_yaml_from_row(row)
            if entity_spec is None:
                continue
            ent_name = entity_spec["name"]
            if ent_name in seen_entities:
                continue
            seen_entities.add(ent_name)
            entity_path = entities_dir / f"{ent_name}.yaml"
            entity_path.write_text(yaml.dump(entity_spec, default_flow_style=False, sort_keys=False))
            created.append(str(entity_path))

    # Datasource emission must come AFTER all FV/entity files are written but
    # BEFORE the ``datasources/`` directory is created — a ValueError raised by
    # ``_collect_datasources`` (column-type or kind/passthrough conflict, or an
    # unrecognised ``source_type``) must propagate cleanly without leaving any
    # partially-written datasource files on disk.
    datasources = _collect_datasources(spec_map)
    if datasources:
        datasources_dir = base / "datasources"
        datasources_dir.mkdir(parents=True, exist_ok=True)
        for emit_name, ds_spec in datasources.items():
            ds_path = datasources_dir / f"{emit_name}.yaml"
            ds_path.write_text(yaml.dump(_ordered_ds_doc(ds_spec), default_flow_style=False, sort_keys=False))
            created.append(str(ds_path))

    return {"status": "exported", "directory": str(base), "files": created}
