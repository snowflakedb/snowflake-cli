"""Standalone enum definitions for the declarative feature store library.

This module is fully self-contained — it does not import from
``snowflake.ml.feature_store.spec.enums`` or any other snowml module.
All enums inherit ``(str, Enum)`` so they serialize naturally in JSON/YAML.
"""

from enum import Enum


class FSBaseType(str, Enum):
    """Canonical feature store type vocabulary.

    Values mirror Snowpark Python SDK class names. These are the types
    used in all YAML, JSON, and compiled output.
    """

    StringType = "StringType"
    LongType = "LongType"
    DoubleType = "DoubleType"
    DecimalType = "DecimalType"
    BooleanType = "BooleanType"
    TimestampType = "TimestampType"


class FeatureViewKind(str, Enum):
    """The kind of feature view being defined."""

    StreamingFeatureView = "StreamingFeatureView"
    RealtimeFeatureView = "RealtimeFeatureView"
    BatchFeatureView = "BatchFeatureView"


class SourceType(str, Enum):
    """The type of data source for a feature view."""

    Stream = "Stream"
    Request = "Request"
    Features = "Features"
    BatchSource = "BatchSource"
    SQLDataSource = "SQLDataSource"


class FeatureAggregationMethod(str, Enum):
    """The aggregation method for feature computation."""

    tiles = "tiles"
    continuous = "continuous"


class OpKind(str, Enum):
    """The kind of plan operation."""

    CREATE_ENTITY = "CREATE_ENTITY"
    CREATE_SOURCE = "CREATE_SOURCE"
    CREATE_FV = "CREATE_FV"
    CREATE_FG = "CREATE_FG"
    UPDATE_SOURCE = "UPDATE_SOURCE"
    UPDATE_FV = "UPDATE_FV"
    RECREATE_FV = "RECREATE_FV"
    DROP_ENTITY = "DROP_ENTITY"
    DROP_SOURCE = "DROP_SOURCE"
    DROP_FV = "DROP_FV"
    DROP_FG = "DROP_FG"
    NO_CHANGE = "NO_CHANGE"


# Python-friendly aliases resolved to FSBaseType values during compilation.
TYPE_ALIASES: dict[str, str] = {
    "str": FSBaseType.StringType,
    "string": FSBaseType.StringType,
    "int": FSBaseType.LongType,
    "integer": FSBaseType.LongType,
    "long": FSBaseType.LongType,
    "float": FSBaseType.DoubleType,
    "double": FSBaseType.DoubleType,
    "number": FSBaseType.DoubleType,
    "decimal": FSBaseType.DecimalType,
    "bool": FSBaseType.BooleanType,
    "boolean": FSBaseType.BooleanType,
    "datetime": FSBaseType.TimestampType,
    "timestamp": FSBaseType.TimestampType,
}


def normalize_type(raw_type: str) -> str:
    """Resolve a type string to its FSBaseType value.

    Accepts FSBaseType names directly (e.g. ``"StringType"``) or
    Python-friendly aliases (e.g. ``"str"``, ``"float"``). Unknown types
    are returned unchanged.

    Args:
        raw_type: A type string to normalize.

    Returns:
        The canonical FSBaseType value string, or ``raw_type`` if not recognized.
    """
    if raw_type in {t.value for t in FSBaseType}:
        return raw_type
    return TYPE_ALIASES.get(raw_type.lower(), raw_type)
