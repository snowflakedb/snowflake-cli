"""The ``@feature_view`` decorator for the Python authoring style.

Allows feature views to be defined as decorated functions where the
function body becomes the UDF's ``function_definition``.

All imports are self-contained — no imports from snowflake.ml.feature_store.spec,
snowflake.snowpark, or snowflake.connector.
"""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Optional, Union

from snowflake.ml.feature_store.decl.spec_models import (
    UDF,
    Feature,
    FeatureView,
    FSColumn,
    SourceRef,
)


def feature_view(
    name: str,
    ordered_entity_column_names: list[Any],
    sources: list[Union[SourceRef, Any]],
    features: list[Feature],
    *,
    kind: str = "StreamingFeatureView",
    database: Optional[str] = None,
    schema: Optional[str] = None,
    version: Optional[str] = None,
    description: Optional[str] = None,
    online: bool = False,
    offline: bool = False,
    timestamp_field: Optional[str] = None,
    feature_granularity: Optional[Union[str, int]] = None,
    udf_output_columns: Optional[list[FSColumn]] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator to define a ``FeatureView`` from a UDF function.

    The decorated function becomes the UDF's ``function_definition``.
    The resulting wrapper function has a ``_feature_view`` attribute
    holding the constructed :class:`~snowflake.ml.feature_store.decl.spec_models.FeatureView`.

    Example::

        @feature_view(
            name="click_stats",
            ordered_entity_column_names=["user_id"],
            sources=[SourceRef(name="events", source_type="Stream")],
            features=[...],
            online=True,
        )
        def compute_click_stats(df):
            ...

    Args:
        name: Feature view name.
        ordered_entity_column_names: Entity join-key column names or Entity objects.
        sources: Source references for the feature view.
        features: Feature definitions.
        kind: Feature view kind string (default ``"StreamingFeatureView"``).
        database: Target database.
        schema: Target schema.
        version: Spec version string.
        description: Human-readable description.
        online: Whether to enable online serving.
        offline: Whether to enable offline serving.
        timestamp_field: Name of the timestamp column.
        feature_granularity: Aggregation granularity (duration string or seconds).
        udf_output_columns: Column schema for the UDF output.

    Returns:
        A decorator that attaches ``_feature_view`` to the wrapped function.
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        udf = UDF(
            name=func.__name__,
            engine="pandas",
            function_definition=func,
            output_columns=udf_output_columns or [],
        )

        fv = FeatureView(
            kind=kind,
            name=name,
            database=database,
            schema_=schema,
            version=version,
            description=description,
            online=online,
            offline=offline,
            timestamp_field=timestamp_field,
            feature_granularity=feature_granularity,
            ordered_entity_column_names=ordered_entity_column_names,
            sources=sources,
            udf=udf,
            features=features,
        )

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return func(*args, **kwargs)

        wrapper._feature_view = fv  # type: ignore[attr-defined]
        return wrapper

    return decorator
