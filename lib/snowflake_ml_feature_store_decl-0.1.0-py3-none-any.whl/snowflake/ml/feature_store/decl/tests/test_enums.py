"""Tests for decl/enums.py — FSBaseType, TYPE_ALIASES, normalize_type()."""

from snowflake.ml.feature_store.decl.enums import (
    TYPE_ALIASES,
    FeatureAggregationMethod,
    FeatureViewKind,
    FSBaseType,
    OpKind,
    SourceType,
    normalize_type,
)


class TestFSBaseType:
    def test_all_values(self):
        assert FSBaseType.StringType == "StringType"
        assert FSBaseType.LongType == "LongType"
        assert FSBaseType.DoubleType == "DoubleType"
        assert FSBaseType.DecimalType == "DecimalType"
        assert FSBaseType.BooleanType == "BooleanType"
        assert FSBaseType.TimestampType == "TimestampType"

    def test_is_string_subclass(self):
        for member in FSBaseType:
            assert isinstance(member, str)

    def test_six_members(self):
        assert len(list(FSBaseType)) == 6


class TestFeatureViewKind:
    def test_all_values(self):
        assert FeatureViewKind.StreamingFeatureView == "StreamingFeatureView"
        assert FeatureViewKind.RealtimeFeatureView == "RealtimeFeatureView"
        assert FeatureViewKind.BatchFeatureView == "BatchFeatureView"

    def test_three_members(self):
        assert len(list(FeatureViewKind)) == 3


class TestSourceType:
    def test_all_values(self):
        assert SourceType.Stream == "Stream"
        assert SourceType.Request == "Request"
        assert SourceType.Features == "Features"
        assert SourceType.BatchSource == "BatchSource"
        assert SourceType.SQLDataSource == "SQLDataSource"


class TestFeatureAggregationMethod:
    def test_all_values(self):
        assert FeatureAggregationMethod.tiles == "tiles"
        assert FeatureAggregationMethod.continuous == "continuous"


class TestOpKind:
    def test_create_ops(self):
        assert OpKind.CREATE_ENTITY == "CREATE_ENTITY"
        assert OpKind.CREATE_SOURCE == "CREATE_SOURCE"
        assert OpKind.CREATE_FV == "CREATE_FV"
        assert OpKind.CREATE_FG == "CREATE_FG"

    def test_update_ops(self):
        assert OpKind.UPDATE_SOURCE == "UPDATE_SOURCE"
        assert OpKind.UPDATE_FV == "UPDATE_FV"
        assert OpKind.RECREATE_FV == "RECREATE_FV"

    def test_drop_ops(self):
        assert OpKind.DROP_ENTITY == "DROP_ENTITY"
        assert OpKind.DROP_SOURCE == "DROP_SOURCE"
        assert OpKind.DROP_FV == "DROP_FV"
        assert OpKind.DROP_FG == "DROP_FG"


class TestTypeAliases:
    def test_string_aliases(self):
        assert TYPE_ALIASES["str"] == "StringType"
        assert TYPE_ALIASES["string"] == "StringType"

    def test_integer_aliases(self):
        assert TYPE_ALIASES["int"] == "LongType"
        assert TYPE_ALIASES["integer"] == "LongType"

    def test_float_aliases(self):
        assert TYPE_ALIASES["float"] == "DoubleType"
        assert TYPE_ALIASES["number"] == "DoubleType"

    def test_decimal_alias(self):
        assert TYPE_ALIASES["decimal"] == "DecimalType"

    def test_boolean_aliases(self):
        assert TYPE_ALIASES["bool"] == "BooleanType"
        assert TYPE_ALIASES["boolean"] == "BooleanType"

    def test_timestamp_aliases(self):
        assert TYPE_ALIASES["datetime"] == "TimestampType"
        assert TYPE_ALIASES["timestamp"] == "TimestampType"

    def test_all_values_are_fsbasetype_values(self):
        canonical_values = {t.value for t in FSBaseType}
        for alias, canonical in TYPE_ALIASES.items():
            assert canonical in canonical_values, f"Alias '{alias}' maps to unknown '{canonical}'"

    def test_eleven_aliases(self):
        from snowflake.ml.feature_store.decl.enums import TYPE_ALIASES

        assert len(TYPE_ALIASES) == 13


class TestNormalizeType:
    def test_passthrough_canonical_names(self):
        for member in FSBaseType:
            assert normalize_type(member.value) == member.value

    def test_str_alias(self):
        assert normalize_type("str") == "StringType"

    def test_string_alias(self):
        assert normalize_type("string") == "StringType"

    def test_int_alias(self):
        assert normalize_type("int") == "LongType"

    def test_integer_alias(self):
        assert normalize_type("integer") == "LongType"

    def test_float_alias(self):
        assert normalize_type("float") == "DoubleType"

    def test_number_alias(self):
        assert normalize_type("number") == "DoubleType"

    def test_decimal_alias(self):
        assert normalize_type("decimal") == "DecimalType"

    def test_bool_alias(self):
        assert normalize_type("bool") == "BooleanType"

    def test_boolean_alias(self):
        assert normalize_type("boolean") == "BooleanType"

    def test_datetime_alias(self):
        assert normalize_type("datetime") == "TimestampType"

    def test_timestamp_alias(self):
        assert normalize_type("timestamp") == "TimestampType"

    def test_case_insensitive_aliases(self):
        assert normalize_type("STR") == "StringType"
        assert normalize_type("INT") == "LongType"
        assert normalize_type("FLOAT") == "DoubleType"
        assert normalize_type("BOOL") == "BooleanType"

    def test_unknown_type_passthrough(self):
        assert normalize_type("MyCustomType") == "MyCustomType"
        assert normalize_type("unknown_xyz") == "unknown_xyz"
