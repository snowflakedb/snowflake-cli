"""Tests for decl/service.py — pure parsing / SQL-building functions."""

from __future__ import annotations

import json

import pytest

from snowflake.ml.feature_store.decl.service import (
    build_ingest_request,
    build_ingest_url,
    build_query_request,
    build_query_url,
    get_service_endpoint,
    parse_ingest_response,
    parse_query_response,
    parse_service_status,
    service_sql,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_RAW_STATUS_WITH_ENDPOINTS = json.dumps(
    {
        "status": "RUNNING",
        "message": "Service is healthy",
        "endpoints": [
            {"name": "ingest", "url": "https://ingest.example.snowflakecomputing.com"},
            {"name": "query", "url": "https://query.example.snowflakecomputing.com"},
        ],
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-02T00:00:00Z",
    }
)

_RAW_STATUS_NO_ENDPOINTS = json.dumps(
    {
        "status": "INITIALIZING",
        "message": "Service is starting up",
    }
)


# ---------------------------------------------------------------------------
# parse_service_status
# ---------------------------------------------------------------------------


class TestParseServiceStatus:
    def test_returns_dict(self):
        result = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)
        assert isinstance(result, dict)

    def test_status_field_present(self):
        result = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)
        assert result["status"] == "RUNNING"

    def test_message_field_present(self):
        result = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)
        assert result["message"] == "Service is healthy"

    def test_endpoints_list_present(self):
        result = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)
        assert isinstance(result.get("endpoints"), list)
        assert len(result["endpoints"]) == 2

    def test_endpoint_has_name_and_url(self):
        result = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)
        ep = result["endpoints"][0]
        assert "name" in ep
        assert "url" in ep

    def test_timestamps_preserved(self):
        result = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)
        assert result.get("created_at") == "2024-01-01T00:00:00Z"
        assert result.get("updated_at") == "2024-01-02T00:00:00Z"

    def test_missing_endpoints_key_returns_empty_list(self):
        result = parse_service_status(_RAW_STATUS_NO_ENDPOINTS)
        assert result.get("endpoints", []) == [] or "endpoints" not in result

    def test_invalid_json_raises_value_error(self):
        with pytest.raises((ValueError, json.JSONDecodeError)):
            parse_service_status("not-json{{{")

    def test_already_dict_passthrough(self):
        # Should also accept a pre-parsed dict (optional convenience)
        result = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)
        assert result["status"] == "RUNNING"


# ---------------------------------------------------------------------------
# get_service_endpoint
# ---------------------------------------------------------------------------


class TestGetServiceEndpoint:
    def setup_method(self):
        self.status = parse_service_status(_RAW_STATUS_WITH_ENDPOINTS)

    def test_finds_ingest_endpoint(self):
        url = get_service_endpoint(self.status, "ingest")
        assert url == "https://ingest.example.snowflakecomputing.com"

    def test_finds_query_endpoint(self):
        url = get_service_endpoint(self.status, "query")
        assert url == "https://query.example.snowflakecomputing.com"

    def test_missing_name_returns_none(self):
        url = get_service_endpoint(self.status, "nonexistent")
        assert url is None

    def test_empty_endpoints_returns_none(self):
        status = parse_service_status(_RAW_STATUS_NO_ENDPOINTS)
        url = get_service_endpoint(status, "ingest")
        assert url is None


# ---------------------------------------------------------------------------
# service_sql
# ---------------------------------------------------------------------------


class TestServiceSql:
    def setup_method(self):
        self.sqls = service_sql("MYDB", "MYSCHEMA")

    def test_returns_dict(self):
        assert isinstance(self.sqls, dict)

    def test_get_status_key_present(self):
        assert "get_status" in self.sqls

    def test_create_key_present(self):
        assert "create" in self.sqls

    def test_drop_key_present(self):
        assert "drop" in self.sqls

    def test_show_ofts_key_present(self):
        assert "show_ofts" in self.sqls

    def test_drop_oft_template_key_present(self):
        assert "drop_oft_template" in self.sqls

    def test_get_status_contains_db_and_schema(self):
        sql = self.sqls["get_status"]
        assert "MYDB" in sql
        assert "MYSCHEMA" in sql

    def test_create_contains_db_and_schema(self):
        sql = self.sqls["create"]
        assert "MYDB" in sql
        assert "MYSCHEMA" in sql

    def test_drop_contains_db_and_schema(self):
        sql = self.sqls["drop"]
        assert "MYDB" in sql
        assert "MYSCHEMA" in sql

    def test_show_ofts_contains_db_and_schema(self):
        sql = self.sqls["show_ofts"]
        assert "MYDB" in sql
        assert "MYSCHEMA" in sql

    def test_drop_oft_template_is_template(self):
        tmpl = self.sqls["drop_oft_template"]
        # Must contain a placeholder for the OFT name
        assert "{name}" in tmpl or "%" in tmpl or "<name>" in tmpl

    def test_get_status_calls_system_function(self):
        sql = self.sqls["get_status"]
        assert "SYSTEM$GET_FEATURE_STORE_RUNTIME_STATUS" in sql

    def test_create_calls_system_function(self):
        sql = self.sqls["create"]
        assert "SYSTEM$CREATE_FEATURE_STORE_RUNTIME" in sql

    def test_drop_calls_system_function(self):
        sql = self.sqls["drop"]
        assert "SYSTEM$DROP_FEATURE_STORE_RUNTIME" in sql


# ---------------------------------------------------------------------------
# build_ingest_request
# ---------------------------------------------------------------------------


class TestBuildIngestRequest:
    def test_returns_dict(self):
        body = build_ingest_request("my_source", [{"k": "v"}])
        assert isinstance(body, dict)

    def test_records_key_present(self):
        body = build_ingest_request("my_source", [{"k": "v"}])
        assert "records" in body

    def test_source_name_is_key_in_records(self):
        records = [{"user_id": "u1", "val": 1}]
        body = build_ingest_request("events_source", records)
        assert "events_source" in body["records"]

    def test_records_payload_matches_input(self):
        records = [{"user_id": "u1"}, {"user_id": "u2"}]
        body = build_ingest_request("src", records)
        assert body["records"]["src"] == records

    def test_empty_records_allowed(self):
        body = build_ingest_request("src", [])
        assert body["records"]["src"] == []


# ---------------------------------------------------------------------------
# build_query_request
# ---------------------------------------------------------------------------


class TestBuildQueryRequest:
    def test_returns_dict(self):
        body = build_query_request("my_fv", [{"user_id": "u1"}])
        assert isinstance(body, dict)

    def test_feature_view_name_key_present(self):
        body = build_query_request("my_fv", [{"user_id": "u1"}])
        assert "feature_view_name" in body

    def test_keys_key_present(self):
        body = build_query_request("my_fv", [{"user_id": "u1"}])
        assert "keys" in body

    def test_feature_view_name_matches_input(self):
        body = build_query_request("user_clicks_v1", [])
        assert body["feature_view_name"] == "user_clicks_v1"

    def test_keys_match_input(self):
        keys = [{"user_id": "u1"}, {"user_id": "u2"}]
        body = build_query_request("fv", keys)
        assert body["keys"] == keys


# ---------------------------------------------------------------------------
# parse_ingest_response
# ---------------------------------------------------------------------------


class TestParseIngestResponse:
    def test_passthrough_on_success(self):
        raw = {"status": "ok", "ingested": 5}
        result = parse_ingest_response(raw)
        assert result["status"] == "ok"

    def test_returns_dict(self):
        result = parse_ingest_response({"status": "ok"})
        assert isinstance(result, dict)

    def test_error_response_preserved(self):
        raw = {"status": "error", "error": "bad request"}
        result = parse_ingest_response(raw)
        assert result["status"] == "error"
        assert "error" in result


# ---------------------------------------------------------------------------
# parse_query_response
# ---------------------------------------------------------------------------


class TestParseQueryResponse:
    def test_passthrough_on_success(self):
        raw = {"status": "ok", "features": [{"val": 1}]}
        result = parse_query_response(raw)
        assert result["status"] == "ok"

    def test_returns_dict(self):
        result = parse_query_response({"features": []})
        assert isinstance(result, dict)

    def test_features_preserved(self):
        raw = {"features": [{"user_id": "u1", "score": 0.9}]}
        result = parse_query_response(raw)
        assert result.get("features") == raw["features"]


# ---------------------------------------------------------------------------
# build_ingest_url / build_query_url
# ---------------------------------------------------------------------------


class TestBuildUrls:
    def test_ingest_url_appends_path(self):
        url = build_ingest_url("https://base.snowflakecomputing.com")
        assert url.endswith("api/v1/ingest")

    def test_ingest_url_no_double_slash(self):
        url = build_ingest_url("https://base.snowflakecomputing.com/")
        assert "//" not in url.replace("https://", "")

    def test_query_url_appends_path(self):
        url = build_query_url("https://base.snowflakecomputing.com")
        assert url.endswith("api/v1/query")

    def test_query_url_no_double_slash(self):
        url = build_query_url("https://base.snowflakecomputing.com/")
        assert "//" not in url.replace("https://", "")

    def test_ingest_url_preserves_base(self):
        url = build_ingest_url("https://my-host.snowflakecomputing.com")
        assert "my-host.snowflakecomputing.com" in url

    def test_query_url_preserves_base(self):
        url = build_query_url("https://my-host.snowflakecomputing.com")
        assert "my-host.snowflakecomputing.com" in url
