"""Tests for decl/spec_models.py — Pydantic v2 authoring models."""

from snowflake.ml.feature_store.decl.spec_models import (
    UDF,
    BatchSource,
    Entity,
    Feature,
    FeatureGroup,
    FeatureView,
    FeatureViewRef,
    FSColumn,
    SourceRef,
    SpecBase,
    SQLDataSource,
    StreamingSource,
)


class TestFSColumn:
    def test_minimal_construction(self):
        col = FSColumn(name="user_id", type="StringType")
        assert col.name == "user_id"
        assert col.type == "StringType"

    def test_optional_fields_default_none(self):
        col = FSColumn(name="x", type="IntegerType")
        assert col.length is None
        assert col.precision is None
        assert col.scale is None
        assert col.tz is None
        assert col.default is None

    def test_all_optional_fields(self):
        col = FSColumn(
            name="amount",
            type="DecimalType",
            precision=10,
            scale=2,
            length=None,
            tz=None,
            default=0.0,
        )
        assert col.precision == 10
        assert col.scale == 2
        assert col.default == 0.0

    def test_model_dump_excludes_none_by_default(self):
        col = FSColumn(name="x", type="FloatType")
        d = col.model_dump(exclude_none=True)
        assert "length" not in d
        assert d["name"] == "x"
        assert d["type"] == "FloatType"

    def test_model_dump_is_plain_dict(self):
        col = FSColumn(name="ts", type="TimestampType", tz="UTC")
        d = col.model_dump()
        assert isinstance(d, dict)
        assert d["tz"] == "UTC"


class TestSpecBase:
    def test_defaults(self):
        s = SpecBase()
        assert s.kind == ""
        assert s.name == ""
        assert s.version is None
        assert s.database is None
        assert s.schema_ is None
        assert s.description is None

    def test_construction(self):
        s = SpecBase(kind="Entity", name="customer", version="v1")
        assert s.kind == "Entity"
        assert s.name == "customer"
        assert s.version == "v1"


class TestEntity:
    def test_default_kind(self):
        e = Entity(name="customer")
        assert e.kind == "Entity"

    def test_join_keys(self):
        e = Entity(
            name="customer",
            join_keys=[FSColumn(name="customer_id", type="StringType")],
        )
        assert len(e.join_keys) == 1
        assert e.join_keys[0].name == "customer_id"

    def test_empty_join_keys_by_default(self):
        e = Entity(name="customer")
        assert e.join_keys == []


class TestStreamingSource:
    def test_default_kind_and_type(self):
        s = StreamingSource(name="events")
        assert s.kind == "StreamingSource"
        assert s.type == "REST"

    def test_columns(self):
        s = StreamingSource(
            name="events",
            columns=[FSColumn(name="event_id", type="StringType")],
        )
        assert len(s.columns) == 1


class TestBatchSource:
    def test_default_kind(self):
        b = BatchSource(name="orders")
        assert b.kind == "BatchSource"

    def test_source_location_fields(self):
        b = BatchSource(
            name="orders",
            source_database="PROD_DB",
            source_schema="PUBLIC",
            table="ORDER_HISTORY",
        )
        assert b.source_database == "PROD_DB"
        assert b.source_schema == "PUBLIC"
        assert b.table == "ORDER_HISTORY"


class TestSQLDataSource:
    def test_inherits_from_batch_source(self):
        s = SQLDataSource(name="sql_src")
        assert s.kind == "SQLDataSource"

    def test_query_field(self):
        s = SQLDataSource(name="sql_src", query="SELECT * FROM t")
        assert s.query == "SELECT * FROM t"

    def test_inherits_columns(self):
        s = SQLDataSource(
            name="sql_src",
            columns=[FSColumn(name="id", type="IntegerType")],
        )
        assert len(s.columns) == 1


class TestSourceRef:
    def test_construction(self):
        ref = SourceRef(name="events_src", source_type="Stream")
        assert ref.name == "events_src"
        assert ref.source_type == "Stream"


class TestUDF:
    def test_defaults(self):
        udf = UDF(name="compute_fn")
        assert udf.engine == "pandas"
        assert udf.file is None
        assert udf.function_definition is None
        assert udf.output_columns == []

    def test_with_file(self):
        udf = UDF(name="fn", file="./compute.py")
        assert udf.file == "./compute.py"

    def test_with_callable(self):
        def my_fn(df):
            return df

        udf = UDF(name="my_fn", function_definition=my_fn)
        assert callable(udf.function_definition)

    def test_with_string_source(self):
        udf = UDF(name="fn", function_definition="def fn(df):\n    return df\n")
        assert isinstance(udf.function_definition, str)


class TestFeature:
    def test_defaults(self):
        f = Feature()
        assert f.function is None
        assert f.window is None
        assert f.offset is None
        assert f.function_params is None

    def test_construction(self):
        f = Feature(
            source_column=FSColumn(name="val", type="FloatType"),
            output_column=FSColumn(name="sum_val_7d", type="FloatType"),
            function="sum",
            window="7d",
        )
        assert f.function == "sum"
        assert f.window == "7d"

    def test_window_accepts_int(self):
        f = Feature(window=3600)
        assert f.window == 3600

    def test_offset_accepts_string(self):
        f = Feature(offset="1m")
        assert f.offset == "1m"


class TestFeatureView:
    def test_default_kind(self):
        fv = FeatureView(name="my_fv")
        assert fv.kind == "StreamingFeatureView"

    def test_online_offline_defaults(self):
        fv = FeatureView(name="my_fv")
        assert fv.online is False
        assert fv.offline is False

    def test_sources_accepts_list(self):
        fv = FeatureView(
            name="my_fv",
            sources=[SourceRef(name="src", source_type="Stream")],
        )
        assert len(fv.sources) == 1

    def test_sources_accepts_source_objects(self):
        src = StreamingSource(name="events")
        fv = FeatureView(name="my_fv", sources=[src])
        assert fv.sources[0] is src

    def test_entity_column_names_list(self):
        fv = FeatureView(
            name="my_fv",
            ordered_entity_column_names=["customer_id"],
        )
        assert fv.ordered_entity_column_names == ["customer_id"]

    def test_entity_column_names_accepts_entity_objects(self):
        entity = Entity(
            name="customer",
            join_keys=[FSColumn(name="customer_id", type="StringType")],
        )
        fv = FeatureView(
            name="my_fv",
            ordered_entity_column_names=[entity],
        )
        assert isinstance(fv.ordered_entity_column_names[0], Entity)

    def test_udf_field(self):
        udf = UDF(name="compute")
        fv = FeatureView(name="my_fv", udf=udf)
        assert fv.udf is udf

    def test_features_list(self):
        fv = FeatureView(
            name="my_fv",
            features=[Feature(function="sum", window="1h")],
        )
        assert len(fv.features) == 1

    def test_duration_fields_accept_strings(self):
        fv = FeatureView(
            name="my_fv",
            feature_granularity="5m",
            target_lag="1h",
        )
        assert fv.feature_granularity == "5m"
        assert fv.target_lag == "1h"

    def test_duration_fields_accept_ints(self):
        fv = FeatureView(name="my_fv", feature_granularity=300)
        assert fv.feature_granularity == 300


class TestFeatureViewRef:
    def test_construction(self):
        ref = FeatureViewRef(name="my_fv")
        assert ref.name == "my_fv"


class TestFeatureGroup:
    def test_default_kind(self):
        fg = FeatureGroup(name="my_fg")
        assert fg.kind == "FeatureGroup"

    def test_feature_views_accepts_feature_view_objects(self):
        fv = FeatureView(name="fv1")
        fg = FeatureGroup(name="my_fg", feature_views=[fv])
        assert isinstance(fg.feature_views[0], FeatureView)

    def test_feature_views_accepts_refs(self):
        ref = FeatureViewRef(name="fv1")
        fg = FeatureGroup(name="my_fg", feature_views=[ref])
        assert isinstance(fg.feature_views[0], FeatureViewRef)

    def test_empty_feature_views_by_default(self):
        fg = FeatureGroup(name="my_fg")
        assert fg.feature_views == []


class TestSerializability:
    """All models must serialize to plain dicts — no Snowpark types."""

    def test_entity_model_dump(self):
        e = Entity(
            name="customer",
            version="v1",
            join_keys=[FSColumn(name="customer_id", type="StringType")],
        )
        d = e.model_dump()
        assert d["kind"] == "Entity"
        assert d["join_keys"][0]["name"] == "customer_id"

    def test_feature_view_model_dump(self):
        fv = FeatureView(
            name="fv",
            online=True,
            sources=[SourceRef(name="src", source_type="Stream")],
            features=[Feature(function="sum", window="1h")],
        )
        d = fv.model_dump()
        assert d["kind"] == "StreamingFeatureView"
        assert d["online"] is True
        assert d["sources"][0]["name"] == "src"
        assert d["features"][0]["function"] == "sum"


class TestFeatureViewAggregationMethod:
    def test_default_is_none(self):
        fv = FeatureView(name="fv")
        assert fv.feature_aggregation_method is None

    def test_accepts_continuous(self):
        fv = FeatureView(name="fv", feature_aggregation_method="continuous")
        assert fv.feature_aggregation_method == "continuous"

    def test_accepts_tiles(self):
        fv = FeatureView(name="fv", feature_aggregation_method="tiles")
        assert fv.feature_aggregation_method == "tiles"

    def test_model_dump_includes_field_when_set(self):
        fv = FeatureView(name="fv", feature_aggregation_method="continuous")
        d = fv.model_dump()
        assert d["feature_aggregation_method"] == "continuous"

    def test_model_dump_field_is_none_when_not_set(self):
        fv = FeatureView(name="fv")
        d = fv.model_dump()
        assert d["feature_aggregation_method"] is None
