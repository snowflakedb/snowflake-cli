"""Tests for decl/planner.py — plan generation."""

from __future__ import annotations

from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.invariants import (
    _model_to_dict,
    _spec_key,
    _structural_fingerprint_hash,
)
from snowflake.ml.feature_store.decl.planner import generate_plan
from snowflake.ml.feature_store.decl.spec_models import (
    Entity,
    FeatureView,
    StreamingSource,
)
from snowflake.ml.feature_store.decl.types import (
    AppliedObject,
    AppliedState,
    PlanOptions,
    SpecBatch,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _entity_model(name: str = "user") -> Entity:
    return Entity.model_validate(
        {
            "kind": "Entity",
            "name": name,
            "database": "DB",
            "schema_": "SCH",
            "join_keys": [{"name": "user_id", "type": "StringType"}],
        }
    )


def _source_model(name: str = "clicks") -> StreamingSource:
    return StreamingSource.model_validate(
        {
            "kind": "StreamingSource",
            "name": name,
            "database": "DB",
            "schema_": "SCH",
            "columns": [],
        }
    )


def _fv_model(name: str = "click_fv", version: str = "V1") -> FeatureView:
    return FeatureView.model_validate(
        {
            "kind": "StreamingFeatureView",
            "name": name,
            "database": "DB",
            "schema_": "SCH",
            "version": version,
            "ordered_entity_column_names": ["user_id"],
            "sources": [{"name": "clicks", "source_type": "Stream"}],
            "features": [
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event", "type": "StringType"},
                }
            ],
        }
    )


def _batch(*models) -> SpecBatch:
    return SpecBatch(specs=list(models), source_files=[])


def _empty_applied() -> AppliedState:
    return AppliedState(objects={})


def _applied_with_model(model) -> AppliedState:
    normalized = _model_to_dict(model)
    key = _spec_key(normalized)
    ao = AppliedObject(
        key=key,
        kind=normalized.get("kind", ""),
        name=normalized.get("name", ""),
        version=normalized.get("version"),
        content_hash=_structural_fingerprint_hash(normalized),
        spec_payload=normalized,
    )
    return AppliedState(objects={key: ao})


def _opts(**kwargs) -> PlanOptions:
    return PlanOptions(**kwargs)


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------


class TestGeneratePlan:
    def test_new_entity_produces_create_op(self):
        batch = _batch(_entity_model())
        plan = generate_plan(batch, _empty_applied(), _opts())
        kinds = [op.kind for op in plan.ops]
        assert OpKind.CREATE_ENTITY in kinds

    def test_new_fv_produces_create_fv_op(self):
        fv = _fv_model()
        batch = _batch(fv)
        plan = generate_plan(batch, _empty_applied(), _opts())
        kinds = [op.kind for op in plan.ops]
        assert OpKind.CREATE_FV in kinds

    def test_new_source_produces_create_source_op(self):
        batch = _batch(_source_model())
        plan = generate_plan(batch, _empty_applied(), _opts())
        kinds = [op.kind for op in plan.ops]
        assert OpKind.CREATE_SOURCE in kinds

    def test_unchanged_spec_produces_no_change_op(self):
        fv = _fv_model()
        applied = _applied_with_model(fv)
        batch = _batch(fv)
        plan = generate_plan(batch, applied, _opts())
        kinds = [op.kind for op in plan.ops]
        assert OpKind.NO_CHANGE in kinds

    def test_updated_spec_produces_recreate_fv_op(self):
        """Changed spec always produces RECREATE since OFTs cannot be updated in place."""
        old_fv = _fv_model(version="V1")
        new_fv = _fv_model(version="V2")
        applied = _applied_with_model(old_fv)
        batch = _batch(new_fv)
        plan = generate_plan(batch, applied, _opts())
        kinds = [op.kind for op in plan.ops]
        assert OpKind.RECREATE_FV in kinds

    def test_plan_ops_are_topologically_ordered(self):
        entity = _entity_model()
        source = _source_model()
        fv = _fv_model()
        # Pass in reverse order — plan should still sort correctly
        batch = _batch(fv, source, entity)
        plan = generate_plan(batch, _empty_applied(), _opts())
        names = [op.name for op in plan.ops]
        # Entity and source must come before FV
        if "click_fv" in names and "user" in names:
            assert names.index("user") < names.index("click_fv")

    def test_plan_op_includes_payload(self):
        fv = _fv_model()
        batch = _batch(fv)
        plan = generate_plan(batch, _empty_applied(), _opts())
        create_ops = [op for op in plan.ops if op.kind == OpKind.CREATE_FV]
        assert len(create_ops) == 1
        assert create_ops[0].payload != {}

    def test_plan_op_name_matches_spec_name(self):
        fv = _fv_model(name="my_fv")
        batch = _batch(fv)
        plan = generate_plan(batch, _empty_applied(), _opts())
        names = [op.name for op in plan.ops]
        assert "my_fv" in names

    def test_changed_spec_always_recreates(self):
        """OFTs cannot be updated in place — any change produces RECREATE."""
        old_fv_spec = {
            "kind": "StreamingFeatureView",
            "name": "click_fv",
            "database": "DB",
            "schema_": "SCH",
            "version": "V1",
            "ordered_entity_column_names": ["user_id"],
            "sources": [{"name": "clicks", "source_type": "Stream"}],
            "features": [
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event_upper", "type": "StringType"},
                    "function": "lower",
                }
            ],
        }
        new_fv_spec = {
            "kind": "StreamingFeatureView",
            "name": "click_fv",
            "database": "DB",
            "schema_": "SCH",
            "version": "V2",
            "ordered_entity_column_names": ["user_id"],
            "sources": [{"name": "clicks", "source_type": "Stream"}],
            "features": [
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event_upper", "type": "StringType"},
                    "function": "upper",
                }
            ],
        }
        old_fv = FeatureView.model_validate(old_fv_spec)
        new_fv = FeatureView.model_validate(new_fv_spec)
        applied = _applied_with_model(old_fv)
        batch = _batch(new_fv)
        # Even without allow_recreate, OFTs always recreate
        plan = generate_plan(batch, applied, _opts())
        recreate_ops = [op for op in plan.ops if op.kind == OpKind.RECREATE_FV]
        assert len(recreate_ops) == 1

    def test_allow_recreate_produces_recreate_op(self):
        old_fv_spec = {
            "kind": "StreamingFeatureView",
            "name": "click_fv",
            "database": "DB",
            "schema_": "SCH",
            "version": "V1",
            "ordered_entity_column_names": ["user_id"],
            "sources": [{"name": "clicks", "source_type": "Stream"}],
            "features": [
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event_upper", "type": "StringType"},
                    "function": "lower",
                }
            ],
        }
        new_fv_spec = {
            "kind": "StreamingFeatureView",
            "name": "click_fv",
            "database": "DB",
            "schema_": "SCH",
            "version": "V2",
            "ordered_entity_column_names": ["user_id"],
            "sources": [{"name": "clicks", "source_type": "Stream"}],
            "features": [
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event_upper", "type": "StringType"},
                    "function": "upper",  # changed function → destructive
                }
            ],
        }
        old_fv = FeatureView.model_validate(old_fv_spec)
        new_fv = FeatureView.model_validate(new_fv_spec)
        applied = _applied_with_model(old_fv)
        batch = _batch(new_fv)
        plan = generate_plan(batch, applied, _opts(allow_recreate=True))
        kinds = [op.kind for op in plan.ops]
        assert OpKind.RECREATE_FV in kinds

    def test_empty_batch_produces_empty_plan(self):
        plan = generate_plan(SpecBatch(), _empty_applied(), _opts())
        assert plan.ops == []

    def test_plan_warnings_for_no_change(self):
        fv = _fv_model()
        applied = _applied_with_model(fv)
        batch = _batch(fv)
        plan = generate_plan(batch, applied, _opts())
        # NO_CHANGE op is emitted; no warnings needed for this case
        kinds = [op.kind for op in plan.ops]
        assert OpKind.NO_CHANGE in kinds
