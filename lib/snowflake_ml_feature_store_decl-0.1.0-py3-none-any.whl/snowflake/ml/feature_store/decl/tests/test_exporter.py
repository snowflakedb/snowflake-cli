"""Tests for decl/exporter.py — export spec reconstruction from SHOW/DESCRIBE data."""

from __future__ import annotations

import yaml

# ---------------------------------------------------------------------------
# Helpers — shared test data
# ---------------------------------------------------------------------------

_SHOW_ROW_1 = {
    "name": "USER_CLICKS$V1$ONLINE",
    "database_name": "MYDB",
    "schema_name": "PUBLIC",
    "scheduling_state": "ACTIVE",
}

_DESCRIBE_ROW_PK = {
    "name": "USER_ID",
    "type": "VARCHAR",
    "primary key": "Y",
}
_DESCRIBE_ROW_FEAT = {
    "name": "EVENT_COUNT",
    "type": "NUMBER",
    "primary key": "N",
}

_DESCRIBE_ROWS_1 = [_DESCRIBE_ROW_PK, _DESCRIBE_ROW_FEAT]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestExportSpecsEmptyInput:
    def test_empty_show_rows_returns_early(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        result = export_specs(
            show_rows=[],
            describe_rows_by_oft={},
            output_dir=str(tmp_path),
            database="DB",
            schema="SCH",
        )
        assert result["status"] == "exported"
        assert result["files"] == []
        assert result["directory"] == ""


class TestExportSpecsDirectoryLayout:
    def test_base_dir_is_database_dot_schema(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        result = export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        assert "MYDB.PUBLIC" in result["directory"]

    def test_subdirectories_created(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        base = tmp_path / "MYDB.PUBLIC"
        assert (base / "feature_views").is_dir()
        assert (base / "entities").is_dir()


class TestExportSpecsFeatureViewYaml:
    def test_feature_view_file_written(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        result = export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        from pathlib import Path

        fv_files = [f for f in result["files"] if Path(f).parent.name == "feature_views"]
        assert len(fv_files) == 1

    def test_feature_view_yaml_content(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        fv_path = tmp_path / "MYDB.PUBLIC" / "feature_views" / "USER_CLICKS.yaml"
        assert fv_path.exists()
        data = yaml.safe_load(fv_path.read_text())
        assert data["kind"] == "StreamingFeatureView"
        assert data["name"] == "USER_CLICKS"
        assert data["version"] == "V1"
        assert data["online"] is True

    def test_feature_view_entity_cols_populated(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        fv_path = tmp_path / "MYDB.PUBLIC" / "feature_views" / "USER_CLICKS.yaml"
        data = yaml.safe_load(fv_path.read_text())
        assert "USER_ID" in data["ordered_entity_column_names"]


class TestExportSpecsPKDetection:
    def test_pk_detected_via_primary_key_key(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        rows = [{"name": "COL_A", "type": "VARCHAR", "primary key": "Y"}]
        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": rows},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        fv_path = tmp_path / "MYDB.PUBLIC" / "feature_views" / "USER_CLICKS.yaml"
        data = yaml.safe_load(fv_path.read_text())
        assert "COL_A" in data["ordered_entity_column_names"]

    def test_pk_detected_via_underscore_key(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        rows = [{"name": "COL_B", "type": "VARCHAR", "primary_key": "Y"}]
        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": rows},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        fv_path = tmp_path / "MYDB.PUBLIC" / "feature_views" / "USER_CLICKS.yaml"
        data = yaml.safe_load(fv_path.read_text())
        assert "COL_B" in data["ordered_entity_column_names"]

    def test_pk_detected_positionally(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        # 5th value (index 4) == "Y" triggers positional fallback
        rows = [{"name": "COL_C", "type": "VARCHAR", "kind": "COLUMN", "null?": "Y", "pk": "Y"}]
        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": rows},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        fv_path = tmp_path / "MYDB.PUBLIC" / "feature_views" / "USER_CLICKS.yaml"
        data = yaml.safe_load(fv_path.read_text())
        assert "COL_C" in data["ordered_entity_column_names"]

    def test_non_pk_column_not_in_entity_cols(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        rows = [{"name": "FEAT_COL", "type": "NUMBER", "primary key": "N"}]
        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": rows},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        fv_path = tmp_path / "MYDB.PUBLIC" / "feature_views" / "USER_CLICKS.yaml"
        data = yaml.safe_load(fv_path.read_text())
        assert "FEAT_COL" not in data["ordered_entity_column_names"]


class TestExportSpecsEntityDeduplication:
    def test_entity_written_once_across_two_feature_views(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        show_rows = [
            {
                "name": "FV_A$V1$ONLINE",
                "database_name": "DB",
                "schema_name": "SCH",
                "scheduling_state": "ACTIVE",
            },
            {
                "name": "FV_B$V1$ONLINE",
                "database_name": "DB",
                "schema_name": "SCH",
                "scheduling_state": "ACTIVE",
            },
        ]
        describe_rows = {
            "FV_A$V1$ONLINE": [{"name": "USER_ID", "type": "VARCHAR", "primary key": "Y"}],
            "FV_B$V1$ONLINE": [{"name": "USER_ID", "type": "VARCHAR", "primary key": "Y"}],
        }
        result = export_specs(
            show_rows=show_rows,
            describe_rows_by_oft=describe_rows,
            output_dir=str(tmp_path),
            database="DB",
            schema="SCH",
        )
        from pathlib import Path

        entity_files = [f for f in result["files"] if Path(f).parent.name == "entities"]
        assert len(entity_files) == 1

    def test_distinct_entities_both_written(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        show_rows = [
            {
                "name": "FV_A$V1$ONLINE",
                "database_name": "DB",
                "schema_name": "SCH",
                "scheduling_state": "ACTIVE",
            },
            {
                "name": "FV_B$V1$ONLINE",
                "database_name": "DB",
                "schema_name": "SCH",
                "scheduling_state": "ACTIVE",
            },
        ]
        describe_rows = {
            "FV_A$V1$ONLINE": [{"name": "USER_ID", "type": "VARCHAR", "primary key": "Y"}],
            "FV_B$V1$ONLINE": [{"name": "PRODUCT_ID", "type": "VARCHAR", "primary key": "Y"}],
        }
        result = export_specs(
            show_rows=show_rows,
            describe_rows_by_oft=describe_rows,
            output_dir=str(tmp_path),
            database="DB",
            schema="SCH",
        )
        from pathlib import Path

        entity_files = [f for f in result["files"] if Path(f).parent.name == "entities"]
        assert len(entity_files) == 2


class TestExportSpecsMissingDescribeData:
    def test_missing_describe_rows_produces_empty_cols(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={},  # no describe data
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        fv_path = tmp_path / "MYDB.PUBLIC" / "feature_views" / "USER_CLICKS.yaml"
        assert fv_path.exists()
        data = yaml.safe_load(fv_path.read_text())
        assert data["ordered_entity_column_names"] == []
        assert data["columns"] == []


class TestExportSpecsReturnValue:
    def test_status_is_exported(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        result = export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        assert result["status"] == "exported"

    def test_directory_key_present(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        result = export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        assert "directory" in result
        assert result["directory"] != ""

    def test_files_key_lists_created_paths(self, tmp_path):
        from snowflake.ml.feature_store.decl.exporter import export_specs

        result = export_specs(
            show_rows=[_SHOW_ROW_1],
            describe_rows_by_oft={"USER_CLICKS$V1$ONLINE": _DESCRIBE_ROWS_1},
            output_dir=str(tmp_path),
            database="MYDB",
            schema="PUBLIC",
        )
        assert isinstance(result["files"], list)
        assert len(result["files"]) >= 1
        for f in result["files"]:
            import os

            assert os.path.isfile(f), f"Expected file not found: {f}"
