"""Wheel isolation tests.

Verifies that:
1. No source file in ``decl/`` (excluding ``tests/``) imports from forbidden
   packages (``snowflake.ml.feature_store.spec``, ``snowflake.snowpark``,
   ``snowflake.connector``).
2. The built wheel contains only ``snowflake/ml/feature_store/decl/`` files
   (plus dist-info metadata).
3. The wheel does NOT contain namespace ``__init__.py`` files for
   ``snowflake/``, ``snowflake/ml/``, or ``snowflake/ml/feature_store/``.
"""

from __future__ import annotations

import ast
import pathlib
import zipfile

import pytest

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_DECL_ROOT = pathlib.Path(__file__).parent.parent  # …/decl/
_WHEEL_GLOB = sorted((_DECL_ROOT.parent / "decl_wheel" / "dist").glob("snowflake_ml_feature_store_decl-*.whl"))

_FORBIDDEN_PREFIXES = (
    "snowflake.ml.feature_store.spec",
    "snowflake.snowpark",
    "snowflake.connector",
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _collect_source_files() -> list[pathlib.Path]:
    """Return all .py files under decl/ that are NOT inside tests/."""
    return [
        p
        for p in _DECL_ROOT.rglob("*.py")
        if "tests" not in p.relative_to(_DECL_ROOT).parts and "__pycache__" not in p.parts
    ]


def _collect_imports(source: str) -> list[str]:
    """Parse *source* and return all top-level import module names.

    Skips imports inside try/except blocks (optional/guarded imports).
    """
    tree = ast.parse(source)
    names: list[str] = []
    # Collect nodes that are inside Try blocks
    guarded_nodes: set[int] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Try):
            for child in ast.walk(node):
                guarded_nodes.add(id(child))

    for node in ast.walk(tree):
        if id(node) in guarded_nodes:
            continue
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                names.append(node.module)
    return names


# ---------------------------------------------------------------------------
# Test 1 — no forbidden imports in production source files
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("source_file", _collect_source_files(), ids=lambda p: p.name)
def test_no_forbidden_imports(source_file: pathlib.Path) -> None:
    """Each production module in decl/ must not import forbidden packages."""
    source = source_file.read_text(encoding="utf-8")
    imports = _collect_imports(source)
    for imp in imports:
        for prefix in _FORBIDDEN_PREFIXES:
            assert not imp.startswith(prefix), (
                f"{source_file.name} imports '{imp}' which starts with " f"forbidden prefix '{prefix}'"
            )


# ---------------------------------------------------------------------------
# Test 2 — wheel contains only decl/ files
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not _WHEEL_GLOB, reason="wheel not yet built; run build first")
def test_wheel_contains_only_decl_files() -> None:
    """Every non-metadata entry in the wheel must live under snowflake/ml/feature_store/decl/."""
    whl_path = _WHEEL_GLOB[-1]
    with zipfile.ZipFile(whl_path) as zf:
        entries = zf.namelist()

    non_meta = [e for e in entries if not e.endswith(".dist-info/") and ".dist-info/" not in e]
    unexpected = [e for e in non_meta if not e.startswith("snowflake/ml/feature_store/decl/")]
    assert unexpected == [], f"Wheel {whl_path.name} contains unexpected entries: {unexpected}"


# ---------------------------------------------------------------------------
# Test 3 — wheel does NOT contain namespace __init__.py files
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not _WHEEL_GLOB, reason="wheel not yet built; run build first")
def test_wheel_no_namespace_init_files() -> None:
    """The wheel must not ship __init__.py for namespace packages."""
    whl_path = _WHEEL_GLOB[-1]
    forbidden_inits = {
        "snowflake/__init__.py",
        "snowflake/ml/__init__.py",
        "snowflake/ml/feature_store/__init__.py",
    }
    with zipfile.ZipFile(whl_path) as zf:
        entries = set(zf.namelist())

    present = forbidden_inits & entries
    assert not present, (
        f"Wheel {whl_path.name} should not contain namespace __init__.py files, " f"but found: {sorted(present)}"
    )


# ---------------------------------------------------------------------------
# Syntax / compile checks — catch IndentationError, SyntaxError early
# ---------------------------------------------------------------------------


class TestSourceFilesCompile:
    """Every .py file under decl/ must parse and compile without errors."""

    @pytest.mark.parametrize("src", _collect_source_files(), ids=lambda p: p.name)
    def test_source_file_compiles(self, src: pathlib.Path) -> None:
        """py_compile each source file — catches SyntaxError, IndentationError."""
        import py_compile

        py_compile.compile(str(src), doraise=True)

    @pytest.mark.parametrize("src", _collect_source_files(), ids=lambda p: p.name)
    def test_source_file_parses_as_ast(self, src: pathlib.Path) -> None:
        """ast.parse each source file — catches subtle AST-level issues."""
        source = src.read_text()
        ast.parse(source, filename=str(src))


class TestModulesImportable:
    """All public decl modules must be importable without errors."""

    _MODULES = [
        "snowflake.ml.feature_store.decl.api",
        "snowflake.ml.feature_store.decl.compiler",
        "snowflake.ml.feature_store.decl.dependencies",
        "snowflake.ml.feature_store.decl.enums",
        "snowflake.ml.feature_store.decl.errors",
        "snowflake.ml.feature_store.decl.examples",
        "snowflake.ml.feature_store.decl.exporter",
        "snowflake.ml.feature_store.decl.http",
        "snowflake.ml.feature_store.decl.invariants",
        "snowflake.ml.feature_store.decl.loader",
        "snowflake.ml.feature_store.decl.planner",
        "snowflake.ml.feature_store.decl.serializer",
        "snowflake.ml.feature_store.decl.service",
        "snowflake.ml.feature_store.decl.spec_models",
        "snowflake.ml.feature_store.decl.sql_generator",
        "snowflake.ml.feature_store.decl.state",
        "snowflake.ml.feature_store.decl.templating",
        "snowflake.ml.feature_store.decl.types",
    ]

    @pytest.mark.parametrize("module_name", _MODULES)
    def test_module_imports_cleanly(self, module_name: str) -> None:
        """importlib.import_module should succeed for every public module."""
        import importlib

        importlib.import_module(module_name)
