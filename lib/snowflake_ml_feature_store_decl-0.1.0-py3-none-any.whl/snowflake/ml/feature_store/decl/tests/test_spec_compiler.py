"""Tests for decl/spec_compiler.py — compile_to_spec and sanitize_json_for_dollar_quoting."""

import json

from snowflake.ml.feature_store.decl.spec_compiler import (
    compile_to_spec,
    sanitize_json_for_dollar_quoting,
)

# ---------------------------------------------------------------------------
# Shared test fixture
# ---------------------------------------------------------------------------

_SAMPLE_SPEC = {
    "kind": "StreamingFeatureView",
    "name": "user_event_features",
    "version": "v1",
    "ordered_entity_column_names": ["user_id"],
    "sources": [
        {
            "name": "user_events",
            "source_type": "Stream",
            "columns": [
                {"name": "user_id", "type": "StringType"},
                {"name": "timestamp", "type": "TimestampType"},
                {"name": "event_count", "type": "IntegerType"},
            ],
        }
    ],
    "udf": {
        "name": "compute_event_features",
        "engine": "pandas",
        "function_definition": "def compute_event_features(df):\n    return df\n",
        "output_columns": [
            {"name": "user_id", "type": "StringType"},
            {"name": "timestamp", "type": "TimestampType"},
            {"name": "event_count", "type": "IntegerType"},
            {"name": "total_value", "type": "FloatType"},
        ],
    },
    "features": [
        {
            "source_column": {"name": "event_count", "type": "IntegerType"},
            "output_column": {"name": "event_count_1h", "type": "IntegerType"},
            "function": "count",
            "window": "1h",
        },
        {
            "source_column": {"name": "event_count", "type": "IntegerType"},
            "output_column": {"name": "event_count_5m", "type": "IntegerType"},
            "function": "count",
            "window": "5m",
        },
    ],
    "timestamp_field": "timestamp",
    "feature_granularity": "5m",
}


# ---------------------------------------------------------------------------
# Basic top-level structure
# ---------------------------------------------------------------------------


class TestCompileToSpec:
    def test_basic_compilation_returns_dict(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert isinstance(result, dict)

    def test_kind_preserved(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["kind"] == "StreamingFeatureView"

    def test_online_store_type_is_postgres(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["online_store_type"] == "postgres"

    def test_result_has_all_top_level_keys(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert "kind" in result
        assert "metadata" in result
        assert "offline_configs" in result
        assert "spec" in result
        assert "online_store_type" in result


# ---------------------------------------------------------------------------
# metadata
# ---------------------------------------------------------------------------


class TestMetadata:
    def test_metadata_database(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["metadata"]["database"] == "DEMO_DB"

    def test_metadata_schema(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["metadata"]["schema"] == "PUBLIC"

    def test_metadata_name(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["metadata"]["name"] == "user_event_features"

    def test_metadata_version(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["metadata"]["version"] == "v1"

    def test_metadata_spec_format_version(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["metadata"]["spec_format_version"] == "1"

    def test_metadata_internal_data_version(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["metadata"]["internal_data_version"] == "1"

    def test_metadata_client_version_present(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert "client_version" in result["metadata"]
        assert isinstance(result["metadata"]["client_version"], str)
        assert len(result["metadata"]["client_version"]) > 0

    def test_metadata_reflects_caller_database_and_schema(self):
        result = compile_to_spec(_SAMPLE_SPEC, "MY_DB", "MY_SCHEMA")
        assert result["metadata"]["database"] == "MY_DB"
        assert result["metadata"]["schema"] == "MY_SCHEMA"


# ---------------------------------------------------------------------------
# offline_configs
# ---------------------------------------------------------------------------


class TestOfflineConfigs:
    def test_offline_configs_has_one_entry_with_udf(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert len(result["offline_configs"]) == 1

    def test_offline_config_store_type(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["offline_configs"][0]["store_type"] == "snowflake"

    def test_offline_config_table_type(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["offline_configs"][0]["table_type"] == "UDFTransformed"

    def test_offline_config_database(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["offline_configs"][0]["database"] == "DEMO_DB"

    def test_offline_config_schema(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["offline_configs"][0]["schema"] == "PUBLIC"

    def test_offline_config_table_name_uppercased_name(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["offline_configs"][0]["table"] == "USER_EVENT_FEATURES$V1$UDF_TRANSFORMED"

    def test_offline_config_table_name_preserves_version_case(self):
        spec = dict(_SAMPLE_SPEC)
        spec["version"] = "V2"
        result = compile_to_spec(spec, "DEMO_DB", "PUBLIC")
        assert result["offline_configs"][0]["table"] == "USER_EVENT_FEATURES$V2$UDF_TRANSFORMED"

    def test_offline_config_columns_from_udf_output_columns(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        cols = result["offline_configs"][0]["columns"]
        assert len(cols) == 4

    def test_offline_config_columns_content(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        cols = result["offline_configs"][0]["columns"]
        assert cols[0] == {"name": "user_id", "type": "StringType"}
        assert cols[1] == {"name": "timestamp", "type": "TimestampType"}
        assert cols[2] == {"name": "event_count", "type": "IntegerType"}
        assert cols[3] == {"name": "total_value", "type": "FloatType"}


# ---------------------------------------------------------------------------
# spec
# ---------------------------------------------------------------------------


class TestSpec:
    def test_ordered_entity_column_names(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["spec"]["ordered_entity_column_names"] == ["user_id"]

    def test_sources_count(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert len(result["spec"]["sources"]) == 1

    def test_sources_name_preserved(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["spec"]["sources"][0]["name"] == "user_events"

    def test_timestamp_field(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["spec"]["timestamp_field"] == "timestamp"

    def test_feature_granularity_sec_converted_from_string(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["spec"]["feature_granularity_sec"] == 300

    def test_feature_granularity_key_absent(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert "feature_granularity" not in result["spec"]

    def test_feature_granularity_sec_passthrough_when_already_int(self):
        spec = {k: v for k, v in _SAMPLE_SPEC.items()}
        spec = dict(_SAMPLE_SPEC)
        del spec["feature_granularity"]
        spec["feature_granularity_sec"] = 600
        result = compile_to_spec(spec, "DEMO_DB", "PUBLIC")
        assert result["spec"]["feature_granularity_sec"] == 600

    def test_features_window_sec_1h_to_3600(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        feat = result["spec"]["features"][0]
        assert feat["window_sec"] == 3600

    def test_features_window_sec_5m_to_300(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        feat = result["spec"]["features"][1]
        assert feat["window_sec"] == 300

    def test_features_window_key_absent(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        for feat in result["spec"]["features"]:
            assert "window" not in feat

    def test_features_window_sec_30s_to_30(self):
        spec = dict(_SAMPLE_SPEC)
        spec["features"] = [
            {
                "source_column": {"name": "val", "type": "DoubleType"},
                "output_column": {"name": "val_30s", "type": "DoubleType"},
                "function": "sum",
                "window": "30s",
            }
        ]
        result = compile_to_spec(spec, "DEMO_DB", "PUBLIC")
        assert result["spec"]["features"][0]["window_sec"] == 30

    def test_feature_aggregation_method_tiles_when_windows_present(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["spec"]["feature_aggregation_method"] == "tiles"

    def test_udf_function_definition_present(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert "function_definition" in result["spec"]["udf"]

    def test_udf_function_definition_content(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert "compute_event_features" in result["spec"]["udf"]["function_definition"]

    def test_udf_file_key_removed(self):
        spec = dict(_SAMPLE_SPEC)
        spec["udf"] = dict(_SAMPLE_SPEC["udf"])
        spec["udf"]["file"] = "./example_udf.py"
        result = compile_to_spec(spec, "DEMO_DB", "PUBLIC")
        assert "file" not in result["spec"]["udf"]

    def test_udf_name_and_engine(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert result["spec"]["udf"]["name"] == "compute_event_features"
        assert result["spec"]["udf"]["engine"] == "pandas"

    def test_udf_output_columns_in_spec_udf(self):
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        assert len(result["spec"]["udf"]["output_columns"]) == 4


# ---------------------------------------------------------------------------
# Features-only FV (no UDF)
# ---------------------------------------------------------------------------


class TestNoUdf:
    _NO_UDF_SPEC = {
        "kind": "StreamingFeatureView",
        "name": "simple_fv",
        "version": "v1",
        "ordered_entity_column_names": ["user_id"],
        "sources": [{"name": "src", "source_type": "Stream", "columns": []}],
        "features": [
            {
                "source_column": {"name": "val", "type": "DoubleType"},
                "output_column": {"name": "val_sum", "type": "DoubleType"},
                "function": "sum",
                "window": "30s",
            }
        ],
        "timestamp_field": "ts",
        "feature_granularity": "30s",
    }

    def test_offline_configs_empty_without_udf(self):
        result = compile_to_spec(self._NO_UDF_SPEC, "DB", "SCH")
        assert result["offline_configs"] == []

    def test_udf_absent_from_spec_without_udf(self):
        result = compile_to_spec(self._NO_UDF_SPEC, "DB", "SCH")
        assert "udf" not in result["spec"]

    def test_online_store_type_still_postgres_without_udf(self):
        result = compile_to_spec(self._NO_UDF_SPEC, "DB", "SCH")
        assert result["online_store_type"] == "postgres"

    def test_features_still_converted_without_udf(self):
        result = compile_to_spec(self._NO_UDF_SPEC, "DB", "SCH")
        assert result["spec"]["features"][0]["window_sec"] == 30


# ---------------------------------------------------------------------------
# Dollar-quoting sanitization
# ---------------------------------------------------------------------------


class TestSanitizeJsonForDollarQuoting:
    def test_double_dollar_replaced(self):
        result = sanitize_json_for_dollar_quoting('{"code": "$$python$$"}')
        assert "$$" not in result
        assert "$\\u0024" in result

    def test_single_dollar_unchanged(self):
        payload = '{"code": "$python"}'
        assert sanitize_json_for_dollar_quoting(payload) == payload

    def test_empty_string(self):
        assert sanitize_json_for_dollar_quoting("") == ""

    def test_no_dollars(self):
        payload = '{"key": "value"}'
        assert sanitize_json_for_dollar_quoting(payload) == payload

    def test_sanitized_json_round_trips(self):
        """Parsing the sanitized JSON restores the original $$ value."""
        spec = dict(_SAMPLE_SPEC)
        spec["udf"] = dict(_SAMPLE_SPEC["udf"])
        spec["udf"]["function_definition"] = "def fn():\n    x = '$$tag$$'\n"
        result = compile_to_spec(spec, "DB", "SCH")
        raw_json = json.dumps(result)
        sanitized = sanitize_json_for_dollar_quoting(raw_json)
        assert "$$" not in sanitized
        # Standard JSON parser decodes \u0024 back to $
        parsed = json.loads(sanitized)
        assert "$$tag$$" in parsed["spec"]["udf"]["function_definition"]


# ---------------------------------------------------------------------------
# Source column enrichment
# ---------------------------------------------------------------------------


class TestSourceColumnEnrichment:
    """Verify that sources without columns get enriched by the compiler."""

    _UDF_SPEC_NO_SOURCE_COLS = {
        "kind": "StreamingFeatureView",
        "name": "user_event_features",
        "version": "v1",
        "ordered_entity_column_names": ["user_id"],
        "sources": [
            {
                "name": "user_events",
                "source_type": "Stream",
                # No "columns" key — this is the bug scenario
            }
        ],
        "udf": {
            "name": "compute_event_features",
            "engine": "pandas",
            "function_definition": "def compute_event_features(df):\n    return df\n",
            "output_columns": [
                {"name": "user_id", "type": "StringType"},
                {"name": "timestamp", "type": "TimestampType"},
                {"name": "event_count", "type": "LongType"},
                {"name": "total_value", "type": "DoubleType"},
            ],
        },
        "features": [
            {
                "source_column": {"name": "event_count", "type": "LongType"},
                "output_column": {"name": "event_count_1h", "type": "LongType"},
                "function": "count",
                "window": "1h",
            },
        ],
        "timestamp_field": "timestamp",
        "feature_granularity": "5m",
    }

    def test_stream_source_without_columns_not_auto_enriched(self):
        """Stream source without columns should NOT be auto-enriched by compiler.

        Source columns must come from the datasource YAML, resolved by the
        apply pipeline before compilation — not inferred from UDF output.
        """
        result = compile_to_spec(self._UDF_SPEC_NO_SOURCE_COLS, "DEMO_DB", "PUBLIC")
        sources = result["spec"]["sources"]
        assert len(sources) == 1
        assert "columns" not in sources[0], (
            "Source should NOT have columns auto-enriched by compiler"
        )

    def test_stream_source_with_pre_resolved_columns_preserved(self):
        """If source already has columns (pre-resolved), they are preserved."""
        spec = dict(self._UDF_SPEC_NO_SOURCE_COLS)
        spec["sources"] = [
            {
                "name": "user_events",
                "source_type": "Stream",
                "columns": [
                    {"name": "user_id", "type": "StringType"},
                    {"name": "event_type", "type": "StringType"},
                    {"name": "event_value", "type": "DoubleType"},
                    {"name": "timestamp", "type": "TimestampType"},
                ],
            }
        ]
        result = compile_to_spec(spec, "DEMO_DB", "PUBLIC")
        cols = result["spec"]["sources"][0]["columns"]
        assert len(cols) == 4
        assert cols[1]["name"] == "event_type"
        assert cols[2]["name"] == "event_value"

    def test_explicit_source_columns_preserved(self):
        """If source already has columns, they should NOT be overwritten."""
        result = compile_to_spec(_SAMPLE_SPEC, "DEMO_DB", "PUBLIC")
        cols = result["spec"]["sources"][0]["columns"]
        # _SAMPLE_SPEC has 3 explicit source columns
        assert len(cols) == 3
        assert cols[0]["name"] == "user_id"
        assert cols[1]["name"] == "timestamp"
        assert cols[2]["name"] == "event_count"

    def test_non_stream_source_not_enriched(self):
        """Non-Stream sources (e.g. BatchSource) should not get auto-enriched."""
        spec = {
            "kind": "BatchFeatureView",
            "name": "batch_fv",
            "version": "v1",
            "ordered_entity_column_names": ["user_id"],
            "sources": [{"name": "batch_src", "source_type": "BatchSource"}],
            "features": [
                {
                    "source_column": {"name": "val", "type": "DoubleType"},
                    "output_column": {"name": "val", "type": "DoubleType"},
                },
            ],
            "timestamp_field": "ts",
        }
        result = compile_to_spec(spec, "DB", "SCH")
        # BatchSource should not be enriched
        assert "columns" not in result["spec"]["sources"][0]

    def test_no_udf_stream_without_columns_not_enriched(self):
        """Stream source without UDF and without columns should not be enriched."""
        spec = {
            "kind": "StreamingFeatureView",
            "name": "simple_stream",
            "version": "v1",
            "ordered_entity_column_names": ["user_id"],
            "sources": [{"name": "events", "source_type": "Stream"}],
            "features": [
                {
                    "source_column": {"name": "amount", "type": "DoubleType"},
                    "output_column": {"name": "amount_sum", "type": "DoubleType"},
                    "function": "sum",
                    "window": "1h",
                },
            ],
            "timestamp_field": "ts",
            "feature_granularity": "5m",
        }
        result = compile_to_spec(spec, "DB", "SCH")
        assert "columns" not in result["spec"]["sources"][0]
