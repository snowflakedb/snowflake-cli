"""Tests for decl/loader.py — expand_input_files, process_file, load_python_file, load_specs."""

import os
import tempfile

from snowflake.ml.feature_store.decl.loader import (
    expand_input_files,
    load_python_file,
    load_specs,
    process_file,
)

# ---------------------------------------------------------------------------
# expand_input_files
# ---------------------------------------------------------------------------


class TestExpandInputFiles:
    def test_py_file_included(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "entity.py")
            open(path, "w").close()
            result = expand_input_files([path])
        assert path in result

    def test_yaml_file_included(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "spec.yaml")
            open(path, "w").close()
            result = expand_input_files([path])
        assert path in result

    def test_yml_file_included(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "spec.yml")
            open(path, "w").close()
            result = expand_input_files([path])
        assert path in result

    def test_json_file_included(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "spec.json")
            open(path, "w").close()
            result = expand_input_files([path])
        assert path in result

    def test_recursive_glob_expands(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            subdir = os.path.join(tmpdir, "entities")
            os.makedirs(subdir)
            py_path = os.path.join(subdir, "customer.py")
            open(py_path, "w").close()
            result = expand_input_files([tmpdir + "/..."])
        assert py_path in result

    def test_recursive_glob_dotslash(self):
        """./... expands current directory recursively."""
        orig_dir = os.getcwd()
        with tempfile.TemporaryDirectory() as tmpdir:
            os.chdir(tmpdir)
            try:
                py_path = os.path.join(tmpdir, "spec.py")
                open(py_path, "w").close()
                result = expand_input_files(["./..."])
            finally:
                os.chdir(orig_dir)
        assert any("spec.py" in r for r in result)

    def test_unsupported_extensions_excluded_from_glob(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            py_path = os.path.join(tmpdir, "spec.py")
            txt_path = os.path.join(tmpdir, "readme.txt")
            open(py_path, "w").close()
            open(txt_path, "w").close()
            result = expand_input_files([tmpdir + "/..."])
        assert py_path in result
        assert txt_path not in result


# ---------------------------------------------------------------------------
# process_file: YAML
# ---------------------------------------------------------------------------


class TestProcessFileYaml:
    def _write_yaml(self, tmpdir: str, content: str, name: str = "spec.yaml") -> str:
        path = os.path.join(tmpdir, name)
        with open(path, "w") as f:
            f.write(content)
        return path

    def test_simple_yaml_loaded(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = self._write_yaml(
                tmpdir,
                "kind: Entity\nname: customer\njoin_keys:\n  - name: customer_id\n    type: str\n",
            )
            results = process_file(path)
        assert len(results) == 1
        assert results[0]["kind"] == "Entity"
        assert results[0]["name"] == "customer"

    def test_yaml_type_normalized(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = self._write_yaml(
                tmpdir,
                "kind: Entity\nname: e\njoin_keys:\n  - name: id\n    type: str\n",
            )
            results = process_file(path)
        assert results[0]["join_keys"][0]["type"] == "StringType"

    def test_yaml_duration_normalized(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = self._write_yaml(
                tmpdir,
                "kind: StreamingFeatureView\nname: fv\nfeature_granularity: 5m\n",
            )
            results = process_file(path)
        assert results[0]["feature_granularity_sec"] == 300

    def test_yml_extension_also_works(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = self._write_yaml(
                tmpdir,
                "kind: Entity\nname: e\n",
                name="spec.yml",
            )
            results = process_file(path)
        assert results[0]["kind"] == "Entity"

    def test_template_yaml_with_config_rendered(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = self._write_yaml(
                tmpdir,
                'kind: Entity\nname: "{{ entity_name }}"\n',
            )
            results = process_file(path, config_source='{"entity_name": "customer"}')
        assert results[0]["name"] == "customer"

    def test_template_yaml_without_config_raises(self):
        import pytest

        from snowflake.ml.feature_store.decl.errors import SpecLoadError

        with tempfile.TemporaryDirectory() as tmpdir:
            path = self._write_yaml(tmpdir, "kind: Entity\nname: {{ entity_name }}\n")
            with pytest.raises(SpecLoadError):
                process_file(path)


# ---------------------------------------------------------------------------
# process_file: JSON
# ---------------------------------------------------------------------------


class TestProcessFileJson:
    def test_simple_json_loaded(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "spec.json")
            with open(path, "w") as f:
                f.write('{"kind": "Entity", "name": "customer"}')
            results = process_file(path)
        assert len(results) == 1
        assert results[0]["kind"] == "Entity"

    def test_json_type_normalized(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "spec.json")
            with open(path, "w") as f:
                f.write('{"kind": "Entity", "join_keys": [{"name": "id", "type": "int"}]}')
            results = process_file(path)
        assert results[0]["join_keys"][0]["type"] == "LongType"


# ---------------------------------------------------------------------------
# load_python_file
# ---------------------------------------------------------------------------


class TestLoadPythonFile:
    def test_loads_pydantic_spec_instance(self):
        code = """
from snowflake.ml.feature_store.decl.spec_models import Entity, FSColumn

customer_entity = Entity(
    name="customer",
    join_keys=[FSColumn(name="customer_id", type="StringType")],
)
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "customer_entity.py")
            with open(path, "w") as f:
                f.write(code)
            objects = load_python_file(path)
        assert len(objects) == 1
        name, obj = objects[0]
        assert name == "customer_entity"
        assert obj.name == "customer"

    def test_imports_not_included(self):
        """Imported specs should not be returned as locally defined."""
        entity_code = """
from snowflake.ml.feature_store.decl.spec_models import Entity, FSColumn
customer_entity = Entity(name="customer", join_keys=[FSColumn(name="id", type="StringType")])
"""
        fv_code = """
import sys
from snowflake.ml.feature_store.decl.spec_models import Entity, FSColumn, FeatureView, SourceRef
from customer_entity import customer_entity

my_fv = FeatureView(
    name="my_fv",
    kind="StreamingFeatureView",
    sources=[SourceRef(name="src", source_type="Stream")],
    ordered_entity_column_names=["customer_id"],
)
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            import sys as _sys

            entity_path = os.path.join(tmpdir, "customer_entity.py")
            fv_path = os.path.join(tmpdir, "my_fv.py")
            with open(entity_path, "w") as f:
                f.write(entity_code)
            with open(fv_path, "w") as f:
                f.write(fv_code)
            # Add tmpdir to sys.path for the import to work
            old_path = list(_sys.path)
            _sys.path.insert(0, tmpdir)
            try:
                objects = load_python_file(fv_path)
            finally:
                _sys.path[:] = old_path

        names = [name for name, _ in objects]
        assert "my_fv" in names
        assert "customer_entity" not in names

    def test_feature_view_decorator_style(self):
        code = """
import sys
from snowflake.ml.feature_store.decl.spec_models import (
    Entity, FSColumn, FeatureView, SourceRef, Feature, UDF
)
from snowflake.ml.feature_store.decl.decorator import feature_view

@feature_view(
    name="click_fv",
    ordered_entity_column_names=["user_id"],
    sources=[SourceRef(name="events", source_type="Stream")],
    features=[],
    online=True,
)
def compute_click_metrics(df):
    return df
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "click_fv.py")
            with open(path, "w") as f:
                f.write(code)
            objects = load_python_file(path)

        assert len(objects) >= 1
        names = [name for name, _ in objects]
        assert "compute_click_metrics" in names
        # The spec should be the FeatureView created by the decorator
        obj = next(o for n, o in objects if n == "compute_click_metrics")
        assert obj.name == "click_fv"


# ---------------------------------------------------------------------------
# process_file: Python
# ---------------------------------------------------------------------------


class TestProcessFilePython:
    def test_python_entity_loaded_and_compiled(self):
        code = """
from snowflake.ml.feature_store.decl.spec_models import Entity, FSColumn

my_entity = Entity(
    name="user",
    join_keys=[FSColumn(name="user_id", type="str")],
)
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "my_entity.py")
            with open(path, "w") as f:
                f.write(code)
            results = process_file(path)

        assert len(results) == 1
        # compile_spec should have normalized the type
        assert results[0]["join_keys"][0]["type"] == "StringType"


# ---------------------------------------------------------------------------
# load_specs
# ---------------------------------------------------------------------------


class TestLoadSpecs:
    def test_returns_spec_batch(self):
        from snowflake.ml.feature_store.decl.types import SpecBatch

        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "entity.yaml")
            with open(path, "w") as f:
                f.write("kind: Entity\nname: customer\n")
            batch = load_specs([path])

        assert isinstance(batch, SpecBatch)
        assert len(batch.specs) == 1
        assert len(batch.source_files) == 1

    def test_multiple_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            p1 = os.path.join(tmpdir, "e1.yaml")
            p2 = os.path.join(tmpdir, "e2.yaml")
            with open(p1, "w") as f:
                f.write("kind: Entity\nname: user\n")
            with open(p2, "w") as f:
                f.write("kind: Entity\nname: customer\n")
            batch = load_specs([p1, p2])

        assert len(batch.specs) == 2

    def test_source_files_recorded(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "e.yaml")
            with open(path, "w") as f:
                f.write("kind: Entity\nname: e\n")
            batch = load_specs([path])

        assert path in batch.source_files
