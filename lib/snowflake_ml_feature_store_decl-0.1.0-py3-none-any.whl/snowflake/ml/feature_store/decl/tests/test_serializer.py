"""Tests for decl/serializer.py — spec_to_dict, spec_to_yaml, spec_to_json, callable_to_source."""

import json

import yaml

from snowflake.ml.feature_store.decl.serializer import (
    callable_to_source,
    spec_to_dict,
    spec_to_json,
    spec_to_yaml,
)
from snowflake.ml.feature_store.decl.spec_models import (
    UDF,
    BatchSource,
    Entity,
    Feature,
    FeatureGroup,
    FeatureView,
    FeatureViewRef,
    FSColumn,
    SourceRef,
    StreamingSource,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _customer_entity() -> Entity:
    return Entity(
        kind="Entity",
        name="customer",
        version="v1",
        join_keys=[FSColumn(name="customer_id", type="StringType")],
    )


def _streaming_source() -> StreamingSource:
    return StreamingSource(
        name="events",
        version="v1",
        columns=[
            FSColumn(name="customer_id", type="StringType"),
            FSColumn(name="amount", type="FloatType"),
        ],
    )


def _batch_source() -> BatchSource:
    return BatchSource(
        name="order_history",
        source_database="PROD",
        source_schema="PUBLIC",
        table="ORDERS",
    )


def _simple_fv() -> FeatureView:
    return FeatureView(
        name="click_stats",
        version="v1",
        kind="StreamingFeatureView",
        online=True,
        ordered_entity_column_names=["customer_id"],
        sources=[SourceRef(name="events", source_type="Stream")],
        features=[
            Feature(
                source_column=FSColumn(name="amount", type="FloatType"),
                output_column=FSColumn(name="total_spend_7d", type="FloatType"),
                function="sum",
                window="7d",
            )
        ],
    )


# ---------------------------------------------------------------------------
# spec_to_dict
# ---------------------------------------------------------------------------


class TestSpecToDict:
    def test_entity_basic(self):
        e = _customer_entity()
        d = spec_to_dict(e)
        assert d["kind"] == "Entity"
        assert d["name"] == "customer"
        assert d["version"] == "v1"

    def test_entity_join_keys_serialized(self):
        e = _customer_entity()
        d = spec_to_dict(e)
        assert isinstance(d["join_keys"], list)
        assert d["join_keys"][0]["name"] == "customer_id"
        assert d["join_keys"][0]["type"] == "StringType"

    def test_none_values_excluded(self):
        e = Entity(name="customer")
        d = spec_to_dict(e)
        assert "version" not in d
        assert "database" not in d
        assert "description" not in d

    def test_empty_list_excluded(self):
        e = Entity(name="customer")
        d = spec_to_dict(e)
        assert "join_keys" not in d

    def test_feature_view_sources_as_sourcerefs(self):
        fv = _simple_fv()
        d = spec_to_dict(fv)
        assert isinstance(d["sources"], list)
        src = d["sources"][0]
        assert src["name"] == "events"
        assert src["source_type"] == "Stream"

    def test_streaming_source_in_sources_collapsed_to_sourceref(self):
        """StreamingSource instances in sources list become SourceRef dicts."""
        src = _streaming_source()
        fv = FeatureView(
            name="fv",
            sources=[src],
        )
        d = spec_to_dict(fv)
        assert d["sources"][0]["name"] == "events"
        assert d["sources"][0]["source_type"] == "Stream"
        # Should NOT be the full source dict
        assert "columns" not in d["sources"][0]

    def test_batch_source_in_sources_collapsed_to_sourceref(self):
        """BatchSource instances in sources list become SourceRef dicts."""
        src = _batch_source()
        fv = FeatureView(
            name="fv",
            sources=[src],
        )
        d = spec_to_dict(fv)
        assert d["sources"][0]["name"] == "order_history"
        assert d["sources"][0]["source_type"] == "BatchSource"

    def test_entity_in_ordered_entity_column_names_expanded(self):
        """Entity objects in ordered_entity_column_names become join-key column name strings."""
        entity = _customer_entity()
        fv = FeatureView(
            name="fv",
            ordered_entity_column_names=[entity],
        )
        d = spec_to_dict(fv)
        assert d["ordered_entity_column_names"] == ["customer_id"]

    def test_string_entity_column_names_passthrough(self):
        fv = _simple_fv()
        d = spec_to_dict(fv)
        assert d["ordered_entity_column_names"] == ["customer_id"]

    def test_feature_group_feature_views_as_refs(self):
        """FeatureView objects in feature_views become name-only ref dicts."""
        fv = _simple_fv()
        fg = FeatureGroup(name="my_group", feature_views=[fv])
        d = spec_to_dict(fg)
        assert d["feature_views"] == [{"name": "click_stats"}]

    def test_feature_group_feature_view_refs_passthrough(self):
        ref = FeatureViewRef(name="click_stats")
        fg = FeatureGroup(name="my_group", feature_views=[ref])
        d = spec_to_dict(fg)
        assert d["feature_views"] == [{"name": "click_stats"}]

    def test_udf_callable_converted_to_source(self):
        def my_transform(df):
            return df * 2

        udf = UDF(name="my_transform", function_definition=my_transform)
        fv = FeatureView(name="fv", udf=udf)
        d = spec_to_dict(fv)
        assert isinstance(d["udf"]["function_definition"], str)
        assert "def my_transform" in d["udf"]["function_definition"]

    def test_udf_string_source_passthrough(self):
        udf = UDF(name="fn", function_definition="def fn(df):\n    return df\n")
        fv = FeatureView(name="fv", udf=udf)
        d = spec_to_dict(fv)
        assert d["udf"]["function_definition"] == "def fn(df):\n    return df\n"

    def test_features_serialized(self):
        fv = _simple_fv()
        d = spec_to_dict(fv)
        feat = d["features"][0]
        assert feat["function"] == "sum"
        assert feat["window"] == "7d"
        assert feat["output_column"]["name"] == "total_spend_7d"

    def test_boolean_true_included(self):
        fv = FeatureView(name="fv", online=True)
        d = spec_to_dict(fv)
        assert d["online"] is True

    def test_boolean_false_excluded(self):
        fv = FeatureView(name="fv", online=False)
        d = spec_to_dict(fv)
        assert "online" not in d


class TestSpecToDictFeatureAggregationMethod:
    def test_feature_aggregation_method_included_when_set(self):
        fv = FeatureView(name="fv", feature_aggregation_method="continuous")
        d = spec_to_dict(fv)
        assert d["feature_aggregation_method"] == "continuous"

    def test_feature_aggregation_method_tiles_included(self):
        fv = FeatureView(name="fv", feature_aggregation_method="tiles")
        d = spec_to_dict(fv)
        assert d["feature_aggregation_method"] == "tiles"

    def test_feature_aggregation_method_excluded_when_none(self):
        fv = FeatureView(name="fv")
        d = spec_to_dict(fv)
        assert "feature_aggregation_method" not in d

    def test_feature_aggregation_method_survives_json_round_trip(self):
        import json as _json

        fv = FeatureView(name="fv", feature_aggregation_method="continuous")
        json_str = spec_to_json(fv)
        parsed = _json.loads(json_str)
        assert parsed["feature_aggregation_method"] == "continuous"


# ---------------------------------------------------------------------------
# spec_to_yaml
# ---------------------------------------------------------------------------


class TestSpecToYaml:
    def test_returns_string(self):
        e = _customer_entity()
        result = spec_to_yaml(e)
        assert isinstance(result, str)

    def test_valid_yaml(self):
        e = _customer_entity()
        result = spec_to_yaml(e)
        parsed = yaml.safe_load(result)
        assert parsed["kind"] == "Entity"
        assert parsed["name"] == "customer"

    def test_join_keys_in_yaml(self):
        e = _customer_entity()
        result = spec_to_yaml(e)
        parsed = yaml.safe_load(result)
        assert parsed["join_keys"][0]["name"] == "customer_id"

    def test_round_trip(self):
        fv = _simple_fv()
        yaml_str = spec_to_yaml(fv)
        parsed = yaml.safe_load(yaml_str)
        assert parsed["kind"] == "StreamingFeatureView"
        assert parsed["sources"][0]["name"] == "events"


# ---------------------------------------------------------------------------
# spec_to_json
# ---------------------------------------------------------------------------


class TestSpecToJson:
    def test_returns_string(self):
        e = _customer_entity()
        result = spec_to_json(e)
        assert isinstance(result, str)

    def test_valid_json(self):
        e = _customer_entity()
        result = spec_to_json(e)
        parsed = json.loads(result)
        assert parsed["kind"] == "Entity"

    def test_round_trip(self):
        fv = _simple_fv()
        json_str = spec_to_json(fv)
        parsed = json.loads(json_str)
        assert parsed["kind"] == "StreamingFeatureView"
        assert parsed["features"][0]["function"] == "sum"


# ---------------------------------------------------------------------------
# callable_to_source
# ---------------------------------------------------------------------------


class TestCallableToSource:
    def test_returns_string(self):
        def my_fn(df):
            return df

        result = callable_to_source(my_fn)
        assert isinstance(result, str)

    def test_contains_def(self):
        def transform(df):
            return df * 2

        result = callable_to_source(transform)
        assert result.startswith("def transform")

    def test_strips_decorator(self):
        import functools

        def simple_deco(fn):
            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                return fn(*args, **kwargs)

            return wrapper

        @simple_deco
        def my_fn(df):
            return df + 1

        result = callable_to_source(my_fn)
        assert "def my_fn" in result
        assert not result.startswith("@")

    def test_dedented(self):
        def outer():
            def inner(df):
                return df

            return inner

        fn = outer()
        result = callable_to_source(fn)
        # Should not start with whitespace
        assert result.startswith("def inner")
