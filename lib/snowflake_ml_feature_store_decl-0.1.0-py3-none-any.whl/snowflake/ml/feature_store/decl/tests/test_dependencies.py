"""Tests for decl/dependencies.py — dependency extraction, topo sort, cycle detection."""

from __future__ import annotations

from snowflake.ml.feature_store.decl.dependencies import (
    detect_cycles,
    extract_dependencies,
    resolve_dependencies,
    topological_sort,
)
from snowflake.ml.feature_store.decl.types import AppliedObject, AppliedState

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _entity(name: str = "user") -> dict:
    return {
        "kind": "Entity",
        "name": name,
        "database": "DB",
        "schema": "SCH",
        "join_keys": [{"name": "user_id", "type": "StringType"}],
    }


def _source(name: str = "clicks") -> dict:
    return {"kind": "StreamingSource", "name": name, "database": "DB", "schema": "SCH", "columns": []}


def _fv(
    name: str = "click_fv",
    entity_cols: list | None = None,
    sources: list | None = None,
) -> dict:
    return {
        "kind": "StreamingFeatureView",
        "name": name,
        "database": "DB",
        "schema": "SCH",
        "version": "V1",
        "ordered_entity_column_names": entity_cols or ["user_id"],
        "sources": sources or [{"name": "clicks", "source_type": "Stream"}],
        "features": [],
    }


def _fg(name: str = "my_group", fv_names: list | None = None) -> dict:
    return {
        "kind": "FeatureGroup",
        "name": name,
        "database": "DB",
        "schema": "SCH",
        "feature_views": [{"name": n} for n in (fv_names or ["click_fv"])],
    }


def _empty_applied() -> AppliedState:
    return AppliedState(objects={})


# ---------------------------------------------------------------------------
# extract_dependencies tests
# ---------------------------------------------------------------------------


class TestExtractDependencies:
    def test_entity_has_no_dependencies(self):
        deps = extract_dependencies(_entity())
        assert deps == []

    def test_source_has_no_dependencies(self):
        deps = extract_dependencies(_source())
        assert deps == []

    def test_fv_depends_on_entity_and_source(self):
        fv = _fv(entity_cols=["user_id"], sources=[{"name": "clicks", "source_type": "Stream"}])
        deps = extract_dependencies(fv)
        assert "user_id" in deps
        assert "clicks" in deps

    def test_fv_multiple_sources(self):
        fv = _fv(
            sources=[
                {"name": "src_a", "source_type": "Stream"},
                {"name": "src_b", "source_type": "BatchSource"},
            ]
        )
        deps = extract_dependencies(fv)
        assert "src_a" in deps
        assert "src_b" in deps

    def test_fg_depends_on_feature_views(self):
        fg = _fg(fv_names=["fv1", "fv2"])
        deps = extract_dependencies(fg)
        assert "fv1" in deps
        assert "fv2" in deps


# ---------------------------------------------------------------------------
# topological_sort tests
# ---------------------------------------------------------------------------


class TestTopologicalSort:
    def test_entities_come_before_fv(self):
        entity = _entity()
        fv = _fv()
        specs = [fv, entity]
        sorted_specs = topological_sort(specs)
        names = [s["name"] for s in sorted_specs]
        assert names.index("user") < names.index("click_fv")

    def test_sources_come_before_fv(self):
        source = _source()
        fv = _fv()
        specs = [fv, source]
        sorted_specs = topological_sort(specs)
        names = [s["name"] for s in sorted_specs]
        assert names.index("clicks") < names.index("click_fv")

    def test_fv_comes_before_fg(self):
        fv = _fv()
        fg = _fg()
        specs = [fg, fv]
        sorted_specs = topological_sort(specs)
        names = [s["name"] for s in sorted_specs]
        assert names.index("click_fv") < names.index("my_group")

    def test_full_ordering(self):
        entity = _entity()
        source = _source()
        fv = _fv()
        fg = _fg()
        specs = [fg, fv, source, entity]
        sorted_specs = topological_sort(specs)
        names = [s["name"] for s in sorted_specs]
        assert names.index("user") < names.index("click_fv")
        assert names.index("clicks") < names.index("click_fv")
        assert names.index("click_fv") < names.index("my_group")

    def test_single_spec_returns_unchanged(self):
        specs = [_entity()]
        result = topological_sort(specs)
        assert len(result) == 1

    def test_empty_list_returns_empty(self):
        result = topological_sort([])
        assert result == []


# ---------------------------------------------------------------------------
# detect_cycles tests
# ---------------------------------------------------------------------------


class TestDetectCycles:
    def test_no_cycles_returns_empty(self):
        specs = [_entity(), _source(), _fv()]
        cycles = detect_cycles(specs)
        assert cycles == []

    def test_self_cycle_detected(self):
        # A FV that depends on itself (via sources list with its own name)
        fv = {
            "kind": "StreamingFeatureView",
            "name": "cyclic_fv",
            "sources": [{"name": "cyclic_fv", "source_type": "Stream"}],
            "ordered_entity_column_names": [],
            "features": [],
        }
        cycles = detect_cycles([fv])
        assert len(cycles) >= 1

    def test_linear_chain_no_cycles(self):
        fv1 = _fv(name="fv1")
        fv2 = _fv(name="fv2", sources=[{"name": "fv1", "source_type": "Features"}])
        cycles = detect_cycles([fv1, fv2])
        assert cycles == []


# ---------------------------------------------------------------------------
# resolve_dependencies tests
# ---------------------------------------------------------------------------


class TestResolveDependencies:
    def test_all_resolved_from_batch(self):
        entity = _entity()
        source = _source()
        fv = _fv()
        results = resolve_dependencies([entity, source, fv], _empty_applied())
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) == 0

    def test_missing_dep_produces_error(self):
        # FV with no entity or source in batch or applied state
        fv = _fv(entity_cols=["missing_entity"], sources=[{"name": "missing_src", "source_type": "Stream"}])
        results = resolve_dependencies([fv], _empty_applied())
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) >= 1

    def test_dep_resolved_from_applied_state(self):
        # Entity and source exist in applied state, not in batch
        entity_payload = _entity()
        ao = AppliedObject(
            key="Entity:DB.SCH:user",
            kind="Entity",
            name="user",
            spec_payload=entity_payload,
        )
        source_ao = AppliedObject(
            key="StreamingSource:DB.SCH:clicks",
            kind="StreamingSource",
            name="clicks",
            spec_payload=_source(),
        )
        applied = AppliedState(objects={"Entity:DB.SCH:user": ao, "StreamingSource:DB.SCH:clicks": source_ao})
        fv = _fv()
        results = resolve_dependencies([fv], applied)
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) == 0
