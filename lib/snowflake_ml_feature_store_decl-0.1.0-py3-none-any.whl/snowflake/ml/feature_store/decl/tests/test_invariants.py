"""Tests for decl/invariants.py — all invariant rule checks.

Each test constructs minimal SpecBatch / AppliedState fixtures, calls
validate_specs(), and asserts the expected ValidationResult severity and code.
"""

from __future__ import annotations

from snowflake.ml.feature_store.decl.invariants import (
    _check_column_evolution,
    _check_database_schema_mismatch,
    _check_dependencies,
    _check_destructive,
    _check_idempotency,
    _check_state_sync,
    _check_versions,
    _content_hash,
    _spec_hash,
    _spec_key,
    _structural_fingerprint_hash,
    validate_specs,
)
from snowflake.ml.feature_store.decl.types import AppliedObject, AppliedState, SpecBatch

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_entity_spec(name: str = "user", join_key: str = "user_id") -> dict:
    return {
        "kind": "Entity",
        "name": name,
        "database": "DB",
        "schema": "SCH",
        "join_keys": [{"name": join_key, "type": "StringType"}],
    }


def _make_source_spec(name: str = "clicks", col: str = "event") -> dict:
    return {
        "kind": "StreamingSource",
        "name": name,
        "database": "DB",
        "schema": "SCH",
        "type": "REST",
        "columns": [{"name": "user_id", "type": "StringType"}, {"name": col, "type": "StringType"}],
    }


def _make_fv_spec(
    name: str = "click_features",
    version: str | None = "V1",
    features: list | None = None,
    sources: list | None = None,
    entity_cols: list | None = None,
) -> dict:
    return {
        "kind": "StreamingFeatureView",
        "name": name,
        "database": "DB",
        "schema": "SCH",
        "version": version,
        "ordered_entity_column_names": entity_cols or ["user_id"],
        "sources": sources or [{"name": "clicks", "source_type": "Stream"}],
        "features": features
        or [
            {
                "source_column": {"name": "event", "type": "StringType"},
                "output_column": {"name": "event", "type": "StringType"},
            }
        ],
    }


def _kind_to_model(spec: dict):
    """Create a typed Pydantic model from a raw spec dict."""
    from snowflake.ml.feature_store.decl.spec_models import (
        Entity,
        FeatureGroup,
        FeatureView,
        SpecBase,
        StreamingSource,
    )

    kind = spec.get("kind", "")
    model_cls = {
        "Entity": Entity,
        "StreamingFeatureView": FeatureView,
        "RealtimeFeatureView": FeatureView,
        "BatchFeatureView": FeatureView,
        "StreamingSource": StreamingSource,
        "FeatureGroup": FeatureGroup,
    }.get(kind, SpecBase)
    return model_cls.model_validate(spec)


def _normalize(spec: dict) -> dict:
    """Normalize a raw spec dict the same way validate_specs does."""
    from snowflake.ml.feature_store.decl.invariants import _model_to_dict

    return _model_to_dict(_kind_to_model(spec))


def _make_applied_object(spec: dict) -> AppliedObject:
    """Create AppliedObject using the same normalization as validate_specs."""
    normalized = _normalize(spec)
    key = _spec_key(normalized)
    return AppliedObject(
        key=key,
        kind=normalized.get("kind", ""),
        name=normalized.get("name", ""),
        version=normalized.get("version"),
        content_hash=_structural_fingerprint_hash(normalized),
        spec_payload=normalized,
        columns=[],
    )


def _empty_applied() -> AppliedState:
    return AppliedState(objects={})


def _applied_with(spec: dict) -> AppliedState:
    obj = _make_applied_object(spec)
    return AppliedState(objects={obj.key: obj})


def _batch(*specs: dict) -> SpecBatch:
    spec_objs = [_kind_to_model(s) for s in specs]
    return SpecBatch(specs=spec_objs, source_files=[])


# ---------------------------------------------------------------------------
# _spec_key tests
# ---------------------------------------------------------------------------


class TestSpecKey:
    def test_basic_key(self):
        spec = {"kind": "Entity", "name": "user", "database": "DB", "schema": "SCH"}
        assert _spec_key(spec) == "Entity:DB.SCH:USER"

    def test_missing_db_schema(self):
        spec = {"kind": "Entity", "name": "user"}
        # qualifier empty string
        assert _spec_key(spec) == "Entity::USER"

    def test_partial_qualifier(self):
        spec = {"kind": "FeatureView", "name": "fv1", "database": "PROD"}
        key = _spec_key(spec)
        assert key.startswith("FeatureView:")
        assert key.endswith(":FV1")


# ---------------------------------------------------------------------------
# _spec_hash / _content_hash tests
# ---------------------------------------------------------------------------


class TestHashing:
    def test_spec_hash_deterministic(self):
        spec = _make_fv_spec()
        assert _spec_hash(spec) == _spec_hash(spec)

    def test_spec_hash_excludes_internal_keys(self):
        spec = _make_fv_spec()
        spec_with_meta = dict(spec, _hash="ignored", _content_hash="ignored")
        assert _spec_hash(spec) == _spec_hash(spec_with_meta)

    def test_content_hash_excludes_version(self):
        spec_v1 = _make_fv_spec(version="V1")
        spec_v2 = _make_fv_spec(version="V2")
        assert _content_hash(spec_v1) == _content_hash(spec_v2)

    def test_spec_hash_changes_on_content_change(self):
        spec1 = _make_fv_spec(name="fv1")
        spec2 = _make_fv_spec(name="fv2")
        assert _spec_hash(spec1) != _spec_hash(spec2)


# ---------------------------------------------------------------------------
# _check_versions tests
# ---------------------------------------------------------------------------


class TestCheckVersions:
    def test_missing_version_non_dev_mode_is_error(self):
        spec = _make_fv_spec(version=None)
        results = _check_versions(spec, None, dev_mode=False)
        assert any(r.severity == "ERROR" and "version" in r.code.lower() for r in results)

    def test_missing_version_dev_mode_is_ok(self):
        spec = _make_fv_spec(version=None)
        results = _check_versions(spec, None, dev_mode=True)
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) == 0

    def test_version_not_greater_than_deployed_is_error(self):
        spec = _make_fv_spec(version="V1")
        applied_spec = _make_fv_spec(version="V2")
        applied = _make_applied_object(applied_spec)
        results = _check_versions(spec, applied, dev_mode=False)
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) >= 1
        assert any("VERSION_CONFLICT" in r.code for r in errors)

    def test_version_equal_to_deployed_is_error(self):
        spec = _make_fv_spec(version="V1")
        applied_spec = _make_fv_spec(version="V1")
        applied = _make_applied_object(applied_spec)
        # only problematic when content changed — same hash means NO_CHANGE not a conflict
        # but if hash differs and version is same, it's a conflict
        applied.content_hash = "different_hash"
        results = _check_versions(spec, applied, dev_mode=False)
        errors = [r for r in results if r.severity == "ERROR"]
        assert any("VERSION_CONFLICT" in r.code for r in errors)

    def test_version_greater_than_deployed_ok(self):
        spec = _make_fv_spec(version="V2")
        applied_spec = _make_fv_spec(version="V1")
        applied = _make_applied_object(applied_spec)
        results = _check_versions(spec, applied, dev_mode=False)
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) == 0

    def test_new_object_no_version_conflict(self):
        spec = _make_fv_spec(version="V1")
        results = _check_versions(spec, None, dev_mode=False)
        assert len(results) == 0


# ---------------------------------------------------------------------------
# _check_idempotency tests
# ---------------------------------------------------------------------------


class TestCheckIdempotency:
    def test_same_spec_is_up_to_date(self):
        spec = _make_fv_spec(version="V1")
        applied = _make_applied_object(spec)
        is_up_to_date, results = _check_idempotency(_normalize(spec), applied, dev_mode=False)
        assert is_up_to_date is True
        assert any(r.code == "NO_CHANGE" for r in results)

    def test_different_spec_not_up_to_date(self):
        spec = _make_fv_spec(version="V2")
        applied_spec = _make_fv_spec(version="V1")
        applied = _make_applied_object(applied_spec)
        is_up_to_date, results = _check_idempotency(_normalize(spec), applied, dev_mode=False)
        assert is_up_to_date is False

    def test_dev_mode_version_excluded_hash_match(self):
        spec_v1 = _make_fv_spec(version="V1")
        spec_devver = _make_fv_spec(version="dev-20240101T120000Z")
        # content is the same except version — content_hash should match
        applied = AppliedObject(
            key=_spec_key(spec_v1),
            kind="StreamingFeatureView",
            name="click_features",
            version="V1",
            content_hash=_content_hash(spec_v1),
            spec_payload=spec_v1,
        )
        is_up_to_date, results = _check_idempotency(spec_devver, applied, dev_mode=True)
        assert is_up_to_date is True

    def test_no_applied_object_is_not_up_to_date(self):
        spec = _make_fv_spec()
        is_up_to_date, results = _check_idempotency(spec, None, dev_mode=False)
        assert is_up_to_date is False


# ---------------------------------------------------------------------------
# _check_column_evolution tests
# ---------------------------------------------------------------------------


class TestCheckColumnEvolution:
    def _fv_with_features(self, cols: list[tuple[str, str]], version: str = "V1") -> dict:
        features = [{"source_column": {"name": c, "type": t}, "output_column": {"name": c, "type": t}} for c, t in cols]
        return _make_fv_spec(version=version, features=features)

    def test_new_output_col_without_default_is_warning(self):
        old_spec = self._fv_with_features([("event", "StringType")])
        new_spec = self._fv_with_features(
            [
                ("event", "StringType"),
                ("new_col", "StringType"),  # no default
            ],
            version="V2",
        )
        applied = _make_applied_object(old_spec)
        results = _check_column_evolution(new_spec, applied)
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "COLUMN_ADDED" for r in warnings)

    def test_new_output_col_with_default_is_ok(self):
        old_spec = self._fv_with_features([("event", "StringType")])
        new_spec = {**self._fv_with_features([("event", "StringType")], version="V2")}
        # Add a feature with default
        new_spec["features"].append(
            {
                "source_column": {"name": "new_col", "type": "StringType"},
                "output_column": {"name": "new_col", "type": "StringType", "default": "unknown"},
            }
        )
        applied = _make_applied_object(old_spec)
        results = _check_column_evolution(new_spec, applied)
        errors = [r for r in results if r.code == "COLUMN_MISSING_DEFAULT"]
        assert len(errors) == 0

    def test_output_col_type_changed_is_warning(self):
        old_spec = self._fv_with_features([("event", "StringType")])
        new_spec = self._fv_with_features([("event", "IntegerType")], version="V2")
        applied = _make_applied_object(old_spec)
        results = _check_column_evolution(new_spec, applied)
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "COLUMN_TYPE_CHANGED" for r in warnings)

    def test_output_col_removed_is_warning(self):
        old_spec = self._fv_with_features([("event", "StringType"), ("count", "IntegerType")])
        new_spec = self._fv_with_features([("event", "StringType")], version="V2")
        applied = _make_applied_object(old_spec)
        results = _check_column_evolution(new_spec, applied)
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "COLUMN_REMOVED" for r in warnings)

    def test_no_applied_object_no_results(self):
        spec = self._fv_with_features([("event", "StringType")])
        results = _check_column_evolution(spec, None)
        assert results == []

    def test_source_col_added_without_default_is_warning(self):
        old_src = _make_source_spec()
        new_src = {
            **old_src,
            "columns": [
                {"name": "user_id", "type": "StringType"},
                {"name": "event", "type": "StringType"},
                {"name": "new_field", "type": "StringType"},  # no default
            ],
        }
        applied = _make_applied_object(old_src)
        results = _check_column_evolution(new_src, applied)
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "COLUMN_ADDED" for r in warnings)


# ---------------------------------------------------------------------------
# _check_dependencies tests
# ---------------------------------------------------------------------------


class TestCheckDependencies:
    def test_missing_entity_join_key_is_error(self):
        fv_spec = _make_fv_spec(entity_cols=["nonexistent_id"])
        batch_names = {"click_features", "clicks"}
        results = _check_dependencies(fv_spec, batch_names, _empty_applied())
        errors = [r for r in results if r.severity == "ERROR"]
        assert any(r.code == "MISSING_ENTITY" for r in errors)

    def test_entity_join_key_resolved_from_batch(self):
        entity_spec = _make_entity_spec(join_key="user_id")
        fv_spec = _make_fv_spec(entity_cols=["user_id"])
        batch_names = {"user", "clicks", "click_features"}
        applied = _applied_with(entity_spec)
        results = _check_dependencies(fv_spec, batch_names, applied)
        errors = [r for r in results if r.code == "MISSING_ENTITY"]
        assert len(errors) == 0

    def test_missing_source_reference_is_error(self):
        fv_spec = _make_fv_spec(sources=[{"name": "missing_source", "source_type": "Stream"}])
        batch_names = {"click_features"}
        results = _check_dependencies(fv_spec, batch_names, _empty_applied())
        errors = [r for r in results if r.severity == "ERROR"]
        assert any(r.code == "MISSING_SOURCE" for r in errors)

    def test_fg_missing_feature_view_is_error(self):
        fg_spec = {
            "kind": "FeatureGroup",
            "name": "my_group",
            "database": "DB",
            "schema": "SCH",
            "feature_views": [{"name": "nonexistent_fv"}],
        }
        results = _check_dependencies(fg_spec, {"my_group"}, _empty_applied())
        errors = [r for r in results if r.severity == "ERROR"]
        assert any(r.code == "MISSING_FEATURE_VIEW" for r in errors)

    def test_entity_resolved_from_applied_state(self):
        entity_spec = _make_entity_spec(join_key="user_id")
        applied = _applied_with(entity_spec)
        fv_spec = _make_fv_spec(entity_cols=["user_id"])
        batch_names = {"click_features", "clicks"}
        results = _check_dependencies(fv_spec, batch_names, applied)
        errors = [r for r in results if r.code == "MISSING_ENTITY"]
        assert len(errors) == 0


# ---------------------------------------------------------------------------
# _check_destructive tests
# ---------------------------------------------------------------------------


class TestCheckDestructive:
    def test_expression_change_is_error_without_allow_recreate(self):
        old_spec = _make_fv_spec(
            features=[
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event_upper", "type": "StringType"},
                    "function": "upper",
                }
            ]
        )
        new_spec = _make_fv_spec(
            version="V2",
            features=[
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event_upper", "type": "StringType"},
                    "function": "lower",  # changed expression
                }
            ],
        )
        applied = _make_applied_object(old_spec)
        results = _check_destructive(new_spec, applied)
        errors = [r for r in results if r.severity == "ERROR"]
        assert any(r.code == "DESTRUCTIVE_CHANGE" for r in errors)

    def test_no_change_no_destructive_error(self):
        spec = _make_fv_spec()
        applied = _make_applied_object(spec)
        results = _check_destructive(spec, applied)
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) == 0

    def test_no_applied_no_destructive_error(self):
        spec = _make_fv_spec()
        results = _check_destructive(spec, None)
        assert results == []


# ---------------------------------------------------------------------------
# _check_state_sync tests
# ---------------------------------------------------------------------------


class TestCheckStateSync:
    def test_object_at_unexpected_version_is_error(self):
        # Spec says V2, but applied state has V3 (concurrent modification)
        spec = _make_fv_spec(version="V2")
        applied_spec = _make_fv_spec(version="V3")
        applied = _make_applied_object(applied_spec)
        # Simulate state drift: applied version doesn't match what we expected
        results = _check_state_sync(spec, applied)
        # STATE_DRIFT if applied has a NEWER version than spec (concurrent write)
        errors = [r for r in results if r.severity == "ERROR"]
        assert any(r.code == "STATE_DRIFT" for r in errors)

    def test_matching_version_no_drift(self):
        spec = _make_fv_spec(version="V1")
        applied = _make_applied_object(spec)
        results = _check_state_sync(spec, applied)
        errors = [r for r in results if r.code == "STATE_DRIFT"]
        assert len(errors) == 0


# ---------------------------------------------------------------------------
# validate_specs integration tests
# ---------------------------------------------------------------------------


class TestValidateSpecs:
    def test_returns_empty_for_valid_batch(self):
        entity_spec = _make_entity_spec()
        source_spec = _make_source_spec()
        fv_spec = _make_fv_spec(
            version="V1",
            entity_cols=["user_id"],
            sources=[{"name": "clicks", "source_type": "Stream"}],
        )
        batch = _batch(entity_spec, source_spec, fv_spec)
        applied = AppliedState(objects={})
        results = validate_specs(batch, applied)
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) == 0

    def test_missing_version_produces_error(self):
        fv_spec = _make_fv_spec(version=None)
        batch = _batch(fv_spec)
        applied = _empty_applied()
        results = validate_specs(batch, applied)
        errors = [r for r in results if r.severity == "ERROR"]
        assert len(errors) >= 1

    def test_second_apply_same_spec_produces_no_change(self):
        spec = _make_fv_spec(version="V1")
        batch = _batch(spec)
        applied = _applied_with(spec)
        results = validate_specs(batch, applied)
        no_change = [r for r in results if r.code == "NO_CHANGE"]
        assert len(no_change) >= 1

    def test_version_conflict_produces_error(self):
        spec = _make_fv_spec(version="V1")
        deployed_spec = _make_fv_spec(version="V2")
        applied = _applied_with(deployed_spec)
        # Ensure hash is different so idempotency doesn't trigger
        applied.objects[_spec_key(_normalize(deployed_spec))].content_hash = "different"
        batch = _batch(spec)
        results = validate_specs(batch, applied)
        errors = [r for r in results if r.severity == "ERROR"]
        assert any(r.code == "VERSION_CONFLICT" for r in errors)

    def test_column_added_is_warning(self):
        old_spec = _make_fv_spec(
            version="V1",
            features=[
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event", "type": "StringType"},
                }
            ],
        )
        new_spec = _make_fv_spec(
            version="V2",
            features=[
                {
                    "source_column": {"name": "event", "type": "StringType"},
                    "output_column": {"name": "event", "type": "StringType"},
                },
                {
                    "source_column": {"name": "new_col", "type": "StringType"},
                    "output_column": {"name": "new_col", "type": "StringType"},
                },  # no default
            ],
        )
        applied = _applied_with(old_spec)
        batch = _batch(new_spec)
        results = validate_specs(batch, applied)
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "COLUMN_ADDED" for r in warnings)

    def test_state_drift_detection(self):
        """Object exists at unexpected (higher) version → StateDrift ERROR."""
        spec = _make_fv_spec(version="V2")
        applied_spec = _make_fv_spec(version="V3")
        applied = _applied_with(applied_spec)
        # Different content to avoid idempotency skip
        applied.objects[_spec_key(_normalize(applied_spec))].content_hash = "something_else"
        batch = _batch(spec)
        results = validate_specs(batch, applied)
        errors = [r for r in results if r.severity == "ERROR"]
        assert any(r.code == "STATE_DRIFT" for r in errors)


# ---------------------------------------------------------------------------
# _check_database_schema_mismatch tests
# ---------------------------------------------------------------------------


class TestCheckDatabaseSchemaMismatch:
    def test_spec_with_different_database_emits_warning(self):
        """Spec with database != target_database produces a DB_MISMATCH warning."""
        spec = _make_fv_spec()
        spec["database"] = "OTHER_DB"
        results = _check_database_schema_mismatch([spec], "MY_DB", "MY_SCHEMA")
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "DB_MISMATCH" for r in warnings)

    def test_spec_with_different_schema_emits_warning(self):
        """Spec with schema != target_schema produces a SCHEMA_MISMATCH warning."""
        spec = _make_fv_spec()
        spec["schema"] = "OTHER_SCHEMA"
        results = _check_database_schema_mismatch([spec], "DB", "MY_SCHEMA")
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "SCHEMA_MISMATCH" for r in warnings)

    def test_spec_schema_field_alias_checked(self):
        """schema_ (Pydantic alias) is also checked for mismatch."""
        spec = _make_fv_spec()
        spec.pop("schema", None)
        spec["schema_"] = "WRONG_SCHEMA"
        results = _check_database_schema_mismatch([spec], "DB", "MY_SCHEMA")
        warnings = [r for r in results if r.severity == "WARNING"]
        assert any(r.code == "SCHEMA_MISMATCH" for r in warnings)

    def test_spec_matching_target_no_warning(self):
        """Spec whose database/schema match the target produces no mismatch warnings."""
        spec = _make_fv_spec()
        spec["database"] = "MY_DB"
        spec["schema"] = "MY_SCHEMA"
        results = _check_database_schema_mismatch([spec], "MY_DB", "MY_SCHEMA")
        mismatch = [r for r in results if r.code in ("DB_MISMATCH", "SCHEMA_MISMATCH")]
        assert len(mismatch) == 0

    def test_spec_without_database_field_no_warning(self):
        """Spec with no database field does not produce a DB_MISMATCH warning."""
        spec = _make_fv_spec()
        spec.pop("database", None)
        results = _check_database_schema_mismatch([spec], "MY_DB", "MY_SCHEMA")
        db_warnings = [r for r in results if r.code == "DB_MISMATCH"]
        assert len(db_warnings) == 0

    def test_empty_target_no_warning(self):
        """When target_database/schema are empty, no mismatch warnings are produced."""
        spec = _make_fv_spec()
        spec["database"] = "SOME_DB"
        spec["schema"] = "SOME_SCHEMA"
        results = _check_database_schema_mismatch([spec], "", "")
        mismatch = [r for r in results if r.code in ("DB_MISMATCH", "SCHEMA_MISMATCH")]
        assert len(mismatch) == 0

    def test_multiple_specs_each_checked(self):
        """All specs in the batch are checked for mismatches."""
        spec1 = _make_fv_spec(name="fv1")
        spec2 = _make_fv_spec(name="fv2")
        spec1["database"] = "WRONG_DB"
        spec2["database"] = "WRONG_DB"
        results = _check_database_schema_mismatch([spec1, spec2], "MY_DB", "MY_SCHEMA")
        warnings = [r for r in results if r.code == "DB_MISMATCH"]
        assert len(warnings) == 2

    def test_validate_specs_with_target_passes_mismatch_warnings(self):
        """validate_specs with target_database/schema returns DB_MISMATCH warnings."""
        spec = _make_fv_spec(version="V1")
        spec["database"] = "OTHER_DB"
        batch = _batch(spec)
        results = validate_specs(
            batch,
            _empty_applied(),
            target_database="MY_DB",
            target_schema="MY_SCHEMA",
        )
        warnings = [r for r in results if r.code == "DB_MISMATCH"]
        assert len(warnings) >= 1

    def test_validate_specs_without_target_no_mismatch_warnings(self):
        """validate_specs without target args does not produce mismatch warnings."""
        spec = _make_fv_spec(version="V1")
        spec["database"] = "OTHER_DB"
        batch = _batch(spec)
        results = validate_specs(batch, _empty_applied())
        mismatch = [r for r in results if r.code in ("DB_MISMATCH", "SCHEMA_MISMATCH")]
        assert len(mismatch) == 0
