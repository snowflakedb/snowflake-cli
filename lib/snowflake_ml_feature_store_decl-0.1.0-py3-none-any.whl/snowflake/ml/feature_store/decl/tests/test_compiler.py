"""Tests for decl/compiler.py — normalize_types, inline_udf_source, normalize_durations, parse_duration_to_seconds."""

import os
import tempfile

from snowflake.ml.feature_store.decl.compiler import (
    compile_spec,
    inline_udf_source,
    normalize_durations,
    normalize_types,
    parse_duration_to_seconds,
)

# ---------------------------------------------------------------------------
# parse_duration_to_seconds
# ---------------------------------------------------------------------------


class TestParseDurationToSeconds:
    def test_none_returns_none(self):
        assert parse_duration_to_seconds(None) is None

    def test_integer_passthrough(self):
        assert parse_duration_to_seconds(300) == 300

    def test_integer_zero(self):
        assert parse_duration_to_seconds(0) == 0

    def test_float_truncated(self):
        result = parse_duration_to_seconds(1.5)
        assert result == 1

    def test_seconds_plain_int_string(self):
        assert parse_duration_to_seconds("300") == 300

    def test_seconds_s_suffix(self):
        assert parse_duration_to_seconds("300s") == 300

    def test_seconds_sec_suffix(self):
        assert parse_duration_to_seconds("60sec") == 60

    def test_seconds_seconds_suffix(self):
        assert parse_duration_to_seconds("5seconds") == 5

    def test_minutes_m_suffix(self):
        assert parse_duration_to_seconds("5m") == 300

    def test_minutes_min_suffix(self):
        assert parse_duration_to_seconds("10min") == 600

    def test_minutes_minutes_suffix(self):
        assert parse_duration_to_seconds("2minutes") == 120

    def test_hours_h_suffix(self):
        assert parse_duration_to_seconds("1h") == 3600

    def test_hours_hr_suffix(self):
        assert parse_duration_to_seconds("2hr") == 7200

    def test_hours_hours_suffix(self):
        assert parse_duration_to_seconds("1hours") == 3600

    def test_days_d_suffix(self):
        assert parse_duration_to_seconds("7d") == 604800

    def test_days_day_suffix(self):
        assert parse_duration_to_seconds("1day") == 86400

    def test_days_days_suffix(self):
        assert parse_duration_to_seconds("3days") == 259200

    def test_weeks_w_suffix(self):
        assert parse_duration_to_seconds("1w") == 604800

    def test_weeks_week_suffix(self):
        assert parse_duration_to_seconds("2week") == 1209600

    def test_weeks_weeks_suffix(self):
        assert parse_duration_to_seconds("1weeks") == 604800

    def test_fractional_minutes(self):
        result = parse_duration_to_seconds("1.5m")
        assert result == 90

    def test_invalid_unit_raises_value_error(self):
        import pytest

        with pytest.raises(ValueError, match="Unknown duration unit"):
            parse_duration_to_seconds("5x")

    def test_invalid_format_raises_value_error(self):
        import pytest

        with pytest.raises(ValueError):
            parse_duration_to_seconds("abc")

    def test_whitespace_stripped(self):
        assert parse_duration_to_seconds("  5m  ") == 300


# ---------------------------------------------------------------------------
# normalize_types
# ---------------------------------------------------------------------------


class TestNormalizeTypes:
    def test_top_level_type_field_resolved(self):
        d = {"type": "str"}
        result = normalize_types(d)
        assert result["type"] == "StringType"

    def test_nested_type_field_resolved(self):
        d = {"join_keys": [{"name": "user_id", "type": "int"}]}
        result = normalize_types(d)
        assert result["join_keys"][0]["type"] == "LongType"

    def test_canonical_type_unchanged(self):
        d = {"type": "StringType"}
        result = normalize_types(d)
        assert result["type"] == "StringType"

    def test_unknown_type_passthrough(self):
        d = {"type": "MyCustomType"}
        result = normalize_types(d)
        assert result["type"] == "MyCustomType"

    def test_non_type_string_field_unchanged(self):
        d = {"name": "str"}  # "str" here is a name, not a type field
        result = normalize_types(d)
        assert result["name"] == "str"

    def test_deeply_nested(self):
        d = {
            "features": [
                {
                    "source_column": {"name": "val", "type": "float"},
                    "output_column": {"name": "out", "type": "number"},
                }
            ]
        }
        result = normalize_types(d)
        assert result["features"][0]["source_column"]["type"] == "DoubleType"
        assert result["features"][0]["output_column"]["type"] == "DoubleType"

    def test_handles_non_dict_top_level(self):
        assert normalize_types([{"type": "str"}]) == [{"type": "StringType"}]
        assert normalize_types("hello") == "hello"
        assert normalize_types(42) == 42


# ---------------------------------------------------------------------------
# normalize_durations
# ---------------------------------------------------------------------------


class TestNormalizeDurations:
    def test_feature_granularity_renamed_and_converted(self):
        d = {"feature_granularity": "5m"}
        result = normalize_durations(d)
        assert "feature_granularity" not in result
        assert result["feature_granularity_sec"] == 300

    def test_target_lag_renamed_and_converted(self):
        d = {"target_lag": "1h"}
        result = normalize_durations(d)
        assert "target_lag" not in result
        assert result["target_lag_sec"] == 3600

    def test_window_renamed_and_converted(self):
        d = {"window": "7d"}
        result = normalize_durations(d)
        assert "window" not in result
        assert result["window_sec"] == 604800

    def test_offset_renamed_and_converted(self):
        d = {"offset": "1m"}
        result = normalize_durations(d)
        assert "offset" not in result
        assert result["offset_sec"] == 60

    def test_duration_none_skipped(self):
        d = {"feature_granularity": None}
        result = normalize_durations(d)
        assert "feature_granularity_sec" not in result
        assert "feature_granularity" in result  # kept as-is when None

    def test_integer_duration_preserved(self):
        d = {"target_lag": 300}
        result = normalize_durations(d)
        assert result["target_lag_sec"] == 300

    def test_non_duration_keys_unchanged(self):
        d = {"name": "fv", "kind": "StreamingFeatureView"}
        result = normalize_durations(d)
        assert result["name"] == "fv"
        assert result["kind"] == "StreamingFeatureView"

    def test_nested_duration_keys_converted(self):
        d = {"features": [{"window": "30d", "function": "sum"}]}
        result = normalize_durations(d)
        assert result["features"][0]["window_sec"] == 2592000
        assert "window" not in result["features"][0]

    def test_invalid_duration_kept_unchanged(self):
        d = {"feature_granularity": "invalid_unit_xyz"}
        result = normalize_durations(d)
        # Invalid duration kept in original key, no _sec variant
        assert "feature_granularity" in result
        assert "feature_granularity_sec" not in result


# ---------------------------------------------------------------------------
# inline_udf_source
# ---------------------------------------------------------------------------


class TestInlineUdfSource:
    def test_no_udf_returns_unchanged(self):
        d = {"kind": "Entity", "name": "customer"}
        result = inline_udf_source(d, None)
        assert result == d

    def test_udf_without_file_returns_unchanged(self):
        d = {"udf": {"name": "fn", "engine": "pandas"}}
        result = inline_udf_source(d, None)
        assert "function_definition" not in result["udf"] or result["udf"]["function_definition"] is None

    def test_udf_with_file_inlines_source(self):
        udf_code = "def my_fn(df):\n    return df * 2\n"
        with tempfile.TemporaryDirectory() as tmpdir:
            udf_path = os.path.join(tmpdir, "my_fn.py")
            with open(udf_path, "w") as f:
                f.write(udf_code)

            d = {"udf": {"name": "my_fn", "file": "my_fn.py"}}
            result = inline_udf_source(d, tmpdir)

        assert result["udf"]["function_definition"] == udf_code
        assert "file" not in result["udf"]

    def test_udf_file_not_found_returns_unchanged(self):
        d = {"udf": {"name": "fn", "file": "nonexistent.py"}}
        with tempfile.TemporaryDirectory() as tmpdir:
            result = inline_udf_source(d, tmpdir)
        # File not found: file key is not removed, no function_definition inlined
        assert "file" in result["udf"] or result["udf"].get("file") == "nonexistent.py"


# ---------------------------------------------------------------------------
# compile_spec
# ---------------------------------------------------------------------------


class TestCompileSpec:
    def test_compile_runs_all_passes(self):
        d = {
            "kind": "StreamingFeatureView",
            "name": "fv",
            "features": [
                {
                    "source_column": {"name": "val", "type": "float"},
                    "output_column": {"name": "out", "type": "int"},
                    "window": "5m",
                }
            ],
        }
        result = compile_spec(d)
        # normalize_types
        assert result["features"][0]["source_column"]["type"] == "DoubleType"
        assert result["features"][0]["output_column"]["type"] == "LongType"
        # normalize_durations
        assert result["features"][0]["window_sec"] == 300
        assert "window" not in result["features"][0]

    def test_compile_with_no_udf_is_fine(self):
        d = {"kind": "Entity", "name": "user", "join_keys": [{"name": "user_id", "type": "str"}]}
        result = compile_spec(d)
        assert result["join_keys"][0]["type"] == "StringType"

    def test_compile_with_spec_file_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            udf_code = "def fn(df):\n    return df\n"
            udf_path = os.path.join(tmpdir, "fn.py")
            with open(udf_path, "w") as f:
                f.write(udf_code)
            d = {
                "kind": "StreamingFeatureView",
                "name": "fv",
                "udf": {"name": "fn", "file": "fn.py"},
            }
            result = compile_spec(d, spec_file_dir=tmpdir)

        assert result["udf"]["function_definition"] == udf_code
        assert "file" not in result["udf"]


class TestCompileSpecFeatureAggregationMethod:
    def test_feature_aggregation_method_preserved(self):
        d = {
            "kind": "StreamingFeatureView",
            "name": "fv",
            "feature_aggregation_method": "continuous",
        }
        result = compile_spec(d)
        assert result["feature_aggregation_method"] == "continuous"

    def test_feature_aggregation_method_tiles_preserved(self):
        d = {
            "kind": "StreamingFeatureView",
            "name": "fv",
            "feature_aggregation_method": "tiles",
        }
        result = compile_spec(d)
        assert result["feature_aggregation_method"] == "tiles"

    def test_feature_aggregation_method_not_treated_as_duration(self):
        """feature_aggregation_method must NOT be renamed to _sec."""
        d = {"feature_aggregation_method": "continuous"}
        result = compile_spec(d)
        assert "feature_aggregation_method" in result
        assert "feature_aggregation_method_sec" not in result

    def test_feature_aggregation_method_not_treated_as_type(self):
        """feature_aggregation_method value must NOT be resolved via normalize_type."""
        d = {"feature_aggregation_method": "continuous"}
        result = compile_spec(d)
        assert result["feature_aggregation_method"] == "continuous"
