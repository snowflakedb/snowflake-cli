"""Tests for decl/queries.py — SQL string factory functions."""

from __future__ import annotations

import pytest

from snowflake.ml.feature_store.decl.queries import (
    describe_columns_query,
    describe_query,
    drop_queries,
    export_queries,
    list_query,
    state_queries,
)


# ---------------------------------------------------------------------------
# state_queries
# ---------------------------------------------------------------------------


class TestStateQueries:
    def test_returns_dict(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert isinstance(result, dict)

    def test_show_ofts_key_present(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert "show_ofts" in result

    def test_show_tables_key_present(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert "show_tables" in result

    def test_show_ofts_contains_db_and_schema(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert "MYDB" in result["show_ofts"]
        assert "MYSCHEMA" in result["show_ofts"]

    def test_show_tables_contains_db_and_schema(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert "MYDB" in result["show_tables"]
        assert "MYSCHEMA" in result["show_tables"]

    def test_show_ofts_is_show_online_feature_tables(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert "SHOW ONLINE FEATURE TABLES" in result["show_ofts"]

    def test_show_tables_is_show_tables_like(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert "SHOW TABLES" in result["show_tables"]
        assert "%" in result["show_tables"]

    def test_show_ofts_exact(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert result["show_ofts"] == "SHOW ONLINE FEATURE TABLES IN SCHEMA MYDB.MYSCHEMA"

    def test_show_tables_exact(self):
        result = state_queries("MYDB", "MYSCHEMA")
        assert result["show_tables"] == "SHOW TABLES LIKE '%' IN SCHEMA MYDB.MYSCHEMA"

    def test_different_db_and_schema(self):
        result = state_queries("PROD_DB", "FS_SCHEMA")
        assert "PROD_DB" in result["show_ofts"]
        assert "FS_SCHEMA" in result["show_ofts"]
        assert "PROD_DB" in result["show_tables"]
        assert "FS_SCHEMA" in result["show_tables"]


# ---------------------------------------------------------------------------
# list_query
# ---------------------------------------------------------------------------


class TestListQuery:
    def test_returns_string(self):
        result = list_query("MYDB", "MYSCHEMA")
        assert isinstance(result, str)

    def test_contains_db_and_schema(self):
        result = list_query("MYDB", "MYSCHEMA")
        assert "MYDB" in result
        assert "MYSCHEMA" in result

    def test_exact_sql(self):
        result = list_query("MYDB", "MYSCHEMA")
        assert result == "SHOW ONLINE FEATURE TABLES IN SCHEMA MYDB.MYSCHEMA"

    def test_is_show_online_feature_tables(self):
        result = list_query("MYDB", "MYSCHEMA")
        assert result.startswith("SHOW ONLINE FEATURE TABLES")

    def test_different_db_and_schema(self):
        result = list_query("PROD_DB", "FS_SCHEMA")
        assert "PROD_DB" in result
        assert "FS_SCHEMA" in result


# ---------------------------------------------------------------------------
# describe_query
# ---------------------------------------------------------------------------


class TestDescribeQuery:
    def test_returns_string(self):
        result = describe_query("my_table", "MYDB", "MYSCHEMA")
        assert isinstance(result, str)

    def test_contains_name(self):
        result = describe_query("my_table", "MYDB", "MYSCHEMA")
        assert "my_table" in result

    def test_contains_db_and_schema(self):
        result = describe_query("my_table", "MYDB", "MYSCHEMA")
        assert "MYDB" in result
        assert "MYSCHEMA" in result

    def test_exact_sql(self):
        result = describe_query("my_table", "MYDB", "MYSCHEMA")
        assert result == "SHOW ONLINE FEATURE TABLES LIKE 'my_table' IN SCHEMA MYDB.MYSCHEMA"

    def test_name_is_single_quoted(self):
        result = describe_query("my_table", "MYDB", "MYSCHEMA")
        assert "'my_table'" in result

    def test_name_with_underscores_and_digits(self):
        result = describe_query("my_fv_v1", "DB", "SCH")
        assert "my_fv_v1" in result

    def test_is_show_online_feature_tables_like(self):
        result = describe_query("tbl", "MYDB", "MYSCHEMA")
        assert "SHOW ONLINE FEATURE TABLES LIKE" in result


# ---------------------------------------------------------------------------
# describe_columns_query
# ---------------------------------------------------------------------------


class TestDescribeColumnsQuery:
    def test_returns_string(self):
        result = describe_columns_query("my_table", "MYDB", "MYSCHEMA")
        assert isinstance(result, str)

    def test_contains_name(self):
        result = describe_columns_query("my_table", "MYDB", "MYSCHEMA")
        assert "my_table" in result

    def test_contains_db_and_schema(self):
        result = describe_columns_query("my_table", "MYDB", "MYSCHEMA")
        assert "MYDB" in result
        assert "MYSCHEMA" in result

    def test_starts_with_describe(self):
        result = describe_columns_query("my_table", "MYDB", "MYSCHEMA")
        assert result.startswith("DESCRIBE ")

    def test_exact_sql(self):
        result = describe_columns_query("my_table", "MYDB", "MYSCHEMA")
        assert result == 'DESCRIBE ONLINE FEATURE TABLE "MYDB"."MYSCHEMA"."my_table"'

    def test_components_are_double_quoted(self):
        result = describe_columns_query("my_table", "MYDB", "MYSCHEMA")
        assert '"MYDB"' in result
        assert '"MYSCHEMA"' in result
        assert '"my_table"' in result

    def test_name_with_hyphens_is_quoted(self):
        result = describe_columns_query("my-table", "MYDB", "MYSCHEMA")
        assert '"my-table"' in result

    def test_name_with_spaces_is_quoted(self):
        result = describe_columns_query("my table", "MYDB", "MYSCHEMA")
        assert '"my table"' in result


# ---------------------------------------------------------------------------
# drop_queries
# ---------------------------------------------------------------------------


class TestDropQueries:
    def test_returns_list(self):
        result = drop_queries(["tbl1"], "MYDB", "MYSCHEMA")
        assert isinstance(result, list)

    def test_empty_names_returns_empty_list(self):
        result = drop_queries([], "MYDB", "MYSCHEMA")
        assert result == []

    def test_one_name_returns_one_sql(self):
        result = drop_queries(["tbl1"], "MYDB", "MYSCHEMA")
        assert len(result) == 1

    def test_multiple_names_returns_multiple_sqls(self):
        result = drop_queries(["tbl1", "tbl2", "tbl3"], "MYDB", "MYSCHEMA")
        assert len(result) == 3

    def test_each_sql_contains_its_name(self):
        result = drop_queries(["alpha", "beta"], "MYDB", "MYSCHEMA")
        assert any("alpha" in s for s in result)
        assert any("beta" in s for s in result)

    def test_each_sql_contains_db_and_schema(self):
        result = drop_queries(["tbl1"], "MYDB", "MYSCHEMA")
        assert "MYDB" in result[0]
        assert "MYSCHEMA" in result[0]

    def test_each_sql_is_drop_if_exists(self):
        result = drop_queries(["tbl1"], "MYDB", "MYSCHEMA")
        assert "DROP ONLINE FEATURE TABLE IF EXISTS" in result[0]

    def test_exact_sql(self):
        result = drop_queries(["my_table"], "MYDB", "MYSCHEMA")
        assert result[0] == 'DROP ONLINE FEATURE TABLE IF EXISTS "MYDB"."MYSCHEMA"."my_table"'

    def test_names_are_double_quoted(self):
        result = drop_queries(["my-table"], "MYDB", "MYSCHEMA")
        assert '"my-table"' in result[0]

    def test_order_preserved(self):
        names = ["zzz", "aaa", "mmm"]
        result = drop_queries(names, "MYDB", "MYSCHEMA")
        assert "zzz" in result[0]
        assert "aaa" in result[1]
        assert "mmm" in result[2]

    def test_each_sql_is_string(self):
        result = drop_queries(["tbl1", "tbl2"], "MYDB", "MYSCHEMA")
        assert all(isinstance(s, str) for s in result)


# ---------------------------------------------------------------------------
# export_queries
# ---------------------------------------------------------------------------


class TestExportQueries:
    def test_returns_dict(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert isinstance(result, dict)

    def test_show_ofts_key_present(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert "show_ofts" in result

    def test_describe_template_key_present(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert "describe_template" in result

    def test_show_ofts_contains_db_and_schema(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert "MYDB" in result["show_ofts"]
        assert "MYSCHEMA" in result["show_ofts"]

    def test_show_ofts_exact(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert result["show_ofts"] == "SHOW ONLINE FEATURE TABLES IN SCHEMA MYDB.MYSCHEMA"

    def test_describe_template_contains_db_and_schema(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert "MYDB" in result["describe_template"]
        assert "MYSCHEMA" in result["describe_template"]

    def test_describe_template_has_name_placeholder(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert "{name}" in result["describe_template"]

    def test_describe_template_formats_correctly(self):
        result = export_queries("MYDB", "MYSCHEMA")
        sql = result["describe_template"].format(name="my_table")
        assert sql == 'DESCRIBE ONLINE FEATURE TABLE "MYDB"."MYSCHEMA"."my_table"'

    def test_describe_template_contains_describe_keyword(self):
        result = export_queries("MYDB", "MYSCHEMA")
        assert "DESCRIBE" in result["describe_template"]

    def test_describe_template_formatted_name_is_quoted(self):
        result = export_queries("MYDB", "MYSCHEMA")
        sql = result["describe_template"].format(name="my-table")
        assert '"my-table"' in sql
