"""Tests for decl/http.py — stdlib-only HTTP POST helper."""

from __future__ import annotations

import io
import json
import urllib.error
import urllib.request
from unittest.mock import MagicMock, patch

import pytest

from snowflake.ml.feature_store.decl.http import post_json

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_URL = "https://service.example.snowflakecomputing.com/api/v1/ingest"
_PAT = "test-pat-token"
_BODY = {"records": {"src": [{"k": "v"}]}}


def _make_response(data: dict, status: int = 200) -> MagicMock:
    """Return a mock response that mimics urllib's http.client.HTTPResponse."""
    raw = json.dumps(data).encode("utf-8")
    mock_resp = MagicMock()
    mock_resp.read.return_value = raw
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    mock_resp.close = MagicMock()
    return mock_resp


# ---------------------------------------------------------------------------
# post_json — happy path
# ---------------------------------------------------------------------------


class TestPostJsonSuccess:
    def test_returns_dict_on_success(self):
        response_data = {"status": "ok", "ingested": 3}
        mock_resp = _make_response(response_data)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            result = post_json(_URL, _PAT, _BODY)

        assert isinstance(result, dict)
        assert result["status"] == "ok"

    def test_sends_correct_content_type(self):
        mock_resp = _make_response({"status": "ok"})
        captured: list[urllib.request.Request] = []

        def fake_urlopen(req, timeout=None):
            captured.append(req)
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            post_json(_URL, _PAT, _BODY)

        assert captured[0].get_header("Content-type") == "application/json"

    def test_sends_bearer_auth_header(self):
        mock_resp = _make_response({"status": "ok"})
        captured: list[urllib.request.Request] = []

        def fake_urlopen(req, timeout=None):
            captured.append(req)
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            post_json(_URL, _PAT, _BODY)

        auth = captured[0].get_header("Authorization")
        assert auth is not None
        assert _PAT in auth

    def test_sends_post_method(self):
        mock_resp = _make_response({"status": "ok"})
        captured: list[urllib.request.Request] = []

        def fake_urlopen(req, timeout=None):
            captured.append(req)
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            post_json(_URL, _PAT, _BODY)

        assert captured[0].get_method() == "POST"

    def test_body_is_json_encoded(self):
        mock_resp = _make_response({"status": "ok"})
        captured: list[urllib.request.Request] = []

        def fake_urlopen(req, timeout=None):
            captured.append(req)
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            post_json(_URL, _PAT, _BODY)

        sent_data = json.loads(captured[0].data.decode("utf-8"))
        assert sent_data == _BODY

    def test_response_is_closed_after_read(self):
        mock_resp = _make_response({"status": "ok"})

        with patch("urllib.request.urlopen", return_value=mock_resp):
            post_json(_URL, _PAT, _BODY)

        mock_resp.close.assert_called_once()


# ---------------------------------------------------------------------------
# post_json — HTTP error handling
# ---------------------------------------------------------------------------


class TestPostJsonHttpErrors:
    def test_http_error_returns_error_dict(self):
        err_body = b"Unauthorized"
        exc = urllib.error.HTTPError(url=_URL, code=401, msg="Unauthorized", hdrs={}, fp=io.BytesIO(err_body))
        with patch("urllib.request.urlopen", side_effect=exc):
            result = post_json(_URL, _PAT, _BODY)

        assert result["status"] == "error"
        assert result.get("http_status") == 401

    def test_http_error_includes_error_body(self):
        err_body = b"bad request details"
        exc = urllib.error.HTTPError(url=_URL, code=400, msg="Bad Request", hdrs={}, fp=io.BytesIO(err_body))
        with patch("urllib.request.urlopen", side_effect=exc):
            result = post_json(_URL, _PAT, _BODY)

        assert "error" in result
        assert "bad request details" in result["error"]

    def test_url_error_returns_error_dict(self):
        exc = urllib.error.URLError(reason="Connection refused")
        with patch("urllib.request.urlopen", side_effect=exc):
            result = post_json(_URL, _PAT, _BODY)

        assert result["status"] == "error"
        assert "error" in result

    def test_os_error_returns_error_dict(self):
        with patch("urllib.request.urlopen", side_effect=OSError("timeout")):
            result = post_json(_URL, _PAT, _BODY)

        assert result["status"] == "error"

    def test_url_error_message_mentions_unreachable(self):
        exc = urllib.error.URLError(reason="Connection refused")
        with patch("urllib.request.urlopen", side_effect=exc):
            result = post_json(_URL, _PAT, _BODY)

        assert "unreachable" in result["error"].lower() or "error" in result


# ---------------------------------------------------------------------------
# post_json — timeout parameter
# ---------------------------------------------------------------------------


class TestPostJsonTimeout:
    def test_default_timeout_is_passed(self):
        mock_resp = _make_response({"status": "ok"})
        timeouts: list[float] = []

        def fake_urlopen(req, timeout=None):
            timeouts.append(timeout)
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            post_json(_URL, _PAT, _BODY)

        assert timeouts[0] == pytest.approx(120.0)

    def test_custom_timeout_is_forwarded(self):
        mock_resp = _make_response({"status": "ok"})
        timeouts: list[float] = []

        def fake_urlopen(req, timeout=None):
            timeouts.append(timeout)
            return mock_resp

        with patch("urllib.request.urlopen", side_effect=fake_urlopen):
            post_json(_URL, _PAT, _BODY, timeout=30.0)

        assert timeouts[0] == pytest.approx(30.0)
