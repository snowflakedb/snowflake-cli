"""Tests for decl/state.py — applied state parsing from raw SHOW results."""

from __future__ import annotations

import json

from snowflake.ml.feature_store.decl.invariants import _structural_fingerprint_hash
from snowflake.ml.feature_store.decl.state import (
    _extract_spec_from_oft,
    _parse_oft_name,
    fetch_applied_state,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SPEC_PAYLOAD = {
    "kind": "StreamingFeatureView",
    "metadata": {"name": "user_clicks", "version": "V1", "database": "DB", "schema": "SCH"},
    "spec": {
        "ordered_entity_column_names": ["USER_ID"],
        "sources": [],
        "features": [
            {
                "source_column": {"name": "EVENT", "type": "StringType"},
                "output_column": {"name": "EVENT", "type": "StringType"},
            }
        ],
    },
}

_SHOW_ROW = {
    "name": "USER_CLICKS$V1$ONLINE",
    "created_on": "2024-01-01 00:00:00",
    "specification": json.dumps(_SPEC_PAYLOAD),
}


# ---------------------------------------------------------------------------
# _parse_oft_name tests
# ---------------------------------------------------------------------------


class TestParseOftName:
    def test_standard_naming_convention(self):
        base, version = _parse_oft_name("USER_CLICKS$V1$ONLINE")
        assert base == "USER_CLICKS"
        assert version == "V1"

    def test_version_with_dots(self):
        base, version = _parse_oft_name("MY_FV$1.2.3$ONLINE")
        assert base == "MY_FV"
        assert version == "1.2.3"

    def test_no_online_suffix(self):
        # Malformed name — should still not crash
        base, version = _parse_oft_name("MY_FV$V2")
        assert base == "MY_FV"
        assert version == "V2"

    def test_minimal_name(self):
        base, version = _parse_oft_name("FV$V1$ONLINE")
        assert base == "FV"
        assert version == "V1"


# ---------------------------------------------------------------------------
# _extract_spec_from_oft tests
# ---------------------------------------------------------------------------


class TestExtractSpecFromOft:
    def test_extracts_valid_json(self):
        row = {"specification": json.dumps(_SPEC_PAYLOAD)}
        spec = _extract_spec_from_oft(row)
        assert spec is not None
        assert spec.get("kind") == "StreamingFeatureView"

    def test_missing_specification_returns_none(self):
        row = {"name": "FV$V1$ONLINE"}
        spec = _extract_spec_from_oft(row)
        assert spec is None

    def test_invalid_json_returns_none(self):
        row = {"specification": "not-valid-json"}
        spec = _extract_spec_from_oft(row)
        assert spec is None

    def test_empty_specification_returns_none(self):
        row = {"specification": ""}
        spec = _extract_spec_from_oft(row)
        assert spec is None


# ---------------------------------------------------------------------------
# fetch_applied_state tests
# ---------------------------------------------------------------------------


class TestFetchAppliedState:
    def test_empty_results_returns_empty_state(self):
        state = fetch_applied_state([], None)
        assert state.objects == {}

    def test_single_row_parsed_correctly(self):
        state = fetch_applied_state([_SHOW_ROW], None)
        assert len(state.objects) == 1
        key = list(state.objects.keys())[0]
        obj = state.objects[key]
        assert obj.name == "USER_CLICKS"
        assert obj.version == "V1"

    def test_content_hash_is_populated(self):
        state = fetch_applied_state([_SHOW_ROW], None)
        obj = list(state.objects.values())[0]
        assert obj.content_hash != ""
        assert len(obj.content_hash) == 64  # SHA-256 hex

    def test_spec_payload_is_stored(self):
        state = fetch_applied_state([_SHOW_ROW], None)
        obj = list(state.objects.values())[0]
        assert obj.spec_payload != {}

    def test_multiple_rows_parsed(self):
        row2_spec = dict(_SPEC_PAYLOAD)
        row2_spec["metadata"] = dict(row2_spec["metadata"], name="profile_fv", version="V2")
        row2 = {
            "name": "PROFILE_FV$V2$ONLINE",
            "created_on": "2024-01-02 00:00:00",
            "specification": json.dumps(row2_spec),
        }
        state = fetch_applied_state([_SHOW_ROW, row2], None)
        assert len(state.objects) == 2

    def test_row_without_specification_column_is_skipped(self):
        row = {"name": "FV$V1$ONLINE", "created_on": "2024-01-01"}
        state = fetch_applied_state([row], None)
        assert len(state.objects) == 0

    def test_kind_is_set_from_spec(self):
        state = fetch_applied_state([_SHOW_ROW], None)
        obj = list(state.objects.values())[0]
        assert obj.kind == "StreamingFeatureView"

    def test_key_format(self):
        state = fetch_applied_state([_SHOW_ROW], None)
        key = list(state.objects.keys())[0]
        # Key should follow kind:db.schema:name format
        assert ":" in key


# ---------------------------------------------------------------------------
# fetch_applied_state with describe_map (Phase 1 — idempotent apply)
# ---------------------------------------------------------------------------


class TestFetchAppliedStateWithDescribeMap:
    """Verify that DESCRIBE data is used to build AppliedObjects when
    the SHOW result has no ``specification`` column (the normal case)."""

    _SHOW_ROW_NO_SPEC = {
        "name": "CLICK_FV$V1$ONLINE",
        "database_name": "DB",
        "schema_name": "SCH",
        "created_on": "2024-01-01 00:00:00",
    }

    _DESCRIBE_ROWS = [
        {"name": "USER_ID", "type": "VARCHAR", "primary key": "Y"},
        {"name": "EVENT", "type": "VARCHAR", "primary key": "N"},
    ]

    def test_describe_map_builds_applied_object(self):
        """Without a specification column, describe_map should produce an AppliedObject."""
        state = fetch_applied_state(
            [self._SHOW_ROW_NO_SPEC],
            None,
            describe_map={"CLICK_FV$V1$ONLINE": self._DESCRIBE_ROWS},
        )
        assert len(state.objects) == 1
        obj = list(state.objects.values())[0]
        assert obj.name == "CLICK_FV"
        assert obj.version == "V1"
        assert obj.content_hash != ""
        assert len(obj.content_hash) == 64  # SHA-256 hex

    def test_describe_map_key_format(self):
        """Key must be StreamingFeatureView:DB.SCH:CLICK_FV."""
        state = fetch_applied_state(
            [self._SHOW_ROW_NO_SPEC],
            None,
            describe_map={"CLICK_FV$V1$ONLINE": self._DESCRIBE_ROWS},
        )
        key = list(state.objects.keys())[0]
        assert key == "StreamingFeatureView:DB.SCH:CLICK_FV"

    def test_describe_map_content_hash_matches_spec_fingerprint(self):
        """Hash from DESCRIBE must equal _structural_fingerprint_hash of authoring spec."""
        state = fetch_applied_state(
            [self._SHOW_ROW_NO_SPEC],
            None,
            describe_map={"CLICK_FV$V1$ONLINE": self._DESCRIBE_ROWS},
        )
        obj = list(state.objects.values())[0]

        # Authoring spec with the same structural shape (StringType → VARCHAR)
        spec_data = {
            "kind": "StreamingFeatureView",
            "name": "CLICK_FV",
            "version": "V1",
            "features": [
                {"output_column": {"name": "EVENT", "type": "StringType"}},
            ],
        }
        expected_hash = _structural_fingerprint_hash(spec_data)
        assert obj.content_hash == expected_hash

    def test_no_describe_map_skips_row_without_spec(self):
        """Without describe_map, rows lacking specification are skipped (old behaviour)."""
        state = fetch_applied_state([self._SHOW_ROW_NO_SPEC], None, describe_map=None)
        assert len(state.objects) == 0

    def test_empty_describe_map_skips_row(self):
        """describe_map present but missing entry for this OFT → row skipped."""
        state = fetch_applied_state([self._SHOW_ROW_NO_SPEC], None, describe_map={})
        assert len(state.objects) == 0

    def test_multiple_ofts_with_describe_map(self):
        """Multiple OFTs are all parsed when describe_map has entries for each."""
        row2 = {
            "name": "PROFILE_FV$V2$ONLINE",
            "database_name": "DB",
            "schema_name": "SCH",
        }
        describe_map = {
            "CLICK_FV$V1$ONLINE": self._DESCRIBE_ROWS,
            "PROFILE_FV$V2$ONLINE": [{"name": "SCORE", "type": "FLOAT", "primary key": "N"}],
        }
        state = fetch_applied_state([self._SHOW_ROW_NO_SPEC, row2], None, describe_map=describe_map)
        assert len(state.objects) == 2
