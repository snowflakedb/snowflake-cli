"""Tests for decl/sql_generator.py — SQL DDL string generation."""

from __future__ import annotations

from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.sql_generator import (
    _snowflake_col_type,
    generate_sql,
)
from snowflake.ml.feature_store.decl.types import Plan, PlanOp

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fv_payload(
    name: str = "CLICK_FV",
    version: str = "V1",
    db: str = "DB",
    schema: str = "SCH",
    warehouse: str = "WH",
    lag: str = "0 seconds",
    with_udf: bool = False,
) -> dict:
    payload: dict = {
        "kind": "StreamingFeatureView",
        "name": name,
        "version": version,
        "database": db,
        "schema": schema,
        "warehouse": warehouse,
        "target_lag": lag,
        "ordered_entity_column_names": ["USER_ID"],
        "features": [
            {
                "source_column": {"name": "EVENT", "type": "StringType"},
                "output_column": {"name": "EVENT", "type": "StringType"},
            }
        ],
    }
    if with_udf:
        payload["udf"] = {
            "name": "my_udf",
            "engine": "pandas",
            "function_definition": "def my_udf(df): return df",
            "output_columns": [
                {"name": "USER_ID", "type": "StringType"},
                {"name": "EVENT", "type": "StringType"},
            ],
        }
    return payload


def _create_fv_op(payload: dict | None = None) -> PlanOp:
    return PlanOp(
        kind=OpKind.CREATE_FV,
        name="CLICK_FV",
        payload=payload or _fv_payload(),
    )


def _drop_fv_op(payload: dict | None = None) -> PlanOp:
    return PlanOp(
        kind=OpKind.DROP_FV,
        name="CLICK_FV",
        payload=payload or _fv_payload(),
    )


def _recreate_fv_op(payload: dict | None = None) -> PlanOp:
    return PlanOp(
        kind=OpKind.RECREATE_FV,
        name="CLICK_FV",
        payload=payload or _fv_payload(),
    )


def _create_entity_op() -> PlanOp:
    return PlanOp(
        kind=OpKind.CREATE_ENTITY,
        name="user",
        payload={"kind": "Entity", "name": "user"},
    )


def _create_source_op() -> PlanOp:
    return PlanOp(
        kind=OpKind.CREATE_SOURCE,
        name="clicks",
        payload={"kind": "StreamingSource", "name": "clicks"},
    )


# ---------------------------------------------------------------------------
# _snowflake_col_type tests
# ---------------------------------------------------------------------------


class TestSnowflakeColType:
    def test_string_type(self):
        assert _snowflake_col_type({"type": "StringType"}) == "VARCHAR"

    def test_string_type_with_length(self):
        assert _snowflake_col_type({"type": "StringType", "length": 100}) == "VARCHAR(100)"

    def test_integer_type(self):
        assert _snowflake_col_type({"type": "IntegerType"}) == "INTEGER"

    def test_float_type(self):
        assert _snowflake_col_type({"type": "FloatType"}) == "FLOAT"

    def test_decimal_type(self):
        assert _snowflake_col_type({"type": "DecimalType", "precision": 18, "scale": 4}) == "NUMBER(18,4)"

    def test_decimal_type_no_precision(self):
        assert _snowflake_col_type({"type": "DecimalType"}) == "NUMBER"

    def test_boolean_type(self):
        assert _snowflake_col_type({"type": "BooleanType"}) == "BOOLEAN"

    def test_timestamp_type(self):
        assert _snowflake_col_type({"type": "TimestampType"}) == "TIMESTAMP_NTZ"

    def test_long_type_alias(self):
        assert _snowflake_col_type({"type": "LongType"}) == "INTEGER"

    def test_double_type_alias(self):
        assert _snowflake_col_type({"type": "DoubleType"}) == "FLOAT"


# ---------------------------------------------------------------------------
# generate_sql tests
# ---------------------------------------------------------------------------


class TestGenerateSql:
    def test_empty_plan_returns_empty(self):
        plan = Plan(ops=[], warnings=[])
        statements = generate_sql(plan)
        assert statements == []

    def test_entity_op_produces_no_ddl(self):
        plan = Plan(ops=[_create_entity_op()])
        statements = generate_sql(plan)
        # Entity is spec-level only in v0 — no DDL or empty/comment
        assert len(statements) == 0 or all("entity" in s.lower() or "--" in s for s in statements)

    def test_source_op_produces_no_ddl(self):
        plan = Plan(ops=[_create_source_op()])
        statements = generate_sql(plan)
        # Source is spec-level only in v0 — no DDL or comment
        assert len(statements) == 0 or all("source" in s.lower() or "--" in s for s in statements)

    def test_create_fv_produces_create_oft(self):
        plan = Plan(ops=[_create_fv_op()])
        statements = generate_sql(plan)
        combined = "\n".join(statements).upper()
        assert "CREATE ONLINE FEATURE TABLE" in combined

    def test_create_fv_includes_offline_tables(self):
        payload = _fv_payload(with_udf=True)
        plan = Plan(ops=[_create_fv_op(payload)])
        statements = generate_sql(plan)
        combined = "\n".join(statements).upper()
        assert "CREATE TABLE" in combined
        assert "BACKFILL" in combined

    def test_create_fv_includes_primary_key(self):
        plan = Plan(ops=[_create_fv_op()])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "PRIMARY KEY" in combined
        assert "USER_ID" in combined

    def test_create_fv_includes_warehouse(self):
        payload = _fv_payload(warehouse="COMPUTE_WH")
        plan = Plan(ops=[_create_fv_op(payload)])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "COMPUTE_WH" in combined

    def test_create_fv_includes_target_lag(self):
        plan = Plan(ops=[_create_fv_op()])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "TARGET_LAG" in combined
        assert "0 seconds" in combined

    def test_create_fv_includes_spec_json(self):
        plan = Plan(ops=[_create_fv_op()])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "FROM SPECIFICATION" in combined or "SPECIFICATION" in combined

    def test_drop_fv_produces_drop_oft(self):
        plan = Plan(ops=[_drop_fv_op()])
        statements = generate_sql(plan)
        combined = "\n".join(statements).upper()
        assert "DROP ONLINE FEATURE TABLE" in combined

    def test_recreate_fv_drops_then_creates(self):
        plan = Plan(ops=[_recreate_fv_op()])
        statements = generate_sql(plan)
        combined = "\n".join(statements).upper()
        assert "DROP ONLINE FEATURE TABLE" in combined
        assert "CREATE ONLINE FEATURE TABLE" in combined
        # DROP comes before CREATE
        drop_idx = combined.index("DROP ONLINE FEATURE TABLE")
        create_idx = combined.index("CREATE ONLINE FEATURE TABLE")
        assert drop_idx < create_idx

    def test_oft_fqn_uses_version_online_suffix(self):
        payload = _fv_payload(name="MY_FV", version="V2", db="MYDB", schema="MYSCH")
        plan = Plan(ops=[_create_fv_op(payload)])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "MY_FV$V2$ONLINE" in combined


class TestGenerateSqlFeatureAggregationMethod:
    def test_spec_json_includes_feature_aggregation_method_when_set(self):
        payload = _fv_payload()
        payload["feature_aggregation_method"] = "continuous"
        payload["features"] = [
            {
                "source_column": {"name": "EVENT", "type": "StringType"},
                "output_column": {"name": "EVENT", "type": "StringType"},
                "function": "count",
                "window": "1h",
            }
        ]
        plan = Plan(ops=[_create_fv_op(payload)])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "feature_aggregation_method" in combined
        assert "continuous" in combined

    def test_spec_json_includes_tiles_method(self):
        payload = _fv_payload()
        payload["features"] = [
            {
                "source_column": {"name": "EVENT", "type": "StringType"},
                "output_column": {"name": "EVENT", "type": "StringType"},
                "function": "count",
                "window": "1h",
            }
        ]
        plan = Plan(ops=[_create_fv_op(payload)])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "feature_aggregation_method" in combined
        assert "tiles" in combined

    def test_spec_json_omits_feature_aggregation_method_when_no_windows(self):
        payload = _fv_payload()
        payload.pop("feature_aggregation_method", None)
        plan = Plan(ops=[_create_fv_op(payload)])
        statements = generate_sql(plan)
        combined = "\n".join(statements)
        assert "feature_aggregation_method" not in combined
