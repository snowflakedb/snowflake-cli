"""Tests for decl/examples.py — example spec generation."""

from __future__ import annotations

import os

import yaml

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestGenerateExample:
    def test_returns_status_created(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        result = generate_example(str(tmp_path))
        assert result["status"] == "created"

    def test_returns_three_files(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        result = generate_example(str(tmp_path))
        assert len(result["files"]) == 4

    def test_files_exist_on_disk(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        result = generate_example(str(tmp_path))
        for path in result["files"]:
            assert os.path.isfile(path), f"Expected file not found: {path}"

    def test_subdirectories_created(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        generate_example(str(tmp_path))
        assert (tmp_path / "entities").is_dir()
        assert (tmp_path / "datasources").is_dir()
        assert (tmp_path / "feature_views").is_dir()

    def test_entity_yaml_is_valid(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        generate_example(str(tmp_path))
        path = tmp_path / "entities" / "example_entity.yaml"
        assert path.exists()
        data = yaml.safe_load(path.read_text())
        assert data["kind"] == "Entity"
        assert data["name"] == "user"
        assert data["version"] == "v1"
        assert isinstance(data["join_keys"], list)
        assert data["join_keys"][0]["name"] == "user_id"

    def test_datasource_yaml_is_valid(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        generate_example(str(tmp_path))
        path = tmp_path / "datasources" / "example_events_source.yaml"
        assert path.exists()
        data = yaml.safe_load(path.read_text())
        assert data["kind"] == "StreamingSource"
        assert data["name"] == "user_events"
        assert isinstance(data["columns"], list)
        assert len(data["columns"]) == 4

    def test_feature_view_yaml_is_valid(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        generate_example(str(tmp_path))
        path = tmp_path / "feature_views" / "example_feature_view.yaml"
        assert path.exists()
        data = yaml.safe_load(path.read_text())
        assert data["kind"] == "StreamingFeatureView"
        assert data["online"] is True
        assert isinstance(data["features"], list)
        assert len(data["features"]) == 2

    def test_idempotent_on_second_call(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        result1 = generate_example(str(tmp_path))
        result2 = generate_example(str(tmp_path))
        assert result1["files"] == result2["files"]

    def test_output_dir_created_if_missing(self, tmp_path):
        from snowflake.ml.feature_store.decl.examples import generate_example

        nested = str(tmp_path / "a" / "b" / "c")
        result = generate_example(nested)
        assert result["status"] == "created"
        assert len(result["files"]) == 4
