"""Dependency graph extraction, topological sort, and cycle detection.

All functions are pure — no database connections, no file I/O.
"""

from __future__ import annotations

from collections import defaultdict

from snowflake.ml.feature_store.decl.types import AppliedState, ValidationResult

# Kind ordinals used to break ties in topological sorting so that
# Entity → Source → FeatureView → FeatureGroup ordering is stable.
_KIND_ORDER: dict[str, int] = {
    "Entity": 0,
    "StreamingSource": 1,
    "BatchSource": 1,
    "StreamingFeatureView": 2,
    "RealtimeFeatureView": 2,
    "BatchFeatureView": 2,
    "FeatureGroup": 3,
}


def extract_dependencies(spec: dict) -> list[str]:
    """Return names of objects this spec depends on.

    - ``FeatureView``: entity column names and source names.
    - ``FeatureGroup``: feature view names.
    - ``Entity`` / ``Source``: no dependencies.

    Args:
        spec: A normalized spec dict.

    Returns:
        List of dependency name strings.
    """
    kind = spec.get("kind", "")
    deps: list[str] = []

    if "FeatureView" in kind:
        for col in spec.get("entities", []):
            if isinstance(col, str) and col:
                deps.append(col)
        for src in spec.get("sources", []):
            src_name = src.get("name", "") if isinstance(src, dict) else ""
            if src_name:
                deps.append(src_name)

    elif kind == "FeatureGroup":
        for fv_ref in spec.get("feature_views", []):
            fv_name = fv_ref.get("name", "") if isinstance(fv_ref, dict) else ""
            if fv_name:
                deps.append(fv_name)

    return deps


def topological_sort(specs: list[dict]) -> list[dict]:
    """Sort specs by dependency order.

    Returns entities first, then sources, then feature views (respecting
    inter-FV dependencies), then feature groups.  Uses Kahn's algorithm
    with stable tie-breaking by ``_KIND_ORDER``.

    Args:
        specs: List of normalized spec dicts.

    Returns:
        Topologically-sorted list of spec dicts.
    """
    if not specs:
        return []

    name_to_spec: dict[str, dict] = {s.get("name", ""): s for s in specs}
    spec_names: set[str] = set(name_to_spec.keys())

    # Build in-degree map and adjacency list (only within the batch).
    in_degree: dict[str, int] = {n: 0 for n in spec_names}
    dependents: dict[str, list[str]] = defaultdict(list)

    for name, spec in name_to_spec.items():
        for dep in extract_dependencies(spec):
            if dep in spec_names:
                in_degree[name] += 1
                dependents[dep].append(name)

    # Kahn's algorithm: process nodes with in-degree 0.
    # Use a list sorted by kind order for stable output.
    def _kind_order(name: str) -> int:
        return _KIND_ORDER.get(name_to_spec[name].get("kind", ""), 99)

    ready = sorted((n for n, d in in_degree.items() if d == 0), key=_kind_order)
    result: list[dict] = []

    while ready:
        node = ready.pop(0)
        result.append(name_to_spec[node])
        for dep_name in sorted(dependents[node], key=_kind_order):
            in_degree[dep_name] -= 1
            if in_degree[dep_name] == 0:
                # Insert in kind-order position
                inserted = False
                for i, r in enumerate(ready):
                    if _kind_order(r) > _kind_order(dep_name):
                        ready.insert(i, dep_name)
                        inserted = True
                        break
                if not inserted:
                    ready.append(dep_name)

    # Append any remaining nodes (handles disconnected / external deps).
    remaining = [name_to_spec[n] for n in spec_names if name_to_spec[n] not in result]
    remaining.sort(key=lambda s: _KIND_ORDER.get(s.get("kind", ""), 99))
    result.extend(remaining)

    return result


def detect_cycles(specs: list[dict]) -> list[list[str]]:
    """Return list of cycles found in the dependency graph.

    Each cycle is a list of spec names forming the cycle.  Returns an
    empty list if the graph is acyclic.

    Uses DFS with path tracking to find all back-edges.

    Args:
        specs: List of normalized spec dicts.

    Returns:
        List of cycles; each cycle is a list of name strings.
    """
    name_to_spec: dict[str, dict] = {s.get("name", ""): s for s in specs}
    spec_names: set[str] = set(name_to_spec.keys())

    # Build adjacency list restricted to the batch.
    graph: dict[str, list[str]] = {n: [] for n in spec_names}
    for name, spec in name_to_spec.items():
        for dep in extract_dependencies(spec):
            if dep in spec_names:
                graph[name].append(dep)

    visited: set[str] = set()
    path_set: set[str] = set()
    cycles: list[list[str]] = []

    def _dfs(node: str, path: list[str]) -> None:
        visited.add(node)
        path_set.add(node)
        path.append(node)

        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                _dfs(neighbor, path)
            elif neighbor in path_set:
                # Found a back-edge → cycle
                cycle_start = path.index(neighbor)
                cycles.append(path[cycle_start:] + [neighbor])

        path.pop()
        path_set.discard(node)

    for name in spec_names:
        if name not in visited:
            _dfs(name, [])

    return cycles


def resolve_dependencies(
    specs: list[dict],
    applied_state: AppliedState,
) -> list[ValidationResult]:
    """Two-phase dependency resolution.

    Phase 1: check all dependencies within the batch.
    Phase 2: check remaining unresolved dependencies against applied_state.

    Args:
        specs: List of normalized spec dicts.
        applied_state: Current applied-state snapshot.

    Returns:
        List of ``ValidationResult`` objects for any unresolved dependencies.
    """
    results: list[ValidationResult] = []

    # Collect available names from the batch.
    batch_names: set[str] = {s.get("name", "") for s in specs if s.get("name")}

    # Collect available entity join-keys, source names, and FV names from applied state.
    applied_entity_join_keys: set[str] = set()
    applied_source_names: set[str] = set()
    applied_fv_names: set[str] = set()

    for obj in applied_state.objects.values():
        payload = obj.spec_payload
        obj_kind = payload.get("kind", "")
        if obj_kind == "Entity":
            for jk in payload.get("join_keys", []):
                jk_name = jk.get("name", "")
                if jk_name:
                    applied_entity_join_keys.add(jk_name)
        elif obj_kind in ("StreamingSource", "BatchSource"):
            n = payload.get("name", "")
            if n:
                applied_source_names.add(n)
        elif "FeatureView" in obj_kind:
            n = payload.get("name", "")
            if n:
                applied_fv_names.add(n)

    # Also collect entity join-keys from batch entities.
    batch_entity_join_keys: set[str] = set()
    batch_source_names: set[str] = set()
    batch_fv_names: set[str] = set()

    for spec in specs:
        kind = spec.get("kind", "")
        name = spec.get("name", "")
        if kind == "Entity":
            for jk in spec.get("join_keys", []):
                jk_name = jk.get("name", "")
                if jk_name:
                    batch_entity_join_keys.add(jk_name)
        elif kind in ("StreamingSource", "BatchSource"):
            if name:
                batch_source_names.add(name)
        elif "FeatureView" in kind:
            if name:
                batch_fv_names.add(name)

    all_entity_join_keys = batch_entity_join_keys | applied_entity_join_keys
    all_source_names = batch_source_names | applied_source_names
    all_fv_names = batch_fv_names | applied_fv_names
    all_names = batch_names | {obj.name for obj in applied_state.objects.values()}

    for spec in specs:
        kind = spec.get("kind", "")
        name = spec.get("name", "")

        if "FeatureView" in kind:
            for ecol in spec.get("entities", []):
                if ecol and ecol not in all_entity_join_keys:
                    results.append(
                        ValidationResult(
                            severity="ERROR",
                            code="MISSING_ENTITY",
                            message=f"{name}: unresolved entity column '{ecol}'.",
                            object_name=name,
                        )
                    )
            for src_ref in spec.get("sources", []):
                src_name = src_ref.get("name", "") if isinstance(src_ref, dict) else ""
                if src_name and src_name not in all_source_names and src_name not in all_names:
                    results.append(
                        ValidationResult(
                            severity="ERROR",
                            code="MISSING_SOURCE",
                            message=f"{name}: unresolved source '{src_name}'.",
                            object_name=name,
                        )
                    )

        elif kind == "FeatureGroup":
            for fv_ref in spec.get("feature_views", []):
                fv_name = fv_ref.get("name", "") if isinstance(fv_ref, dict) else ""
                if fv_name and fv_name not in all_fv_names and fv_name not in all_names:
                    results.append(
                        ValidationResult(
                            severity="ERROR",
                            code="MISSING_FEATURE_VIEW",
                            message=f"{name}: unresolved feature view '{fv_name}'.",
                            object_name=name,
                        )
                    )

    return results
