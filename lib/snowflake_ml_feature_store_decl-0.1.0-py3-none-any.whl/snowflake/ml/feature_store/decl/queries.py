"""SQL string factories for feature store object operations.

No IO — no SQL execution, no HTTP calls, no file writes.
All functions accept connection context (database, schema) as plain string
arguments and return SQL strings for the CLI to execute.
"""

from __future__ import annotations


def state_queries(database: str, schema: str) -> dict[str, str]:
    """Return SQL strings for fetching applied state.

    Args:
        database: Snowflake database name.
        schema: Snowflake schema name.

    Returns:
        Dict with keys: ``show_ofts``, ``show_tables``.
    """
    location = f"{database}.{schema}"
    return {
        "show_ofts": f"SHOW ONLINE FEATURE TABLES IN SCHEMA {location}",
        "show_tables": f"SHOW TABLES LIKE '%' IN SCHEMA {location}",
    }


def list_query(database: str, schema: str) -> str:
    """Return the SHOW ONLINE FEATURE TABLES SQL string.

    Args:
        database: Snowflake database name.
        schema: Snowflake schema name.

    Returns:
        SQL string to list all online feature tables in the schema.
    """
    return f"SHOW ONLINE FEATURE TABLES IN SCHEMA {database}.{schema}"


def describe_query(name: str, database: str, schema: str) -> str:
    """Return the SHOW ONLINE FEATURE TABLES LIKE SQL string for a named object.

    Args:
        name: Online feature table name to look up.
        database: Snowflake database name.
        schema: Snowflake schema name.

    Returns:
        SQL string to show the named online feature table.
    """
    location = f"{database}.{schema}"
    return f"SHOW ONLINE FEATURE TABLES LIKE '{name}' IN SCHEMA {location}"


def describe_columns_query(name: str, database: str, schema: str) -> str:
    """Return the DESCRIBE ONLINE FEATURE TABLE SQL string for a named object.

    Args:
        name: Online feature table name.
        database: Snowflake database name.
        schema: Snowflake schema name.

    Returns:
        SQL string to describe the columns of the named online feature table.
    """
    return f'DESCRIBE ONLINE FEATURE TABLE "{database}"."{schema}"."{name}"'


def drop_queries(names: list[str], database: str, schema: str) -> list[str]:
    """Return DROP SQL strings for the named online feature tables.

    Args:
        names: List of online feature table names to drop.
        database: Snowflake database name.
        schema: Snowflake schema name.

    Returns:
        List of DROP ONLINE FEATURE TABLE IF EXISTS SQL strings, one per name.
    """
    return [
        f'DROP ONLINE FEATURE TABLE IF EXISTS "{database}"."{schema}"."{name}"'
        for name in names
    ]


def export_queries(database: str, schema: str) -> dict[str, str]:
    """Return SQL strings for the export workflow.

    Args:
        database: Snowflake database name.
        schema: Snowflake schema name.

    Returns:
        Dict with keys: ``show_ofts``, ``describe_template`` (with ``{name}``
        placeholder for use with ``.format(name=...)``).
    """
    location = f"{database}.{schema}"
    return {
        "show_ofts": f"SHOW ONLINE FEATURE TABLES IN SCHEMA {location}",
        "describe_template": f'DESCRIBE ONLINE FEATURE TABLE "{database}"."{schema}"."{{name}}"',
    }
