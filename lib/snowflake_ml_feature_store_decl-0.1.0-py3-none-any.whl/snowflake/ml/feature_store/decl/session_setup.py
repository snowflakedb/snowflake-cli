"""Session priming so DESCRIBE … TYPE = SPECIFICATION is enabled for the declarative client.

Isolated here so the SQL string and the strict-failure policy live in one place.
"""

from __future__ import annotations

from typing import Any, Callable

from snowflake.ml.feature_store.decl.errors import SessionSetupError

ALTER_SESSION_DESCRIBE_OFT_SPECIFICATION = "ALTER SESSION SET ENABLE_FEATURE_STORE_DESCRIBE_OFT_SPECIFICATION = TRUE"


def session_setup_queries() -> list[str]:
    """Return the ordered list of SQL statements that prime a session.

    Returns:
        A list of SQL strings that must each succeed before the declarative
        client issues any feature-store state query.
    """
    return [ALTER_SESSION_DESCRIBE_OFT_SPECIFICATION]


def ensure_session_setup(execute_query: Callable[[str], Any]) -> None:
    """Run every priming query through ``execute_query``.

    The CLI passes its bound ``self.execute_query`` callable so this module
    never owns a connection. Each query in ``session_setup_queries()`` is
    invoked in order; the first failure is wrapped in ``SessionSetupError``
    with ``__cause__`` set to the underlying exception, and propagated.

    Args:
        execute_query: A callable that executes a single SQL string.

    Raises:
        SessionSetupError: If any priming query fails.
    """
    for query in session_setup_queries():
        try:
            execute_query(query)
        except Exception as exc:
            raise SessionSetupError(query, exc) from exc


def apply_to_session(session: Any) -> None:
    """Run every priming query directly on a Snowpark ``Session``.

    Used by ``imperative_executor.execute_plan`` where a Snowpark session is
    already in hand. Each query is executed via ``session.sql(q).collect()``;
    the first failure is wrapped in ``SessionSetupError`` and propagated.

    Args:
        session: A Snowpark ``Session`` (or any object exposing
            ``.sql(query).collect()``).

    Raises:
        SessionSetupError: If any priming query fails.
    """
    for query in session_setup_queries():
        try:
            session.sql(query).collect()
        except Exception as exc:
            raise SessionSetupError(query, exc) from exc
