"""SQL DDL generator for the declarative feature store library.

Given a ``Plan``, produces ordered SQL DDL strings.
No execution — returns strings only.
"""

from __future__ import annotations

from typing import Any

from snowflake.ml.feature_store.decl.enums import OpKind
from snowflake.ml.feature_store.decl.spec_compiler import compile_to_spec, to_json
from snowflake.ml.feature_store.decl.types import Plan, PlanOp

# Snowflake column type mapping (mirrors ofs_quake/tests/utils/oft_manager.py).
_SF_TYPE_MAP: dict[str, str] = {
    "StringType": "VARCHAR",
    "IntegerType": "INTEGER",
    "LongType": "INTEGER",
    "FloatType": "FLOAT",
    "DoubleType": "FLOAT",
    "DecimalType": "NUMBER",
    "BooleanType": "BOOLEAN",
    "TimestampType": "TIMESTAMP_NTZ",
}


def _snowflake_col_type(col: dict[str, Any]) -> str:
    """Convert a column dict to a Snowflake DDL type string."""
    col_type = col.get("type", "")
    base = _SF_TYPE_MAP.get(col_type)
    if base is None:
        raise ValueError(f"Unsupported column type: {col_type!r}")

    if col_type == "StringType":
        length = col.get("length", 0)
        if length and length > 0:
            return f"VARCHAR({length})"
        return "VARCHAR"

    if col_type == "DecimalType":
        precision = col.get("precision", 0)
        if precision and precision > 0:
            scale = col.get("scale", 0)
            return f"NUMBER({precision},{scale})"
        return "NUMBER"

    return base


def _fqn(db: str, schema: str, table: str) -> str:
    """Build a quoted fully-qualified table name."""
    return f'"{db}"."{schema}".{table}'


def _oft_fqn(db: str, schema: str, name: str, version: str) -> str:
    """Build the OFT fully-qualified name including the $version$ONLINE suffix."""
    return f"{db}.{schema}.{name}${version}$ONLINE"


def _entity_op_sql(op: PlanOp, **_kw: Any) -> list[str]:
    """Entity DDL is intentionally NOT emitted as SQL strings here.

    Tag DDL for ``CREATE_ENTITY``, ``DROP_ENTITY``, and ``UPDATE_ENTITY``
    is executed by the imperative executor — see
    :func:`imperative_executor._execute_create_entity`,
    :func:`imperative_executor._execute_drop_entity`, and
    :func:`imperative_executor._execute_update_entity` — which call the
    imperative ``FeatureStore.register_entity`` / ``delete_entity`` and
    ``ALTER TAG`` directly.  The SQL generator returns an empty list so
    the apply pipeline can ignore entity ops when only SQL strings are
    of interest (e.g. ``snow feature apply --dry-run`` rendering).

    Future readers: do NOT re-introduce ``CREATE TAG`` / ``DROP TAG``
    SQL here — that would re-create the architectural boundary
    violation the entity round-trip migration removed.

    Args:
        op: The plan op (unused — the entity DDL is dispatched
            elsewhere; the parameter exists to satisfy the dispatcher's
            uniform signature).
        **_kw: Catch-all for the dispatcher's keyword args (database,
            schema, warehouse) which entity ops do not need.

    Returns:
        Always an empty list.
    """
    return []


def _create_source_sql(op: PlanOp, **_kw: Any) -> list[str]:
    """Source is spec-level only in v0 — no DDL needed."""
    return []


def _create_fv_sql(
    op: PlanOp,
    database: str = "",
    schema: str = "",
    warehouse: str = "",
) -> list[str]:
    """Generate DDL for a new feature view (offline tables + OFT).

    Uses ``spec_compiler.compile_to_spec()`` to build the imperative-format
    specification JSON that Snowflake expects in ``FROM SPECIFICATION``.

    Args:
        op: The ``CREATE_FV`` plan op carrying the authoring-format spec
            payload (kind, name, version, sources, features, etc.).
        database: Connection-context database used as a fallback when the
            spec payload does not carry a ``database`` field.
        schema: Connection-context schema used as a fallback when the spec
            payload does not carry a ``schema`` field.
        warehouse: Connection-context warehouse used as a fallback when the
            spec payload does not carry a ``warehouse`` field.

    Returns:
        Ordered list of SQL statements: offline backing tables (one
        ``CREATE TABLE IF NOT EXISTS`` per ``offline_configs[]`` entry, plus
        the matching ``$BACKFILL`` table) followed by the
        ``CREATE ONLINE FEATURE TABLE ... FROM SPECIFICATION ...`` for the
        OFT itself.  Empty list if the compiled spec carries no
        offline configs and no spec section (defensive).
    """
    stmts: list[str] = []
    payload = op.payload
    name = payload.get("name", "")
    version = payload.get("version", "V1")
    db = payload.get("database", database)
    sch = payload.get("schema", schema)
    wh = payload.get("warehouse", warehouse)

    # Compile authoring spec → imperative FeatureViewSpec format
    compiled = compile_to_spec(payload, db, sch)

    # --- Offline tables from compiled offline_configs ---
    for oc in compiled.get("offline_configs", []):
        if oc.get("store_type") != "snowflake":
            continue
        table_name = oc.get("table", "")
        cols = oc.get("columns", [])
        col_defs = ", ".join(f"{c['name']} {_snowflake_col_type(c)}" for c in cols)
        table_fqn = _fqn(db, sch, table_name)
        stmts.append(f"CREATE TABLE IF NOT EXISTS {table_fqn} ({col_defs})")
        stmts.append(f"CREATE TABLE IF NOT EXISTS {table_fqn}$BACKFILL ({col_defs})")

    # --- Online feature table ---
    spec_section = compiled.get("spec", {})
    entity_cols = spec_section.get("ordered_entity_column_names", [])

    # Build column list from offline_configs columns (entity) + features (output)
    all_cols: dict[str, str] = {}
    for oc in compiled.get("offline_configs", []):
        for c in oc.get("columns", []):
            all_cols[c["name"]] = _snowflake_col_type(c)

    online_col_parts: list[str] = []
    for ecol in entity_cols:
        col_type = all_cols.get(ecol, "VARCHAR")
        online_col_parts.append(f"{ecol} {col_type}")

    for feat in spec_section.get("features", []):
        oc_col = feat.get("output_column", {})
        col_name = oc_col.get("name", "")
        col_type = _snowflake_col_type(oc_col)
        online_col_parts.append(f"{col_name} {col_type}")

    col_list = ", ".join(online_col_parts)
    pk_clause = f"PRIMARY KEY ({', '.join(entity_cols)})"
    oft_fqn_str = _oft_fqn(db, sch, name, version)
    spec_json = to_json(compiled)

    warehouse_clause = f"WAREHOUSE = {wh}" if wh else ""
    target_lag = "'0 seconds'"

    oft_parts = [
        f"CREATE ONLINE FEATURE TABLE {oft_fqn_str} (",
        f"    {col_list}",
        f") {pk_clause}",
    ]
    if warehouse_clause:
        oft_parts.append(warehouse_clause)
    oft_parts.append(f"TARGET_LAG = {target_lag}")
    oft_parts.append(f"FROM SPECIFICATION $${spec_json}$$")

    stmts.append("\n".join(oft_parts))
    return stmts


def _drop_fv_sql(op: PlanOp, **_kw: Any) -> list[str]:
    """Generate DROP DDL for a feature view (OFT + offline tables)."""
    stmts: list[str] = []
    payload = op.payload
    name = payload.get("name", "")
    version = payload.get("version", "V1")
    db = payload.get("database", _kw.get("database", ""))
    sch = payload.get("schema", _kw.get("schema", ""))

    oft_fqn_str = _oft_fqn(db, sch, name, version)
    stmts.append(f"DROP ONLINE FEATURE TABLE IF EXISTS {oft_fqn_str}")

    for oc in payload.get("offline_configs", []):
        if oc.get("store_type") != "snowflake":
            continue
        table_name = oc.get("table", "")
        table_fqn = _fqn(db, sch, table_name)
        stmts.append(f"DROP TABLE IF EXISTS {table_fqn}$BACKFILL")
        stmts.append(f"DROP TABLE IF EXISTS {table_fqn}")

    return stmts


def _recreate_fv_sql(
    op: PlanOp,
    database: str = "",
    schema: str = "",
    warehouse: str = "",
) -> list[str]:
    """Generate DROP-then-CREATE DDL for a feature view."""
    stmts: list[str] = []
    drop_op = PlanOp(kind=OpKind.DROP_FV, name=op.name, payload=op.payload)
    stmts.extend(_drop_fv_sql(drop_op, database=database, schema=schema))
    create_op = PlanOp(kind=OpKind.CREATE_FV, name=op.name, payload=op.payload)
    stmts.extend(_create_fv_sql(create_op, database=database, schema=schema, warehouse=warehouse))
    return stmts


def generate_sql(
    plan: Plan,
    database: str = "",
    schema: str = "",
    warehouse: str = "",
) -> list[str]:
    """Generate ordered SQL DDL strings from a Plan.

    Args:
        plan: The execution plan from ``generate_plan``.
        database: Snowflake database name (from connection context).
        schema: Snowflake schema name (from connection context).
        warehouse: Snowflake warehouse name (from connection context).

    Returns:
        Ordered list of SQL DDL statement strings.
    """
    stmts: list[str] = []

    ctx = {"database": database, "schema": schema, "warehouse": warehouse}

    _dispatch = {
        OpKind.CREATE_ENTITY: _entity_op_sql,
        OpKind.DROP_ENTITY: _entity_op_sql,
        OpKind.UPDATE_ENTITY: _entity_op_sql,
        OpKind.CREATE_SOURCE: _create_source_sql,
        OpKind.UPDATE_SOURCE: _create_source_sql,
        OpKind.DROP_SOURCE: _create_source_sql,
        OpKind.CREATE_FV: _create_fv_sql,
        OpKind.UPDATE_FV: _create_fv_sql,
        OpKind.RECREATE_FV: _recreate_fv_sql,
        OpKind.DROP_FV: _drop_fv_sql,
        OpKind.CREATE_FG: _entity_op_sql,
        OpKind.DROP_FG: _entity_op_sql,
    }

    for op in plan.ops:
        handler = _dispatch.get(op.kind)
        if handler:
            stmts.extend(handler(op, **ctx))

    return stmts
