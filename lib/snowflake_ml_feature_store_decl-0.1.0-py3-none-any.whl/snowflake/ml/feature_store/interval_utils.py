"""Interval parsing and conversion utilities.

General-purpose functions for parsing interval strings (e.g., ``"1h"``,
``"30 minutes"``, ``"0 seconds"``) into structured representations and
converting them to seconds.  Used by aggregation specs, spec builder,
tile SQL generator, feature views, and the declarative authoring layer
(``decl/compiler.py`` delegates string parsing here).
"""

from __future__ import annotations

import re

LIFETIME_WINDOW = "lifetime"

# Single canonical regex.  The numeric group accepts an optional fractional
# component so that :func:`interval_to_seconds` can support authoring-format
# durations like ``"1.5m"`` while :func:`parse_interval` keeps its
# integer-only contract (the SQL-string-interpolating callers in
# ``tile_sql_generator.py`` rely on integer slice lengths).
_INTERVAL_PATTERN = re.compile(
    r"^\s*(\d+(?:\.\d+)?)\s*"
    r"(s|sec|secs|second|seconds"
    r"|m|min|mins|minute|minutes"
    r"|h|hr|hrs|hour|hours"
    r"|d|day|days"
    r"|w|week|weeks)\s*$",
    re.IGNORECASE,
)

_INTERVAL_UNIT_MAP = {
    "s": "SECOND",
    "sec": "SECOND",
    "secs": "SECOND",
    "second": "SECOND",
    "seconds": "SECOND",
    "m": "MINUTE",
    "min": "MINUTE",
    "mins": "MINUTE",
    "minute": "MINUTE",
    "minutes": "MINUTE",
    "h": "HOUR",
    "hr": "HOUR",
    "hrs": "HOUR",
    "hour": "HOUR",
    "hours": "HOUR",
    "d": "DAY",
    "day": "DAY",
    "days": "DAY",
    "w": "WEEK",
    "week": "WEEK",
    "weeks": "WEEK",
}

_SECONDS_PER_UNIT = {
    "SECOND": 1,
    "MINUTE": 60,
    "HOUR": 3600,
    "DAY": 86400,
    "WEEK": 604800,
}


def is_lifetime_window(window: str) -> bool:
    """Check if a window string represents a lifetime aggregation.

    Args:
        window: The window string to check.

    Returns:
        True if the window is "lifetime", False otherwise.
    """
    return window.lower().strip() == LIFETIME_WINDOW


def _match_interval(interval: str) -> tuple[float, str]:
    """Parse an interval string into ``(numeric_value, snowflake_unit)``.

    Internal helper shared by :func:`parse_interval` and
    :func:`interval_to_seconds`.  Returns the numeric value as ``float`` so
    callers can decide whether to enforce integer-only inputs (the case for
    ``parse_interval``) or accept fractional values (the case for
    ``interval_to_seconds``).

    Args:
        interval: Interval string like ``"1h"``, ``"24 hours"``,
            ``"0 seconds"``, ``"1w"``, or ``"1.5m"``.

    Returns:
        Tuple of ``(numeric_value, snowflake_unit)`` e.g. ``(1.0, "HOUR")``.

    Raises:
        ValueError: If the interval format is invalid or the value is
            negative.
    """
    match = _INTERVAL_PATTERN.match(interval)
    if not match:
        raise ValueError(
            f"Invalid interval format: '{interval}'. "
            f"Expected format: '<number> <unit>' where unit is one of: "
            f"seconds, minutes, hours, days, weeks (or abbreviations s, m, h, d, w)"
        )

    value = float(match.group(1))
    unit_str = match.group(2).lower()
    unit = _INTERVAL_UNIT_MAP[unit_str]

    if value < 0:
        raise ValueError(f"Interval value must be non-negative, got: {value}")

    return value, unit


def parse_interval(interval: str) -> tuple[int, str]:
    """Parse an interval string into ``(value, unit)`` tuple.

    This function is intentionally agnostic about whether zero is valid —
    callers that require positive intervals (e.g., aggregation windows)
    should enforce that constraint themselves.

    Fractional values (``"1.5m"``) are rejected here so the SQL-string-
    interpolating callers in ``tile_sql_generator.py`` always emit integer
    slice lengths into Snowflake ``TIME_SLICE``.  Use
    :func:`interval_to_seconds` if you need fractional support.

    Args:
        interval: Interval string like ``"1h"``, ``"24 hours"``,
            ``"0 seconds"``, or ``"1w"``.  ``"lifetime"`` is NOT a valid
            interval — use :func:`is_lifetime_window` first.

    Returns:
        Tuple of (numeric_value, snowflake_unit) e.g. ``(1, "HOUR")``.

    Raises:
        ValueError: If the interval format is invalid, the value is
            negative, or the value has a fractional component.
    """
    if is_lifetime_window(interval):
        raise ValueError(f"'{interval}' is not a numeric interval.")

    value, unit = _match_interval(interval)

    if value != int(value):
        raise ValueError(
            f"Fractional intervals are not supported here, got: '{interval}'. "
            f"Use snowflake.ml.feature_store.interval_utils.interval_to_seconds "
            f"for fractional support."
        )

    return int(value), unit


def interval_to_seconds(interval: str) -> int:
    """Convert an interval string to total seconds.

    Accepts every shape :func:`parse_interval` accepts, plus fractional
    values (``"1.5m"`` → 90; truncated via ``int()``) and the
    ``"lifetime"`` sentinel (``-1``).  This is the canonical duration
    parser shared between the imperative aggregation layer and the
    declarative authoring layer.

    Args:
        interval: Interval string like ``"1h"``, ``"24 hours"``, ``"1w"``,
            or ``"1.5m"``.  ``"lifetime"`` returns ``-1`` as a sentinel
            value.

    Returns:
        Total seconds represented by the interval, or ``-1`` for lifetime.
    """
    if is_lifetime_window(interval):
        return -1
    value, unit = _match_interval(interval)
    return int(value * _SECONDS_PER_UNIT[unit])


def format_interval_for_snowflake(interval: str) -> str:
    """Format an interval string for use in Snowflake SQL.

    Fractional intervals are rejected by :func:`parse_interval` (and
    therefore by this function); use :func:`interval_to_seconds` if
    fractional support is needed.

    Args:
        interval: Interval string like ``"1h"``, ``"24 hours"``, or ``"1w"``.

    Returns:
        Snowflake unit string like ``"HOUR"``, ``"DAY"``, or ``"WEEK"``.
    """
    _, unit = parse_interval(interval)
    return unit
