from __future__ import annotations


def hello_function(name: str) -> str:
    return f"Hello {name}!"
